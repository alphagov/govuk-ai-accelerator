"""
Error collection utilities for all engines.

Provides ErrorCollector class for collecting and managing errors during processing.
"""


class ErrorCollector:
    """
    Collects and manages errors during processing.

    Allows non-failing error collection for reporting and analysis.
    Errors are collected with type, message, severity, and optional field information.
    """

    def __init__(self):
        """Initialize empty error collector."""
        self._errors: list[dict[str, object]] = []
        self._validation_errors: list[dict[str, object]] = []

        assert isinstance(self._errors, list), "Errors must be initialized as list"
        assert isinstance(self._validation_errors, list), (
            "Validation errors must be initialized as list"
        )

    def add_error(
        self,
        error_type: str,
        message: str,
        severity: str = "error",
        **kwargs: object,
    ) -> None:
        """
        Add an error to the collection.

        Args:
            error_type: Type/category of error (e.g., "llm_error", "validation_error")
            message: Human-readable error message
            severity: Error severity level ("error", "warning", "info")
            **kwargs: Additional error metadata
        """
        assert isinstance(error_type, str), "Error type must be a string"
        assert isinstance(message, str), "Message must be a string"

        error = {
            "type": error_type,
            "message": message,
            "severity": severity,
            **kwargs,
        }
        self._errors.append(error)

    def add_validation_error(
        self,
        message: str,
        field: str | None = None,
        severity: str = "error",
        **kwargs: object,
    ) -> None:
        """
        Add a validation error to the collection.

        Args:
            message: Human-readable validation error message
            field: Optional field name that failed validation
            severity: Error severity level ("error", "warning", "info")
            **kwargs: Additional error metadata
        """
        assert isinstance(message, str), "Message must be a string"
        assert field is None or isinstance(field, str), "Field must be None or string"

        error = {
            "type": "validation_error",
            "message": message,
            "severity": severity,
            "field": field,
            **kwargs,
        }
        self._validation_errors.append(error)
        # Also add to main errors list
        self._errors.append(error)

    def add_config_error(
        self,
        message: str,
        config_path: str | None = None,
        **kwargs: object,
    ) -> None:
        """
        Add a configuration error to the collection.

        Args:
            message: Human-readable configuration error message
            config_path: Optional path to the configuration file that caused the error
            **kwargs: Additional error metadata
        """
        assert isinstance(message, str), "Message must be a string"
        assert config_path is None or isinstance(config_path, str), (
            "Config path must be None or string"
        )

        error = {
            "type": "config_error",
            "message": message,
            "severity": "error",
            "config_path": config_path,
            **kwargs,
        }
        self._errors.append(error)

    @property
    def errors(self) -> list[dict[str, object]]:
        """
        Get all collected errors.

        Returns:
            List of error dictionaries
        """
        assert isinstance(self._errors, list), "Errors must be a list"
        assert all(isinstance(e, dict) for e in self._errors), "All errors must be dictionaries"

        return self._errors.copy()

    @property
    def validation_errors(self) -> list[dict[str, object]]:
        """
        Get all validation errors.

        Returns:
            List of validation error dictionaries
        """
        assert isinstance(self._validation_errors, list), "Validation errors must be a list"
        assert len(self._validation_errors) <= len(self._errors), (
            "Validation errors must be subset of all errors"
        )

        return self._validation_errors.copy()

    def to_list(self) -> list[dict[str, object]]:
        """
        Convert errors to list format (alias for errors property).

        Returns:
            List of error dictionaries
        """
        assert isinstance(self._errors, list), "Errors must be a list"
        assert hasattr(self, "errors"), "Errors property must be defined"

        return self.errors

    def has_errors(self) -> bool:
        """
        Check if any errors have been collected.

        Returns:
            True if errors exist, False otherwise
        """
        assert isinstance(self._errors, list), "Errors must be a list"
        assert len(self._errors) >= 0, "Error count must be non-negative"

        return len(self._errors) > 0

    def has_validation_errors(self) -> bool:
        """
        Check if any validation errors have been collected.

        Returns:
            True if validation errors exist, False otherwise
        """
        assert isinstance(self._validation_errors, list), "Validation errors must be a list"
        assert len(self._validation_errors) >= 0, "Validation error count must be non-negative"

        return len(self._validation_errors) > 0

    def clear(self) -> None:
        """Clear all collected errors."""
        assert isinstance(self._errors, list), "Errors must be a list"
        assert isinstance(self._validation_errors, list), "Validation errors must be a list"

        self._errors.clear()
        self._validation_errors.clear()

    def __len__(self) -> int:
        """Return number of errors collected."""
        assert isinstance(self._errors, list), "Errors must be a list"
        assert len(self._errors) >= 0, "Error count must be non-negative"

        return len(self._errors)

    def __bool__(self) -> bool:
        """Return True if errors exist."""
        assert isinstance(self._errors, list), "Errors must be a list"
        assert hasattr(self, "has_errors"), "has_errors method must be defined"

        return self.has_errors()
