"""Domain utilities for listing and discovering domain folders."""

from pathlib import Path

import fsspec


def list_available_domains(base_dir: Path | None = None) -> list[str]:
    """
    List all available domain folders in the domains/ directory.

    A valid domain folder must:
    - Be a directory
    - Contain an 'input/' subdirectory

    Searches in: {base_dir}/domains/

    Args:
        base_dir: Base directory to search for domains (defaults to current directory)

    Returns:
        List of domain names (folder names)

    Examples:
        >>> from pathlib import Path
        >>> import tempfile
        >>> with tempfile.TemporaryDirectory() as tmpdir:
        ...     base = Path(tmpdir)
        ...     (base / "domains" / "travel" / "input").mkdir(parents=True)
        ...     (base / "domains" / "healthcare" / "input").mkdir(parents=True)
        ...     (base / "domains" / "invalid").mkdir()  # No input folder
        ...     domains = list_available_domains(base)
        ...     sorted(domains)
        ['healthcare', 'travel']
    """
    assert base_dir is None or isinstance(base_dir, Path), "Base dir must be Path or None"

    fs = fsspec.filesystem("file")
    search_dir = base_dir if base_dir is not None else Path.cwd()
    assert fs.exists(str(search_dir)), f"Search directory does not exist: {search_dir}"

    domains = []
    domains_folder = search_dir / "domains"

    if fs.exists(str(domains_folder)) and fs.isdir(str(domains_folder)):
        for item in domains_folder.iterdir():
            if fs.isdir(str(item)) and fs.isdir(str(item / "input")):
                domains.append(item.name)

    return sorted(domains)
