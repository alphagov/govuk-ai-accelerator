"""
Common logging utilities for all engines.

Provides configurable logging with support for:
- Rich console output (default)
- JSON structured logging
- Simple text logging
- Progress bars for long-running operations
- Colorful emoji-rich output for better UX
"""

import logging
import sys
import traceback

from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn


class RichLogger:
    """
    Wrapper around Rich console for consistent logging across all engines.

    Provides styled output methods and progress bar support for better UX
    during long-running operations with colorful emoji-rich formatting.
    """

    def __init__(self, show_progress: bool = True, log_level: str = "INFO") -> None:
        """
        Initialize Rich logger.

        Args:
            show_progress: Whether to enable progress bar support
            log_level: Logging level (DEBUG, INFO, WARNING, ERROR)
        """
        assert isinstance(show_progress, bool), "show_progress must be a boolean"
        assert isinstance(log_level, str), "log_level must be a string"

        self.console: Console = Console(force_terminal=True, color_system="auto")
        self.show_progress: bool = show_progress
        self._progress: Progress | None = None
        # Map log level strings to logging constants (NASA01: avoid getattr)
        level_map = {
            "DEBUG": logging.DEBUG,
            "INFO": logging.INFO,
            "WARNING": logging.WARNING,
            "ERROR": logging.ERROR,
            "CRITICAL": logging.CRITICAL,
        }
        self.log_level: int = level_map.get(log_level.upper(), logging.INFO)

    def print(self, message: str, style: str = "") -> None:
        """
        Print a message with optional style.

        Args:
            message: Message to print
            style: Optional Rich style string (e.g., "bold red")
        """
        assert isinstance(message, str), "Message must be a string"
        assert isinstance(style, str), "Style must be a string"

        self.console.print(message, style=style)

    def error(self, message: str, exc_info: bool | BaseException | None = False) -> None:
        """
        Print an error message in red with error emoji.

        Args:
            message: Error message to display
            exc_info: If True or an exception, include exception traceback
        """
        assert isinstance(message, str), "Message must be a string"
        assert exc_info is None or isinstance(exc_info, bool | BaseException), (
            "exc_info must be None, bool, or BaseException"
        )

        self.console.print(f"[bold red]❌ {message}[/bold red]")
        if exc_info:
            if isinstance(exc_info, BaseException):
                self.console.print(
                    f"[red]{''.join(traceback.format_exception(type(exc_info), exc_info, exc_info.__traceback__))}[/red]"
                )
            else:
                self.console.print(f"[red]{traceback.format_exc()}[/red]")

    def exception(self, message: str, exc_info: bool = True) -> None:
        """
        Log an exception with traceback (standard Python logging interface).

        Args:
            message: Exception message to display
            exc_info: If True, include exception traceback (default: True)
        """
        assert isinstance(message, str), "Message must be a string"
        assert isinstance(exc_info, bool), "exc_info must be a boolean"

        self.error(message, exc_info=exc_info)

    def success(self, message: str) -> None:
        """
        Print a success message in green with checkmark emoji.

        Args:
            message: Success message to display
        """
        assert isinstance(message, str), "Message must be a string"
        assert len(message) > 0, "Message must not be empty"

        self.console.print(f"[bold green]✅ {message}[/bold green]")

    def warning(self, message: str, exc_info: bool = False) -> None:
        """
        Print a warning message in yellow with warning emoji.

        Args:
            message: Warning message to display
            exc_info: If True, include exception traceback
        """
        assert isinstance(message, str), "Message must be a string"
        assert isinstance(exc_info, bool), "exc_info must be a boolean"

        self.console.print(f"[bold yellow]⚠️  {message}[/bold yellow]")
        if exc_info:
            self.console.print(f"[yellow]{traceback.format_exc()}[/yellow]")

    def info(self, message: str) -> None:
        """
        Print an info message in bright cyan with info emoji.

        Args:
            message: Info message to display
        """
        assert isinstance(message, str), "Message must be a string"
        assert len(message) > 0, "Message must not be empty"

        self.console.print(f"[bright_cyan]ℹ️  {message}[/bright_cyan]")  # noqa: RUF001

    def dim(self, message: str) -> None:
        """
        Print a dimmed message (only at DEBUG level).

        Args:
            message: Message to display in dimmed style
        """
        assert isinstance(message, str), "Message must be a string"
        assert len(message) > 0, "Message must not be empty"

        if self.log_level <= logging.DEBUG:
            self.console.print(f"[dim]{message}[/dim]")

    def debug(self, message: str) -> None:
        """
        Print a debug message in dimmed magenta with debug emoji.

        Args:
            message: Debug message to display
        """
        assert isinstance(message, str), "Message must be a string"
        assert len(message) > 0, "Message must not be empty"

        if self.log_level <= logging.DEBUG:
            self.console.print(f"[dim magenta]🔍 DEBUG: {message}[/dim magenta]")

    def stage(self, stage_num: int, total_stages: int, message: str) -> None:
        """
        Print a stage progress message with rocket emoji.

        Args:
            stage_num: Current stage number
            total_stages: Total number of stages
            message: Stage description
        """
        assert isinstance(stage_num, int), "stage_num must be an integer"
        assert isinstance(total_stages, int), "total_stages must be an integer"
        assert stage_num > 0, "stage_num must be positive"
        assert total_stages > 0, "total_stages must be positive"

        self.console.print(
            f"[bold bright_cyan]🚀 [{stage_num}/{total_stages}] {message}[/bold bright_cyan]"
        )

    def progress(self, message: str, details: str = "") -> None:
        """
        Print a progress message with hourglass emoji.

        Args:
            message: Progress message
            details: Optional additional details
        """
        assert isinstance(message, str), "Message must be a string"
        assert isinstance(details, str), "Details must be a string"

        if details:
            self.console.print(
                f"[bold bright_blue]⏳ {message}[/bold bright_blue] [bright_white]{details}[/bright_white]"
            )
        else:
            self.console.print(f"[bold bright_blue]⏳ {message}[/bold bright_blue]")

    def complete(self, message: str, stats: str = "") -> None:
        """
        Print a completion message with party emoji.

        Args:
            message: Completion message
            stats: Optional statistics to display
        """
        assert isinstance(message, str), "Message must be a string"
        assert isinstance(stats, str), "Stats must be a string"

        if stats:
            self.console.print(
                f"[bold bright_green]🎉 {message}[/bold bright_green] [bright_white]{stats}[/bright_white]"
            )
        else:
            self.console.print(f"[bold bright_green]🎉 {message}[/bold bright_green]")

    def processing(self, message: str) -> None:
        """
        Print a processing message with gear emoji.

        Args:
            message: Processing message
        """
        assert isinstance(message, str), "Message must be a string"
        assert len(message) > 0, "Message must not be empty"

        self.console.print(f"[bold yellow]⚙️ {message}[/bold yellow]")

    def data(self, message: str) -> None:
        """
        Print a data-related message with database emoji.

        Args:
            message: Data message
        """
        assert isinstance(message, str), "Message must be a string"
        assert len(message) > 0, "Message must not be empty"

        self.console.print(f"[bold bright_blue]💾 {message}[/bold bright_blue]")

    def llm(self, message: str) -> None:
        """
        Print an LLM-related message with brain emoji.

        Args:
            message: LLM message
        """
        assert isinstance(message, str), "Message must be a string"
        assert len(message) > 0, "Message must not be empty"

        self.console.print(f"[bold magenta]🧠 {message}[/bold magenta]")

    def cache(self, message: str) -> None:
        """
        Print a cache-related message with lightning emoji.

        Args:
            message: Cache message
        """
        assert isinstance(message, str), "Message must be a string"
        assert len(message) > 0, "Message must not be empty"

        self.console.print(f"[yellow]⚡ {message}[/yellow]")

    def merge(self, message: str) -> None:
        """
        Print a merge-related message with merge emoji.

        Args:
            message: Merge message
        """
        assert isinstance(message, str), "Message must be a string"
        assert len(message) > 0, "Message must not be empty"

        self.console.print(f"[bold bright_cyan]🔀 {message}[/bold bright_cyan]")

    def dedupe(self, message: str) -> None:
        """
        Print a deduplication message with filter emoji.

        Args:
            message: Deduplication message
        """
        assert isinstance(message, str), "Message must be a string"
        assert len(message) > 0, "Message must not be empty"

        self.console.print(f"[bold bright_green]🔬 {message}[/bold bright_green]")

    def semantic(self, message: str) -> None:
        """
        Print a semantic analysis message with magnifying glass emoji.

        Args:
            message: Semantic message
        """
        assert isinstance(message, str), "Message must be a string"
        assert len(message) > 0, "Message must not be empty"

        self.console.print(f"[bold bright_magenta]🔎 {message}[/bold bright_magenta]")

    def save(self, message: str) -> None:
        """
        Print a save operation message with floppy disk emoji.

        Args:
            message: Save message
        """
        assert isinstance(message, str), "Message must be a string"
        assert len(message) > 0, "Message must not be empty"

        self.console.print(f"[bold bright_green]💿 {message}[/bold bright_green]")

    def load(self, message: str) -> None:
        """
        Print a load operation message with folder emoji.

        Args:
            message: Load message
        """
        assert isinstance(message, str), "Message must be a string"
        assert len(message) > 0, "Message must not be empty"

        self.console.print(f"[bold bright_blue]📂 {message}[/bold bright_blue]")

    def config(self, message: str) -> None:
        """
        Print a configuration message with wrench emoji.

        Args:
            message: Config message
        """
        assert isinstance(message, str), "Message must be a string"
        assert len(message) > 0, "Message must not be empty"

        self.console.print(f"[bold bright_yellow]🔧 {message}[/bold bright_yellow]")

    def stats(self, message: str) -> None:
        """
        Print statistics with chart emoji.

        Args:
            message: Statistics message
        """
        assert isinstance(message, str), "Message must be a string"
        assert len(message) > 0, "Message must not be empty"

        self.console.print(f"[bold bright_blue]📊 {message}[/bold bright_blue]")

    def separator(self, char: str = "=", length: int = 80, style: str = "bright_cyan") -> None:
        """
        Print a separator line.

        Args:
            char: Character to use for separator
            length: Length of separator
            style: Rich style for the separator
        """
        assert isinstance(char, str), "Char must be a string"
        assert isinstance(length, int), "Length must be an integer"
        assert length > 0, "Length must be positive"

        self.console.print(f"[bold {style}]{char * length}[/bold {style}]")

    def banner(self, message: str, emoji: str = "🎯") -> None:
        """
        Print a banner message with custom emoji.

        Args:
            message: Banner message
            emoji: Emoji to use
        """
        assert isinstance(message, str), "Message must be a string"
        assert isinstance(emoji, str), "Emoji must be a string"

        self.console.print("")  # Empty line before
        self.separator("=", 80, "bold bright_cyan")
        self.console.print(
            f"[bold bright_white on bright_blue] {emoji}  {message}  [/bold bright_white on bright_blue]"
        )
        self.separator("=", 80, "bold bright_cyan")
        self.console.print("")  # Empty line after

    def create_progress(self) -> Progress:
        """
        Create a progress bar for long-running operations.

        Returns:
            Progress bar instance

        Note:
            Progress bar is automatically entered as context manager.
            Call close_progress() when done.
        """
        assert self.console is not None, "Console must be initialized"
        assert isinstance(self.show_progress, bool), "show_progress must be a boolean"

        if self._progress is None:
            self._progress = Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=self.console,
            )
            _ = self._progress.__enter__()
        return self._progress

    def close_progress(self) -> None:
        """Close and cleanup the progress bar."""
        assert self._progress is None or isinstance(self._progress, Progress), (
            "Progress must be None or Progress instance"
        )
        assert True, "close_progress will safely cleanup progress bar"

        if self._progress is not None:
            try:
                self._progress.__exit__(None, None, None)
            except Exception:
                pass  # Ignore errors during cleanup
            finally:
                self._progress = None


# Global logger instance (lazy-initialized)
_logger: RichLogger | None = None
_logger_configured = False


def setup_logger(
    config_format: str = "rich", level: str = "INFO", show_progress: bool = True
) -> None:
    """
    Setup logging based on configuration.

    Args:
        config_format: Logging format - "rich", "json", or "simple"
        level: Log level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        show_progress: Whether to enable progress bars

    Raises:
        ValueError: If config_format is invalid
    """
    assert isinstance(config_format, str), "config_format must be a string"
    assert isinstance(level, str), "level must be a string"
    assert isinstance(show_progress, bool), "show_progress must be a boolean"

    global _logger, _logger_configured
    _logger_configured = True

    # Map log level strings to logging constants (NASA01: avoid getattr)
    level_map = {
        "DEBUG": logging.DEBUG,
        "INFO": logging.INFO,
        "WARNING": logging.WARNING,
        "ERROR": logging.ERROR,
        "CRITICAL": logging.CRITICAL,
    }
    log_level_value = level_map.get(level.upper(), logging.INFO)

    if config_format == "rich":
        _logger = RichLogger(show_progress=show_progress)
    elif config_format == "json":
        logging.basicConfig(
            level=log_level_value,
            format='{"time": "%(asctime)s", "level": "%(levelname)s", "message": "%(message)s"}',
            handlers=[logging.StreamHandler(sys.stdout)],
        )
        _logger = None
    elif config_format == "simple":
        logging.basicConfig(
            level=log_level_value,
            format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
            handlers=[logging.StreamHandler(sys.stdout)],
        )
        _logger = None
    else:
        raise ValueError(
            f"Invalid log format: {config_format}. Must be 'rich', 'json', or 'simple'"
        )


def get_logger(log_level: str = "INFO") -> RichLogger:
    """
    Get the configured logger instance.

    Args:
        log_level: Logging level (DEBUG, INFO, WARNING, ERROR) - default INFO

    Returns:
        RichLogger instance

    Note:
        Always returns RichLogger to ensure custom methods (dim, stats, etc.)
        are available. For JSON/simple output, configure the underlying logging
        system and use the standard logging module directly.
    """
    assert isinstance(log_level, str), "log_level must be a string"
    assert len(log_level) > 0, "log_level must not be empty"

    global _logger, _logger_configured
    if _logger is not None:
        return _logger
    # Always use RichLogger to ensure all custom methods are available
    _logger = RichLogger(show_progress=True, log_level=log_level)
    return _logger
