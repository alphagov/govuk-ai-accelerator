"""I/O utilities for all engines."""

from taxonomy_ontology_accelerator.commons.io.file_utils import (
    safe_read_file,
    safe_write_file,
    safe_write_json,
)
from taxonomy_ontology_accelerator.commons.io.fsspec_utils import get_filesystem_from_config

__all__ = [
    "get_filesystem_from_config",
    "safe_read_file",
    "safe_write_file",
    "safe_write_json",
]
