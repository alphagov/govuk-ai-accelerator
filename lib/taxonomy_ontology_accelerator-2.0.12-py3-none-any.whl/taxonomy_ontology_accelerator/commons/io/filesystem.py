"""Clean filesystem interface wrapping fsspec for local and cloud storage."""

import gzip
import json
from pathlib import Path
from typing import Any

import fsspec
from fsspec import AbstractFileSystem


class FileSystem:
    """Clean filesystem interface that works with local and cloud storage.

    Wraps fsspec AbstractFileSystem with automatic Path-to-str conversion
    and a simplified API for common file operations.

    Usage:
        from taxonomy_ontology_accelerator.commons.io.filesystem import fs

        if fs.exists(path):
            content = fs.read_text(path)
            fs.write_json(output_path, data)

        # Custom filesystem (S3, GCS, Azure, etc.)
        s3_fs = FileSystem(fsspec.filesystem("s3"))
        s3_fs.read_text("s3://bucket/file.txt")
    """

    def __init__(self, wrapped_fs: AbstractFileSystem | None = None) -> None:
        assert wrapped_fs is None or isinstance(wrapped_fs, AbstractFileSystem), (
            "wrapped_fs must be an AbstractFileSystem or None"
        )
        self._fs = wrapped_fs or fsspec.filesystem("file")
        assert self._fs is not None, "Filesystem must not be None after initialization"

    @property
    def raw(self) -> AbstractFileSystem:
        """Access the underlying fsspec filesystem for advanced operations."""
        assert self._fs is not None, "Filesystem must not be None"
        assert self._fs.protocol is not None, "Filesystem must be properly initialized"
        return self._fs

    def _to_str(self, path: Path | str) -> str:
        assert path is not None, "Path must not be None"
        assert isinstance(path, str | Path), "Path must be a string or Path object"
        return str(path)

    def exists(self, path: Path | str) -> bool:
        """Check if path exists."""
        assert path is not None, "Path must not be None"
        path_str = self._to_str(path)
        assert isinstance(path_str, str), "Converted path must be a string"
        fs = self._fs
        return fs.exists(path_str)

    def isdir(self, path: Path | str) -> bool:
        """Check if path is a directory."""
        assert path is not None, "Path must not be None"
        path_str = self._to_str(path)
        assert isinstance(path_str, str), "Converted path must be a string"
        return self._fs.isdir(path_str)

    def isfile(self, path: Path | str) -> bool:
        """Check if path is a file."""
        assert path is not None, "Path must not be None"
        path_str = self._to_str(path)
        assert isinstance(path_str, str), "Converted path must be a string"
        return self._fs.isfile(path_str)

    def makedirs(self, path: Path | str, exist_ok: bool = True) -> None:
        """Create directory and any missing parents."""
        assert path is not None, "Path must not be None"
        path_str = self._to_str(path)
        assert isinstance(path_str, str), "Converted path must be a string"
        self._fs.makedirs(path_str, exist_ok=exist_ok)

    def ls(self, path: Path | str) -> list[str]:
        """List directory contents, returning paths as strings."""
        assert path is not None, "Path must not be None"
        path_str = self._to_str(path)
        assert isinstance(path_str, str), "Converted path must be a string"
        return self._fs.ls(path_str, detail=False)

    def rm(self, path: Path | str, recursive: bool = False) -> None:
        """Remove a file or directory."""
        assert path is not None, "Path must not be None"
        path_str = self._to_str(path)
        assert isinstance(path_str, str), "Converted path must be a string"
        self._fs.rm(path_str, recursive=recursive)

    def read_text(self, path: Path | str, encoding: str = "utf-8") -> str:
        """Read text file contents.

        Supports gzip-compressed files (detected by .gz extension).
        """
        assert path is not None, "Path must not be None"
        assert isinstance(encoding, str), "Encoding must be a string"

        path_str = self._to_str(path)
        fs = self._fs
        if not fs.exists(path_str):
            raise FileNotFoundError(f"File not found: {path_str}")

        if path_str.endswith(".gz"):
            with self._fs.open(path_str, "rb") as f, gzip.open(f, "rt", encoding=encoding) as gz:  # pyright: ignore[reportCallIssue,reportArgumentType]
                return gz.read()

        with self._fs.open(path_str, "r", encoding=encoding) as f:
            return f.read()

    def write_text(self, path: Path | str, content: str, encoding: str = "utf-8") -> None:
        """Write text content to file. Creates parent directories if needed."""
        assert path is not None, "Path must not be None"
        assert content is not None, "Content must not be None"

        path_str = self._to_str(path)
        self._fs.makedirs(self._fs._parent(path_str), exist_ok=True)
        with self._fs.open(path_str, "w", encoding=encoding) as f:
            f.write(content)

    def read_json(self, path: Path | str, encoding: str = "utf-8") -> Any:
        """Read and parse JSON file."""
        assert path is not None, "Path must not be None"
        assert isinstance(encoding, str), "Encoding must be a string"

        content = self.read_text(path, encoding=encoding)
        return json.loads(content)

    def write_json(
        self,
        path: Path | str,
        data: dict[str, Any] | list[Any],
        pretty: bool = False,
        encoding: str = "utf-8",
        compress: bool = False,
    ) -> None:
        """Write JSON data to file. Creates parent directories if needed.

        Supports optional gzip compression.
        """
        assert path is not None, "Path must not be None"
        assert data is not None, "Data must not be None"

        path_str = self._to_str(path)
        if compress and not path_str.endswith(".gz"):
            path_str = path_str + ".gz"

        self._fs.makedirs(self._fs._parent(path_str), exist_ok=True)
        json_str = json.dumps(data, indent=2 if pretty else None, ensure_ascii=False)

        if compress:
            json_bytes = json_str.encode(encoding)
            with self._fs.open(path_str, "wb") as f, gzip.open(f, "wb") as gz:  # pyright: ignore[reportCallIssue,reportArgumentType]
                gz.write(json_bytes)
        else:
            with self._fs.open(path_str, "w", encoding=encoding) as f:
                f.write(json_str)

    def write_jsonl(
        self,
        path: Path | str,
        records: list[dict[str, Any]] | tuple[dict[str, Any], ...],
        encoding: str = "utf-8",
    ) -> None:
        """Write JSONL (JSON Lines) data to file. One JSON object per line."""
        assert path is not None, "Path must not be None"
        assert records is not None, "Records must not be None"

        path_str = self._to_str(path)
        self._fs.makedirs(self._fs._parent(path_str), exist_ok=True)
        with self._fs.open(path_str, "w", encoding=encoding) as f:
            for record in records:
                f.write(json.dumps(record, ensure_ascii=False) + "\n")

    def open(self, path: Path | str, mode: str = "r", **kwargs: Any) -> Any:
        """Open a file, returning a file-like object.

        For advanced use cases not covered by read_text/write_text.
        """
        assert path is not None, "Path must not be None"
        assert isinstance(mode, str), "Mode must be a string"

        path_str = self._to_str(path)
        return self._fs.open(path_str, mode, **kwargs)

    def parent(self, path: Path | str) -> str:
        """Get parent directory path."""
        assert path is not None, "Path must not be None"
        path_str = self._to_str(path)
        assert isinstance(path_str, str), "Converted path must be a string"
        return self._fs._parent(path_str)


fs = FileSystem()
