"""Safe file I/O utilities for all engines."""

import os
from pathlib import Path
from typing import Any

from fsspec import AbstractFileSystem

from taxonomy_ontology_accelerator.commons.io.fsspec_utils import (
    safe_read_file_fsspec,
    safe_write_file_fsspec,
    safe_write_json_fsspec,
    safe_write_jsonl_fsspec,
)
from taxonomy_ontology_accelerator.commons.utils.logger import get_logger

logger = get_logger()

_CLOUD_PROTOCOLS = ("s3", "gs", "gcs", "az", "hdfs")


def _extract_cloud_protocol(path_str: str) -> str | None:
    """Return the cloud protocol prefix for a URI-like path."""
    assert path_str is not None, "path_str must not be None"
    for protocol in _CLOUD_PROTOCOLS:
        if path_str.startswith(f"{protocol}://") or path_str.startswith(f"{protocol}::"):
            return protocol
    return None


def join_path(base: str | Path, *parts: str) -> str | Path:
    assert base is not None, "base must not be None"
    assert all(isinstance(part, str) for part in parts), "parts must be strings"

    if isinstance(base, str):
        normalized_parts = [part.strip("/") for part in parts if part]
        if not normalized_parts:
            return base.rstrip("/")
        return f"{base.rstrip('/')}/{'/'.join(normalized_parts)}"

    result = base
    for part in parts:
        if part:
            result = result / part
    return result


def normalize_path(file_path: str | Path) -> Path | str:
    """
    Normalize file path for consistent handling.

    For local paths: Expands ~ and resolves to absolute path.
    For cloud paths (s3://, gs://, az://): Returns unchanged.

    Args:
        file_path: File path as string or Path object

    Returns:
        Path object for local paths, string for cloud paths

    Examples:
        >>> normalize_path("~/data/file.json")
        Path('/home/user/data/file.json')
        >>> normalize_path("s3://bucket/file.json")
        's3://bucket/file.json'
    """
    assert file_path is not None, "File path must not be None"
    assert isinstance(file_path, str | Path), "File path must be string or Path"

    file_path_str = str(file_path)

    # Cloud paths - return unchanged
    if any(file_path_str.startswith(f"{proto}://") for proto in ["s3", "gs", "gcs", "az", "hdfs"]):
        return file_path_str

    # Local paths - normalize using os.path (no Path methods)
    expanded = os.path.expanduser(file_path_str)
    return Path(os.path.abspath(expanded))


def canonicalize_listed_path(listed_path: str | Path, reference_path: str | Path) -> str:
    """
    Restore a cloud protocol stripped by fsspec listing APIs.

    For local paths this is a no-op. For cloud paths, if the discovered path has
    no explicit protocol but the reference path does, prepend the reference
    protocol so downstream code receives a canonical URI.
    """
    assert listed_path is not None, "listed_path must not be None"
    assert reference_path is not None, "reference_path must not be None"

    listed_str = str(listed_path)
    reference_str = str(reference_path)

    if _extract_cloud_protocol(listed_str):
        return listed_str

    reference_protocol = _extract_cloud_protocol(reference_str)
    if reference_protocol is None:
        return listed_str

    return f"{reference_protocol}://{listed_str.lstrip('/')}"


def safe_read_file(
    file_path: str | Path, fs: AbstractFileSystem | None = None, encoding: str = "utf-8"
) -> str:
    """
    Safely read file contents with error handling.
    Supports both regular and gzip-compressed files.

    Always uses fsspec for unified file operations across all storage backends.

    Args:
        file_path: Path to file to read
        fs: Optional filesystem instance (defaults to LocalFileSystem)
        encoding: File encoding (default: utf-8)

    Returns:
        File contents as string

    Raises:
        FileNotFoundError: If file doesn't exist
        IOError: If file cannot be read
    """
    assert file_path is not None, "File path must not be None"
    assert isinstance(encoding, str), "Encoding must be a string"

    return safe_read_file_fsspec(str(file_path), fs=fs, encoding=encoding)


def safe_write_json(
    file_path: str | Path,
    data: dict[str, Any] | list[Any],  # pyright: ignore[reportExplicitAny]
    fs: AbstractFileSystem | None = None,
    pretty: bool = False,
    encoding: str = "utf-8",
    compress: bool = False,
) -> None:
    """
    Safely write JSON with atomic temp file + rename.

    Uses atomic write pattern (temp file + rename) to prevent corruption.
    Creates parent directories if needed. Supports gzip compression.
    Always uses fsspec for unified file operations across all storage backends.

    Args:
        file_path: Path to file to write
        data: Data to write (dict or list)
        fs: Optional filesystem instance (defaults to LocalFileSystem)
        pretty: If True, format JSON with indentation (default: False)
        encoding: File encoding (default: utf-8)
        compress: If True, compress output with gzip (default: False)

    Raises:
        IOError: If file cannot be written
        TypeError: If data cannot be serialized to JSON
    """
    assert file_path is not None, "File path must not be None"
    assert data is not None, "Data must not be None"
    assert isinstance(data, dict | list), "Data must be dict or list"

    return safe_write_json_fsspec(
        str(file_path), data, fs=fs, pretty=pretty, encoding=encoding, compress=compress
    )


def safe_write_file(
    file_path: str | Path,
    content: str,
    fs: AbstractFileSystem | None = None,
    encoding: str = "utf-8",
) -> None:
    """
    Safely write text content to file with error handling.

    Creates parent directories if they don't exist.
    Always uses fsspec for unified file operations across all storage backends.

    Args:
        file_path: Path to file to write
        content: Text content to write
        fs: Optional filesystem instance (defaults to LocalFileSystem)
        encoding: File encoding (default: utf-8)

    Raises:
        IOError: If file cannot be written
    """
    assert file_path is not None, "File path must not be None"
    assert content is not None, "Content must not be None"
    assert isinstance(content, str), "Content must be a string"

    return safe_write_file_fsspec(str(file_path), content, fs=fs, encoding=encoding)


def safe_write_jsonl(
    file_path: str | Path,
    records: list[dict[str, Any]],  # pyright: ignore[reportExplicitAny]
    fs: AbstractFileSystem | None = None,
    encoding: str = "utf-8",
) -> None:
    """
    Safely write JSONL (JSON Lines) data to file.

    Writes one JSON object per line. Creates parent directories if needed.
    Always uses fsspec for unified file operations across all storage backends.

    Args:
        file_path: Path to file to write
        records: List of records to write (one JSON object per line)
        fs: Optional filesystem instance (defaults to LocalFileSystem)
        encoding: File encoding (default: utf-8)

    Raises:
        IOError: If file cannot be written
        TypeError: If records cannot be serialized to JSON
    """
    assert file_path is not None, "File path must not be None"
    assert records is not None, "Records must not be None"
    assert isinstance(records, list), "Records must be a list"

    return safe_write_jsonl_fsspec(str(file_path), records, fs=fs, encoding=encoding)
