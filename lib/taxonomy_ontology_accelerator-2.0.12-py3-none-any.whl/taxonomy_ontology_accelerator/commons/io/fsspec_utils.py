"""
Filesystem operations using fsspec for cloud and local storage.

Provides unified interface for file operations across different storage backends.
"""

import gzip
import json
from pathlib import Path
from typing import Any

import fsspec
from fsspec import AbstractFileSystem
from fsspec.implementations.local import LocalFileSystem

from taxonomy_ontology_accelerator.commons.utils.logger import get_logger

logger = get_logger()


def get_default_filesystem() -> AbstractFileSystem:
    """
    Get default local filesystem instance using fsspec.

    Returns:
        LocalFileSystem instance
    """
    fs = LocalFileSystem()
    assert fs is not None, "Filesystem must not be None"
    assert isinstance(fs, AbstractFileSystem), "Must be an AbstractFileSystem instance"
    return fs


def find_project_root(start_path: Path, fs: AbstractFileSystem | None = None) -> Path:
    """
    Find project root by searching upward for markers like pyproject.toml or .git.

    Args:
        start_path: Starting directory path
        fs: Filesystem instance (defaults to local filesystem)

    Returns:
        Path to project root

    Raises:
        FileNotFoundError: If no project root markers found
    """
    assert start_path is not None, "start_path must not be None"
    assert isinstance(start_path, Path), "start_path must be a Path object"

    if fs is None:
        fs = get_default_filesystem()

    # Convert to string for fsspec operations (use str() instead of Path methods)
    current_str = str(start_path)
    # Make absolute if relative
    if not current_str.startswith("/"):
        import os

        current_str = str(Path(os.getcwd()) / start_path)

    markers = ["pyproject.toml", ".git", "setup.py", "setup.cfg"]

    # Search upward for project markers (bounded by max_depth to satisfy NASA02)
    max_depth = 20  # Reasonable max directory depth
    for _ in range(max_depth):
        for marker in markers:
            marker_path = f"{current_str}/{marker}"
            if fs.exists(marker_path):
                return Path(current_str)

        # Move to parent directory using fsspec's _parent method
        parent_str = fs._parent(current_str)

        if parent_str in (current_str, ""):
            # Reached filesystem root
            raise FileNotFoundError(f"No project root found from {start_path}")

        current_str = parent_str

    # Max depth reached without finding project root
    raise FileNotFoundError(f"No project root found from {start_path} within {max_depth} levels")


def get_filesystem_from_config(
    protocol: str = "local", options: dict[str, Any] | None = None
) -> AbstractFileSystem:
    """
    Create filesystem instance from configuration.

    Supports: local, s3 (s3fs), gcs (gcsfs), az (adlfs), hdfs, and more.

    Args:
        protocol: Filesystem protocol (local, s3, gcs, az, hdfs, etc.)
        options: Protocol-specific options (credentials, regions, etc.)

    Returns:
        Filesystem instance for the specified protocol

    Raises:
        ImportError: If required fsspec implementation is not installed
        ValueError: If protocol configuration is invalid
    """
    assert protocol is not None, "Protocol must not be None"
    assert isinstance(protocol, str), "Protocol must be a string"

    if options is None:
        options = {}

    try:
        fs = fsspec.filesystem(protocol, **options)
    except ImportError as e:
        msg = (
            f"Failed to create {protocol} filesystem: {e}\n"
            f"Install required package: pip install s3fs/gcsfs/adlfs"
        )
        logger.error(msg)
        raise ImportError(msg) from e
    except Exception as e:
        msg = f"Failed to create {protocol} filesystem with options {options}: {e}"
        logger.error(msg)
        raise ValueError(msg) from e

    assert fs is not None, "Filesystem must not be None"
    assert isinstance(fs, AbstractFileSystem), "Must be an AbstractFileSystem instance"
    return fs


def safe_read_file_fsspec(
    file_path: str, fs: AbstractFileSystem | None = None, encoding: str = "utf-8"
) -> str:
    """
    Safely read file contents using fsspec with error handling.
    Supports both regular and gzip-compressed files.

    Args:
        file_path: Path to file to read
        fs: Filesystem instance (defaults to local filesystem)
        encoding: File encoding (default: utf-8)

    Returns:
        File contents as string

    Raises:
        FileNotFoundError: If file doesn't exist
        OSError: If file cannot be read
    """
    assert file_path is not None, "File path must not be None"
    assert isinstance(file_path, str), "File path must be a string"

    if fs is None:
        fs = get_default_filesystem()

    if not fs.exists(file_path):
        raise FileNotFoundError(f"File not found: {file_path}")

    try:
        # Check if file is compressed
        if file_path.endswith(".gz"):
            with fs.open(file_path, "rb") as f, gzip.open(f, "rt", encoding=encoding) as gz:  # pyright: ignore[reportCallIssue,reportArgumentType]
                content = gz.read()
        else:
            with fs.open(file_path, "r", encoding=encoding) as f:
                content = f.read()
        return content
    except OSError as e:
        logger.error(f"Failed to read file {file_path}: {e}")
        raise OSError(f"Failed to read file {file_path}: {e}") from e


def safe_write_file_fsspec(
    file_path: str, content: str, fs: AbstractFileSystem | None = None, encoding: str = "utf-8"
) -> None:
    """
    Safely write text content to file using fsspec.

    Args:
        file_path: Path to file to write
        content: Text content to write
        fs: Filesystem instance (defaults to local filesystem)
        encoding: File encoding (default: utf-8)

    Raises:
        OSError: If file cannot be written
    """
    assert file_path is not None, "File path must not be None"
    assert content is not None, "Content must not be None"

    if fs is None:
        fs = get_default_filesystem()

    try:
        fs.makedirs(fs._parent(file_path), exist_ok=True)
        with fs.open(file_path, "w", encoding=encoding) as f:
            f.write(content)
        logger.debug(f"Successfully wrote file {file_path}")
    except OSError as e:
        logger.error(f"Failed to write file {file_path}: {e}")
        raise OSError(f"Failed to write file {file_path}: {e}") from e


def safe_write_json_fsspec(
    file_path: str,
    data: dict[str, Any] | list[Any],
    fs: AbstractFileSystem | None = None,
    pretty: bool = False,
    encoding: str = "utf-8",
    compress: bool = False,
) -> None:
    """
    Safely write JSON data to file using fsspec.

    Args:
        file_path: Path to file to write
        data: Data to write (dict or list)
        fs: Filesystem instance (defaults to local filesystem)
        pretty: If True, format JSON with indentation (default: False)
        encoding: File encoding (default: utf-8)
        compress: If True, compress output with gzip (default: False)

    Raises:
        OSError: If file cannot be written
        TypeError: If data cannot be serialized to JSON
    """
    assert file_path is not None, "File path must not be None"
    assert data is not None, "Data must not be None"

    if fs is None:
        fs = get_default_filesystem()

    if compress and not file_path.endswith(".gz"):
        file_path = file_path + ".gz"

    try:
        fs.makedirs(fs._parent(file_path), exist_ok=True)

        json_str = json.dumps(data, indent=2 if pretty else None, ensure_ascii=False)

        if compress:
            json_bytes = json_str.encode(encoding)
            with fs.open(file_path, "wb") as f, gzip.open(f, "wb") as gz:  # pyright: ignore[reportCallIssue,reportArgumentType]
                gz.write(json_bytes)
            logger.debug(f"Successfully wrote compressed JSON to {file_path}")
        else:
            with fs.open(file_path, "w", encoding=encoding) as f:
                f.write(json_str)
            logger.debug(f"Successfully wrote JSON to {file_path}")
    except OSError as e:
        logger.error(f"Failed to write JSON file {file_path}: {e}")
        raise OSError(f"Failed to write JSON file {file_path}: {e}") from e


def safe_write_jsonl_fsspec(
    file_path: str,
    records: list[dict[str, Any]] | tuple[dict[str, Any], ...],
    fs: AbstractFileSystem | None = None,
    encoding: str = "utf-8",
) -> None:
    """
    Safely write JSONL (JSON Lines) data to file using fsspec.

    Streams records one at a time to minimize memory usage.

    Args:
        file_path: Path to file to write
        records: Iterable of records to write (one JSON object per line)
        fs: Filesystem instance (defaults to local filesystem)
        encoding: File encoding (default: utf-8)

    Raises:
        OSError: If file cannot be written
        TypeError: If records cannot be serialized to JSON
    """
    assert file_path is not None, "File path must not be None"
    assert records is not None, "Records must not be None"

    if fs is None:
        fs = get_default_filesystem()

    try:
        fs.makedirs(fs._parent(file_path), exist_ok=True)

        count = 0
        with fs.open(file_path, "w", encoding=encoding) as f:
            for record in records:
                json_line = json.dumps(record, ensure_ascii=False)
                f.write(json_line + "\n")
                count += 1

        logger.debug(f"Successfully wrote {count} records to JSONL file {file_path}")
    except OSError as e:
        logger.error(f"Failed to write JSONL file {file_path}: {e}")
        raise OSError(f"Failed to write JSONL file {file_path}: {e}") from e
