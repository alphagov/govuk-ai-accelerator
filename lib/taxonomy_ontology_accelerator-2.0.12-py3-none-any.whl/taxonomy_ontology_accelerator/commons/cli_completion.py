"""CLI autocomplete utilities for domain selection."""

import sys
from pathlib import Path

from taxonomy_ontology_accelerator.commons.utils.domain_utils import list_available_domains


def complete_domain(incomplete: str) -> list[str]:
    """
    Typer autocomplete callback for domain parameter.

    Lists all available domain folders in the current directory.
    A valid domain folder must contain an 'input/' subdirectory.

    Args:
        incomplete: Partial domain name being typed

    Returns:
        List of matching domain names

    Examples:
        >>> complete_domain("")
        ['finance', 'healthcare', 'travel']
        >>> complete_domain("hea")
        ['healthcare']
    """
    assert incomplete is not None, "Incomplete string must not be None"
    assert isinstance(incomplete, str), "Incomplete must be a string"

    domains = list_available_domains(Path.cwd())
    return [d for d in domains if d.startswith(incomplete)]


def prompt_for_domain(*, _test_default: str | None = None) -> str:
    """Interactively prompt user to select a domain from available domains."""
    assert sys.stdout.isatty() or not sys.stdout.isatty(), "stdout must be defined"
    assert _test_default is None or isinstance(_test_default, str), (
        "Test default must be string or None"
    )

    domains = list_available_domains(Path.cwd())
    assert isinstance(domains, list), "Domains must be a list"

    if not domains:
        raise ValueError(
            "No domain folders found in current directory.\n"
            "Run 'toa init --domain <name>' to create a domain folder first.\n"
            "Example: toa init --domain travel"
        )

    if not sys.stdout.isatty():
        raise ValueError(
            "Domain parameter required in non-interactive mode.\n"
            f"Available domains: {', '.join(domains)}\n"
            "Usage: toa <command> --domain <name>"
        )

    # Return test default if provided (testing only)
    if _test_default is not None:
        assert _test_default in domains, f"Test default '{_test_default}' not in available domains"
        return _test_default

    import questionary

    selected = questionary.select(
        "Select a domain:", choices=domains, instruction="(Use arrow keys)"
    ).ask()

    if selected is None:
        raise ValueError("Domain selection cancelled")

    assert isinstance(selected, str), "Selected domain must be a string"
    assert len(selected) > 0, "Selected domain must not be empty"

    return selected


def resolve_domain(domain: str | None) -> str:
    """
    Resolve domain parameter: use provided value or prompt interactively.

    If domain is provided, return it.
    If domain is None, prompt user to select from available domains.

    Args:
        domain: Domain name or None

    Returns:
        Resolved domain name

    Raises:
        ValueError: If no domains available or user cancels selection

    Examples:
        >>> resolve_domain("travel")
        'travel'
        >>> resolve_domain(None)  # Shows interactive selector
        ? Select a domain: healthcare
        'healthcare'
    """
    assert domain is None or isinstance(domain, str), "Domain must be string or None"

    if domain is not None:
        assert len(domain) > 0, "Domain must not be empty string"
        return domain

    return prompt_for_domain()
