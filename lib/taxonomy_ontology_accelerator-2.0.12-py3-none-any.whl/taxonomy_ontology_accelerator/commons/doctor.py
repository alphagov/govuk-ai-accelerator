"""
Doctor command utilities for verifying setup and configuration.

Provides health checks for:
- Python version (MANDATORY)
- Required API keys - at least one LLM key (MANDATORY)
- Configuration files (MANDATORY for core, OPTIONAL for extras)
- Output directories (MANDATORY)
- Optional dependencies (OPTIONAL)
"""

import importlib.util
import os
import sys
from pathlib import Path

import fsspec
import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

console = Console()

# Constants for version checking
MIN_PYTHON_MAJOR = 3
MIN_PYTHON_MINOR = 11

# Constants for API key masking
KEY_PREFIX_LENGTH = 8
KEY_SUFFIX_LENGTH = 4
MIN_KEY_LENGTH_FOR_MASKING = 12

# Check categories
CHECK_MANDATORY = "mandatory"
CHECK_OPTIONAL = "optional"


def _check_python_version() -> tuple[bool, str]:
    """Check Python version meets requirements."""
    assert sys is not None, "sys module must be available"
    assert hasattr(sys, "version_info"), "sys must have version_info attribute"

    version = sys.version_info
    version_str = f"{version.major}.{version.minor}.{version.micro}"

    if version.major >= MIN_PYTHON_MAJOR and version.minor >= MIN_PYTHON_MINOR:
        return True, f"Python {version_str}"
    return False, f"Python {version_str} (requires {MIN_PYTHON_MAJOR}.{MIN_PYTHON_MINOR}+)"


def _check_api_key(key_name: str, env_var: str) -> tuple[bool, str]:
    """Check if an API key is set."""
    assert isinstance(key_name, str), "key_name must be a string"
    assert isinstance(env_var, str), "env_var must be a string"

    value = os.environ.get(env_var, "")
    if value:
        # Mask the key for display
        if len(value) > MIN_KEY_LENGTH_FOR_MASKING:
            masked = value[:KEY_PREFIX_LENGTH] + "..." + value[-KEY_SUFFIX_LENGTH:]
        else:
            masked = "***"
        return True, f"{key_name}: {masked}"
    return False, f"{key_name}: Not set"


def _check_config_file(name: str, path: Path) -> tuple[bool, str]:
    """Check if a configuration file exists."""
    assert isinstance(name, str), "name must be a string"
    assert isinstance(path, Path), "path must be a Path object"

    fs = fsspec.filesystem("file")
    if fs.exists(str(path)):
        return True, f"{name}: {path}"
    return False, f"{name}: Not found at {path}"


def _check_output_directory(path: Path) -> tuple[bool, str]:
    """Check if output directory is writable."""
    assert isinstance(path, Path), "path must be a Path object"
    assert path is not None, "path must not be None"

    try:
        fs = fsspec.filesystem("file")
        # Create directory if it doesn't exist
        fs.makedirs(str(path), exist_ok=True)

        # Try to write a test file
        test_file = str(path / ".doctor_test")
        with fs.open(test_file, "w") as f:
            f.write("test")
        fs.rm(test_file)

        return True, f"Output directory: {path} (writable)"
    except PermissionError:
        return False, f"Output directory: {path} (not writable)"
    except OSError as e:
        return False, f"Output directory: {path} (error: {e})"


def _check_optional_dependency(name: str, package: str) -> tuple[bool, str]:
    """Check if an optional dependency is installed."""
    assert isinstance(name, str), "name must be a string"
    assert isinstance(package, str), "package must be a string"

    # Use importlib.util.find_spec instead of __import__ (NASA01-A compliance)
    spec = importlib.util.find_spec(package)
    if spec is not None:
        return True, f"{name}: Installed"
    return False, f"{name}: Not installed"


def _run_python_checks() -> list[tuple[bool, str, str, str]]:
    """Run Python environment checks. Returns (passed, name, msg, category)."""
    assert callable(_check_python_version), "_check_python_version must be callable"

    results: list[tuple[bool, str, str, str]] = []
    passed, msg = _check_python_version()
    results.append((passed, "Python Version", msg, CHECK_MANDATORY))

    assert len(results) > 0, "results must not be empty"
    return results


def _run_api_key_checks() -> list[tuple[bool, str, str, str]]:
    """Run API key checks. Returns (passed, name, msg, category)."""
    results: list[tuple[bool, str, str, str]] = []

    api_keys = [
        ("Google API Key", "GOOGLE_API_KEY"),
        ("Anthropic API Key", "ANTHROPIC_API_KEY"),
        ("OpenAI API Key", "OPENAI_API_KEY"),
    ]

    assert len(api_keys) > 0, "api_keys must not be empty"

    for name, env_var in api_keys:
        passed, msg = _check_api_key(name, env_var)
        # Individual keys are optional, but we'll check if at least one is set later
        results.append((passed, name, msg, CHECK_OPTIONAL))

    assert len(results) == len(api_keys), "results must match api_keys length"
    return results


def _check_at_least_one_llm_key() -> tuple[bool, str, str, str]:
    """Check if at least one LLM API key is configured."""
    llm_keys = ["GOOGLE_API_KEY", "ANTHROPIC_API_KEY", "OPENAI_API_KEY"]

    assert len(llm_keys) > 0, "llm_keys must not be empty"
    assert all(isinstance(k, str) for k in llm_keys), "all keys must be strings"

    has_key = any(os.environ.get(key) for key in llm_keys)

    if has_key:
        return True, "LLM API Key", "At least one LLM API key configured", CHECK_MANDATORY
    return (
        False,
        "LLM API Key",
        "MISSING - Set GOOGLE_API_KEY, ANTHROPIC_API_KEY, or OPENAI_API_KEY",
        CHECK_MANDATORY,
    )


def _run_aws_checks() -> list[tuple[bool, str, str, str]]:
    """Run AWS credential checks. Returns (passed, name, msg, category)."""
    results: list[tuple[bool, str, str, str]] = []

    aws_keys = [
        ("AWS Region", "AWS_DEFAULT_REGION"),
        ("AWS Access Key", "AWS_ACCESS_KEY_ID"),
    ]

    assert len(aws_keys) > 0, "aws_keys must not be empty"

    for name, env_var in aws_keys:
        passed, msg = _check_api_key(name, env_var)
        results.append((passed, name, msg, CHECK_OPTIONAL))

    assert len(results) == len(aws_keys), "results must match aws_keys length"
    return results


def _run_config_checks(project_root: Path) -> list[tuple[bool, str, str, str]]:
    """Run configuration file checks. Returns (passed, name, msg, category)."""
    assert isinstance(project_root, Path), "project_root must be a Path"
    fs = fsspec.filesystem("file")
    assert fs.exists(str(project_root)), "project_root must exist"

    results: list[tuple[bool, str, str, str]] = []

    # Core config files (MANDATORY)
    # Note: Ontology engine now uses Pydantic defaults (no YAML file required)
    core_configs = []

    # Extra config files (OPTIONAL)
    optional_configs = [
        ("Travel Config", project_root / "resources" / "config" / "travel.yaml"),
        ("Default Config", project_root / "resources" / "config" / "default.yaml"),
    ]

    for name, path in core_configs:
        passed, msg = _check_config_file(name, path)
        results.append((passed, name, msg, CHECK_MANDATORY))

    for name, path in optional_configs:
        passed, msg = _check_config_file(name, path)
        results.append((passed, name, msg, CHECK_OPTIONAL))

    return results


def _run_directory_checks(project_root: Path) -> list[tuple[bool, str, str, str]]:
    """Run output directory checks. Returns (passed, name, msg, category)."""
    assert isinstance(project_root, Path), "project_root must be a Path"
    assert project_root is not None, "project_root must not be None"

    results: list[tuple[bool, str, str, str]] = []

    output_dirs = [
        project_root / "output" / "ontology",
    ]

    for path in output_dirs:
        passed, msg = _check_output_directory(path)
        results.append((passed, "Directory", msg, CHECK_MANDATORY))

    return results


def _run_dependency_checks() -> list[tuple[bool, str, str, str]]:
    """Run optional dependency checks. Returns (passed, name, msg, category)."""
    results: list[tuple[bool, str, str, str]] = []

    optional_deps = [
        ("AWS Bedrock (boto3)", "boto3"),
        ("Neo4j Driver", "neo4j"),
        ("RDF Library", "rdflib"),
        ("Sentence Transformers", "sentence_transformers"),
    ]

    assert len(optional_deps) > 0, "optional_deps must not be empty"

    for name, package in optional_deps:
        passed, msg = _check_optional_dependency(name, package)
        results.append((passed, name, msg, CHECK_OPTIONAL))

    assert len(results) == len(optional_deps), "results must match deps length"
    return results


def _display_results(
    results: list[tuple[bool, str, str, str]],
) -> tuple[int, int, int]:
    """Display results in a formatted table."""
    assert isinstance(results, list), "results must be a list"
    assert len(results) > 0, "results must not be empty"

    table = Table(title="Doctor Summary", show_header=True)
    table.add_column("Status", style="bold", width=6)
    table.add_column("Check", style="cyan")
    table.add_column("Details")
    table.add_column("Type", style="dim", width=10)

    passed_count = 0
    error_count = 0
    warning_count = 0

    for passed, check_name, details, category in results:
        if passed:
            status = "[green]✓[/green]"
            type_label = "[green]OK[/green]"
            passed_count += 1
        elif category == CHECK_OPTIONAL:
            status = "[yellow]○[/yellow]"
            type_label = "[yellow]Optional[/yellow]"
            warning_count += 1
        else:
            status = "[red]✗[/red]"
            type_label = "[red]Required[/red]"
            error_count += 1

        table.add_row(status, check_name, details, type_label)

    console.print(table)

    return passed_count, error_count, warning_count


def _display_summary(passed_count: int, error_count: int, warning_count: int) -> bool:
    """Display final summary. Returns True if all mandatory checks passed."""
    assert isinstance(passed_count, int), "passed_count must be an int"
    assert isinstance(error_count, int), "error_count must be an int"

    console.print("\n[bold]Summary:[/bold]")
    console.print(f"  [green]✓ Passed: {passed_count}[/green]")
    if warning_count > 0:
        console.print(f"  [yellow]○ Warnings (optional): {warning_count}[/yellow]")
    if error_count > 0:
        console.print(f"  [red]✗ Errors (required): {error_count}[/red]")

    if error_count == 0:
        console.print(
            "\n[bold green]✓ All mandatory checks passed! You're ready to use TOA.[/bold green]"
        )
        return True
    console.print(
        "\n[bold red]✗ Some mandatory checks failed. Please fix the errors above.[/bold red]"
    )
    return False


def _collect_all_checks(project_root: Path) -> list[tuple[bool, str, str, str]]:
    """Collect all check results."""
    assert isinstance(project_root, Path), "project_root must be a Path"

    results: list[tuple[bool, str, str, str]] = []

    console.print("\n[bold cyan]Python Environment[/bold cyan]")
    results.extend(_run_python_checks())

    console.print("\n[bold cyan]LLM API Keys (at least one required)[/bold cyan]")
    # First add the mandatory "at least one key" check
    results.append(_check_at_least_one_llm_key())
    # Then add individual key checks (optional/informational)
    results.extend(_run_api_key_checks())

    console.print("\n[bold cyan]AWS Credentials (Optional - for Bedrock)[/bold cyan]")
    results.extend(_run_aws_checks())

    console.print("\n[bold cyan]Configuration Files[/bold cyan]")
    results.extend(_run_config_checks(project_root))

    console.print("\n[bold cyan]Output Directories[/bold cyan]")
    results.extend(_run_directory_checks(project_root))

    console.print("\n[bold cyan]Optional Dependencies[/bold cyan]")
    results.extend(_run_dependency_checks())

    assert len(results) > 0, "results must not be empty"
    return results


def run_doctor_checks():
    """
    Run all doctor checks and display results.

    Mandatory checks (errors if failed):
    - Python version (>=3.11)
    - At least one LLM API key (GOOGLE_API_KEY, ANTHROPIC_API_KEY, or OPENAI_API_KEY)
    - Core configuration files (ontology config)
    - Output directories (writable)

    Optional checks (warnings if failed):
    - Individual API keys (when at least one is set)
    - AWS credentials (for Bedrock)
    - Extra config files (travel, default)
    - Optional dependencies (boto3, neo4j, rdflib)

    Exits with code 1 if any mandatory check fails.
    """
    assert console is not None, "console must be initialized"

    console.print(
        Panel.fit(
            "[bold blue]TOA Doctor - Setup Verification[/bold blue]",
            border_style="blue",
        )
    )

    project_root = Path(__file__).parent.parent.parent
    fs = fsspec.filesystem("file")
    assert fs.exists(str(project_root)), "project_root must exist"

    # Collect and display all checks
    results = _collect_all_checks(project_root)

    # Display results
    console.print("\n")
    passed, errors, warnings = _display_results(results)
    all_passed = _display_summary(passed, errors, warnings)

    # Exit with error code if mandatory checks failed
    if not all_passed:
        raise typer.Exit(code=1)
