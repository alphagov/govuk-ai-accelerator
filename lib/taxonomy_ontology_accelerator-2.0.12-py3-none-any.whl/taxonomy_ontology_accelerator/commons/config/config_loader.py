"""
Configuration loader for domain-specific configurations.

Supports loading YAML and JSON configuration files with validation
and backward compatibility handling.
"""

import copy
import json
import os
from pathlib import Path
from typing import Any

import fsspec
import yaml
from pydantic import BaseModel, Field, ValidationError

from taxonomy_ontology_accelerator.commons.utils.logger import get_logger

logger = get_logger()


# Configuration Models
class APIConfig(BaseModel):
    """API configuration for data fetching."""

    base_url: str
    list_endpoint: str
    item_endpoint_template: str = "{base_url}/{item_id}"
    timeout: int = 30
    retries: int = 3


class ExtractionConfig(BaseModel):
    """Configuration for data extraction rules."""

    list_selector: dict[str, Any]
    item_selector: dict[str, Any]
    parts_selector: dict[str, Any] = Field(default_factory=dict)
    container_selector: dict[str, Any] = Field(default_factory=dict)
    # Format-specific parser configurations (optional)
    csv_parser: dict[str, Any] | None = Field(
        default=None, description="CSV parser field mappings and settings"
    )
    text_parser: dict[str, Any] | None = Field(
        default=None, description="Text parser extraction rules and settings"
    )
    markdown_parser: dict[str, Any] | None = Field(
        default=None, description="Markdown parser extraction rules and settings"
    )
    json_parser: dict[str, Any] | None = Field(
        default=None,
        description="JSON parser settings (selectors are in item_selector/container_selector)",
    )


class ExtractionDefaultsConfig(BaseModel):
    """Default configurations for extraction engine parsers and processors."""

    model_config = {"populate_by_name": True}  # Allow both 'json' and 'json_config'

    file: dict[str, Any] = Field(default_factory=dict)
    csv: dict[str, Any] = Field(default_factory=dict)
    json_config: dict[str, Any] = Field(
        default_factory=dict, alias="json", description="JSON parser defaults"
    )
    api: dict[str, Any] = Field(default_factory=dict)
    text: dict[str, Any] = Field(default_factory=dict)
    markdown: dict[str, Any] = Field(default_factory=dict)
    postgresql: dict[str, Any] = Field(default_factory=dict)
    preprocessing: dict[str, Any] = Field(default_factory=dict)
    validation: dict[str, Any] = Field(default_factory=dict)
    error_handling: dict[str, Any] = Field(default_factory=dict)
    output: dict[str, Any] = Field(default_factory=dict)


class LLMConfig(BaseModel):
    """Configuration for LLM agents."""

    model: str
    retries: int = 3
    max_tokens: int | None = None
    temperature: float = 0.0  # 0.0 = most deterministic, 1.0 = most creative


class LLMConfigs(BaseModel):
    """Collection of LLM configurations for different stages."""

    extraction: LLMConfig
    clustering: LLMConfig


class DeduplicationConfig(BaseModel):
    """Configuration for deduplication rules."""

    normalization_rules: list[dict[str, str]] = Field(default_factory=list)
    remove_punctuation: bool = True
    remove_common_words: list[str] = Field(default_factory=list)
    word_replacements: dict[str, str] = Field(default_factory=dict)


class EmbeddingsConfig(BaseModel):
    """Configuration for embedding generation."""

    model: str
    provider: str | None = None  # "gemini", "openai" - auto-detected from model if not set
    task_type: str = "clustering"
    cache_dir: str = ".cache/taxonomy_engine"
    cache_file: str = "embeddings.json"
    api_key_env: str | None = None  # Environment variable name for API key (e.g., "GEMINI_API_KEY")


class ClusteringConfig(BaseModel):
    """Configuration for clustering operations."""

    cache_dir: str = "~/.cache/taxonomy_engine"
    cache_file: str = "clusters.json"
    batch_size: int = 30
    similarity_threshold: float = 0.70


class ExtractionCacheConfig(BaseModel):
    """Configuration for extraction cache."""

    cache_dir: str = "~/.cache/taxonomy_engine"
    cache_file: str = "extractions.json"


class DirectoriesConfig(BaseModel):
    """Configuration for directory paths."""

    taxonomies: str = "output/taxonomy_engine"
    output: str = "output/taxonomy_engine/normalised_taxonomy.json"


class OutputFilesConfig(BaseModel):
    """Configuration for output file names."""

    clustered: str = "clustered_taxonomy.json"
    normalised: str = "normalised_taxonomy.json"


class PromptsConfig(BaseModel):
    """Configuration for prompt file paths."""

    extraction: str | None = None  # Path to extraction prompt file
    clustering: str | None = None  # Path to clustering prompt file


class ConcurrencyConfig(BaseModel):
    """Configuration for concurrent operations."""

    max_workers: int = 20
    rate_limit: int | None = None
    retry_delay: int = 2
    max_retries: int = 3


class LoggingConfig(BaseModel):
    """Configuration for logging."""

    format: str = "rich"
    level: str = "INFO"
    show_progress: bool = True


class FilesystemConfig(BaseModel):
    """Configuration for filesystem operations.

    Supports multiple storage backends via fsspec:
    - local: Local filesystem (default)
    - s3: Amazon S3
    - gcs: Google Cloud Storage
    - az: Azure Blob Storage
    - hdfs: Hadoop Distributed File System

    Examples:
        # Local filesystem (default)
        filesystem:
          protocol: local

        # S3 with credentials
        filesystem:
          protocol: s3
          options:
            key: your-access-key
            secret: your-secret-key

        # GCS with service account
        filesystem:
          protocol: gcs
          options:
            token: /path/to/service-account.json
    """

    protocol: str = "local"  # fsspec protocol: local, s3, gcs, az, hdfs, etc.
    options: dict[str, Any] = Field(
        default_factory=dict, description="Protocol-specific options (credentials, regions, etc.)"
    )


class SitemapConfig(BaseModel):
    """Configuration for sitemap generation (optional)."""

    enabled: bool = False
    output: str = "sitemap.json"


class ValidationConfig(BaseModel):
    """Configuration for data validation."""

    required_fields: list[str] = Field(default_factory=list)
    min_parts: int = 1


class ModelStructureConfig(BaseModel):
    """Configuration for model structure and field mappings."""

    item: dict[str, Any] = Field(
        default_factory=lambda: {
            "id_field": "item_id",
            "name_field": "item_name",
            "id_alias": "country_slug",
            "name_alias": "country_name",
        }
    )
    container: dict[str, Any] = Field(
        default_factory=lambda: {
            "id_field": "container_id",
            "name_field": "container_name",
            "items_field": "nodes",
            "id_alias": "section_slug",
            "name_alias": "section_title",
            "items_alias": "sections",
        }
    )
    content: dict[str, Any] = Field(
        default_factory=lambda: {
            "id_field": "content_id",
            "name_field": "content_name",
            "body_field": "body",
            "id_alias": "slug",
            "name_alias": "title",
        }
    )
    source_field: str = "source_items"
    source_alias: str = "source_countries"


class DomainConfig(BaseModel):
    """Complete domain configuration."""

    domain: str
    name: str
    # Required for taxonomy engine
    llm: LLMConfigs
    deduplication: DeduplicationConfig
    embeddings: EmbeddingsConfig
    clustering: ClusteringConfig
    extraction_cache: ExtractionCacheConfig = Field(default_factory=lambda: ExtractionCacheConfig())
    directories: DirectoriesConfig
    output_files: OutputFilesConfig = Field(default_factory=lambda: OutputFilesConfig())
    prompts: PromptsConfig = Field(default_factory=lambda: PromptsConfig())
    logging: LoggingConfig
    # Optional - used by extraction engine or other engines
    api: APIConfig | None = None
    extraction: ExtractionConfig | None = None
    extraction_defaults: ExtractionDefaultsConfig = Field(
        default_factory=lambda: ExtractionDefaultsConfig()
    )
    concurrency: ConcurrencyConfig = Field(default_factory=lambda: ConcurrencyConfig())
    sitemap: SitemapConfig = Field(default_factory=lambda: SitemapConfig())
    validation: ValidationConfig = Field(default_factory=lambda: ValidationConfig())
    model_structure: ModelStructureConfig = Field(default_factory=lambda: ModelStructureConfig())


def _resolve_domain_config_path(domain: str, config_path: Path | None) -> Path:
    """Resolve config file path for a domain."""
    assert domain is not None, "domain parameter is required"
    assert isinstance(domain, str), "domain must be a string"

    if config_path is not None:
        return config_path

    project_root = Path(__file__).parent.parent.parent.parent
    return project_root / "domains" / domain / "config.yaml"


def _load_and_parse_config_file(config_path: Path) -> dict[str, Any]:
    """Load and parse config file from path."""
    assert config_path is not None, "config_path parameter is required"
    assert isinstance(config_path, Path), "config_path must be a Path object"

    try:
        fs = fsspec.filesystem("file")
        if config_path.suffix in (".yaml", ".yml"):
            with fs.open(str(config_path), "r", encoding="utf-8") as f:
                return yaml.safe_load(f)
        elif config_path.suffix == ".json":
            with fs.open(str(config_path), "r", encoding="utf-8") as f:
                return json.load(f)
        else:
            raise ValueError(f"Unsupported config format: {config_path.suffix}")
    except (yaml.YAMLError, json.JSONDecodeError) as e:
        raise ValueError(f"Failed to parse config file {config_path}: {e}") from e


class ConfigLoader:
    """Loader for domain configuration files with default merging."""

    @staticmethod
    def _load_default_config(default_path: Path | None = None) -> dict[str, Any]:
        """
        Load default configuration file.

        Args:
            default_path: Optional path to default config.
                         If None, returns empty config (domains have their own configs)

        Returns:
            Default config dictionary

        Raises:
            FileNotFoundError: If default config doesn't exist
            ValueError: If default config is invalid
        """
        assert default_path is None or isinstance(default_path, Path), (
            "default_path must be None or Path"
        )
        assert Path is not None, "Path class must be available"
        if default_path is None:
            return {}

        fs = fsspec.filesystem("file")
        if not fs.exists(str(default_path)):
            raise FileNotFoundError(
                f"Default config not found: {default_path}. Default config file does not exist"
            )

        try:
            if default_path.suffix in (".yaml", ".yml"):
                with fs.open(str(default_path), "r", encoding="utf-8") as f:
                    data = yaml.safe_load(f)
            elif default_path.suffix == ".json":
                with fs.open(str(default_path), "r", encoding="utf-8") as f:
                    data = json.load(f)
            else:
                raise ValueError(f"Unsupported default config format: {default_path.suffix}")
        except (yaml.YAMLError, json.JSONDecodeError) as e:
            raise ValueError(f"Failed to parse default config {default_path}: {e}") from e
        except OSError as e:
            raise OSError(f"Failed to read default config {default_path}: {e}") from e

        if not isinstance(data, dict):
            raise ValueError(f"Default config must contain a dictionary, got {type(data)}")

        if not data:
            raise ValueError("Default config is empty")

        return data

    @staticmethod
    def _deep_update(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
        """
        Deep merge: override values replace base values recursively.

        Args:
            base: Base dictionary (defaults)
            override: Override dictionary (domain config)

        Returns:
            Merged dictionary (override takes precedence)

        Rules:
        - Dictionaries are merged recursively
        - Lists are replaced entirely (not merged)
        - None values override base values
        - Other types are replaced directly

        Example:
            base = {"a": {"b": 1, "c": 2}, "list": [1, 2]}
            override = {"a": {"b": 3}, "list": [3, 4]}
            result = {"a": {"b": 3, "c": 2}, "list": [3, 4]}
        """
        assert isinstance(base, dict), "base must be a dictionary"
        assert isinstance(override, dict), "override must be a dictionary"
        result = copy.deepcopy(base)
        for key, value in override.items():
            # If both are dicts, merge recursively
            if (
                key in result
                and isinstance(result[key], dict)
                and isinstance(value, dict)
                and value is not None  # None should override, not merge
            ):
                result[key] = ConfigLoader._deep_update(result[key], value)
            else:
                # Replace entirely (for lists, None, or other types)
                result[key] = copy.deepcopy(value) if value is not None else None
        return result

    @staticmethod
    def _validate_required_fields(config: dict[str, Any], required_paths: list[str]) -> None:
        """
        Validate that all required fields are present in merged config.

        Args:
            config: Merged config dictionary
            required_paths: List of required field paths (dot notation)

        Raises:
            ValueError: If any required field is missing
        """
        assert isinstance(config, dict), "config must be a dictionary"
        assert isinstance(required_paths, list), "required_paths must be a list"
        missing = []
        for path in required_paths:
            keys = path.split(".")
            value = config
            try:
                for key in keys:
                    value = value[key]
                if value is None:
                    missing.append(path)
            except (KeyError, TypeError):
                missing.append(path)

        if missing:
            raise ValueError(
                f"Required config fields missing: {', '.join(missing)}. "
                "Add to default.yaml or domain config."
            )

    @staticmethod
    def _resolve_config_path(domain: str, config_path: Path | None) -> Path:
        """Resolve the config path for a domain."""
        assert domain is not None, "domain parameter is required"
        assert isinstance(domain, str), "domain must be a string"
        if config_path is not None:
            return config_path

        project_root = Path(__file__).parent.parent.parent.parent
        return project_root / "domains" / domain / "config.yaml"

    @staticmethod
    def _load_domain_config(config_path: Path) -> dict[str, Any]:
        """Load domain config from file."""
        assert config_path is not None, "config_path parameter is required"
        assert isinstance(config_path, Path), "config_path must be a Path object"
        fs = fsspec.filesystem("file")
        if not fs.exists(str(config_path)):
            return {}

        try:
            if config_path.suffix in (".yaml", ".yml"):
                with fs.open(str(config_path), "r", encoding="utf-8") as f:
                    return yaml.safe_load(f) or {}
            elif config_path.suffix == ".json":
                with fs.open(str(config_path), "r", encoding="utf-8") as f:
                    return json.load(f) or {}
        except (yaml.YAMLError, json.JSONDecodeError) as e:
            raise ValueError(f"Failed to parse domain config {config_path}: {e}") from e
        except OSError as e:
            raise OSError(f"Failed to read domain config {config_path}: {e}") from e
        return {}

    @staticmethod
    def _expand_llm_config(config: dict[str, Any]) -> None:
        """Expand shared LLM config (model/retries) to extraction and clustering stages."""
        assert config is not None, "config parameter is required"
        assert isinstance(config, dict), "config must be a dictionary"
        if "llm" not in config or not isinstance(config["llm"], dict):
            return

        llm_config = config["llm"]
        if "model" not in llm_config or "retries" not in llm_config:
            return

        model = llm_config.pop("model")
        retries = llm_config.pop("retries")

        for stage in ["extraction", "clustering"]:
            if stage not in llm_config:
                llm_config[stage] = {}
            llm_config[stage].setdefault("model", model)
            llm_config[stage].setdefault("retries", retries)

    @staticmethod
    def load_with_defaults(
        domain: str,
        config_path: Path | None = None,
        default_path: Path | None = None,
        required_fields: list[str] | None = None,
    ) -> dict[str, Any]:
        """
        Load domain config merged with defaults.

        Precedence: Domain Config → Default Config → ERROR
        """
        assert domain is not None, "domain parameter is required"
        assert isinstance(domain, str), "domain must be a string"
        # 1. Load default config (REQUIRED)
        default_config = ConfigLoader._load_default_config(default_path)

        # 2. Load domain config (optional)
        resolved_path = ConfigLoader._resolve_config_path(domain, config_path)
        domain_config = ConfigLoader._load_domain_config(resolved_path)

        # 3. Expand shared LLM config in defaults
        ConfigLoader._expand_llm_config(default_config)

        # 4. Deep merge: domain overrides defaults
        merged_config = ConfigLoader._deep_update(default_config, domain_config)

        # 5. Expand shared LLM config in merged (in case domain overrides it)
        ConfigLoader._expand_llm_config(merged_config)

        # 6. Validate required fields
        if required_fields:
            ConfigLoader._validate_required_fields(merged_config, required_fields)

        return merged_config

    @staticmethod
    def load(domain: str, config_path: Path | None = None) -> DomainConfig:
        """
        Load domain configuration from YAML or JSON file.

        Args:
            domain: Domain name (e.g., "travel")
            config_path: Optional path to config file.

        Returns:
            DomainConfig instance with validated configuration

        Raises:
            FileNotFoundError: If config file doesn't exist
            ValueError: If config format is unsupported or invalid
        """
        assert domain is not None, "domain parameter is required"
        assert isinstance(domain, str), "domain must be a string"

        fs = fsspec.filesystem("file")
        resolved_path = _resolve_domain_config_path(domain, config_path)
        if not fs.exists(str(resolved_path)):
            raise FileNotFoundError(
                f"Configuration file not found: {resolved_path}. "
                f"Expected location: domains/{domain}/config.yaml"
            )

        data = _load_and_parse_config_file(resolved_path)
        if not isinstance(data, dict):
            raise ValueError(f"Config file must contain a dictionary, got {type(data)}")

        data = ConfigLoader._handle_backward_compatibility(data)
        merged_data = ConfigLoader.load_with_defaults(domain, resolved_path)

        try:
            return DomainConfig(**merged_data)
        except ValidationError as e:
            raise ValueError(f"Invalid configuration in {resolved_path}: {e}") from e

    @staticmethod
    def _handle_backward_compatibility(data: dict[str, Any]) -> dict[str, Any]:
        """
        Handle backward compatibility for old config formats.

        Args:
            data: Raw config data dictionary

        Returns:
            Updated config data with backward compatibility applied
        """
        assert data is not None, "data parameter is required"
        assert isinstance(data, dict), "data must be a dictionary"
        # Handle parts_selector -> container_selector migration
        if "extraction" in data:
            extraction = data["extraction"]
            if "parts_selector" in extraction and "container_selector" not in extraction:
                extraction["container_selector"] = copy.deepcopy(extraction["parts_selector"])

                # Update field names for backward compatibility
                if "fields" in extraction["container_selector"]:
                    fields = extraction["container_selector"]["fields"]
                    # Map old field names to new ones
                    if "slug" in fields and "container_id" not in fields:
                        fields["container_id"] = fields["slug"]
                    if "title" in fields and "container_name" not in fields:
                        fields["container_name"] = fields["title"]
                    if "body" in fields and "content_body" not in fields:
                        fields["content_body"] = fields["body"]

        return data

    @staticmethod
    def list_available_domains(config_dir: Path | None = None) -> list[str]:
        """
        List all available domain configurations.

        Args:
            config_dir: Optional directory to search.
                       If None, searches domains/ directory.

        Returns:
            Sorted list of available domain names
        """
        assert config_dir is None or isinstance(config_dir, Path), "config_dir must be None or Path"
        assert Path is not None, "Path class must be available"
        if config_dir is None:
            project_root = Path(__file__).parent.parent.parent.parent
            config_dir = project_root / "domains"

        fs = fsspec.filesystem("file")
        if not fs.exists(str(config_dir)):
            return []

        config_dir_str = str(config_dir)
        domains: list[str] = []
        for pattern in ("*.yaml", "*.yml", "*.json"):
            for path_str in fs.glob(f"{config_dir_str.rstrip('/')}/{pattern}"):
                domains.append(os.path.splitext(os.path.basename(path_str))[0])

        return sorted(set(domains))
