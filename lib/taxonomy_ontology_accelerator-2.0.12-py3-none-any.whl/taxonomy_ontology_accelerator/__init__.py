"""
Taxonomy-Ontology-Accelerator - Multi-engine taxonomy, ontology, and tagging system.

This package provides AI-powered tools for:
- Taxonomy extraction and clustering
- Ontology/knowledge graph extraction
- Content tagging

Usage as CLI:
    toa taxonomy extract -d travel -i ./data/
    toa ontology extract -i file.txt -d travel
    toa doctor

Usage as library:
    # Ontology extraction (high-level)
    from taxonomy_ontology_accelerator import extract_ontology, OntologyOutput
    result: OntologyOutput = extract_ontology(texts, config)

    # Pipeline builder (chainable API)
    from taxonomy_ontology_accelerator import OntologyPipelineBuilder

    # Option 1: Use run() method (recommended)
    result = OntologyPipelineBuilder.run("travel", "data.txt")

    # Option 2: Builder pattern (sync context)
    import asyncio
    builder = OntologyPipelineBuilder(domain="travel").setup_pipeline("data.txt").extract()
    asyncio.run(builder.process())
    asyncio.run(builder.finalize())
    result = builder.build()

    # Individual stage functions (full control)
    from taxonomy_ontology_accelerator import (
        ExtractionState,
        setup,
        chunk_input_text,
        run_llm_extraction,
        deduplicate_entities,
    )
    state = ExtractionState(domain="travel", incremental=False)
    setup(state, input_path="data.txt")
    # ... run extraction and processing stages individually

    # Working with ontology models
    from taxonomy_ontology_accelerator import OntologySchema, OntologyGraph, Entity, Relationship
    schema: OntologySchema = result.schema
    graph: OntologyGraph = result.graph

    # Export to OWL/RDF
    from taxonomy_ontology_accelerator import export_to_owl_rdf, export_to_owl_rdf_from_files
    export_to_owl_rdf(schema, graph, output_path="ontology.ttl")

    # Schema utilities
    from taxonomy_ontology_accelerator import compare_schemas, generate_pydantic_models_from_schema, schema_to_graph
    comparison = compare_schemas("schema1.json", "schema2.json")
    models_code = generate_pydantic_models_from_schema(schema)
    graph_data = schema_to_graph(schema)

Usage as module:
    python -m taxonomy_ontology_accelerator --help
"""

__version__ = "2.0.12"

# Expose key components for library usage (sorted alphabetically)
__all__ = [
    "Entity",
    "ExtractionState",
    "OntologyGraph",
    "OntologyOutput",
    "OntologyPipelineBuilder",
    "OntologySchema",
    "Relationship",
    "__version__",
    "build_and_validate",
    "build_relationships",
    "chunk_input_text",
    "compare_schemas",
    "deduplicate_entities",
    "evolve_schema",
    "export_owl",
    "export_to_owl_rdf",
    "export_to_owl_rdf_from_files",
    "extract_ontology",
    "finalize_metadata",
    "generate_pydantic_models_from_schema",
    "load_existing_data",
    "merge_relationships",
    "merge_with_existing",
    "resolve_conflicts",
    "run_llm_extraction",
    "save_output",
    "schema_to_graph",
    "setup",
]

_PIPELINE_STAGE_NAMES = {
    "ExtractionState",
    "setup",
    "load_existing_data",
    "chunk_input_text",
    "run_llm_extraction",
    "deduplicate_entities",
    "build_relationships",
    "evolve_schema",
    "resolve_conflicts",
    "merge_with_existing",
    "merge_relationships",
    "build_and_validate",
    "save_output",
    "export_owl",
    "finalize_metadata",
}

_MODEL_NAMES = {"Entity", "OntologyGraph", "OntologyOutput", "OntologySchema", "Relationship"}

_EXPORT_NAMES = {"export_to_owl_rdf", "export_to_owl_rdf_from_files"}


def _load_pipeline_stage(name: str):
    """Load pipeline stage function or class - imports directly from implementation modules."""
    assert isinstance(name, str), "Name must be a string"
    assert name, "Name must not be empty"
    assert name in _PIPELINE_STAGE_NAMES, f"Invalid pipeline stage: {name}"

    # Import directly from implementation modules to avoid duplicate function names
    from taxonomy_ontology_accelerator.ontology_engine.core.extraction_finalize import (
        build_and_validate_graph,
        export_to_owl_format,
        finalize_extraction_output,
        merge_and_deduplicate_relationships,
        merge_with_existing_graph,
        save_schema_and_graph,
    )
    from taxonomy_ontology_accelerator.ontology_engine.core.extraction_pipeline import (
        ExtractionState,
    )
    from taxonomy_ontology_accelerator.ontology_engine.core.extraction_stages import (
        build_entity_relationships,
        chunk_input_text,
        deduplicate_extracted_entities,
        evolve_ontology_schema,
        resolve_conflicting_relationships,
        run_llm_extraction,
    )

    # Keep setup and load_existing_data from pipeline_stages (convenience wrappers)
    from taxonomy_ontology_accelerator.ontology_engine.pipeline_stages import (
        load_existing_data,
        setup,
    )

    _stage_map = {
        "ExtractionState": ExtractionState,
        "setup": setup,
        "load_existing_data": load_existing_data,
        "chunk_input_text": chunk_input_text,
        "run_llm_extraction": run_llm_extraction,
        "deduplicate_entities": deduplicate_extracted_entities,
        "build_relationships": build_entity_relationships,
        "evolve_schema": evolve_ontology_schema,
        "resolve_conflicts": resolve_conflicting_relationships,
        "merge_with_existing": merge_with_existing_graph,
        "merge_relationships": merge_and_deduplicate_relationships,
        "build_and_validate": build_and_validate_graph,
        "save_output": save_schema_and_graph,
        "export_owl": export_to_owl_format,
        "finalize_metadata": finalize_extraction_output,
    }
    return _stage_map[name]


def _load_model(name: str):
    """Load ontology model class."""
    assert isinstance(name, str), "Name must be a string"
    assert name in _MODEL_NAMES, f"Invalid model: {name}"

    from taxonomy_ontology_accelerator.ontology_engine.core.models import (
        Entity,
        OntologyGraph,
        OntologyOutput,
        OntologySchema,
        Relationship,
    )

    _m = {
        "Entity": Entity,
        "OntologyGraph": OntologyGraph,
        "OntologyOutput": OntologyOutput,
        "OntologySchema": OntologySchema,
        "Relationship": Relationship,
    }
    return _m[name]


def _load_export(name: str):
    """Load export function."""
    assert isinstance(name, str), "Name must be a string"
    assert name in _EXPORT_NAMES, f"Invalid export function: {name}"

    from taxonomy_ontology_accelerator.ontology_engine.storage.export import (
        export_to_owl_rdf,
        export_to_owl_rdf_from_files,
    )

    _e = {
        "export_to_owl_rdf": export_to_owl_rdf,
        "export_to_owl_rdf_from_files": export_to_owl_rdf_from_files,
    }
    return _e[name]


def _load_other(name: str):
    """Load other library function or class."""
    assert isinstance(name, str), "Name must be a string"
    assert name not in (_PIPELINE_STAGE_NAMES | _MODEL_NAMES | _EXPORT_NAMES), (
        f"Name should be handled by specific loader: {name}"
    )

    from taxonomy_ontology_accelerator.ontology_engine.core.extractor import extract_ontology
    from taxonomy_ontology_accelerator.ontology_engine.pipeline_builder import (
        OntologyPipelineBuilder,
    )
    from taxonomy_ontology_accelerator.ontology_engine.storage.schema_graph import schema_to_graph
    from taxonomy_ontology_accelerator.ontology_engine.utils.schema_code_generator import (
        generate_pydantic_models_from_schema,
    )
    from taxonomy_ontology_accelerator.ontology_engine.utils.schema_comparator import (
        compare_schemas,
    )

    _o = {
        "extract_ontology": extract_ontology,
        "OntologyPipelineBuilder": OntologyPipelineBuilder,
        "compare_schemas": compare_schemas,
        "generate_pydantic_models_from_schema": generate_pydantic_models_from_schema,
        "schema_to_graph": schema_to_graph,
    }
    assert name in _o, f"module {__name__!r} has no attribute {name!r}"
    return _o[name]


def __getattr__(name: str):
    """Lazy imports for library usage to avoid circular imports."""
    assert isinstance(name, str), "Attribute name must be a string"
    assert name, "Attribute name must not be empty"

    if name in _PIPELINE_STAGE_NAMES:
        return _load_pipeline_stage(name)
    if name in _MODEL_NAMES:
        return _load_model(name)
    if name in _EXPORT_NAMES:
        return _load_export(name)

    return _load_other(name)
