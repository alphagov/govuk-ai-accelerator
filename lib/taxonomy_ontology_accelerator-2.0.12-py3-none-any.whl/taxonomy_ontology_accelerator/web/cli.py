import os
import shutil
import subprocess
import threading
import time
import webbrowser
from pathlib import Path

import fsspec
import typer
import uvicorn

app = typer.Typer(
    help="Web visualization server",
    invoke_without_command=True,
    no_args_is_help=False,
)

MIN_PORT = 1024
MAX_PORT = 65535
DEFAULT_DOMAINS_DIR = Path.cwd() / "domains"


def build_frontend() -> None:
    """Build frontend bundle."""
    fs = fsspec.filesystem("file")
    frontend_dir = Path(__file__).parent.parent.parent / "frontend"
    assert fs.exists(str(frontend_dir)), f"Frontend directory not found: {frontend_dir}"
    assert fs.exists(str(frontend_dir / "package.json")), "package.json must exist"

    if shutil.which("npm") is None:
        raise RuntimeError(
            "npm not found. Install Node.js/npm to use 'toa web'.\nVisit: https://nodejs.org/"
        )

    if not fs.exists(str(frontend_dir / "node_modules")):
        typer.echo("Installing frontend dependencies...")
        subprocess.run(["npm", "install"], cwd=frontend_dir, check=True)

    subprocess.run(["npm", "run", "build"], cwd=frontend_dir, check=True)


def open_browser(url: str, delay: float = 1.5) -> None:
    """Open browser after a delay to ensure server is ready."""
    assert url, "URL must not be empty"
    assert delay > 0, "Delay must be positive"
    time.sleep(delay)
    webbrowser.open(url)


@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    port: int = 8000,
    reload: bool = True,
    auto_open: bool = True,
    domains_dir: Path | None = None,
) -> None:
    """Start web visualization server."""
    if ctx.invoked_subcommand is not None:
        return

    assert isinstance(port, int), "Port must be an integer"
    assert MIN_PORT <= port <= MAX_PORT, f"Port must be between {MIN_PORT} and {MAX_PORT}"

    if domains_dir is None:
        domains_dir = DEFAULT_DOMAINS_DIR

    # Resolve to absolute path
    domains_path_str = os.path.abspath(str(domains_dir))

    import fsspec

    fs = fsspec.filesystem("file")
    if not fs.exists(domains_path_str):
        typer.echo(f"Warning: Domains directory does not exist: {domains_path_str}", err=True)
        typer.echo("The app will fail if no domains are available.", err=True)

    os.environ["TOA_DOMAINS_DIR"] = domains_path_str
    typer.echo(f"Using domains directory: {domains_path_str}")

    typer.echo("Building frontend...")
    build_frontend()
    typer.echo("Starting server...")

    url = f"http://127.0.0.1:{port}"
    if auto_open:
        threading.Thread(target=open_browser, args=(url,), daemon=True).start()
        typer.echo(f"Opening browser at {url}...")

    uvicorn.run(
        "taxonomy_ontology_accelerator.web.app:app",
        host="127.0.0.1",
        port=port,
        reload=reload,
    )


if __name__ == "__main__":
    app()
