from taxonomy_ontology_accelerator.ontology_engine.core.models import OntologyGraph


def analyze_graph(graph: OntologyGraph) -> dict[str, dict]:
    """Analyze graph structure for visualization.

    Returns dict mapping entity IDs to analysis metrics:
    - depth: hierarchy depth (0 for root nodes)
    - connectivity: number of relationships
    - has_description: whether entity has a description
    """
    assert graph is not None, "Graph must not be None"
    assert isinstance(graph, OntologyGraph), "Graph must be OntologyGraph instance"

    connectivity = {}
    for rel in graph.relationships:
        connectivity[rel.from_] = connectivity.get(rel.from_, 0) + 1
        connectivity[rel.to] = connectivity.get(rel.to, 0) + 1

    MAX_DEPTH = 100

    parent_map = {}
    for rel in graph.relationships:
        if (
            rel.type.lower() in ["subclassof", "is_a", "isa", "parent"]
            and rel.from_ not in parent_map
        ):
            parent_map[rel.from_] = rel.to

    depths = {}
    for entity in graph.entities:
        depth = 0
        current = entity.id
        visited = set()
        while current in parent_map and current not in visited:
            visited.add(current)
            current = parent_map[current]
            depth += 1
            if depth > MAX_DEPTH:
                break
        depths[entity.id] = depth

    analysis = {}
    for entity in graph.entities:
        assert entity.id is not None, "Entity ID must not be None"
        analysis[entity.id] = {
            "depth": depths.get(entity.id, 0),
            "connectivity": connectivity.get(entity.id, 0),
            "has_description": bool(entity.description and len(entity.description.strip()) > 0),
        }

    assert len(analysis) == len(graph.entities), "Analysis must cover all entities"
    return analysis
