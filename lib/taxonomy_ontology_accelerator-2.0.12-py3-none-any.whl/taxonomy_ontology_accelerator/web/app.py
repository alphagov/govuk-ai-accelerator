import asyncio
import json
import boto3
import botocore.exceptions

from pathlib import Path
from pydantic import ValidationError

import fsspec
from fastapi import FastAPI, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from taxonomy_ontology_accelerator.commons.utils.logger import get_logger
from taxonomy_ontology_accelerator.ontology_engine.agent_ui import (
    AgentDependencies,
    create_ontology_agent,
    load_domain,
)
from taxonomy_ontology_accelerator.ontology_engine.core.models import OntologyGraph
from taxonomy_ontology_accelerator.web.analyzer import analyze_graph

logger = get_logger()


def _error_page_html(detail: str) -> str:
    return f"""<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><title>Taxonomy Ontology Visualizer - Something went wrong</title>
<style>
  body {{ font-family: system-ui, sans-serif; background: #0f1117; color: #e2e8f0;
         display: flex; align-items: center; justify-content: center; min-height: 100vh; margin: 0; }}
  .card {{ background: #1a1f2e; border: 1px solid #e53e3e; border-radius: 12px;
           padding: 2rem 2.5rem; max-width: 600px; width: 90%; }}
  h1 {{ color: #fc8181; margin-top: 0; }}
  pre {{ background: #0f1117; border-radius: 6px; padding: 1rem;
         overflow-x: auto; font-size: 0.85rem; white-space: pre-wrap; word-break: break-word; }}
  p {{ color: #a0aec0; line-height: 1.6; }}
  code {{ background: #2d3748; padding: 2px 6px; border-radius: 4px; }}
</style>
</head>
<body>
<div class="card">
  <h1>Something went wrong</h1>
  <p>The server encountered an error:</p>
  <pre>{detail}</pre>
  <p>Please check that your <code>graph.json</code> file is valid.</p>
</div>
</body>
</html>"""


_MODULE_DIR = Path(__file__).parent
fs = fsspec.filesystem("file")
assert fs.exists(str(_MODULE_DIR)), "Web module directory must exist"

# Create static directory if it doesn't exist (may not exist in fresh clones due to gitignore)
static_dir = _MODULE_DIR / "static"
try:
    fs.makedirs(str(static_dir), exist_ok=True)
    if not fs.exists(str(static_dir)):
        logger.warning(
            f"Static directory was not created at {static_dir}, static files will not be available"
        )
except Exception as e:
    logger.warning(f"Failed to create static directory: {e}. Static files will not be available.")

app = FastAPI(title="Taxonomy Ontology Visualizer")


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception) -> HTMLResponse:
    logger.error(f"Unhandled exception on {request.url}: {exc}", exc_info=True)
    return HTMLResponse(content=_error_page_html(str(exc)), status_code=500)


# Only mount static files if directory exists
if fs.exists(str(static_dir)):
    app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")
else:
    logger.info("Static directory not available, skipping static files mount")

# Agent state
_agent = None
_agent_domains = None
_conversation_history: dict[str, list] = {}
_fs_cache = None


def get_fs() -> fsspec.AbstractFileSystem:
    """Get cached fsspec filesystem instance."""
    global _fs_cache
    assert _fs_cache is None or hasattr(_fs_cache, "open"), "Filesystem must have open method"
    if _fs_cache is None:
        _fs_cache = fsspec.filesystem("file")
        assert _fs_cache is not None, "Filesystem must be initialized"
    return _fs_cache



def get_agent(run_path: str):
    """Lazy load agent on first use."""
    global _agent, _agent_domains

    if _agent is None:
        print(f"Loading agent for {run_path}")
        _agent_domains = load_domain(run_path)
        if len(_agent_domains) == 0:
            raise HTTPException(
                status_code=503,
                detail=f"No workable domains found",
            )

        _agent = create_ontology_agent(_agent_domains)
        logger.info(f"Agent initialized with {len(_agent_domains)} domains")

    return _agent, _agent_domains

templates = Jinja2Templates(directory=f"{_MODULE_DIR}/templates")

@app.get("/", response_class=HTMLResponse)
async def index(request: Request, run: str | None = None) -> str:
    assert fs.exists(str(_MODULE_DIR)), "Web module directory must exist"
    template_path = _MODULE_DIR / "templates" / "index.html"
    assert fs.exists(str(template_path)), f"Template file must exist at {template_path}"
    if run is None:
        return templates.TemplateResponse(request=request, name="index.html", context={})
    context = {
        "run": run
    }

    return templates.TemplateResponse(
        request=request, name="index.html", context=context
    )


@app.get("/api/sources")
async def get_sources_map(file: str) -> dict:
    """Return the slug→URL sidecar map written by ingestion.

    Missing file returns an empty dict so the visualizer degrades gracefully on
    domains ingested before the sidecar existed.
    """
    if not file.strip():
        raise HTTPException(status_code=400, detail="'file' query parameter must not be empty.")
    s3_client = boto3.client("s3")
    try:
        response = s3_client.get_object(
            Bucket="govuk-ai-accelerator-data-integration",
            Key=file,
        )
    except botocore.exceptions.ClientError as exc:
        error_code = exc.response["Error"]["Code"]
        if error_code == "NoSuchKey":
            return {}
        raise HTTPException(status_code=502, detail=f"S3 error: {exc}")
    try:
        return json.loads(response["Body"].read().decode("utf-8"))
    except json.JSONDecodeError as e:
        raise HTTPException(
            status_code=422,
            detail=f"Sources file '{file}' is not valid JSON: {e}.",
        )


@app.get("/api/graph")
async def get_graph_data(file: str) -> dict:
    if not file.strip():
        raise HTTPException(status_code=400, detail="'file' query parameter must not be empty.")
    s3_client = boto3.client("s3")
    try:
        response = s3_client.get_object(
            Bucket="govuk-ai-accelerator-data-integration",
            Key=file,
        )
    except botocore.exceptions.ClientError as exc:
        error_code = exc.response["Error"]["Code"]
        status = 404 if error_code == "NoSuchKey" else 502
        raise HTTPException(status_code=status, detail=f"S3 error: {exc}")
    try:
        graph_data = json.loads(response["Body"].read().decode('utf-8'))
    except json.JSONDecodeError as e:
        raise HTTPException(
            status_code=422,
            detail=f"Graph file '{file}' is not valid JSON: {e}. "
        )
    try:
        graph = OntologyGraph(**graph_data)
    except ValidationError as e:
        bad_fields = [".".join(str(x) for x in err["loc"]) for err in e.errors()]
        raise HTTPException(
            status_code=422,
            detail=f"Graph file '{file}' has invalid/missing fields: {bad_fields}. "
        )

    def serialize_for_duckdb(data: dict) -> dict:
        """Convert complex types to JSON strings for DuckDB compatibility."""
        assert isinstance(data, dict), "Data must be a dictionary"
        assert data is not None, "Data must not be None"
        result = {}
        for key, value in data.items():
            if isinstance(value, (dict, list)):
                result[key] = (
                    json.dumps(value) if value else ("{}" if isinstance(value, dict) else "[]")
                )
            elif value is None:
                result[key] = ""
            else:
                result[key] = value
        return result

    nodes = [serialize_for_duckdb(entity.model_dump()) for entity in graph.entities]

    links = [
        serialize_for_duckdb(rel.model_dump(by_alias=True))
        | {"source": rel.from_, "target": rel.to}
        for rel in graph.relationships
    ]

    assert len(nodes) >= 0, "Nodes must be valid list"
    assert len(links) >= 0, "Links must be valid list"

    try:
        analysis = analyze_graph(graph)
    except Exception as e:
        print(f"Analysis failed: {e}")
        analysis = {}

    return {"nodes": nodes, "links": links, "analysis": analysis}


async def stream_agent_events(agent, message: str, deps: AgentDependencies, history: list):
    """Stream agent events as SSE and return accumulated text."""
    assert agent is not None, "Agent must not be None"
    assert message is not None, "Message must not be None"

    text_parts = []
    tools_shown = set()

    async for event in agent.run_stream_events(message, deps=deps, message_history=history):
        event_kind = type(event).__name__

        if event_kind == "PartStartEvent" and hasattr(event, "part"):
            part = event.part
            if hasattr(part, "content") and isinstance(part.content, str):
                initial = part.content
                if initial:
                    text_parts.append(initial)
                    yield f"event: text\ndata: {json.dumps({'chunk': initial})}\n\n"
                    await asyncio.sleep(0)

        elif event_kind == "PartDeltaEvent" and hasattr(event, "delta"):
            if hasattr(event.delta, "content_delta"):
                delta = event.delta.content_delta
                text_parts.append(delta)
                yield f"event: text\ndata: {json.dumps({'chunk': delta})}\n\n"
                await asyncio.sleep(0)

        elif event_kind == "FunctionToolCallEvent":
            tool_name = "unknown"
            if hasattr(event, "part") and hasattr(event.part, "tool_name"):
                tool_name = event.part.tool_name
            if tool_name not in tools_shown:
                tools_shown.add(tool_name)
                yield f"event: tool\ndata: {json.dumps({'tool': tool_name})}\n\n"
                await asyncio.sleep(0.1)

        elif event_kind == "FunctionToolResultEvent":
            state = deps.graph_state.model_dump()
            yield f"event: state\ndata: {json.dumps({'state': state})}\n\n"
            await asyncio.sleep(0.1)

    yield ("TEXT_COMPLETE", "".join(text_parts))


@app.post("/api/chat/stream")
async def chat_stream(
    message: str = Form(...), run = Form(...), session_id: str = Form("default")
):
    """Streaming chat with graph updates."""
    assert message is not None, "Message must not be None"

    agent, domains = get_agent(run)
    assert agent is not None, "Agent must be initialized"

    deps = AgentDependencies(domains=domains)

    async def generate():
        assert session_id is not None, "Session ID must not be None"
        assert deps is not None, "Dependencies must not be None"

        try:
            if session_id not in _conversation_history:
                _conversation_history[session_id] = []

            logger.info(f"Streaming: {message[:50]}...")

            full_text = ""
            stream_iter = stream_agent_events(
                agent, message, deps, _conversation_history[session_id]
            ).__aiter__()
            while True:
                try:
                    item = await asyncio.wait_for(stream_iter.__anext__(), timeout=10)
                except asyncio.TimeoutError:
                    yield ": ping\n\n"
                    continue
                except StopAsyncIteration:
                    break
                if isinstance(item, tuple) and item[0] == "TEXT_COMPLETE":
                    full_text = item[1]
                else:
                    yield item

            _conversation_history[session_id].append({"role": "user", "content": message})
            _conversation_history[session_id].append({"role": "assistant", "content": full_text})

            # if deps.current_domain != domain:
            #     yield f"event: state\ndata: {json.dumps({'domain': deps.current_domain})}\n\n"

            yield f"event: complete\ndata: {json.dumps({'status': 'done'})}\n\n"

        except Exception as e:
            logger.error(f"Stream error: {e}")
            yield f"event: error\ndata: {json.dumps({'message': str(e)})}\n\n"

    return StreamingResponse(
        generate(), media_type="text/event-stream", headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"}
    )
