"""
Domain initialization module for Taxonomy-Ontology-Accelerator.

Provides functionality to scaffold new domain projects with:
- Configuration files
- Prompt templates
- Input/output directory structure

Usage:
    # CLI
    toa init --domain travel

    # Library
    from taxonomy_ontology_accelerator.init import DomainInitializer, InitConfig
    initializer = DomainInitializer()
    result = initializer.init_domain("travel")
"""

from taxonomy_ontology_accelerator.init.initializer import (
    DomainInitializer,
    InitConfig,
    InitResult,
)

__all__ = [
    "DomainInitializer",
    "InitConfig",
    "InitResult",
]
