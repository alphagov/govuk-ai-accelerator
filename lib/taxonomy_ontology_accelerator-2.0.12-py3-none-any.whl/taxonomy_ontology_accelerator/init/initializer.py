"""
Core initialization logic for domain scaffolding.

Provides DomainInitializer class for creating domain project structures
with configuration files, prompts, and directory layouts.
"""

from dataclasses import dataclass, field
from pathlib import Path

import fsspec

from taxonomy_ontology_accelerator.init.templates import TemplateRenderer
from taxonomy_ontology_accelerator.init.validators import validate_domain_name


@dataclass
class InitConfig:
    """Configuration for domain initialization.

    Attributes:
        domain: Domain name (e.g., "travel", "healthcare")
        engines: List of engines to initialize ("taxonomy", "ontology", or both)
        output_dir: Base directory for domain folder (defaults to current directory)
        model: LLM model to configure (e.g., "anthropic:claude-sonnet-4-20250514")
        basic_config: If True, generate basic config (LLM only); if False (default), full config
        force: If True, overwrite existing files
        dry_run: If True, only show what would be created without creating
    """

    domain: str
    engines: list[str] = field(default_factory=lambda: ["ontology"])
    output_dir: Path = field(default_factory=Path.cwd)
    model: str | None = None
    basic_config: bool = False
    force: bool = False
    dry_run: bool = False

    def __post_init__(self):
        """Validate and normalize configuration."""
        assert self.domain, "Domain must not be empty"
        assert isinstance(self.engines, list), "Engines must be a list"
        assert len(self.engines) > 0, "At least one engine must be specified"

        # Normalize engines
        valid_engines = {"taxonomy", "ontology"}
        for engine in self.engines:
            if engine not in valid_engines:
                raise ValueError(f"Invalid engine: {engine}. Must be one of {valid_engines}")

        # Validate basic_config is boolean (NASA05: 2 assertions)
        assert isinstance(self.basic_config, bool), "basic_config must be a boolean"
        assert self.output_dir is not None, "output_dir must not be None"

        # Convert output_dir to Path if string
        if isinstance(self.output_dir, str):
            self.output_dir = Path(self.output_dir)


@dataclass
class InitResult:
    """Result of domain initialization.

    Attributes:
        success: Whether initialization completed successfully
        domain: Domain name that was initialized
        domain_path: Path to the created domain folder
        created_files: List of files that were created
        created_dirs: List of directories that were created
        skipped_files: List of files that were skipped (already exist)
        errors: List of error messages if any
    """

    success: bool
    domain: str
    domain_path: Path
    created_files: list[Path] = field(default_factory=list)
    created_dirs: list[Path] = field(default_factory=list)
    skipped_files: list[Path] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)


class DomainInitializer:
    """Initializes domain project structures.

    Creates the standard folder structure and configuration files
    for taxonomy and/or ontology engines.

    Example:
        >>> initializer = DomainInitializer()
        >>> result = initializer.init_domain("travel")
        >>> print(f"Created {len(result.created_files)} files")

        >>> # With configuration
        >>> config = InitConfig(domain="healthcare", engines=["ontology"])
        >>> result = initializer.init(config)
    """

    def __init__(self):
        """Initialize the domain initializer."""
        assert TemplateRenderer is not None, "TemplateRenderer class must be available"
        self._renderer = TemplateRenderer()
        assert self._renderer is not None, "TemplateRenderer must be initialized"

    def init_domain(  # noqa: PLR0913
        self,
        domain: str,
        *,
        engines: list[str] | None = None,
        output_dir: Path | None = None,
        model: str | None = None,
        basic_config: bool = False,
        force: bool = False,
        dry_run: bool = False,
    ) -> InitResult:
        """Initialize a domain with default or specified options.

        Args:
            domain: Domain name (e.g., "travel", "healthcare")
            engines: Engines to initialize (default: ["taxonomy", "ontology"])
            output_dir: Base directory for domain folder (default: current directory)
            model: LLM model to configure
            basic_config: If True, generate basic config (LLM only); if False (default), full config
            force: If True, overwrite existing files
            dry_run: If True, only show what would be created

        Returns:
            InitResult with details of created files and directories

        Raises:
            ValueError: If domain name is invalid
        """
        assert domain, "Domain must not be empty"
        assert isinstance(domain, str), "Domain must be a string"

        config = InitConfig(
            domain=domain,
            engines=engines or ["ontology"],
            output_dir=output_dir or Path.cwd(),
            model=model,
            basic_config=basic_config,
            force=force,
            dry_run=dry_run,
        )
        return self.init(config)

    def init(self, config: InitConfig) -> InitResult:
        """Initialize a domain with the given configuration.

        Args:
            config: InitConfig with initialization options

        Returns:
            InitResult with details of created files and directories
        """
        assert config is not None, "Config must not be None"
        assert isinstance(config, InitConfig), "Config must be an InitConfig instance"

        # Validate domain name
        validation_error = validate_domain_name(config.domain)
        if validation_error:
            return InitResult(
                success=False,
                domain=config.domain,
                domain_path=config.output_dir / config.domain,
                errors=[validation_error],
            )

        # Create result object
        domain_path = config.output_dir / config.domain
        result = InitResult(
            success=True,
            domain=config.domain,
            domain_path=domain_path,
        )

        # Create directory structure
        self._create_directories(config, result)

        # Create configuration file
        self._create_config_file(config, result)

        # Create prompt files based on selected engines
        self._create_prompt_files(config, result)

        # Set success based on errors
        result.success = len(result.errors) == 0

        return result

    def _create_directories(self, config: InitConfig, result: InitResult) -> None:
        """Create the directory structure for the domain."""
        assert config is not None, "Config must not be None"
        assert result is not None, "Result must not be None"

        directories = [
            result.domain_path,
            result.domain_path / "input",
            result.domain_path / "prompts",
        ]

        for dir_path in directories:
            if config.dry_run:
                result.created_dirs.append(dir_path)
                continue

            try:
                fs = fsspec.filesystem("file")
                fs.makedirs(str(dir_path), exist_ok=True)
                result.created_dirs.append(dir_path)
            except OSError as e:
                result.errors.append(f"Failed to create directory {dir_path}: {e}")

    def _create_config_file(self, config: InitConfig, result: InitResult) -> None:
        """Create the domain configuration file."""
        assert config is not None, "Config must not be None"
        assert result is not None, "Result must not be None"

        config_path = result.domain_path / "config.yaml"
        from taxonomy_ontology_accelerator.commons.io.fsspec_utils import get_default_filesystem

        fs = get_default_filesystem()
        if fs.exists(str(config_path)) and not config.force:
            result.skipped_files.append(config_path)
            return

        if config.dry_run:
            result.created_files.append(config_path)
            return

        try:
            # Convert boolean basic_config to string config_mode for render_config
            # True → "minimal" (basic), False (default) → "maximum" (full)
            config_mode = "minimal" if config.basic_config else "maximum"
            content = self._renderer.render_config(
                domain=config.domain,
                engines=config.engines,
                model=config.model,
                config_mode=config_mode,
            )
            fs = fsspec.filesystem("file")
            with fs.open(str(config_path), "w", encoding="utf-8") as f:
                f.write(content)
            result.created_files.append(config_path)
        except FileNotFoundError as e:
            result.errors.append(f"Failed to load default config: {e}")
        except OSError as e:
            result.errors.append(f"Failed to create config file {config_path}: {e}")

    def _create_prompt_files(self, config: InitConfig, result: InitResult) -> None:
        """Create prompt template files based on selected engines."""
        assert config is not None, "Config must not be None"
        assert result is not None, "Result must not be None"

        prompts_dir = result.domain_path / "prompts"
        prompt_files: list[tuple[str, str]] = []

        # Ontology engine uses a single prompt.txt
        if "ontology" in config.engines:
            prompt_files.append(("prompt.txt", "ontology"))
            # Research prompt files (created empty, uses default if empty)
            prompt_files.append(("research_system_prompt.txt", "research_system"))
            prompt_files.append(("research_user_prompt.txt", "research_user"))

        for filename, template_type in prompt_files:
            prompt_path = prompts_dir / filename
            from taxonomy_ontology_accelerator.commons.io.fsspec_utils import get_default_filesystem

            fs = get_default_filesystem()
            if fs.exists(str(prompt_path)) and not config.force:
                result.skipped_files.append(prompt_path)
                continue

            if config.dry_run:
                result.created_files.append(prompt_path)
                continue

            try:
                content = self._renderer.render_prompt(
                    template_type=template_type,
                    domain=config.domain,
                )
                fs = fsspec.filesystem("file")
                with fs.open(str(prompt_path), "w", encoding="utf-8") as f:
                    f.write(content)
                result.created_files.append(prompt_path)
            except OSError as e:
                result.errors.append(f"Failed to create prompt file {prompt_path}: {e}")
