"""
Template rendering for domain initialization.

Provides templates for configuration files and prompts,
with rendering logic to customize for specific domains.
"""

# Default LLM model if not specified
DEFAULT_MODEL = "google-gla:gemini-2.5-pro"
DEFAULT_MAX_TOKENS = 100000

# Template strings stored as module-level constants to keep functions short
_ONTOLOGY_PROMPT_HEADER = """# Ontology Extraction Prompt for {domain_title} Domain
#
# This prompt guides the LLM to extract entities and relationships
# from unstructured text to build a knowledge graph.
#
# Customize this prompt for your specific domain requirements.

You are an expert knowledge engineer specializing in the {domain} domain.
Your task is to extract structured information from the provided text
to build a comprehensive ontology.

## Instructions

1. **Identify Entities**: Extract all meaningful entities (people, places,
   organizations, concepts, events, etc.) relevant to the {domain} domain.

2. **Extract Properties**: For each entity, identify relevant properties
   and their values from the text.

3. **Identify Relationships**: Determine how entities are related to each other.
   Use clear, descriptive relationship types.

4. **Maintain Consistency**: Use consistent naming conventions:
   - Entity types: PascalCase (e.g., "Person", "Location", "Event")
   - Relationship types: SCREAMING_SNAKE_CASE (e.g., "LOCATED_IN", "WORKS_FOR")
   - Property names: snake_case (e.g., "start_date", "full_name")
"""

_ONTOLOGY_PROMPT_FORMAT = """
## Output Format

Return a JSON object with the following structure:

```json
{{
  "entities": [
    {{
      "name": "Entity Name",
      "type": "EntityType",
      "properties": {{
        "property_name": "value"
      }}
    }}
  ],
  "relationships": [
    {{
      "source": "Source Entity Name",
      "target": "Target Entity Name",
      "type": "RELATIONSHIP_TYPE",
      "properties": {{}}
    }}
  ]
}}
```

## Domain-Specific Guidelines

Add specific extraction rules for the {domain} domain here:
- What types of entities are most important?
- What relationships should be prioritized?
- Are there domain-specific properties to always extract?

---

Now extract entities and relationships from the following text:
"""

_TAXONOMY_EXTRACT_HEADER = """# Taxonomy Extraction Prompt for {domain_title} Domain
#
# This prompt guides the LLM to extract hierarchical category structures
# from unstructured text.
#
# Customize this prompt for your specific domain requirements.

You are an expert taxonomist specializing in the {domain} domain.
Your task is to extract a hierarchical category structure from the provided text.

## Instructions

1. **Identify Categories**: Extract all meaningful categories and subcategories
   relevant to the {domain} domain.

2. **Build Hierarchy**: Organize categories into a logical parent-child structure.
   - Top-level categories should be broad concepts
   - Subcategories should be more specific

3. **Maintain Consistency**: Use consistent naming:
   - Category names should be clear and descriptive
   - Use title case for category names
   - Avoid redundant prefixes/suffixes

4. **Include Metadata**: Where available, extract:
   - Category descriptions
   - Example items that belong to each category
   - Alternative names or synonyms
"""

_TAXONOMY_EXTRACT_FORMAT = """
## Output Format

Return a JSON object with the following structure:

```json
{{
  "taxonomy": {{
    "name": "Root Category",
    "children": [
      {{
        "name": "Subcategory 1",
        "description": "Optional description",
        "children": []
      }}
    ]
  }}
}}
```

## Domain-Specific Guidelines

Add specific extraction rules for the {domain} domain here:
- What are the expected top-level categories?
- How deep should the hierarchy typically go?
- Are there standard classification schemes to follow?

---

Now extract the taxonomy from the following text:
"""

_TAXONOMY_CLUSTER_HEADER = """# Taxonomy Clustering Prompt for {domain_title} Domain
#
# This prompt guides the LLM to cluster and merge multiple taxonomy
# extractions into a unified structure.
#
# Customize this prompt for your specific domain requirements.

You are an expert taxonomist specializing in the {domain} domain.
Your task is to merge and cluster multiple taxonomy extractions into
a unified, deduplicated hierarchy.

## Instructions

1. **Identify Duplicates**: Find categories that represent the same concept
   but may have different names or slightly different structures.

2. **Merge Hierarchies**: Combine overlapping hierarchies into a single
   coherent structure.

3. **Resolve Conflicts**: When categories conflict:
   - Prefer more specific/descriptive names
   - Merge children from both versions
   - Preserve the most complete metadata

4. **Maintain Consistency**: Ensure the final taxonomy:
   - Has consistent depth across branches
   - Uses uniform naming conventions
   - Has no orphaned categories
"""

_TAXONOMY_CLUSTER_FORMAT = """
## Output Format

Return a JSON object with the merged taxonomy:

```json
{{
  "taxonomy": {{
    "name": "Root Category",
    "children": [
      {{
        "name": "Merged Subcategory",
        "description": "Combined description",
        "sources": ["extraction_1", "extraction_2"],
        "children": []
      }}
    ]
  }}
}}
```

## Domain-Specific Guidelines

Add specific clustering rules for the {domain} domain here:
- How should similar categories be identified?
- What's the preferred naming when merging?
- Are there canonical category names to use?

---

Now cluster and merge the following taxonomy extractions:
"""


class TemplateRenderer:
    """Renders templates for domain initialization.

    Provides methods to generate configuration files and prompt templates
    customized for specific domains and engine configurations.
    """

    def render_config(
        self,
        domain: str,
        engines: list[str],
        model: str | None = None,
        config_mode: str = "minimal",
    ) -> str:
        """Render a domain configuration file.

        Args:
            domain: Domain name
            engines: List of engines being configured
            model: LLM model to use (defaults to google-gla:gemini-2.5-pro)
            config_mode: "minimal" (default, only llm section) or "maximum" (full config)

        Returns:
            YAML configuration file content as string
        """
        assert domain, "Domain must not be empty"
        assert engines, "Engines must not be empty"
        assert config_mode in ("minimal", "maximum"), "config_mode must be 'minimal' or 'maximum'"

        if config_mode == "maximum":
            return self._render_maximum_config(domain, engines)
        return self._render_minimal_config(domain, engines, model)

    def _render_minimal_config(self, domain: str, engines: list[str], model: str | None) -> str:
        """Generate minimal config with only LLM settings.

        Args:
            domain: Domain name
            engines: List of engines being configured
            model: LLM model to use

        Returns:
            Minimal YAML configuration content
        """
        assert domain, "Domain must not be empty"
        assert engines, "Engines must not be empty"

        model = model or DEFAULT_MODEL
        engine_list = ", ".join(engines)

        sections = [
            "# yaml-language-server: $schema=https://raw.githubusercontent.com/DATA-AI-Service-Line/Taxonomy-Ontology-Accelerator/main/schemas/ontology-config.schema.json",
            f"# Domain configuration for {domain}",
            f"# Engines: {engine_list}",
            "#",
            "# This is a MINIMAL configuration with only LLM settings.",
            "# All other settings use defaults from:",
        ]

        # Add engine-specific default config references
        if "ontology" in engines:
            sections.append("#   - Pydantic defaults in config.py (ontology engine)")
        if "taxonomy" in engines:
            sections.append("#   - domains/{domain}/config.yaml (taxonomy engine)")

        sections.extend(
            [
                "#",
                "# To see all available settings, run:",
                f"#   toa init --domain {domain} --force",
                "",
                "llm:",
                f"  model: {model}",
                f"  max_tokens: {DEFAULT_MAX_TOKENS}",
                "",
            ]
        )

        return "\n".join(sections)

    def _render_maximum_config(self, domain: str, engines: list[str]) -> str:
        """Generate maximum config by copying full default configurations.

        For mixed engines (both taxonomy and ontology), combines both configs.
        For single engine, uses only that engine's config.

        Args:
            domain: Domain name
            engines: List of engines being configured

        Returns:
            Full YAML configuration content
        """
        assert domain, "Domain must not be empty"
        assert engines, "Engines must not be empty"

        # Determine which config(s) to use
        has_ontology = "ontology" in engines
        has_taxonomy = "taxonomy" in engines

        if has_ontology and not has_taxonomy:
            # Ontology only
            return self._load_ontology_full_config(domain, engines)
        if has_taxonomy and not has_ontology:
            # Taxonomy only
            return self._load_taxonomy_full_config(domain, engines)
        # Both engines - combine configs
        return self._load_combined_full_config(domain, engines)

    def _get_ontology_config_template(self) -> str:
        """Get complete ontology configuration template from config_reference.md."""
        import re
        from pathlib import Path

        import fsspec

        # Find config_reference.md relative to this file
        docs_path = (
            Path(__file__).parent.parent.parent / "docs" / "ontology" / "config_reference.md"
        )
        fs = fsspec.filesystem("file")
        assert fs.exists(str(docs_path)), f"Config reference not found: {docs_path}"

        # Read and extract YAML block
        content = docs_path.read_text(encoding="utf-8")
        yaml_pattern = r"```yaml\n(.*?)\n```"
        matches = re.findall(yaml_pattern, content, re.DOTALL)

        assert len(matches) > 0, "No YAML blocks found in config_reference.md"
        # Return the first YAML block (the full config template)
        return matches[0]

    def _load_ontology_full_config(self, domain: str, engines: list[str]) -> str:
        """
        Generate full ontology config showing all available settings.

        Note: Ontology engine now uses Pydantic defaults (no YAML file required).
        This generates a comprehensive YAML showing all available settings for documentation.
        """
        assert domain, "Domain must not be empty"
        assert engines, "Engines must not be empty"

        full_config = self._get_ontology_config_template()
        header = self._create_maximum_config_header(domain, engines, "ontology")

        # Find where actual config starts (skip empty lines)
        config_lines = full_config.split("\n")
        start_idx = next((i for i, line in enumerate(config_lines) if line.strip()), 0)

        return "\n".join(header + config_lines[start_idx:])

    def _load_taxonomy_full_config(self, domain: str, engines: list[str]) -> str:
        """Load full taxonomy config from domains/{domain}/config.yaml."""
        assert domain, "Domain must not be empty"
        assert engines, "Engines must not be empty"

        from pathlib import Path

        import fsspec

        fs = fsspec.filesystem("file")

        try:
            # Try importlib.resources first (works when installed as library)
            import importlib.resources as importlib_resources

            files = importlib_resources.files("taxonomy_ontology_accelerator")
            config_traversable = files / "resources" / "config" / "default.yaml"
            config_path = Path(str(config_traversable))

            if fs.exists(str(config_path)):
                # Successfully found via importlib.resources
                pass
            else:
                # Fall through to Path(__file__) approach
                raise FileNotFoundError("Not found via importlib.resources")

        except (ImportError, AttributeError, TypeError, FileNotFoundError):
            # Fallback to Path(__file__) for development
            config_path = (
                Path(__file__).parent.parent.parent / "resources" / "config" / "default.yaml"
            )

            if not fs.exists(str(config_path)):
                raise FileNotFoundError(
                    f"Taxonomy default config not found at: {config_path}"
                ) from None

        full_config = config_path.read_text(encoding="utf-8")

        # Replace header with domain-specific one
        header = self._create_maximum_config_header(domain, engines, "taxonomy")

        # Skip original header (first 3 lines) and add new header
        config_lines = full_config.split("\n")
        # Find where actual config starts (after comment block)
        start_idx = 0
        for i, line in enumerate(config_lines):
            if line.strip() and not line.strip().startswith("#"):
                start_idx = i
                break

        return "\n".join(header + config_lines[start_idx:])

    def _resolve_taxonomy_config_path(self):
        """Resolve path to taxonomy default config file."""
        from pathlib import Path

        import fsspec

        assert self is not None, "Self must not be None"
        fs = fsspec.filesystem("file")
        assert fs is not None, "Filesystem must not be None"
        try:
            # Try importlib.resources first (works when installed as library)
            import importlib.resources as importlib_resources

            files = importlib_resources.files("taxonomy_ontology_accelerator")
            taxonomy_traversable = files / "resources" / "config" / "default.yaml"
            taxonomy_path = Path(str(taxonomy_traversable))

            if not fs.exists(str(taxonomy_path)):
                raise FileNotFoundError("Not found via importlib.resources")

        except (ImportError, AttributeError, TypeError, FileNotFoundError):
            # Fallback to Path(__file__) for development
            taxonomy_path = (
                Path(__file__).parent.parent.parent / "resources" / "config" / "default.yaml"
            )

            if not fs.exists(str(taxonomy_path)):
                raise FileNotFoundError(
                    f"Taxonomy default config not found at: {taxonomy_path}"
                ) from None

        return taxonomy_path

    def _load_combined_full_config(self, domain: str, engines: list[str]) -> str:
        """Load combined config for both taxonomy and ontology engines."""
        assert domain, "Domain must not be empty"
        assert engines, "Engines must not be empty"

        # Load ontology config (generated from Pydantic defaults)
        ontology_config = self._load_ontology_full_config(domain, engines)

        # Load taxonomy config from YAML file
        taxonomy_path = self._resolve_taxonomy_config_path()

        # Create header
        header = self._create_maximum_config_header(domain, engines, "both")

        # Process ontology config - skip header
        ontology_lines = ontology_config.split("\n")
        ontology_start = 0
        for i, line in enumerate(ontology_lines):
            if line.strip() and not line.strip().startswith("#"):
                ontology_start = i
                break
        ontology_lines = ontology_lines[ontology_start:]

        # Load and process taxonomy-specific sections
        taxonomy_sections = self._extract_taxonomy_sections(taxonomy_path)

        # Combine all sections
        combined = header + ontology_lines + taxonomy_sections
        return "\n".join(combined)

    def _extract_taxonomy_sections(self, taxonomy_path) -> list[str]:
        """Extract taxonomy-specific sections from config."""
        import fsspec

        fs = fsspec.filesystem("file")
        assert taxonomy_path, "Taxonomy path must not be empty"
        assert fs.exists(str(taxonomy_path)), "Taxonomy path must exist"

        taxonomy_config = taxonomy_path.read_text(encoding="utf-8")

        # Build taxonomy sections header
        taxonomy_sections = [
            "",
            "# ============================================================================",
            "# TAXONOMY ENGINE SPECIFIC SETTINGS",
            "# ============================================================================",
            "",
        ]

        # Extract relevant taxonomy sections
        taxonomy_keywords = [
            "prompts:",
            "directories:",
            "output_files:",
            "clustering:",
            "extraction_cache:",
        ]
        in_taxonomy_section = False

        for line in taxonomy_config.split("\n"):
            if any(keyword in line for keyword in taxonomy_keywords):
                in_taxonomy_section = True

            if (in_taxonomy_section and line.strip() and not line.startswith("#")) or (
                in_taxonomy_section and not line.strip()
            ):
                taxonomy_sections.append(line)

        return taxonomy_sections

    def _create_maximum_config_header(
        self, domain: str, engines: list[str], config_type: str
    ) -> list[str]:
        """Create header for maximum config files.

        Args:
            domain: Domain name
            engines: List of engines
            config_type: "ontology", "taxonomy", or "both"
        """
        assert domain, "Domain must not be empty"
        assert engines, "Engines must not be empty"

        engine_list = ", ".join(engines)

        header = [
            "# yaml-language-server: $schema=https://raw.githubusercontent.com/DATA-AI-Service-Line/Taxonomy-Ontology-Accelerator/main/schemas/ontology-config.schema.json",
            f"# Domain configuration for {domain}",
            f"# Engines: {engine_list}",
            "#",
            "# This is a FULL configuration with all available settings.",
            "# Customize as needed for your domain.",
            "#",
        ]

        if config_type == "ontology":
            header.extend(
                [
                    "# Source: Pydantic defaults in config.py (ontology engine)",
                ]
            )
        elif config_type == "taxonomy":
            header.append("# Source: domains/{domain}/config.yaml (taxonomy engine)")
        else:  # both
            header.extend(
                [
                    "# Sources:",
                    "#   - Pydantic defaults in config.py (ontology engine)",
                    "#   - domains/{domain}/config.yaml (taxonomy engine)",
                ]
            )

        header.extend(
            [
                "#",
                "# To switch back to basic config, run:",
                f"#   toa init --domain {domain} --basic --force",
                "",
            ]
        )

        return header

    def render_prompt(self, template_type: str, domain: str) -> str:
        """Render a prompt template file.

        Args:
            template_type: Type of prompt ("ontology", "taxonomy_extract", "taxonomy_cluster")
            domain: Domain name for customization

        Returns:
            Prompt template content as string
        """
        assert template_type, "Template type must not be empty"
        assert domain, "Domain must not be empty"

        if template_type == "ontology":
            return self._render_ontology_prompt(domain)
        if template_type == "taxonomy_extract":
            return self._render_taxonomy_extract_prompt(domain)
        if template_type == "taxonomy_cluster":
            return self._render_taxonomy_cluster_prompt(domain)
        if template_type == "research_system":
            return self._render_research_system_prompt(domain)
        if template_type == "research_user":
            return self._render_research_user_prompt(domain)

        raise ValueError(f"Unknown template type: {template_type}")

    def _render_ontology_prompt(self, domain: str) -> str:
        """Render ontology extraction prompt template."""
        assert domain, "Domain must not be empty"
        assert isinstance(domain, str), "Domain must be a string"

        header = _ONTOLOGY_PROMPT_HEADER.format(domain=domain, domain_title=domain.title())
        footer = _ONTOLOGY_PROMPT_FORMAT.format(domain=domain)
        return header + footer

    def _render_taxonomy_extract_prompt(self, domain: str) -> str:
        """Render taxonomy extraction prompt template."""
        assert domain, "Domain must not be empty"
        assert isinstance(domain, str), "Domain must be a string"

        header = _TAXONOMY_EXTRACT_HEADER.format(domain=domain, domain_title=domain.title())
        footer = _TAXONOMY_EXTRACT_FORMAT.format(domain=domain)
        return header + footer

    def _render_taxonomy_cluster_prompt(self, domain: str) -> str:
        """Render taxonomy clustering prompt template."""
        assert domain, "Domain must not be empty"
        assert isinstance(domain, str), "Domain must be a string"

        header = _TAXONOMY_CLUSTER_HEADER.format(domain=domain, domain_title=domain.title())
        footer = _TAXONOMY_CLUSTER_FORMAT.format(domain=domain)
        return header + footer

    def _render_research_system_prompt(self, domain: str) -> str:
        """Render research system prompt template (empty by default, uses built-in)."""
        assert domain, "Domain must not be empty"
        assert isinstance(domain, str), "Domain must be a string"

        return f"""# Research System Prompt for {domain.title()} Domain
#
# This file customizes the LLM system prompt for generating web search queries.
# If this file is empty or contains only comments, the default system prompt is used.
#
# Default behavior: The LLM acts as a research assistant generating diverse
# search queries to discover ontologies, taxonomies, and domain knowledge.
#
# To customize, add your system prompt below (remove the # comment markers):
# You are a specialized research assistant for the {domain} domain...
"""

    def _render_research_user_prompt(self, domain: str) -> str:
        """Render research user prompt template (empty by default, uses built-in)."""
        assert domain, "Domain must not be empty"
        assert isinstance(domain, str), "Domain must be a string"

        return f"""# Research User Prompt Template for {domain.title()} Domain
#
# This file customizes the LLM user prompt for generating web search queries.
# If this file is empty or contains only comments, the default template is used.
#
# Available placeholders:
#   {{domain}} - The domain name (e.g., "{domain}")
#   {{num_queries}} - Number of queries to generate (from config)
#
# Default template generates queries for ontologies, classifications, and key concepts.
#
# To customize, add your prompt template below (remove the # comment markers):
# Generate {{num_queries}} search queries to research {domain} focusing on...
"""
