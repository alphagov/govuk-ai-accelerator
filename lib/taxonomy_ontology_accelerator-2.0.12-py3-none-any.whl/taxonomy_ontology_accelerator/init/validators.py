"""
Validation utilities for domain initialization.

Provides validation functions for domain names and configuration values.
"""

import re

# Constants for domain name validation
MIN_DOMAIN_LENGTH = 2
MAX_DOMAIN_LENGTH = 64
# Pre-compiled pattern for domain name validation
# Pattern: starts with lowercase letter, followed by lowercase letters, numbers, underscores, hyphens
DOMAIN_NAME_PATTERN_STRING = r"^[a-z][a-z0-9_-]*$"

# Constants for model name validation
MIN_MODEL_LENGTH = 3
MAX_MODEL_LENGTH = 128

# Reserved names that cannot be used as domain names
RESERVED_NAMES = frozenset(
    {
        "init",
        "doctor",
        "config",
        "help",
        "version",
        "test",
        "tests",
        "output",
        "domains",
        "taxonomy",
        "ontology",
        "tagging",
        "commons",
        "scripts",
        "docs",
        "site",
        ".git",
        ".github",
        "__pycache__",
    }
)


def validate_domain_name(domain: str) -> str | None:
    """Validate a domain name for use as a project folder.

    Args:
        domain: The domain name to validate

    Returns:
        None if valid, error message string if invalid

    Validation rules:
    - Must be 2-64 characters long
    - Must start with a lowercase letter
    - Can only contain lowercase letters, numbers, underscores, and hyphens
    - Cannot be a reserved name
    - Cannot contain path traversal characters

    Examples:
        >>> validate_domain_name("travel")  # Valid
        None
        >>> validate_domain_name("healthcare_v2")  # Valid
        None
        >>> validate_domain_name("Travel")  # Invalid - uppercase
        "Domain name must start with a lowercase letter..."
        >>> validate_domain_name("a")  # Invalid - too short
        "Domain name must be between 2 and 64 characters..."
    """
    assert domain is not None, "Domain must not be None"
    assert isinstance(domain, str), "Domain must be a string"

    # Check for empty string
    if not domain or not domain.strip():
        return "Domain name cannot be empty"

    return _validate_domain_name_rules(domain.strip())


def _validate_domain_name_rules(domain: str) -> str | None:
    """Apply validation rules to a non-empty domain name."""
    assert domain, "Domain must not be empty at this point"
    assert isinstance(domain, str), "Domain must be a string"

    # Check length constraints
    if len(domain) < MIN_DOMAIN_LENGTH:
        return f"Domain name must be at least {MIN_DOMAIN_LENGTH} characters long"
    if len(domain) > MAX_DOMAIN_LENGTH:
        return f"Domain name must be at most {MAX_DOMAIN_LENGTH} characters long"

    # Check for path traversal
    if ".." in domain or "/" in domain or "\\" in domain:
        return "Domain name cannot contain path traversal characters (.. / \\)"

    # Check pattern (lowercase start, alphanumeric + underscore/hyphen)
    if not re.match(DOMAIN_NAME_PATTERN_STRING, domain):
        return (
            "Domain name must start with a lowercase letter and contain only "
            "lowercase letters, numbers, underscores, and hyphens"
        )

    # Check reserved names
    if domain.lower() in RESERVED_NAMES:
        return f"'{domain}' is a reserved name and cannot be used as a domain name"

    return None
