#!/usr/bin/env python3
"""
Main CLI entry point for the Taxonomy-Ontology-Accelerator.

Provides a unified CLI interface with commands:
    toa extract    - Extract knowledge graphs from text
    toa export     - Export ontology to OWL/RDF format
    toa info       - Show ontology statistics
    toa research   - Research domain using web search
    toa visualize  - Visualize ontology in browser
    toa init       - Initialize a new domain project
    toa doctor     - Verify setup and configuration

Examples:
    # Initialize a new domain
    toa init --domain travel

    # Ontology commands
    toa extract --domain travel
    toa export --domain travel --format turtle

    # Utility commands
    toa doctor

This module can be used in three ways:
    1. As CLI: `toa <command>` (when installed via pip/uv)
    2. As module: `python -m taxonomy_ontology_accelerator <command>`
    3. As library: `from taxonomy_ontology_accelerator.cli import app`
"""

from pathlib import Path

import typer
from rich.console import Console

from taxonomy_ontology_accelerator.commons.cli_completion import (
    complete_domain,
)
from taxonomy_ontology_accelerator.ontology_engine.cli import (
    export,
    extract,
    info,
    research,
    verify_alignment,
    visualize,
)
from taxonomy_ontology_accelerator.web.cli import app as web_app

__version__ = "2.0.0"
_MIN_VERSION_PARTS = 2  # Semantic versioning requires at least major.minor

# Create the main app with examples in epilog for cliqa compliance
app = typer.Typer(
    help=(
        "Turn messy text into organized knowledge graphs. "
        "AI-powered extraction from .txt, .json files and directories. "
        "Outputs structured JSON files."
    ),
    no_args_is_help=True,
    invoke_without_command=True,
    context_settings={"help_option_names": ["--help", "-h"]},
    rich_markup_mode="rich",
    epilog=(
        "GETTING STARTED:\n\n"
        "  1. toa init --domain travel\n"
        "     Initialize a new domain project with config and prompts\n\n"
        "  2. toa doctor\n"
        "     Verify setup and API keys are configured\n\n"
        "  3. toa extract --domain travel\n"
        "     Build knowledge graph -> creates graph.json, schema.json\n\n"
        "EXAMPLES:\n\n"
        "  toa init --domain healthcare\n"
        "  toa doctor\n"
        "  toa extract --domain travel --output ./out/\n"
        "  toa export --domain travel --format turtle\n\n"
        "Use 'toa COMMAND --help' for all options. Large datasets may take several minutes."
    ),
)
console = Console()

# Register ontology commands at root level
app.command()(extract)
app.command()(export)
app.command()(info)
app.command()(research)
app.command()(visualize)
app.command(name="verify-alignment")(verify_alignment)


# Deprecated ontology subcommand - provide helpful migration message
@app.command(hidden=True)
def ontology(ctx: typer.Context):
    """Deprecated: ontology commands are now at root level."""
    assert console is not None, "Console must be initialized"
    assert ctx is not None, "Context must be provided"

    console.print("[bold yellow]⚠ Command structure changed![/bold yellow]")
    console.print()
    console.print("The 'ontology' subcommand has been removed.")
    console.print("Commands are now available directly at the root level:")
    console.print()
    console.print("  [cyan]toa extract[/cyan]    (was: toa ontology extract)")
    console.print("  [cyan]toa export[/cyan]     (was: toa ontology export)")
    console.print("  [cyan]toa info[/cyan]       (was: toa ontology info)")
    console.print("  [cyan]toa research[/cyan]   (was: toa ontology research)")
    console.print("  [cyan]toa visualize[/cyan]  (was: toa ontology visualize)")
    console.print()
    console.print("Run [cyan]toa --help[/cyan] to see all available commands.")
    raise typer.Exit(1)


# Add web subcommand
app.add_typer(
    web_app,
    name="web",
    help="Web visualization server commands",
)


def version_callback(value: bool):
    """Print version and exit."""
    assert __version__, "Version string must not be empty"
    assert len(__version__.split(".")) >= _MIN_VERSION_PARTS, (
        "Version must have at least major.minor format"
    )

    if value:
        console.print(f"toa version {__version__}")
        raise typer.Exit(0)


@app.callback(invoke_without_command=True)
def main(
    _ctx: typer.Context,
    _version: bool = typer.Option(
        False,
        "--version",
        "-V",
        help="Show version and exit",
        callback=version_callback,
        is_eager=True,
    ),
):
    """
    Turn messy text into organized knowledge graphs.

    AI-powered extraction from .txt, .json files and directories.
    Outputs structured JSON files.

    GETTING STARTED:

      1. toa init --domain travel
         Initialize a new domain project with config and prompts

      2. toa doctor
         Verify setup and API keys are configured

      3. toa extract --domain travel
         Build knowledge graph -> creates graph.json, schema.json

    EXAMPLES:

      toa init --domain healthcare
      toa doctor
      toa extract --domain travel --output ./out/
      toa export --domain travel --format turtle

    Use 'toa COMMAND --help' for all options. Large datasets may take several minutes.
    """
    assert app.registered_commands or app.registered_groups, (
        "At least one command or group must be registered"
    )
    assert console is not None, "Console must be initialized"


# =============================================================================
# DOCTOR COMMAND
# =============================================================================


@app.command()
def doctor():
    """
    Verify setup, API keys, and check for common configuration issues.

    Run this command first to ensure your environment is properly configured.

    Checks:
    - Python version compatibility
    - Required API keys (GEMINI_API_KEY, OPENAI_API_KEY, etc.)
    - Configuration files exist and are valid
    - Output directory permissions
    - Optional dependencies (boto3, neo4j, etc.)

    EXAMPLES:

    toa doctor
    """
    assert console is not None, "Console must be initialized"
    assert app is not None, "App must be initialized"

    from taxonomy_ontology_accelerator.commons.doctor import run_doctor_checks

    run_doctor_checks()


# =============================================================================
# INIT COMMAND
# =============================================================================


@app.command()
def init(
    domain: str = typer.Argument(help="Domain name", autocompletion=complete_domain),
    output_dir: Path = typer.Option(
        Path.cwd() / "domains",
        "--output",
        "-o",
        help="Output directory for domain files (default: ./domains)",
    ),
    model: str | None = typer.Option(
        None, "--model", "-m", help="LLM model name (default: google-gla:gemini-2.5-pro)"
    ),
    basic_config: bool = typer.Option(
        False,
        "--basic/--full",
        help="Use basic config (LLM only) or full config with all settings (default: full)",
    ),
    force: bool = typer.Option(False, "--force", "-F", help="Force overwrite existing files"),
    dry_run: bool = typer.Option(
        False, "--dry-run", help="Preview changes without creating files (dry run mode)"
    ),
):
    """
    Initialize a new domain project with configuration and prompt files.

    Creates config.yaml, prompts/, and input/ directories.

    By default, creates FULL config with all available settings.
    Use --basic to generate basic config with only LLM settings.

    After initialization, consider running 'toa research --domain <name>'
    to get AI-powered recommendations for what to research in your domain.

    EXAMPLES:

    toa init travel                               # Full config (default)
    toa init healthcare --basic                   # Basic config with only LLM
    toa init travel --model openai:gpt-4o         # Full config with custom model
    """
    assert console is not None, "Console must be initialized"
    assert domain, "Domain must be provided"
    result = _run_init(domain, output_dir, model, basic_config, force, dry_run)
    _handle_init_result(result, dry_run)


def _run_init(
    domain: str,
    output_dir: Path,
    model: str | None,
    basic_config: bool,
    force: bool,
    dry_run: bool,
):
    """Run the domain initialization."""
    assert domain, "Domain must not be empty"
    assert output_dir is not None, "Output directory must not be None"

    from taxonomy_ontology_accelerator.init import DomainInitializer

    initializer = DomainInitializer()
    return initializer.init_domain(
        domain=domain,
        output_dir=output_dir,
        model=model,
        basic_config=basic_config,
        force=force,
        dry_run=dry_run,
    )


def _handle_init_result(result, dry_run: bool) -> None:
    """Handle the result of domain initialization."""
    assert result is not None, "Result must not be None"
    assert console is not None, "Console must be initialized"

    if dry_run:
        console.print("[bold blue]Dry run - no files created[/bold blue]")
        console.print()

    if result.success:
        _display_init_success(result, dry_run)
    else:
        _display_init_failure(result)
        raise typer.Exit(1)


def _display_init_success(result, dry_run: bool) -> None:
    """Display success message for init command."""
    assert result is not None, "Result must not be None"
    assert hasattr(result, "domain"), "Result must have domain attribute"

    action = "Would create" if dry_run else "Created"
    console.print(f"[bold green]✓ Domain '{result.domain}' initialized![/bold green]")
    console.print()

    _display_created_items(result, action)
    _display_skipped_items(result)

    if not dry_run:
        _display_next_steps(result)


def _display_created_items(result, action: str) -> None:
    """Display created directories and files."""
    assert result is not None, "Result must not be None"
    assert action, "Action must not be empty"

    if result.created_dirs:
        console.print(f"[cyan]{action} directories:[/cyan]")
        for dir_path in result.created_dirs:
            console.print(f"  [dim]{dir_path}[/dim]")
        console.print()

    if result.created_files:
        console.print(f"[cyan]{action} files:[/cyan]")
        for file_path in result.created_files:
            console.print(f"  [dim]{file_path}[/dim]")
        console.print()


def _display_skipped_items(result) -> None:
    """Display skipped files."""
    assert result is not None, "Result must not be None"
    assert hasattr(result, "skipped_files"), "Result must have skipped_files attribute"

    if result.skipped_files:
        console.print("[yellow]Skipped (already exist):[/yellow]")
        for file_path in result.skipped_files:
            console.print(f"  [dim]{file_path}[/dim]")
        console.print()


def _display_next_steps(result) -> None:
    """Display next steps after initialization."""
    assert result is not None, "Result must not be None"
    assert hasattr(result, "domain_path"), "Result must have domain_path attribute"

    console.print("[bold]Next steps:[/bold]")
    console.print(f"  1. Add input data to [cyan]{result.domain_path}/input/[/cyan]")
    console.print(f"  2. Customize prompts in [cyan]{result.domain_path}/prompts/[/cyan]")
    console.print("  3. Run [cyan]toa doctor[/cyan] to verify setup")
    console.print(f"  4. Run [cyan]toa extract --domain {result.domain}[/cyan]")


def _display_init_failure(result) -> None:
    """Display failure message for init command."""
    assert result is not None, "Result must not be None"
    assert hasattr(result, "errors"), "Result must have errors attribute"

    console.print(f"[bold red]✗ Failed to initialize domain '{result.domain}'[/bold red]")
    console.print()

    for error in result.errors:
        console.print(f"[red]  {error}[/red]")


def run_cli():
    """Entry point function for the CLI.

    This function is called by the `toa` command when installed via pip/uv.
    It can also be called directly for programmatic CLI invocation.

    Returns:
        Exit code (0 for success, non-zero for errors)
    """
    assert app is not None, "App must be initialized"
    assert callable(app), "App must be callable"
    try:
        app()
        return 0
    except typer.Exit as e:
        return e.exit_code
    except KeyboardInterrupt:
        console.print("\n[yellow]Interrupted by user[/yellow]")
        return 130  # Standard exit code for SIGINT
    except SystemExit as e:
        return e.code if e.code is not None else 1
    except Exception as e:
        console.print(f"[bold red]Error: {e}[/bold red]")
        return 1


if __name__ == "__main__":
    run_cli()
