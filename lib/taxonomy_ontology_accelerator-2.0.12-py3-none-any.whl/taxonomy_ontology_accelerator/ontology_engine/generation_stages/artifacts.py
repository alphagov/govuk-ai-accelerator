import json
from collections.abc import Iterable
from pathlib import Path
from typing import Any

import fsspec
from fsspec import AbstractFileSystem
from pydantic import BaseModel


def write_intermediate_jsonl(
    *,
    output_dir: Path | str,
    stage_name: str,
    artifact_name: str,
    rows: Iterable[BaseModel | dict[str, Any]],
    fs: AbstractFileSystem | None = None,
) -> str:
    path = f"{str(output_dir).rstrip('/')}/intermediate/{stage_name}/{artifact_name}"

    fs = fs or fsspec.filesystem("file")
    parent = path.rsplit("/", 1)[0]
    fs.makedirs(parent, exist_ok=True)
    with fs.open(path, "w", encoding="utf-8") as file:
        _write_rows(file, rows)

    return path


def _write_rows(file: Any, rows: Iterable[BaseModel | dict[str, Any]]) -> None:
    for row in rows:
        if isinstance(row, BaseModel):
            file.write(row.model_dump_json())
        else:
            file.write(json.dumps(row, ensure_ascii=False))
        file.write("\n")
