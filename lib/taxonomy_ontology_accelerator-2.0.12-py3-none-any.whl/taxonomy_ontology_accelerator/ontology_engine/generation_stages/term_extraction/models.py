from typing import Literal

from pydantic import BaseModel, Field


class TermOccurrence(BaseModel):
    sentence: str
    documents: list[str] = Field(default_factory=list)


class ExtractedTerm(BaseModel):
    term: str
    type_hint: Literal["class", "individual"]
    occurrences: list[TermOccurrence] = Field(default_factory=list)
    source_urls: list[str] = Field(default_factory=list)
    batch_id: int | None = None


class ExtractedTerms(BaseModel):
    """Prompt 9 terms wrapped in an object for Bedrock-compatible schemas."""

    terms: list[ExtractedTerm] = Field(default_factory=list)
