from dataclasses import dataclass
from typing import Any

from pydantic_ai import Agent

from taxonomy_ontology_accelerator.ontology_engine.config.config import OntologyConfig
from taxonomy_ontology_accelerator.ontology_engine.core.extraction_pipeline import ExtractionState
from taxonomy_ontology_accelerator.ontology_engine.core.extraction_stages import (
    _accumulate_usage,
    _get_model_instance,
)
from taxonomy_ontology_accelerator.ontology_engine.generation_stages.artifacts import (
    write_intermediate_jsonl,
)
from taxonomy_ontology_accelerator.ontology_engine.generation_stages.term_extraction.models import (
    ExtractedTerm,
    ExtractedTerms,
)
from taxonomy_ontology_accelerator.ontology_engine.generation_stages.term_extraction.prompts import (
    TERM_EXTRACTION_PROMPT_9,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.llm_usage import (
    get_or_estimate_llm_result_usage,
)


@dataclass(frozen=True)
class TermExtractionBatch:
    batch_id: int
    source_text: str
    sources: list[str]


async def run_term_extraction_path(state: ExtractionState) -> list[ExtractedTerm]:
    config = state.config
    assert config is not None

    term_agent = _create_term_agent(config)
    all_terms: list[ExtractedTerm] = []

    for batch in _build_batches(state):
        result = await term_agent.run(batch.source_text)
        _record_usage(state, result, f"{TERM_EXTRACTION_PROMPT_9}\n\n{batch.source_text}")

        batch_terms = [
            term.model_copy(update={"batch_id": batch.batch_id, "source_urls": batch.sources})
            for term in result.output.terms
        ]
        all_terms.extend(batch_terms)

    _write_terms_artifact(state, all_terms)

    return all_terms


def _create_term_agent(config: OntologyConfig) -> Agent[None, ExtractedTerms]:
    agent = Agent(
        _get_model_instance(config),
        output_type=ExtractedTerms,
        retries=config.llm.retries,
        output_retries=config.llm.retries,
        model_settings=_build_model_settings(config),
    )

    @agent.system_prompt
    def instructions(_ctx) -> str:
        return TERM_EXTRACTION_PROMPT_9

    return agent


def _build_model_settings(config: OntologyConfig) -> dict[str, Any] | None:
    settings: dict[str, Any] = {}
    if config.llm.max_tokens is not None:
        settings["max_tokens"] = config.llm.max_tokens
    if config.llm.temperature is not None:
        settings["temperature"] = config.llm.temperature
    return settings or None


def _build_batches(state: ExtractionState) -> list[TermExtractionBatch]:
    config = state.config
    assert config is not None

    batch_size = max(1, config.batching.chunks_per_batch)
    batches: list[TermExtractionBatch] = []

    for start in range(0, len(state.chunks), batch_size):
        chunks = state.chunks[start : start + batch_size]
        sources = state.chunk_sources[start : start + batch_size] if state.chunk_sources else []
        source_text = "\n\n---DOCUMENT_SEPARATOR---\n\n".join(
            f"SOURCE_URLS: {sources[index] if index < len(sources) else 'unknown_source'}\n{chunk}"
            for index, chunk in enumerate(chunks)
        )
        batches.append(
            TermExtractionBatch(
                batch_id=len(batches) + 1,
                source_text=source_text,
                sources=sources,
            )
        )

    return batches


def _write_terms_artifact(state: ExtractionState, terms: list[ExtractedTerm]) -> None:
    if state.output_dir is None:
        return

    write_intermediate_jsonl(
        output_dir=state.output_dir,
        stage_name="term_extraction",
        artifact_name="terms.raw.jsonl",
        rows=terms,
        fs=state.output_fs or state.fs,
    )


def _record_usage(state: ExtractionState, result, prompt: str) -> None:
    state.llm_calls += 1
    assert state.config is not None
    usage = get_or_estimate_llm_result_usage(result, prompt, state.config)
    if usage is not None:
        _accumulate_usage(state, [usage])
