from collections.abc import Callable
from pathlib import Path

from taxonomy_ontology_accelerator.ontology_engine.generation_stages.term_extraction.models import (
    ExtractedTerm,
    TermOccurrence,
)

BatchCandidateContextProvider = Callable[[list[str], list[str] | None], str | None]

NO_BATCH_CANDIDATES_CONTEXT = (
    'No candidate terms match this batch. Return {"concepts": [], "relationships": []}.'
)


def build_candidate_context(terms: list[ExtractedTerm]) -> str:
    """Build batch context from Prompt 9 term candidates without embedding a base prompt."""
    return _build_context(_dedupe_terms(terms))


def build_candidate_context_for_batch(
    terms: list[ExtractedTerm],
    *,
    batch_chunks: list[str],
    batch_sources: list[str] | None,
) -> str:
    """Build candidate context scoped to terms supported by a concrete ontology batch."""
    batch_text = "\n\n".join(batch_chunks)
    source_names = _source_names(batch_sources or [])
    candidates = [
        scoped
        for term in _dedupe_terms(terms)
        if (scoped := _scope_term_to_batch(term, batch_text, source_names)) is not None
    ]
    return _build_context(candidates)


def build_candidate_context_provider(
    terms: list[ExtractedTerm],
) -> BatchCandidateContextProvider:
    """Return a provider that supplies only batch-local Prompt 9 candidates."""
    candidates = _dedupe_terms(terms)

    def provide(batch_chunks: list[str], batch_sources: list[str] | None) -> str:
        context = build_candidate_context_for_batch(
            candidates,
            batch_chunks=batch_chunks,
            batch_sources=batch_sources,
        )
        return context or NO_BATCH_CANDIDATES_CONTEXT

    return provide


def has_candidate_terms(terms: list[ExtractedTerm]) -> bool:
    """Return whether Prompt 9 produced at least one non-empty candidate term."""
    return any(term.term.strip() for term in terms)


def _build_context(candidates: list[ExtractedTerm]) -> str:
    candidate_blocks = [_format_candidate(term) for term in candidates if term.term.strip()]
    if not candidate_blocks:
        return ""

    return "\n".join(
        [
            "Candidate terms extracted by the term extraction stage.",
            "Only these terms may be considered for ontology concepts:",
            "",
            *candidate_blocks,
        ]
    )


def _format_candidate(term: ExtractedTerm) -> str:
    lines = [
        f"- term: {term.term.strip()}",
        f"  type_hint: {term.type_hint}",
    ]
    sources = _compact_sources(term.source_urls)
    if sources:
        lines.append(f"  sources: {', '.join(sources)}")

    evidence = _format_evidence(term)
    if evidence:
        lines.append("  evidence:")
        lines.extend(f"    - {sentence}" for sentence in evidence)

    return "\n".join(lines)


def _format_evidence(term: ExtractedTerm) -> list[str]:
    seen: set[str] = set()
    evidence: list[str] = []
    for occurrence in term.occurrences:
        sentence = occurrence.sentence.strip()
        if not sentence:
            continue
        key = sentence.casefold()
        if key in seen:
            continue
        seen.add(key)
        evidence.append(sentence)
    return evidence


def _scope_term_to_batch(
    term: ExtractedTerm,
    batch_text: str,
    batch_source_names: set[str],
) -> ExtractedTerm | None:
    term_text = term.term.strip()
    if not term_text:
        return None

    term_in_batch = _contains_normalized(batch_text, term_text)
    if not term_in_batch:
        return None

    occurrences = [
        occurrence
        for occurrence in term.occurrences
        if _occurrence_matches_batch(occurrence, term_text, batch_source_names)
    ]
    if term.occurrences and not occurrences and not _term_sources_match(term, batch_source_names):
        return None

    sources = _filter_sources_for_batch(term.source_urls, batch_source_names)
    if not sources:
        sources = _sources_from_occurrences(occurrences, batch_source_names)

    return term.model_copy(
        update={
            "occurrences": occurrences,
            "source_urls": sources,
        }
    )


def _occurrence_matches_batch(
    occurrence: TermOccurrence,
    term_text: str,
    batch_source_names: set[str],
) -> bool:
    if not _sources_match(occurrence.documents, batch_source_names):
        return False

    sentence = occurrence.sentence.strip()
    if not sentence:
        return False

    return _contains_normalized(sentence, term_text)


def _term_sources_match(term: ExtractedTerm, batch_source_names: set[str]) -> bool:
    if not batch_source_names:
        return True
    candidate_sources = [*term.source_urls]
    for occurrence in term.occurrences:
        candidate_sources.extend(occurrence.documents)
    return _sources_match(candidate_sources, batch_source_names)


def _sources_match(candidate_sources: list[str], batch_source_names: set[str]) -> bool:
    if not batch_source_names or not candidate_sources:
        return True
    return bool(_source_names(candidate_sources) & batch_source_names)


def _filter_sources_for_batch(sources: list[str], batch_source_names: set[str]) -> list[str]:
    filtered: list[str] = []
    for source in sources:
        source_name = _source_name(source)
        if not batch_source_names or source_name in batch_source_names:
            filtered.append(source)
    return _unique_strings(filtered)


def _sources_from_occurrences(
    occurrences: list[TermOccurrence],
    batch_source_names: set[str],
) -> list[str]:
    sources: list[str] = []
    for occurrence in occurrences:
        for document in occurrence.documents:
            document_name = _source_name(document)
            if not batch_source_names or document_name in batch_source_names:
                sources.append(document)
    return _unique_strings(sources)


def _source_names(sources: list[str]) -> set[str]:
    return {_source_name(source) for source in sources if source and source.strip()}


def _source_name(source: str) -> str:
    source = source.strip()
    if not source:
        return ""
    if source.startswith(("http://", "https://")):
        return source
    return Path(source).name or source.rstrip("/").rsplit("/", 1)[-1]


def _compact_sources(sources: list[str]) -> list[str]:
    return _unique_strings(_source_name(source) for source in sources)


def _contains_normalized(text: str, needle: str) -> bool:
    return needle.strip().casefold() in text.casefold()


def _unique_strings(values) -> list[str]:
    seen: set[str] = set()
    unique: list[str] = []
    for value in values:
        if not value:
            continue
        text = str(value).strip()
        key = text.casefold()
        if not text or key in seen:
            continue
        seen.add(key)
        unique.append(text)
    return unique


def _dedupe_terms(terms: list[ExtractedTerm]) -> list[ExtractedTerm]:
    merged: dict[str, ExtractedTerm] = {}

    for term in terms:
        key = term.term.strip().casefold()
        if key not in merged:
            merged[key] = term.model_copy(update={"source_urls": _unique_strings(term.source_urls)})
            continue

        existing = merged[key]
        merged[key] = existing.model_copy(
            update={
                "occurrences": [*existing.occurrences, *term.occurrences],
                "source_urls": _unique_strings([*existing.source_urls, *term.source_urls]),
            }
        )

    return list(merged.values())
