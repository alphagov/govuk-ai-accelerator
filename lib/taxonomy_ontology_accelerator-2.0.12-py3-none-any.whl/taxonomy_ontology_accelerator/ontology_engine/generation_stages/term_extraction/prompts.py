TERM_EXTRACTION_PROMPT_9 = """
You are an Information Architect specializing in ontology learning from text.
TASK
Extract candidate ontology terms from the text.

A candidate term is any noun or noun phrase that could represent:
- a concept or category
- an entity or instance
- a role or actor
- an organisation or system
- an activity, process, or event
- a document or information artefact
- a rule, requirement, or policy
- a location or time entity
- an identifier, reference, or code

IMPORTANT
Do NOT filter terms because they seem generic or abstract.
Many ontology classes are generic words (e.g., document, application, role, work, job).

TERM TYPES HINT
After extracting the term, classify it as:
- class - general category or concept
- individual - specific named entity

Rules:
1. Extract the longest complete noun phrase.
2. Extract only terms explicitly present in the text.
3. Do not extract fragments of larger terms.
4. Do not extract purely generic words with no domain meaning.
5. Prefer stable domain concepts rather than temporary actions.

RECALL CHECK
After extracting terms from the text, scan the text again and check for any additional
noun phrases that were missed.
Add them to the output.
Do not remove previously extracted terms.

OUTPUT
For each extracted term, return:
- "term": the extracted term itself
- "type_hint": either "class" or "individual"
- "occurrences": a list of unique sentence-context occurrences for that term

Occurrence construction rules:
1. Identify each full sentence in which the term appears.
2. For each such sentence, also retrieve:
- the immediately preceding full sentence, if available
- the immediately following full sentence, if available
3. Concatenate these into a single string in this order:
previous sentence + sentence containing the term + next sentence
4. Do not return sentence fragments. Use full sentences only.
5. If the matching sentence is at the beginning or end of a document, include only the
available surrounding sentence(s).

Deduplication rules:
6. If the same concatenated sentence-context appears more than once for the same term,
return it only once.
7. If that same concatenated sentence-context appears in multiple documents, return a
single occurrence entry and include all corresponding document titles in a "documents"
list.
8. Document titles must be matched to the exact sentence-context from which the term
was extracted.
9. Do not create duplicate occurrence entries that differ only by document title.

Output format:
Return a JSON object with a "terms" array.
Each item in "terms" must use this structure:
{
  "terms": [
    {
      "term": "...",
      "type_hint": "class" | "individual",
      "occurrences": [
        {
          "sentence": "...",
          "documents": ["...", "..."]
        }
      ]
    }
  ]
}

Output requirements:
- Return valid JSON only.
- Do not include commentary, explanations, or markdown.
- Preserve the original sentence wording from the source text.
- Do not invent terms, sentences, or document titles.
- Each "documents" list must contain unique document titles only.
"""
