"""
Builder pattern for ontology extraction pipelines.

This module provides OntologyPipelineBuilder, a chainable API for composing
custom ontology extraction workflows. The builder manages ExtractionState
automatically and provides convenient methods for running stage groups.

Usage:
    # Convenience method - full pipeline in one call (recommended)
    result = OntologyPipelineBuilder.run("travel", "data.txt")

    # Custom pipeline with inspection (sync context)
    import asyncio
    builder = OntologyPipelineBuilder(domain="travel")
    builder.setup_pipeline("data.txt").extract()
    asyncio.run(builder.process())
    asyncio.run(builder.finalize())
    result = builder.build()

    # With custom agent
    from pydantic_ai.models.test import TestModel
    test_model = TestModel()
    custom_agent = Agent(test_model, output_type=ExtractionResult)
    result = OntologyPipelineBuilder.run(
        "travel",
        "data.txt",
        extraction_agent=custom_agent
    )
"""

import asyncio
import shutil
import tempfile
from contextlib import ExitStack
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Self

from pydantic_ai import Agent

from taxonomy_ontology_accelerator.commons.utils.logger import get_logger
from taxonomy_ontology_accelerator.ontology_engine.core.extraction_pipeline import (
    _initialize_checkpoint_manager,
)
from taxonomy_ontology_accelerator.ontology_engine.core.extraction_router import (
    run_configured_extraction,
)
from taxonomy_ontology_accelerator.ontology_engine.core.file_worker_pool import (
    process_files_parallel,
)
from taxonomy_ontology_accelerator.ontology_engine.core.models import (
    ExtractionResult,
    OntologyOutput,
)
from taxonomy_ontology_accelerator.ontology_engine.pipeline_stages import (
    ExtractionState,
    build_and_validate,
    build_relationships,
    chunk_input_text,
    deduplicate_entities,
    evolve_schema,
    export_owl,
    finalize_metadata,
    load_existing_data,
    merge_relationships,
    merge_with_existing,
    resolve_conflicts,
    save_output,
    setup,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.list_emitter import (
    emit_raw_entity_list,
    emit_raw_relationship_list,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.run_artifacts import (
    allocate_run_output_dir,
    capture_run_logs,
    prepare_run_snapshot,
    run_snapshot_dir_from_output_dir,
)
from taxonomy_ontology_accelerator.ontology_engine.validators import ValidationResult

__all__ = ["OntologyPipelineBuilder"]

logger = get_logger()


class _NoOpCheckpointManager:
    def is_file_completed(self, _file_path: str) -> bool:
        return False

    def mark_file_completed(self, _file_path: str) -> None:
        return None

    def mark_file_failed(self, _file_path: str) -> None:
        return None


def _parallel_worker_payload(file_state: Any, concepts: list[Any], relationships: list[Any]) -> dict[str, Any]:
    return {
        "concepts": concepts,
        "relationships": relationships,
        "llm_calls": int(getattr(file_state, "llm_calls", 0) or 0),
        "input_tokens": int(getattr(file_state, "input_tokens", 0) or 0),
        "output_tokens": int(getattr(file_state, "output_tokens", 0) or 0),
        "cache_read_tokens": int(getattr(file_state, "cache_read_tokens", 0) or 0),
        "cache_write_tokens": int(getattr(file_state, "cache_write_tokens", 0) or 0),
        "estimated_llm_input_tokens": int(
            getattr(file_state, "estimated_llm_input_tokens", 0) or 0
        ),
        "estimated_llm_output_tokens": int(
            getattr(file_state, "estimated_llm_output_tokens", 0) or 0
        ),
        "llm_usage_missing_calls": int(
            getattr(file_state, "llm_usage_missing_calls", 0) or 0
        ),
        "embedding_input_tokens": int(getattr(file_state, "embedding_input_tokens", 0) or 0),
        "embedding_output_tokens": int(getattr(file_state, "embedding_output_tokens", 0) or 0),
        "embedding_cache_read_tokens": int(
            getattr(file_state, "embedding_cache_read_tokens", 0) or 0
        ),
        "embedding_cache_write_tokens": int(
            getattr(file_state, "embedding_cache_write_tokens", 0) or 0
        ),
        "embeddings_generated": int(getattr(file_state, "embeddings_generated", 0) or 0),
    }


def _merge_parallel_worker_payload(state: ExtractionState, payload: Any) -> tuple[list[Any], list[Any]]:
    if not isinstance(payload, dict):
        concepts, relationships = payload
        return list(concepts), list(relationships)

    state.llm_calls += int(payload.get("llm_calls", 0) or 0)
    state.input_tokens += int(payload.get("input_tokens", 0) or 0)
    state.output_tokens += int(payload.get("output_tokens", 0) or 0)
    state.cache_read_tokens += int(payload.get("cache_read_tokens", 0) or 0)
    state.cache_write_tokens += int(payload.get("cache_write_tokens", 0) or 0)
    state.estimated_llm_input_tokens += int(payload.get("estimated_llm_input_tokens", 0) or 0)
    state.estimated_llm_output_tokens += int(payload.get("estimated_llm_output_tokens", 0) or 0)
    state.llm_usage_missing_calls += int(payload.get("llm_usage_missing_calls", 0) or 0)
    state.embedding_input_tokens += int(payload.get("embedding_input_tokens", 0) or 0)
    state.embedding_output_tokens += int(payload.get("embedding_output_tokens", 0) or 0)
    state.embedding_cache_read_tokens += int(payload.get("embedding_cache_read_tokens", 0) or 0)
    state.embedding_cache_write_tokens += int(payload.get("embedding_cache_write_tokens", 0) or 0)
    state.embeddings_generated += int(payload.get("embeddings_generated", 0) or 0)
    return list(payload.get("concepts", []) or []), list(payload.get("relationships", []) or [])


class OntologyPipelineBuilder:
    """
    Builder for ontology extraction pipelines.

    Provides chainable API for running extraction stages with
    automatic state management. Allows full control over pipeline
    composition while handling state flow automatically.

    The builder exposes the underlying ExtractionState via the .state
    property, allowing inspection and modification at any point.

    Example:
        # Full pipeline with validators
        result = (OntologyPipelineBuilder(domain="travel")
                  .after_extraction(EntityCountValidator(min_count=5))
                  .after_schema_evolution(SchemaConsistencyValidator())
                  .setup_pipeline("data.txt")
                  .extract()
                  .process()
                  .finalize()
                  .build())

        # Custom pipeline with inspection
        builder = OntologyPipelineBuilder(domain="travel")
        builder.setup_pipeline("data.txt").chunk()
        print(f"Created {len(builder.state.chunks)} chunks")
        builder.extract()
        asyncio.run(builder.process())
        asyncio.run(builder.finalize())
        result = builder.build()

    Attributes:
        state: ExtractionState object containing all intermediate data
    """

    def __init__(
        self,
        domain: str,
        incremental: bool = False,
        extraction_agent: Agent[None, ExtractionResult] | None = None,
        submitted_config_yaml: str | None = None,
        **kwargs,
    ):
        """
        Initialize pipeline builder with domain and options.

        Args:
            domain: Domain name for ontology (e.g., "travel", "medical")
            incremental: Whether to load and merge with existing ontology
            extraction_agent: Optional custom Agent for extraction. If not provided,
                            agent will be created in setup_agent() or extract()
            **kwargs: Additional ExtractionState parameters
        """
        assert domain is not None, "domain must not be None"
        assert isinstance(domain, str), "domain must be a string"
        assert isinstance(incremental, bool), "incremental must be a boolean"

        self.state = ExtractionState(domain=domain, incremental=incremental, **kwargs)
        self.extraction_agent: Agent[None, ExtractionResult] | None = extraction_agent
        self.extraction_prompt: str | None = None
        self._validators: dict[str, list[Any]] = {}  # Stage name -> list of validators
        self._submitted_config_yaml = submitted_config_yaml
        self._run_snapshot_dir: Path | None = None
        self._run_started_at_utc: datetime | None = None
        self._log_capture_stack: ExitStack | None = None
        self._local_stdout_log_path: Path | None = None

    # ========================================================================
    # Validator Management
    # ========================================================================

    def after_extraction(self, validator: Any) -> Self:
        """
        Add validator to run after extraction stage.

        Args:
            validator: Validator instance with validate(**kwargs) method

        Returns:
            Self for method chaining
        """
        assert validator is not None, "validator must not be None"
        assert hasattr(validator, "validate"), "validator must have validate method"

        if "extraction" not in self._validators:
            self._validators["extraction"] = []
        self._validators["extraction"].append(validator)
        return self

    def after_schema_evolution(self, validator: Any) -> Self:
        """
        Add validator to run after schema evolution stage.

        Args:
            validator: Validator instance with validate(**kwargs) method

        Returns:
            Self for method chaining
        """
        assert validator is not None, "validator must not be None"
        assert hasattr(validator, "validate"), "validator must have validate method"

        if "schema_evolution" not in self._validators:
            self._validators["schema_evolution"] = []
        self._validators["schema_evolution"].append(validator)
        return self

    def get_validators(self, stage: str) -> list[Any]:
        """
        Get validators for a specific stage.

        Args:
            stage: Stage name (e.g., "extraction", "schema_evolution")

        Returns:
            List of validators for that stage
        """
        assert stage is not None, "stage must not be None"
        assert isinstance(stage, str), "stage must be a string"
        return self._validators.get(stage, [])

    def clear_validators(self, stage: str) -> Self:
        """
        Clear validators for a specific stage.

        Args:
            stage: Stage name to clear validators for

        Returns:
            Self for method chaining
        """
        assert stage is not None, "stage must not be None"
        assert isinstance(stage, str), "stage must be a string"

        if stage in self._validators:
            self._validators[stage] = []
        return self

    def clear_all_validators(self) -> Self:
        """
        Clear all validators from all stages.

        Returns:
            Self for method chaining
        """
        assert hasattr(self, "_validators"), "Must have _validators attribute"
        assert isinstance(self._validators, dict), "_validators must be a dict"
        self._validators = {}
        return self

    def _validate_result_type(self, result: Any, validator_name: str) -> None:
        """Validate that validator returned correct type."""
        assert validator_name is not None, "validator_name required"
        assert isinstance(validator_name, str), "validator_name must be string"
        if result is None:
            raise ValueError(f"Validator {validator_name} returned None")
        if not isinstance(result, ValidationResult):
            raise TypeError(f"Validator {validator_name} returned {type(result).__name__}")

    def _log_validation_success(self, validator_name: str, message: str | None) -> None:
        """Log successful validation."""
        assert validator_name is not None, "validator_name required"
        assert message is None or isinstance(message, str), "message must be string or None"
        msg = message if message else "Passed"
        logger.info(f"[Validation] ✓ {validator_name}: {msg}")

    def _build_failure_message(
        self, stage: str, validator_name: str, result: ValidationResult
    ) -> str:
        """Build error message for validation failure."""
        assert stage is not None, "stage required"
        assert validator_name is not None, "validator_name required"
        error_msg = f"Validation failed at stage '{stage}' (validator: {validator_name})"
        if result.message:
            error_msg += f": {result.message}"
        if result.details:
            error_msg += f"\nDetails: {result.details}"
        return error_msg

    def _run_validators(self, stage: str, **kwargs: Any) -> None:
        """Execute all validators for a given stage."""
        assert stage is not None, "stage must not be None"
        assert isinstance(stage, str), "stage must be a string"

        validators = self.get_validators(stage)
        if not validators:
            return

        logger.debug(f"[Validation] Running {len(validators)} validator(s) for stage: {stage}")

        for idx, validator in enumerate(validators, start=1):
            assert validator is not None, f"Validator {idx} must not be None"
            assert hasattr(validator, "validate"), f"Validator {idx} must have validate method"

            validator_name = validator.__class__.__name__
            logger.debug(
                f"[Validation] Running validator {idx}/{len(validators)}: {validator_name}"
            )

            try:
                result = validator.validate(**kwargs)
                self._validate_result_type(result, validator_name)

                if result.success:
                    self._log_validation_success(validator_name, result.message)
                else:
                    if result.details:
                        logger.error(f"[Validation] ✗ {validator_name}: {result.message}")
                        logger.error(f"[Validation] Details: {result.details}")
                    else:
                        logger.error(f"[Validation] ✗ {validator_name}: {result.message}")
                    raise ValueError(self._build_failure_message(stage, validator_name, result))

            except ValueError:
                raise
            except Exception as e:
                error_msg = f"Validator {validator_name} raised unexpected exception: {e!s}"
                logger.error(f"[Validation] ✗ {validator_name}: {error_msg}")
                raise ValueError(error_msg) from e

        logger.debug(f"[Validation] All {len(validators)} validator(s) passed for stage: {stage}")

    # ========================================================================
    # Setup (Stages 1-6, Grouped)
    # ========================================================================

    def setup_pipeline(
        self,
        input_path: str | Path,
        output_dir: str | Path | None = None,
        prompt_path: str | Path | None = None,
    ) -> Self:
        """
        Complete setup for ontology extraction.

        This is the main setup method that handles all core configuration:
        - Load configuration
        - Validate parameters
        - Load domain prompt (optional)
        - Load input content
        - Setup output directory

        Args:
            input_path: Path to input file or directory
            output_dir: Custom output directory (optional)
            prompt_path: Path to domain prompt file (optional)

        Returns:
            Self for method chaining

        Example:
            builder = (OntologyPipelineBuilder(domain="travel")
                      .setup_pipeline("data.txt")
                      .extract()
                      .process()
                      .finalize())
        """
        assert self.state is not None, "state must be initialized"
        assert input_path is not None, "input_path must not be None"

        setup(self.state, input_path, output_dir, prompt_path)
        self._initialize_run_artifacts()
        return self

    def _initialize_run_artifacts(self) -> None:
        assert self.state is not None, "state must be initialized"
        if self._run_snapshot_dir is not None:
            return

        assert self.state.output_dir is not None, "output_dir must be initialized"
        assert self.state.fs is not None, "filesystem must be initialized"
        output_fs = self.state.output_fs or self.state.fs

        self.state.output_dir = allocate_run_output_dir(
            self.state.output_dir,
            self.state.domain,
            output_fs,
        )
        if self.state.config is not None:
            self.state.config._runtime_output_dir = str(self.state.output_dir)

        # Reinitialize checkpoint manager now that state.output_dir points to the
        # run-specific directory (setup_output_directory created it at the base dir).
        if self.state.config and self.state.config.checkpointing.enabled:
            _initialize_checkpoint_manager(self.state, self.state.config)

        prepare_run_snapshot(
            run_snapshot_dir_from_output_dir(self.state.output_dir),
            output_fs,
            input_path=self.state.input_path,
            prompt_path=self.state.prompt_path,
            config_text=self._submitted_config_yaml,
            prompt_text=self.state.domain_prompt,
        )

        run_snapshot_dir = Path(tempfile.mkdtemp(prefix=f"ontology_run_{self.state.domain}_"))
        self._run_snapshot_dir = run_snapshot_dir
        self._run_started_at_utc = datetime.now(UTC)

        stdout_log = run_snapshot_dir / "stdout.log"
        self._local_stdout_log_path = stdout_log

        self._log_capture_stack = ExitStack()
        self._log_capture_stack.enter_context(capture_run_logs(stdout_log))

    def _finalize_run_artifacts(self) -> None:
        assert self.state is not None, "state must be initialized"
        if self._run_snapshot_dir is None or self._run_started_at_utc is None:
            return

        run_snapshot_dir = self._run_snapshot_dir
        started_at_utc = self._run_started_at_utc
        ended_at_utc = datetime.now(UTC)
        stdout_log = self._local_stdout_log_path or (run_snapshot_dir / "stdout.log")

        try:
            if self._log_capture_stack is not None:
                self._log_capture_stack.close()
                self._log_capture_stack = None

            from taxonomy_ontology_accelerator.ontology_engine.cli_helpers import (
                OntologyCLIHelpers,
            )

            csv_path = OntologyCLIHelpers._run_bedrock_cost_script(
                run_snapshot_dir=run_snapshot_dir,
                start_time_utc=started_at_utc,
                end_time_utc=ended_at_utc,
                config=self.state.config,
                state=self.state,
            )

            output_dir = self.state.output_dir
            fs = self.state.output_fs or self.state.fs
            if output_dir is not None and fs is not None:
                output_str = str(output_dir).rstrip("/")
                fs.makedirs(output_str, exist_ok=True)

                stdout_remote = f"{output_str}/stdout.log"
                fs.put_file(str(stdout_log), stdout_remote)
                logger.info(f"[Artifacts] Uploaded: {stdout_remote}")

                if csv_path is not None:
                    csv_remote = f"{output_str}/bedrock_costs.csv"
                    fs.put_file(str(csv_path), csv_remote)
                    logger.info(f"[Artifacts] Uploaded: {csv_remote}")

                try:
                    shutil.rmtree(run_snapshot_dir)
                except Exception as cleanup_exc:
                    logger.debug(f"[Artifacts] Failed to clean up temp dir {run_snapshot_dir}: {cleanup_exc}")
        except Exception as exc:
            logger.warning(f"[Artifacts] Failed to finalize run artifacts: {exc}")

    def load_existing(self) -> Self:
        """
        Load existing ontology data (incremental mode).

        Only needed for incremental extractions. Call after setup_pipeline().

        Returns:
            Self for method chaining

        Example:
            builder = OntologyPipelineBuilder(domain="travel", incremental=True)
            builder.setup_pipeline("data.txt").load_existing().extract()
            asyncio.run(builder.process())
            asyncio.run(builder.finalize())
            result = builder.build()
        """
        assert self.state is not None, "state must be initialized"
        assert self.state.incremental is not None, "incremental flag must be set"

        load_existing_data(self.state)
        return self

    # ========================================================================
    # Extraction Stages (7-9)
    # ========================================================================

    def chunk(self) -> Self:
        """
        Chunk input text.

        Returns:
            Self for method chaining
        """
        assert self.state is not None, "state must be initialized"
        assert self.state.texts is not None, "texts must be loaded before chunking"

        early_return = asyncio.run(chunk_input_text(self.state))
        if early_return:
            # File already processed, store result for build()
            self._early_return_output = early_return
        return self

    def _attach_system_prompts(
        self, agent: Agent[None, ExtractionResult], naming_instructions: str
    ) -> None:
        """Attach system prompts to extraction agent."""
        assert agent is not None, "agent must not be None"
        assert self.extraction_prompt is not None, "extraction_prompt must be set"

        @agent.system_prompt
        def extraction_instructions(_ctx) -> str:
            assert self.extraction_prompt, "extraction_prompt cannot be empty"
            assert len(self.extraction_prompt) > 0, "extraction_prompt must have content"
            return self.extraction_prompt

        @agent.system_prompt
        def naming_conventions(_ctx) -> str:
            assert isinstance(naming_instructions, str), "naming_instructions must be a string"
            assert not naming_instructions or len(naming_instructions) > 0, (
                "if set, must have content"
            )
            return naming_instructions if naming_instructions else ""

        @agent.system_prompt
        def domain_instructions(_ctx) -> str:
            domain_prompt = self.state.domain_prompt
            assert domain_prompt is None or isinstance(domain_prompt, str), "must be string or None"
            assert not domain_prompt or len(domain_prompt) > 0, "if set, must have content"
            return domain_prompt if domain_prompt else ""

    def setup_agent(self) -> Self:
        """
        Create extraction agent with dependency injection.

        Returns:
            Self for method chaining
        """
        assert self.state is not None, "state must be initialized"
        assert self.state.config is not None, "config must be loaded"

        from taxonomy_ontology_accelerator.ontology_engine.core.extraction_stages import (
            _build_naming_instructions,
            _get_model_instance,
            _load_extraction_prompt,
        )
        from taxonomy_ontology_accelerator.ontology_engine.core.extractor import (
            _build_retry_strategy,
        )

        config = self.state.config
        self.extraction_prompt = _load_extraction_prompt(config)
        naming_instructions = _build_naming_instructions(config.naming_conventions)
        model_instance = _get_model_instance(config)

        from typing import cast

        from pydantic_ai import ModelSettings

        model_settings: ModelSettings | None = None
        if config.llm.max_tokens is not None or config.llm.temperature is not None:
            settings_dict: dict[str, Any] = {}
            if config.llm.max_tokens is not None:
                settings_dict["max_tokens"] = config.llm.max_tokens
            if config.llm.temperature is not None:
                settings_dict["temperature"] = config.llm.temperature
            model_settings = cast("ModelSettings", settings_dict)

        retry_strategy = _build_retry_strategy(config)

        self.extraction_agent = Agent(
            model_instance,
            output_type=ExtractionResult,
            retries=retry_strategy,
            output_retries=retry_strategy,
            model_settings=model_settings,
        )

        self._attach_system_prompts(self.extraction_agent, naming_instructions)
        return self

    def extract(
        self,
        extraction_agent: Agent[None, ExtractionResult] | None = None,
    ) -> Self:
        """
        Chunk, setup agent, and run LLM extraction.

        Args:
            extraction_agent: Optional custom Agent. If provided, overrides agent from __init__

        Returns:
            Self for method chaining

        Note:
            This method runs async code using asyncio.run(). If you're already
            in an async context, use extract_async() instead.
        """
        assert self.state is not None, "state must be initialized"
        assert self.state.config is not None, "config must be loaded before extraction"

        if not self.state.chunks:
            self.chunk()

        if hasattr(self, "_early_return_output"):
            # Chunking returned early (file already processed)
            return self

        # Determine which agent to use (parameter > instance > create default)
        agent_to_use = extraction_agent or self.extraction_agent
        if agent_to_use is None:
            self.setup_agent()
            agent_to_use = self.extraction_agent

        # Load prompt if not already loaded
        if self.extraction_prompt is None:
            from taxonomy_ontology_accelerator.ontology_engine.core.extraction_stages import (
                _load_extraction_prompt,
            )

            assert self.state.config is not None, "config must be set before extraction"
            self.extraction_prompt = _load_extraction_prompt(self.state.config)

        # Run async extraction with dependency injection
        assert agent_to_use is not None, "Agent must be provided or created"
        assert self.extraction_prompt is not None, "Extraction prompt must be loaded"
        asyncio.run(run_configured_extraction(agent_to_use, self.extraction_prompt, self.state))

        # Run post-extraction validators
        self._run_validators(
            "extraction",
            entities=self.state.all_concepts,
            relationships=self.state.all_relationships,
            state=self.state,
        )

        return self

    async def _chunk_if_needed_async(self) -> bool:
        """Chunk input if not already chunked. Returns True if early return needed."""
        assert self.state is not None, "state must be initialized"
        assert self.state.texts is not None, "texts must be loaded"
        if not self.state.chunks:
            from taxonomy_ontology_accelerator.ontology_engine.pipeline_stages import (
                chunk_input_text,
            )

            early_return = await chunk_input_text(self.state)
            if early_return:
                self._early_return_output = early_return
                return True
        return False

    def _get_or_create_agent_async(
        self, extraction_agent: Agent[None, ExtractionResult] | None
    ) -> Agent[None, ExtractionResult]:
        """Get provided agent or create default one for async context."""
        assert self.state is not None, "state must be initialized"
        assert self.state.config is not None, "config must be loaded"
        if extraction_agent is not None:
            return extraction_agent
        # Recreate agent in async context for correct event loop binding
        self.setup_agent()
        assert self.extraction_agent is not None, "Agent must be created"
        return self.extraction_agent

    def _ensure_extraction_prompt_loaded(self) -> None:
        """Load extraction prompt if not already loaded."""
        assert self.state is not None, "state must be initialized"
        assert self.state.config is not None, "config required"
        if self.extraction_prompt is None:
            from taxonomy_ontology_accelerator.ontology_engine.core.extraction_stages import (
                _load_extraction_prompt,
            )

            self.extraction_prompt = _load_extraction_prompt(self.state.config)

    async def extract_async(
        self,
        extraction_agent: Agent[None, ExtractionResult] | None = None,
    ) -> Self:
        """Async version of extract() for use in async contexts."""
        assert self.state is not None, "state must be initialized"
        assert self.state.config is not None, "config must be loaded"

        if await self._chunk_if_needed_async():
            return self

        agent_to_use = self._get_or_create_agent_async(extraction_agent)
        self._ensure_extraction_prompt_loaded()

        assert agent_to_use is not None, "Agent must be provided or created"
        assert self.extraction_prompt is not None, "Extraction prompt must be loaded"
        if self._should_use_parallel_file_workers():
            await self._run_parallel_file_extraction(agent_to_use, self.extraction_prompt)
        else:
            await run_configured_extraction(agent_to_use, self.extraction_prompt, self.state)

        self._run_validators(
            "extraction",
            entities=self.state.all_concepts,
            relationships=self.state.all_relationships,
            state=self.state,
        )

        return self

    def _should_use_parallel_file_workers(self) -> bool:
        assert self.state is not None, "state must be initialized"
        config = self.state.config
        assert config is not None, "config must be loaded"
        input_path = self.state.input_path
        if input_path is None or self.state.fs is None:
            return False
        return config.parallel_files > 1 and self.state.fs.isdir(str(input_path))

    async def _run_parallel_file_extraction(
        self,
        extraction_agent: Agent[None, ExtractionResult],
        extraction_prompt: str,
    ) -> None:
        assert self.state is not None, "state must be initialized"
        config = self.state.config
        assert config is not None, "config must be loaded"
        assert self.state.input_path is not None, "input_path must be set"
        assert self.state.fs is not None, "filesystem must be initialized"

        from taxonomy_ontology_accelerator.ontology_engine.utils.file_loading import (
            _find_supported_files,
        )

        file_paths = _find_supported_files(self.state.input_path, fs=self.state.fs)
        if len(file_paths) <= 1:
            await run_configured_extraction(extraction_agent, extraction_prompt, self.state)
            return

        logger.info(
            f"Running parallel file extraction with {min(len(file_paths), config.parallel_files)} worker(s)"
        )

        checkpoint_manager = self.state.checkpoint_manager or _NoOpCheckpointManager()

        async def _process_file(file_path: str, file_state: Any) -> Any:
            worker_config = config.model_copy(deep=True)
            worker_config.checkpointing.flush_interval_batches = 0
            file_state.config = worker_config
            file_state.input_path = file_path
            file_state.output_dir = self.state.output_dir
            file_state.prompt_path = self.state.prompt_path
            file_state.source_file_path = str(file_path)
            file_state.domain_prompt = self.state.domain_prompt
            file_state.fs = self.state.fs
            file_state.output_fs = self.state.output_fs

            from taxonomy_ontology_accelerator.ontology_engine.core.extraction_pipeline import (
                load_input_content,
            )
            from taxonomy_ontology_accelerator.ontology_engine.pipeline_stages import (
                chunk_input_text,
            )

            load_input_content(file_path, file_state)
            early_return = await chunk_input_text(file_state)
            if early_return is not None:
                return _parallel_worker_payload(file_state, [], [])

            await run_configured_extraction(extraction_agent, extraction_prompt, file_state)
            return _parallel_worker_payload(
                file_state,
                list(file_state.all_concepts),
                list(file_state.all_relationships),
            )

        file_results = await process_files_parallel(
            file_paths=file_paths,
            process_fn=_process_file,
            shared_config=config,
            checkpoint_manager=checkpoint_manager,
            max_workers=config.parallel_files,
        )

        all_concepts: list[Any] = []
        all_relationships: list[Any] = []
        for result in file_results:
            if not result.success or result.result is None:
                continue
            concepts, relationships = _merge_parallel_worker_payload(self.state, result.result)
            all_concepts.extend(concepts)
            all_relationships.extend(relationships)

        self.state.all_concepts = all_concepts
        self.state.all_relationships = all_relationships
        if config.output.emit_pipeline_stage_lists and self.state.output_dir is not None:
            emit_raw_entity_list(
                self.state.all_concepts,
                self.state.output_dir,
                fs=self.state.output_fs or self.state.fs,
            )
            emit_raw_relationship_list(
                self.state.all_relationships,
                self.state.output_dir,
                fs=self.state.output_fs or self.state.fs,
            )

    # ========================================================================
    # Processing Stages (10-12a)
    # ========================================================================

    async def deduplicate(self) -> Self:
        """
        Deduplicate entities.

        Returns:
            Self for method chaining
        """
        assert self.state is not None, "state must be initialized"
        assert self.state.all_concepts is not None, "concepts must be extracted first"

        await deduplicate_entities(self.state)
        return self

    async def build_relations(self) -> Self:
        """
        Build relationships.

        Returns:
            Self for method chaining
        """
        assert self.state is not None, "state must be initialized"
        assert self.state.entities is not None, "entities must be deduplicated first"

        await build_relationships(self.state)
        return self

    async def update_schema(self) -> Self:
        """
        Evolve schema and resolve conflicts.

        Returns:
            Self for method chaining
        """
        assert self.state is not None, "state must be initialized"
        assert self.state.entities is not None, "entities must be processed first"

        await evolve_schema(self.state)
        resolve_conflicts(self.state)

        # Run post-schema-evolution validators
        if self.state.ontology_schema is not None:
            self._run_validators(
                "schema_evolution",
                schema=self.state.ontology_schema,
                entities=self.state.entities,
                relationships=self.state.relationships,
                state=self.state,
            )
        else:
            # Schema evolution validators skipped when schema is None
            validators = self.get_validators("schema_evolution")
            if validators:
                logger.warning(
                    f"[Validation] Skipping {len(validators)} schema evolution validator(s): "
                    f"ontology_schema is None"
                )

        return self

    async def process(self) -> Self:
        """
        Deduplicate, build relations, update schema.

        Convenience method that runs all processing stages in sequence.

        Returns:
            Self for method chaining
        """
        assert self.state is not None, "state must be initialized"
        assert self.state.all_concepts is not None, "extraction must complete first"

        await self.deduplicate()
        await self.build_relations()
        await self.update_schema()
        return self

    # ========================================================================
    # Finalization Stages (13-17)
    # ========================================================================

    async def merge(self) -> Self:
        """
        Merge with existing graph.

        Returns:
            Self for method chaining
        """
        assert self.state is not None, "state must be initialized"
        assert self.state.existing_graph is not None, "existing graph required for merge"

        merge_with_existing(self.state)
        await merge_relationships(self.state)
        return self

    def validate(self) -> Self:
        """
        Build and validate final graph.

        Returns:
            Self for method chaining

        Raises:
            ValueError: If critical validation errors found
        """
        assert self.state is not None, "state must be initialized"
        assert self.state.entities is not None, "entities must be processed"

        build_and_validate(self.state)
        return self

    def save(self) -> Self:
        """
        Save schema and graph JSON.

        Returns:
            Self for method chaining
        """
        assert self.state is not None, "state must be initialized"
        assert self.state.graph is not None, "graph must be built before saving"

        save_output(self.state)
        return self

    def export(self) -> Self:
        """
        Export to OWL/RDF.

        Export format is controlled by config.output.export.format.

        Returns:
            Self for method chaining
        """
        assert self.state is not None, "state must be initialized"
        assert self.state.ontology_schema is not None, "schema required for export"

        export_owl(self.state)
        return self

    async def finalize(self) -> Self:
        """
        Merge, validate, save, export (if enabled), metadata.

        Convenience method that runs all finalization stages in sequence.

        Returns:
            Self for method chaining
        """
        assert self.state is not None, "state must be initialized"
        assert self.state.entities is not None, "entities must be processed"

        try:
            if self.state.existing_graph:
                await self.merge()
            self.validate()
            self.save()

            config = self.state.config
            assert config is not None, "config must be loaded"

            if config.output.export.enabled:
                self.export()
        finally:
            self._finalize_run_artifacts()

        return self

    # ========================================================================
    # Build and Convenience Methods
    # ========================================================================

    def build(self) -> OntologyOutput:
        """
        Return final OntologyOutput.

        Must be called after finalize() to get the complete result.

        Returns:
            OntologyOutput with schema, graph, metadata, and errors

        Raises:
            AssertionError: If finalize() not called before build()
        """
        assert self.state is not None, "state must be initialized"
        assert self.state.output_dir is not None, "output directory must be set"

        # Check for early return (file already processed)
        if hasattr(self, "_early_return_output"):
            return self._early_return_output

        assert self.state.graph is not None, "Must run finalize() before build()"
        return finalize_metadata(self.state)

    def _add_validators_to_builder(
        self, extraction_validators: list[Any] | None, schema_validators: list[Any] | None
    ) -> None:
        """Add validators to builder if provided."""
        assert extraction_validators is None or isinstance(extraction_validators, list), (
            "Must be list"
        )
        assert schema_validators is None or isinstance(schema_validators, list), "Must be list"
        if extraction_validators:
            for validator in extraction_validators:
                self.after_extraction(validator)
        if schema_validators:
            for validator in schema_validators:
                self.after_schema_evolution(validator)

    @classmethod
    def run(
        cls,
        domain: str,
        input_path: str | Path,
        incremental: bool = False,
        output_dir: str | Path | None = None,
        prompt_path: str | Path | None = None,
        extraction_agent: Agent[None, ExtractionResult] | None = None,
        **kwargs,
    ) -> OntologyOutput:
        """
        Convenience method to run full pipeline in one call.

        Args:
            domain: Domain name for ontology
            input_path: Path to input file or directory
            incremental: Whether to merge with existing ontology
            output_dir: Optional custom output directory
            prompt_path: Optional domain-specific prompt file
            extraction_agent: Optional custom Agent for extraction
            **kwargs: Additional parameters including extraction_validators, schema_validators

        Returns:
            Complete OntologyOutput
        """
        assert domain is not None, "domain must not be None"
        assert input_path is not None, "input_path must not be None"

        # Extract validators from kwargs
        extraction_validators = kwargs.pop("extraction_validators", None)
        schema_validators = kwargs.pop("schema_validators", None)

        builder = cls(
            domain=domain, incremental=incremental, extraction_agent=extraction_agent, **kwargs
        )

        builder._add_validators_to_builder(extraction_validators, schema_validators)
        builder.setup_pipeline(input_path, output_dir, prompt_path)

        if incremental:
            builder.load_existing()

        builder.extract()
        asyncio.run(builder.process())
        asyncio.run(builder.finalize())
        return builder.build()
