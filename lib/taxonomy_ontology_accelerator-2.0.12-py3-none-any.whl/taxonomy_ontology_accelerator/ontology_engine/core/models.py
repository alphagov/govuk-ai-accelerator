"""
Pydantic models for ontology extraction and output.

Defines all data structures used throughout the ontology engine:
- Extraction models (LLM output): ExtractedConcept, ExtractedRelationship
- Ontology models (final output): Entity, Relationship, OntologySchema, OntologyGraph
- Output models: OntologyOutput, ProcessingMetadata

All models use Pydantic for validation and type safety.
"""

from datetime import UTC, datetime
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator


def _get_current_timestamp() -> str:
    """Get current UTC timestamp in ISO 8601 format."""
    result = datetime.now(UTC).isoformat().replace("+00:00", "Z")
    assert result is not None, "Timestamp must not be None"
    assert isinstance(result, str), "Timestamp must be a string"
    assert result.endswith("Z"), "Timestamp must be in UTC (end with Z)"
    return result


def _to_upper_camel_case(text: str) -> str:
    """Convert snake_case or space-separated to UpperCamelCase."""
    assert text is not None, "Text must not be None"
    assert isinstance(text, str), "Text must be a string"
    words = text.replace("_", " ").split()
    result = "".join(word.capitalize() for word in words)
    assert len(result) > 0, "Result must not be empty"
    return result


def _to_lower_camel_case(text: str) -> str:
    """Convert snake_case or space-separated to lowerCamelCase."""
    assert text is not None, "Text must not be None"
    assert isinstance(text, str), "Text must be a string"
    words = text.replace("_", " ").split()
    result = words[0].lower() + "".join(word.capitalize() for word in words[1:]) if words else ""
    assert len(result) > 0, "Result must not be empty"
    return result


def apply_label_casing(label: str, casing: str) -> str:
    """Apply casing convention to entity label using pydantic's alias generators."""
    from pydantic.alias_generators import to_camel, to_pascal, to_snake

    assert label is not None, "Label must not be None"
    assert isinstance(label, str), "Label must be a string"
    assert casing in ("preserve", "UpperCamelCase", "snake_case", "lowerCamelCase"), (
        "Invalid casing type"
    )

    if casing == "preserve":
        return label

    # Replace spaces with underscores for pydantic alias generators
    normalized = label.replace(" ", "_")

    if casing == "snake_case":
        result = to_snake(normalized)
    elif casing == "lowerCamelCase":
        result = to_camel(normalized)
    elif casing == "UpperCamelCase":
        result = to_pascal(normalized)
    else:
        result = label

    assert result is not None, "Result must not be None"
    assert len(result) > 0, "Result must not be empty"
    return result


def apply_type_casing(type_text: str, casing: str) -> str:
    """Apply casing convention to entity types and relationship types.

    Cleans the input (strips whitespace, removes punctuation, collapses spaces)
    and then applies the configured casing style. Unlike normalize_text(), this
    does NOT apply generic text_processing.normalization.casing (which would
    lowercase everything), preserving the intended naming convention.

    Args:
        type_text: The type string to format (e.g., 'health_risk', 'HealthRisk')
        casing: One of 'UpperCamelCase', 'lowerCamelCase', 'snake_case'

    Returns:
        Type string with the configured casing applied
    """
    import re

    assert type_text is not None, "type_text must not be None"
    assert isinstance(type_text, str), "type_text must be a string"
    assert casing in ("UpperCamelCase", "lowerCamelCase", "snake_case"), (
        f"Invalid casing type for types: {casing}"
    )

    # Clean: strip, remove punctuation (except underscores), collapse whitespace
    cleaned = type_text.strip()
    cleaned = re.sub(r"[^\w\s]", "", cleaned)
    cleaned = re.sub(r"\s+", " ", cleaned).strip()

    if not cleaned:
        return type_text.strip()

    # Split into words: handle CamelCase, snake_case, and space-separated
    # First, insert spaces before uppercase letters in CamelCase (e.g., HealthRisk -> Health Risk)
    spaced = re.sub(r"([a-z])([A-Z])", r"\1 \2", cleaned)
    # Then split on underscores and spaces
    words = [w for w in spaced.replace("_", " ").split() if w]

    if not words:
        return type_text.strip()

    if casing == "UpperCamelCase":
        result = "".join(word.capitalize() for word in words)
    elif casing == "lowerCamelCase":
        result = words[0].lower() + "".join(word.capitalize() for word in words[1:])
    elif casing == "snake_case":
        result = "_".join(word.lower() for word in words)
    else:
        result = cleaned

    assert result is not None, "Result must not be None"
    assert len(result) > 0, "Result must not be empty"
    return result


# ============================================================================
# OWL 2 Feature Models
# ============================================================================


class RestrictionType(StrEnum):
    """OWL restriction types."""

    SOME_VALUES_FROM = "someValuesFrom"
    ALL_VALUES_FROM = "allValuesFrom"
    HAS_VALUE = "hasValue"
    MIN_CARDINALITY = "minCardinality"
    MAX_CARDINALITY = "maxCardinality"
    EXACT_CARDINALITY = "cardinality"
    MIN_QUALIFIED_CARDINALITY = "minQualifiedCardinality"
    MAX_QUALIFIED_CARDINALITY = "maxQualifiedCardinality"
    EXACT_QUALIFIED_CARDINALITY = "qualifiedCardinality"


class OWLRestriction(BaseModel):
    """OWL restriction on a class."""

    property: str = Field(description="Property being restricted", min_length=1)
    restriction_type: RestrictionType = Field(description="Type of OWL restriction")
    value: int | str | None = Field(default=None, description="Restriction value")
    on_class: str | None = Field(default=None, description="For qualified cardinality")


class PropertyCharacteristic(StrEnum):
    """OWL property characteristics."""

    FUNCTIONAL = "Functional"
    INVERSE_FUNCTIONAL = "InverseFunctional"
    TRANSITIVE = "Transitive"
    SYMMETRIC = "Symmetric"
    ASYMMETRIC = "Asymmetric"
    REFLEXIVE = "Reflexive"
    IRREFLEXIVE = "Irreflexive"


class ClassExpression(BaseModel):
    """OWL class expression (unionOf, intersectionOf, complementOf, oneOf)."""

    expression_type: str = Field(description="Expression type", min_length=1)
    classes: list[str] = Field(default_factory=list, description="Classes in expression")


class PropertyChain(BaseModel):
    """OWL property chain axiom."""

    properties: list[str] = Field(description="Ordered list of properties in chain", min_length=2)


# ============================================================================
# Extraction Models (PydanticAI Output)
# ============================================================================


class ExtractedConcept(BaseModel):
    """
    Entity extracted from text (LLM output uses 'concept' terminology).

    Note: LLM output uses "concept" but we convert to "entity" in final output.
    """

    label: str = Field(description="Entity label/name", min_length=1)
    concept_type: str = Field(description="Type of entity (e.g., 'medical_concept')", min_length=1)
    description: str | None = Field(default=None, description="Optional description")
    aliases: list[str] = Field(default_factory=list, description="Alternative names")
    properties: dict[str, Any] = Field(  # pyright: ignore[reportExplicitAny]
        default_factory=dict,
        description="Dynamic properties specific to entity type (e.g., category, jurisdiction, status)",
    )
    confidence: float = Field(ge=0.0, le=1.0, description="Extraction confidence score")
    restrictions: list[dict[str, Any]] = Field(  # pyright: ignore[reportExplicitAny]
        default_factory=list,
        description="OWL restrictions (cardinality, value constraints)",
    )

    @field_validator("concept_type")
    @classmethod
    def normalize_concept_type(cls, v: str) -> str:
        """Convert concept_type to UpperCamelCase if needed.

        Preserves formal ontology identifiers (e.g., VO_0010343, DOID_4325)
        that match the default formal identifier pattern.
        """
        assert v is not None, "concept_type must not be None"
        assert isinstance(v, str), "concept_type must be a string"
        from taxonomy_ontology_accelerator.ontology_engine.utils.text_normalization import (
            is_formal_identifier_default,
        )

        if is_formal_identifier_default(v):
            return v
        if "_" in v or " " in v:
            return _to_upper_camel_case(v)
        return v

    @field_validator("properties")
    @classmethod
    def normalize_property_keys(cls, v: dict[str, Any]) -> dict[str, Any]:
        """Convert property keys to lowerCamelCase if needed."""
        assert v is not None, "properties must not be None"
        assert isinstance(v, dict), "properties must be a dict"
        return {
            (_to_lower_camel_case(k) if "_" in k or " " in k else k): val for k, val in v.items()
        }


class ExtractedRelationship(BaseModel):
    """
    Relationship between entities extracted from text (LLM output).

    Properties field allows storing context-dependent attributes that vary based on
    the relationship context. For example, passport validity may differ per country,
    visa processing times may vary by embassy, or health risks may differ by location.

    Example:
        - passport → USA: properties={"validity": "6 months", "blank_pages": 3}
        - passport → UK: properties={"validity": "3 months", "blank_pages": 2}
    """

    type: str = Field(description="Relationship type (e.g., 'requires', 'is_a')", min_length=1)
    source_label: str = Field(description="Source entity label", min_length=1)
    target_label: str = Field(description="Target entity label", min_length=1)
    confidence: float = Field(ge=0.0, le=1.0, description="Extraction confidence score")
    description: str | None = Field(default=None, description="Optional relationship description")
    properties: dict[str, Any] = Field(  # pyright: ignore[reportExplicitAny]
        default_factory=dict,
        description=(
            "Context-dependent properties specific to this relationship. "
            "Use for attributes that vary based on the relationship context "
            "(e.g., validity periods, processing times, risk levels per location)."
        ),
    )
    characteristics: list[str] = Field(
        default_factory=list,
        description="Property characteristics: Functional, Transitive, Symmetric, etc.",
    )
    inverse_of: str | None = Field(default=None, description="Inverse relationship type")

    @field_validator("type")
    @classmethod
    def normalize_relationship_type(cls, v: str) -> str:
        """Convert relationship type to lowerCamelCase if needed."""
        assert v is not None, "type must not be None"
        assert isinstance(v, str), "type must be a string"
        if "_" in v or " " in v:
            return _to_lower_camel_case(v)
        return v

    @field_validator("properties")
    @classmethod
    def normalize_property_keys(cls, v: dict[str, Any]) -> dict[str, Any]:
        """Convert property keys to lowerCamelCase if needed."""
        assert v is not None, "properties must not be None"
        assert isinstance(v, dict), "properties must be a dict"
        return {
            (_to_lower_camel_case(k) if "_" in k or " " in k else k): val for k, val in v.items()
        }


class ExtractionResult(BaseModel):
    """Structured output from PydanticAI Agent."""

    concepts: list[ExtractedConcept] = Field(default_factory=list)
    relationships: list[ExtractedRelationship] = Field(default_factory=list)


# ============================================================================
# Ontology Models (Final Output)
# ============================================================================


class EntityMetadata(BaseModel):
    """Structured metadata for ontology entities."""

    confidence: float | None = Field(
        default=None, ge=0.0, le=1.0, description="Extraction confidence score"
    )
    first_seen: str | None = Field(default=None, description="First extraction timestamp")
    last_updated: str | None = Field(default=None, description="Last update timestamp")
    merged_from: list[dict[str, Any]] = Field(  # pyright: ignore[reportExplicitAny]
        default_factory=list, description="List of merged entity records"
    )
    merge_provenance: list[str] = Field(default_factory=list, description="Merge reason strings")


class AliasEntry(BaseModel):
    """An alias with provenance tracking: which source files mentioned this name."""

    name: str = Field(min_length=1, description="Alternative name for the entity")
    source_files: list[str] = Field(
        default_factory=list, description="Source file paths where this alias was found"
    )

    def __str__(self) -> str:
        return self.name

    def __hash__(self) -> int:
        return hash(self.name)

    def __eq__(self, other: object) -> bool:
        if isinstance(other, AliasEntry):
            return self.name == other.name
        if isinstance(other, str):
            return self.name == other
        return NotImplemented


class Entity(BaseModel):
    """Entity in ontology graph."""

    model_config = ConfigDict(populate_by_name=True)  # pyright: ignore[reportUnannotatedClassAttribute]

    id: str = Field(min_length=1, description="Run-specific identifier")
    canonical_key: str = Field(
        min_length=1, description="Stable identifier (consistent across runs)"
    )
    label: str = Field(min_length=1, description="Normalized label")
    aliases: list[AliasEntry] = Field(default_factory=list, description="Alternative names with provenance")
    type: str = Field(min_length=1, description="Entity type from schema")
    description: str | None = Field(default=None, description="Optional description")
    properties: dict[str, Any] = Field(  # pyright: ignore[reportExplicitAny]
        default_factory=dict, description="Dynamic properties from schema fields"
    )
    metadata: dict[str, Any] = Field(  # pyright: ignore[reportExplicitAny]
        default_factory=dict, description="Confidence, timestamps only"
    )

    @field_validator("aliases", mode="before")
    @classmethod
    def _coerce_aliases(cls, v: list) -> list:  # pyright: ignore[reportExplicitAny]
        """Accept plain strings (backward compat) or AliasEntry dicts."""
        if not v:
            return []
        return [
            AliasEntry(name=item) if isinstance(item, str) else item
            for item in v
        ]

    @property
    def alias_names(self) -> list[str]:
        """Return alias names as plain strings (convenience for lookups)."""
        return [a.name if isinstance(a, AliasEntry) else str(a) for a in self.aliases]

    def has_alias(self, name: str) -> bool:
        """Check whether an alias exists by name (case-insensitive)."""
        lower = name.lower()
        return any(a.lower() == lower for a in self.alias_names)

    def validated_metadata(self) -> EntityMetadata:
        """Return metadata as a validated EntityMetadata instance."""
        assert self.metadata is not None, "metadata cannot be None"
        assert isinstance(self.metadata, dict), "metadata must be a dict"
        return EntityMetadata(**self.metadata)


class Relationship(BaseModel):
    """Relationship between entities."""

    id: str = Field(min_length=1, description="Unique identifier")
    type: str = Field(min_length=1, description="Relationship type")
    from_: str = Field(
        alias="from", min_length=1, description="Source entity ID (must exist in entities)"
    )
    to: str = Field(min_length=1, description="Target entity ID (must exist in entities)")
    properties: dict[str, Any] = Field(  # pyright: ignore[reportExplicitAny]
        default_factory=dict, description="Dynamic properties for relationship"
    )
    metadata: dict[str, Any] = Field(  # pyright: ignore[reportExplicitAny]
        default_factory=dict, description="Confidence, timestamp only"
    )

    model_config = ConfigDict(  # pyright: ignore[reportUnannotatedClassAttribute]
        populate_by_name=True
    )  # Allow both 'from' and 'from_' in JSON


class EntityTypeDefinition(BaseModel):
    """Entity type definition in schema."""

    model_config = ConfigDict(populate_by_name=True)  # pyright: ignore[reportUnannotatedClassAttribute]

    parent_type: str | None = Field(default=None, description="Parent entity type")
    label: str | None = Field(default=None, description="Human-readable label")
    description: str | None = Field(default=None, description="Type description")
    aliases: list[str] = Field(default_factory=list, description="Alternative names")
    fields: list[str] = Field(description="All field names for this entity type")
    required_fields: list[str] = Field(description="Required field names")
    uri: str | None = Field(default=None, description="Ontology URI for this type")
    deprecated: bool = Field(default=False, description="Whether this type is deprecated")
    metadata: dict[str, Any] = Field(  # pyright: ignore[reportExplicitAny]
        default_factory=dict, description="Additional metadata"
    )
    created_at: str | None = Field(default=None, description="When type was created")
    similarity_check: dict[str, Any] | None = Field(  # pyright: ignore[reportExplicitAny]
        default=None, description="Similarity check results"
    )
    restrictions: list[OWLRestriction] = Field(
        default_factory=list, description="OWL restrictions on this class"
    )
    equivalent_classes: list[str] = Field(
        default_factory=list, description="Equivalent class definitions"
    )
    disjoint_with: list[str] = Field(
        default_factory=list, description="Classes disjoint with this class"
    )
    class_expression: ClassExpression | None = Field(
        default=None, description="OWL class expression (unionOf, intersectionOf, etc.)"
    )


class RelationshipTypeDefinition(BaseModel):
    """Relationship type definition in schema."""

    model_config = ConfigDict(populate_by_name=True)  # pyright: ignore[reportUnannotatedClassAttribute]

    is_core: bool = Field(default=False, description="True if core relationship type")
    from_type: str = Field(description="Source entity type")
    to_type: str = Field(description="Target entity type")
    direction: str | None = Field(default=None, description="Explicit direction semantics")
    created_at: str | None = Field(default=None, description="When type was created")
    characteristics: list[PropertyCharacteristic] = Field(
        default_factory=list, description="OWL property characteristics"
    )
    inverse_of: str | None = Field(default=None, description="Inverse property")
    equivalent_properties: list[str] = Field(
        default_factory=list, description="Equivalent property definitions"
    )
    sub_property_of: str | None = Field(default=None, description="Parent property")
    property_chain: PropertyChain | None = Field(default=None, description="Property chain axiom")
    disjoint_with: list[str] = Field(
        default_factory=list, description="Properties disjoint with this property"
    )


class OntologySchema(BaseModel):
    """Evolving schema definition."""

    model_config = ConfigDict(populate_by_name=True)  # pyright: ignore[reportUnannotatedClassAttribute]

    domain: str = Field(min_length=1, description="Domain identifier")
    version: str = Field(min_length=1, description="Schema version")
    last_updated: str = Field(
        default_factory=_get_current_timestamp, description="Last update timestamp"
    )
    entity_types: dict[str, EntityTypeDefinition] = Field(
        default_factory=dict, description="Entity type definitions"
    )
    relationship_types: dict[str, RelationshipTypeDefinition] = Field(
        default_factory=dict, description="Relationship type definitions"
    )
    normalization_rules: dict[str, Any] = Field(  # pyright: ignore[reportExplicitAny]
        default_factory=dict, description="Normalization rules"
    )
    history: list[dict[str, Any]] = Field(  # pyright: ignore[reportExplicitAny]
        default_factory=list, description="Schema change history"
    )


class OntologyGraph(BaseModel):
    """Complete ontology graph."""

    model_config = ConfigDict(populate_by_name=True)  # pyright: ignore[reportUnannotatedClassAttribute]

    domain: str = Field(min_length=1, description="Domain identifier")
    schema_version: str = Field(min_length=1, description="Schema version")
    extracted_at: str = Field(
        default_factory=_get_current_timestamp, description="Extraction timestamp"
    )
    entities: list[Entity] = Field(default_factory=list, description="All entities")
    relationships: list[Relationship] = Field(default_factory=list, description="All relationships")


# ============================================================================
# Processing Models
# ============================================================================


class MergeDecision(BaseModel):
    """Record of a single entity merge during deduplication."""

    canonical_id: str = Field(description="ID of entity kept (canonical)", min_length=1)
    canonical_label: str = Field(description="Label of canonical entity", min_length=1)
    merged_id: str = Field(description="ID of entity merged/removed", min_length=1)
    merged_label: str = Field(description="Label of merged entity", min_length=1)
    reason: str = Field(
        description="Merge reason: exact_match | normalization | semantic | abbreviation",
        min_length=1,
    )
    similarity_score: float | None = Field(
        default=None, ge=0.0, le=1.0, description="Semantic similarity score (semantic stage only)"
    )
    confidence: float = Field(ge=0.0, le=1.0, description="Canonical entity confidence score")
    threshold: float | None = Field(
        default=None, ge=0.0, le=1.0, description="Semantic threshold used (semantic stage only)"
    )
    timestamp: str = Field(default_factory=_get_current_timestamp, description="Merge timestamp")

    @model_validator(mode="after")
    def validate_different_entities(self) -> "MergeDecision":
        """Validate that canonical and merged entities are different."""
        assert self.canonical_id is not None, "canonical_id must be set"
        assert self.merged_id is not None, "merged_id must be set"
        assert self.canonical_id != self.merged_id, (
            f"Cannot merge entity with itself: canonical_id={self.canonical_id} == merged_id={self.merged_id}"
        )
        return self


class DeduplicationSummary(BaseModel):
    """Summary statistics for deduplication."""

    total_entities_before: int = Field(ge=0, description="Entity count before deduplication")
    total_entities_after: int = Field(ge=0, description="Entity count after deduplication")
    total_merged: int = Field(ge=0, description="Total entities merged")
    merge_by_stage: dict[str, int] = Field(
        default_factory=dict, description="Merge counts by stage (exact_match, normalization, etc.)"
    )
    avg_similarity_semantic: float | None = Field(
        default=None, ge=0.0, le=1.0, description="Average similarity for semantic merges"
    )
    timestamp: str = Field(default_factory=_get_current_timestamp, description="Summary timestamp")


class ProcessingMetadata(BaseModel):
    """Processing metadata for ontology extraction."""

    total_entities_extracted: int = Field(description="Total entities extracted from text")
    total_relationships_extracted: int = Field(
        description="Total relationships extracted from text"
    )
    entities_after_deduplication: int = Field(description="Entities after deduplication")
    relationships_after_deduplication: int = Field(description="Relationships after deduplication")
    new_entity_types_created: int = Field(description="New entity types created")
    new_relationship_types_created: int = Field(description="New relationship types created")
    processing_time_seconds: float = Field(description="Total processing time in seconds")
    llm_calls_made: int = Field(description="Number of LLM calls made")
    embeddings_generated: int = Field(description="Number of embeddings generated")
    input_tokens: int = Field(default=0, description="Total input tokens used")
    output_tokens: int = Field(default=0, description="Total output tokens generated")
    cache_read_tokens: int = Field(default=0, description="Total cache read tokens")
    cache_write_tokens: int = Field(default=0, description="Total cache write tokens")
    estimated_llm_input_tokens: int = Field(
        default=0, description="Estimated LLM input tokens when provider usage was missing"
    )
    estimated_llm_output_tokens: int = Field(
        default=0, description="Estimated LLM output tokens when provider usage was missing"
    )
    llm_usage_missing_calls: int = Field(
        default=0, description="LLM calls where provider token usage was missing"
    )
    embedding_input_tokens: int = Field(default=0, description="Total embedding input tokens")
    embedding_output_tokens: int = Field(
        default=0, description="Total embedding output tokens"
    )
    embedding_cache_read_tokens: int = Field(
        default=0, description="Total embedding cache read tokens"
    )
    embedding_cache_write_tokens: int = Field(
        default=0, description="Total embedding cache write tokens"
    )
    total_tokens: int = Field(default=0, description="Total tokens (input + output)")
    estimated_cost_usd: float | None = Field(
        default=None, description="Estimated cost in USD (requires genai-prices)"
    )
    stage_timings: dict[str, float] = Field(
        default_factory=dict, description="Duration of each pipeline stage in seconds"
    )
    throughput_entities_per_sec: float = Field(
        default=0.0, description="Entity processing throughput"
    )
    throughput_relationships_per_sec: float = Field(
        default=0.0, description="Relationship processing throughput"
    )
    cache_hit_rates: dict[str, float] = Field(
        default_factory=dict, description="Cache hit rates (0.0-1.0) by cache type"
    )
    peak_memory_mb: float | None = Field(
        default=None, description="Peak memory usage in MB (requires psutil)"
    )
    avg_memory_mb: float | None = Field(
        default=None, description="Average memory usage in MB (requires psutil)"
    )
    ontology_shape_metrics: dict[str, int | float] = Field(
        default_factory=dict,
        description="Structural ontology quality metrics (roots, depth, placeholder types, etc.)",
    )


class OntologyOutput(BaseModel):
    """Final output from extract_ontology()."""

    ontology_schema: OntologySchema = Field(description="Ontology schema")
    graph: OntologyGraph
    metadata: ProcessingMetadata
    errors: list[dict[str, Any]] = Field(default_factory=list, description="Processing errors")
    schema_path: str = Field(description="Path to saved schema.json")
    graph_path: str = Field(description="Path to saved graph.json")
