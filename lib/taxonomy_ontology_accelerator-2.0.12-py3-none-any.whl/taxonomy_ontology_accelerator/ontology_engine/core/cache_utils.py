"""Prompt caching utility functions for Anthropic API integration.

This module provides utilities for preparing system prompts for Anthropic's
prompt caching feature, which requires:
- Minimum 1024 tokens for Claude 3 Haiku
- Minimum 2048 tokens for Claude Sonnet (recommended)
- Proper message format with cache_control field

The get_cacheable_system_prompt() function returns system messages in the
format required by Anthropic's Messages API with caching enabled.
"""

from typing import Any

from taxonomy_ontology_accelerator.ontology_engine.prompts import (
    DEFAULT_ONTOLOGY_PROMPT,
)

def _combine_system_prompt_sections(*sections: str | None) -> str:
    """Combine non-empty prompt sections into a single cacheable system prompt."""
    combined_sections = [section.strip() for section in sections if section and section.strip()]
    return "\n\n".join(combined_sections)


def get_cacheable_system_prompt(
    config: Any,
    extraction_prompt: str | None = None,
    naming_instructions: str | None = None,
    domain_prompt: str | None = None,
) -> list[dict[str, Any]]:
    """
    Get system prompts formatted for Anthropic prompt caching.

    This function retrieves the three system prompts registered in the extraction
    pipeline (extraction_instructions, naming_conventions, domain_instructions)
    and returns them in Anthropic API format with cache_control enabled.

    The prompts are combined into a single system message block with the
    cache_control field set to ephemeral type, enabling prompt caching.

    Args:
        config: Configuration object (currently unused, reserved for future use).
                If None, uses default prompts from prompts.py.
        extraction_prompt: Main extraction instructions. Defaults to DEFAULT_ONTOLOGY_PROMPT.
        naming_instructions: Optional naming instruction block.
        domain_prompt: Optional domain-specific instruction block.

    Returns:
        A list containing a single message dict in Anthropic API format:
        [
            {
                "role": "system",
                "content": [
                    {
                        "type": "text",
                        "text": "combined system prompt text...",
                        "cache_control": {"type": "ephemeral"}
                    }
                ]
            }
        ]

    The returned format is compatible with Anthropic's Messages API:
        response = client.messages.create(
            model="claude-3-5-sonnet-20241022",
            max_tokens=1024,
            system=get_cacheable_system_prompt(config),
            messages=[...]
        )

    Note:
        - Minimum token count: 1024 (Haiku), 2048 (Sonnet recommended)
        - Cache TTL: 5 minutes (standard), ~1 hour (batch context)
        - Cache control type: "ephemeral" (standard caching)
    """
                                                                   

                                                                     
                                                                           
    del config

    combined_prompt = _combine_system_prompt_sections(
        extraction_prompt or DEFAULT_ONTOLOGY_PROMPT,
        naming_instructions,
        domain_prompt,
    )

                                                       
    return [
        {
            "role": "system",
            "content": [
                {
                    "type": "text",
                    "text": combined_prompt,
                    "cache_control": {"type": "ephemeral"},
                }
            ],
        }
    ]
