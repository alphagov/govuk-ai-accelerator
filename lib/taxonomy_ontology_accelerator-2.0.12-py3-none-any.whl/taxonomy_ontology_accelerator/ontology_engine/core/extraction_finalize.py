"""
Extraction finalization stages 13-17 for ontology extraction pipeline.

This module handles the final stages: merging, validation, output, and summary.
"""

import asyncio
import json
import math
import os
import re
import subprocess
import sys
import tempfile
import time
from collections import Counter
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from fsspec import AbstractFileSystem

try:
    import genai_prices  # noqa: F401

    HAS_GENAI_PRICES = True
except ImportError:
    HAS_GENAI_PRICES = False

from taxonomy_ontology_accelerator.commons.errors import ErrorCollector
from taxonomy_ontology_accelerator.commons.io.file_utils import (
    join_path,
    safe_read_file,
    safe_write_json,
)
from taxonomy_ontology_accelerator.commons.utils.logger import get_logger
from taxonomy_ontology_accelerator.ontology_engine.alignment import run_pipeline_alignment
from taxonomy_ontology_accelerator.ontology_engine.config.config import OntologyConfig
from taxonomy_ontology_accelerator.ontology_engine.core.extraction_pipeline import ExtractionState
from taxonomy_ontology_accelerator.ontology_engine.core.models import (
    Entity,
    EntityTypeDefinition,
    OntologyGraph,
    OntologyOutput,
    OntologySchema,
    OWLRestriction,
    ProcessingMetadata,
    Relationship,
    RelationshipTypeDefinition,
    RestrictionType,
)
from taxonomy_ontology_accelerator.ontology_engine.processing.entity_processor import (
    merge_existing_entities,
    merge_new_with_existing,
)
from taxonomy_ontology_accelerator.ontology_engine.processing.merge_validator import (
    validate_merged_graph,
)
from taxonomy_ontology_accelerator.ontology_engine.processing.relationship_builder import (
    _merge_relationship_metadata,
    _merge_relationship_properties_safe,
    merge_relationships,
    resolve_chain_mappings,
)
from taxonomy_ontology_accelerator.ontology_engine.processing.schema_evolver import (
    _can_assign_parent_type,
    evolve_schema,
)
from taxonomy_ontology_accelerator.ontology_engine.processing.validation import validate_ontology
from taxonomy_ontology_accelerator.ontology_engine.storage.export import export_to_owl_rdf
from taxonomy_ontology_accelerator.ontology_engine.storage.file_locking import FileLock
from taxonomy_ontology_accelerator.ontology_engine.storage.schema_graph import schema_to_graph
from taxonomy_ontology_accelerator.ontology_engine.utils.error_helpers import (
    collect_error_if_enabled,
    validate_confidence,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.id_generation import (
    get_current_timestamp,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.list_emitter import (
    emit_entity_list,
    emit_relationship_list,
    emit_vocabulary,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.math_utils import (
    safe_divide,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.property_merger import merge_properties
from taxonomy_ontology_accelerator.ontology_engine.utils.spelling_variants import (
    convert_spelling,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.text_normalization import (
    normalize_text,
    split_identifier_words,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.versioning import increment_schema_version

logger = get_logger()

# Threshold for displaying scale info in summary (entities count)
# Threshold for displaying scale info in summary (entities count)
LARGE_GRAPH_SCALE_THRESHOLD = 10000
FLAT_HIERARCHY_WARNING_MIN_TYPES = 6
FLAT_HIERARCHY_MIN_ROOTS = 4
FLAT_HIERARCHY_ROOT_RATIO_THRESHOLD = 0.5
RELATIONSHIP_TYPE_PRESSURE_MIN_TYPES = 10
RELATIONSHIP_TYPE_PRESSURE_RATIO_THRESHOLD = 1.5
MIN_ACCEPTABLE_HIERARCHY_DEPTH = 1
ABSTRACT_CLASS_INSTANCE_PRESSURE_MIN_INSTANCES = 5
SEMANTIC_REPAIR_MAX_PASSES = 3
_DIRECT_INSTANCE_RETYPE_TEXT_PROPERTY_KEYS = frozenset(
    {
        "description",
        "summary",
        "note",
        "notes",
        "detail",
        "details",
        "guidance",
        "evidence",
        "acceptedAs",
        "role",
    }
)


async def async_safe_write_json(
    path: Path,
    data: dict,
    config: OntologyConfig | None = None,
    fs: "AbstractFileSystem | None" = None,
    pretty: bool = False,
    compress: bool = False,
) -> None:
    """
        Async wrapper for safe_write_json.

        When ``config.async_file_io`` is True, the synchronous write is offloaded
        to a thread via ``asyncio.to_thread`` so the event loop is not blocked.
        When the flag is False (or config is None), falls back to a direct
        synchronous call for backward compatibility.
    # ========================================================================
        Args:
            path: Output file path
            data: Dictionary data to serialize as JSON
            config: OntologyConfig (checked for async_file_io flag)
            fs: Optional fsspec filesystem instance
            pretty: Pretty-print JSON output
            compress: Compress output with gzip
    """
    assert path is not None, "path parameter is required"
    assert data is not None, "data parameter is required"
    # Merge with Existing Graph
    if config and config.async_file_io:
        await asyncio.to_thread(
            safe_write_json,
            path,
            data,
            fs=fs,
            pretty=pretty,
            compress=compress,
        )
    else:
        safe_write_json(
            path,
            data,
            fs=fs,
            pretty=pretty,
            compress=compress,
        )


def merge_with_existing_graph(state: ExtractionState) -> None:
    """
    Merge newly extracted entities with existing graph data.

    For incremental extraction, merges new entities with existing ones:
    1. Matches entities by normalized label
    2. Merges properties, preserving higher confidence values
    3. Updates timestamps and merge metadata
    4. Removes duplicates, keeping canonical entities
    5. Validates entity counts after merge

    Skips if no existing graph (fresh extraction).

    Args:
        state: Extraction state with entities and existing_graph
    """
    assert state is not None, "state parameter is required"
    if state.existing_graph is None:
        return

    config = state.config
    assert config is not None

    # Track counts for validation
    # Track counts for validation
    initial_new_count = len(state.entities)
    initial_existing_count = len(state.existing_graph.entities)

    # Step 1: Get or reuse pre-merged entities
    existing_by_label, existing_by_id = _get_existing_entity_maps(state)

    # Step 2: Merge new entities with existing
    # Step 2: Merge new entities with existing
    entities_to_remove = _merge_new_entities(state, existing_by_label, existing_by_id)

    # Remove merged entities
    for idx in reversed(entities_to_remove):
        state.entities.pop(idx)

    # Step 3: Add remaining existing entities
    # Step 3: Add remaining existing entities
    _add_remaining_existing(state, existing_by_label)

    # Validate accounting
    _validate_entity_accounting(
        initial_new_count,
        initial_existing_count,
        len(state.entities),
        len(entities_to_remove),
        existing_by_label,
    )


def _get_existing_entity_maps(
    state: ExtractionState,
) -> tuple[dict[str, Entity], dict[str, Entity]]:
    """
    Get lookup maps for existing entities.

    Either reuses pre-merged entities from stage 6 (optimization),
    or merges existing entities now. Returns two maps for efficient
    lookup during entity merging.

    Args:
        state: Extraction state with existing_graph and potential pre-merged data

    Returns:
        Tuple of (existing_by_label, existing_by_id) dictionaries
    """
    assert state is not None, "state parameter is required"
    config = state.config
    assert config is not None
    assert state.existing_graph is not None

    # Reuse pre-merged entities if available
    # Reuse pre-merged entities if available
    if (
        state.pre_merged_entity_by_label is not None
        and state.pre_merged_entity_id_mapping is not None
    ):
        existing_by_label = state.pre_merged_entity_by_label
        state.entity_id_mapping.update(state.pre_merged_entity_id_mapping)
    else:
        # Fallback: merge now
        # Fallback: merge now
        existing_by_label, id_mapping = _merge_existing_entities_now(state)
        state.entity_id_mapping.update(id_mapping)

    # Build ID lookup from merged canonical entities
    existing_by_id: dict[str, Entity] = {}
    for entity in existing_by_label.values():
        existing_by_id[entity.id] = entity

    # Include any unmerged entities
    # Include any unmerged entities
    for entity in state.existing_graph.entities:
        if entity.id not in existing_by_id:
            existing_by_id[entity.id] = entity

    return existing_by_label, existing_by_id


def _merge_existing_entities_now(
    state: ExtractionState,
) -> tuple[dict[str, Entity], dict[str, str]]:
    """Merge existing entities when pre-merge wasn't done."""
    config = state.config
    assert config is not None
    assert state.existing_graph is not None

    entities_by_label: dict[str, list[Entity]] = {}
    for entity in state.existing_graph.entities:
        normalized = normalize_text(entity.label, config, cache=state.normalization_cache)
        if normalized not in entities_by_label:
            entities_by_label[normalized] = []
        entities_by_label[normalized].append(entity)

    existing_by_label: dict[str, Entity] = {}
    id_mapping: dict[str, str] = {}

    for normalized_label, entity_list in entities_by_label.items():
        cache = state.normalization_cache or {}
        canonical, mapping = merge_existing_entities(entity_list, config, cache)
        existing_by_label[normalized_label] = canonical
        id_mapping.update(mapping)

    return existing_by_label, id_mapping


def _merge_new_entities(
    state: ExtractionState,
    existing_by_label: dict[str, Entity],
    existing_by_id: dict[str, Entity],
) -> list[int]:
    """Merge new entities with existing. Returns indices to remove."""
    assert state is not None, "state parameter is required"
    config = state.config
    assert config is not None

    resolved = resolve_chain_mappings(state.entity_id_mapping)
    entities_to_remove: list[int] = []

    for idx, new_entity in enumerate(state.entities):
        normalized = normalize_text(new_entity.label, config, cache=state.normalization_cache)
        resolved_id = resolved.get(new_entity.id, new_entity.id)

        # Check by resolved ID
        # Check by resolved ID
        if resolved_id in existing_by_id:
            _do_merge(new_entity, existing_by_id[resolved_id], state)
            entities_to_remove.append(idx)

        # Check by label
        elif normalized in existing_by_label:
            _do_merge(new_entity, existing_by_label[normalized], state)
            entities_to_remove.append(idx)

    return entities_to_remove


def _do_merge(new_entity: Entity, existing: Entity, state: ExtractionState) -> None:
    """Merge new entity into existing."""
    assert new_entity is not None, "new_entity parameter is required"
    config = state.config
    assert config is not None
    cache = state.normalization_cache or {}
    _, mapping = merge_new_with_existing(new_entity, existing, config, cache)
    state.entity_id_mapping.update(mapping)


def _add_remaining_existing(state: ExtractionState, existing_by_label: dict[str, Entity]) -> None:
    """
    Add existing entities that weren't merged with new entities.

    After merging, some existing entities may not have matching new entities.
    This adds them to the final entity list to preserve the complete graph.
    Entities with duplicate canonical_key are remapped (not added) to preserve
    relationship integrity without creating invalid duplicate keys.

    Args:
        state: Extraction state with entities list to extend
        existing_by_label: Map of existing entities (unmerged ones remain)
    """
    assert state is not None, "state parameter is required"
    assert existing_by_label is not None, "existing_by_label parameter is required"
    config = state.config
    assert config is not None
    cache = state.normalization_cache or {}

    # Map canonical_key → entity for O(1) lookup of canonical target
    # Map canonical_key → entity for O(1) lookup of canonical target
    seen_key_to_entity = {e.canonical_key: e for e in state.entities}
    seen_ids = {e.id for e in state.entities}
    keys_to_delete: list[str] = []

    for norm_label, entity in existing_by_label.items():
        if entity.id in seen_ids:
            continue
        if entity.canonical_key in seen_key_to_entity:
            # Merge entity's data into the canonical entity (in-place) so no properties,
            # aliases, or descriptions are lost, then register the ID remapping so
            # relationships are redirected via merge_and_deduplicate_relationships().
            canonical = seen_key_to_entity[entity.canonical_key]
            _, mapping = merge_new_with_existing(
                entity, canonical, config, cache, merge_reason="canonical_key_collision"
            )
            state.entity_id_mapping.update(mapping)
            logger.warning(
                f"Duplicate canonical_key for entity '{entity.id}' "
                f"- merging into canonical '{canonical.id}'"
            )
            keys_to_delete.append(norm_label)
            continue
        state.entities.append(entity)
        seen_key_to_entity[entity.canonical_key] = entity
        seen_ids.add(entity.id)

    # Remove remapped entities from existing_by_label so _validate_entity_accounting() is accurate
    # Remove remapped entities from existing_by_label so _validate_entity_accounting() is accurate
    for key in keys_to_delete:
        del existing_by_label[key]


def _validate_entity_accounting(
    initial_new: int,
    initial_existing: int,
    final: int,
    merged_new: int,
    existing_by_label: dict[str, Entity],
) -> None:
    """
    Validate that all entities are accounted for after merge.

    Ensures: initial_new + initial_existing = final + merged
    Logs warning if there's a discrepancy, which may indicate a bug.

    Args:
        initial_new: Count of new entities before merge
        initial_existing: Count of existing entities before merge
        final: Count of entities after merge
        merged_new: Count of new entities that were merged
        existing_by_label: Remaining existing entities (for calculating existing merged)
    """
    assert isinstance(initial_new, int), "initial_new must be an integer"
    assert isinstance(final, int), "final must be an integer"
    merged_existing = initial_existing - len(existing_by_label)
    total_merged = merged_new + merged_existing
    input_count = initial_new + initial_existing
    accounted = final + total_merged

    if accounted != input_count:
        logger.warning(
            f"Entity merge accounting discrepancy | Input: {input_count} | Accounted: {accounted}"
        )
        logger.debug(f"Final: {final} | Merged: {total_merged}")
    else:
        logger.debug(
            f"Entity merge validated | {input_count} input = {final} final + {total_merged} merged"
        )


async def merge_and_deduplicate_relationships(state: ExtractionState) -> None:
    """
    Merge new relationships with existing and remove duplicates.

    Performs relationship merging:
    1. Updates entity IDs using resolved mapping
    2. Normalizes relationship types for matching
    3. Merges duplicate relationships (same from, to, type)
    4. Removes orphaned relationships (missing entities)
    5. Validates relationship count accounting

    Args:
        state: Extraction state with relationships to merge
    """
    assert state is not None, "state parameter is required"
    config = state.config
    assert config is not None

    initial_count = len(state.all_relationships)
    existing_rels = state.existing_graph.relationships if state.existing_graph else None
    entity_ids = {e.id for e in state.entities}

    state.relationships = await merge_relationships(
        state.relationships,
        existing_rels,
        state.entity_id_mapping,
        config,
        entity_ids=entity_ids,
    )

    # Log accounting
    # Log accounting
    if initial_count > 0:
        final = len(state.relationships)
        expected_min = int(initial_count * 0.8)
        if final < expected_min:
            retention_pct = (final / initial_count) * 100
            logger.warning(
                f"✨ Relationship optimization: {final}/{initial_count} ({retention_pct:.1f}%) kept after deduplication and quality filtering"
            )
            logger.debug(f"Expected minimum: {expected_min} relationships")


def _handle_validation_errors(
    errors: list[str],
    state: ExtractionState,
    config: OntologyConfig,
) -> None:
    """Handle validation errors, distinguishing between unknown types and real errors."""
    assert errors is not None, "errors parameter is required"
    assert state is not None, "state parameter is required"
    assert config is not None, "config parameter is required"

    # Check if errors are only about unknown types (expected during incremental extraction)
    # Check if errors are only about unknown types (expected during incremental extraction)
    unknown_type_errors = [
        e
        for e in errors
        if "unknown entity types" in e.lower() or "unknown relationship types" in e.lower()
    ]
    other_errors = [e for e in errors if e not in unknown_type_errors]

    if unknown_type_errors and not other_errors:
        # Only unknown type errors - expected during incremental extraction
        # Only unknown type errors - expected during incremental extraction
        logger.debug(
            f"Validation: {len(unknown_type_errors)} type(s) not yet in schema "
            f"(will be added during schema evolution)"
        )
    elif other_errors:
        _log_and_collect_validation_errors(other_errors, state, config)


def _log_and_collect_validation_errors(
    errors: list[str],
    state: ExtractionState,
    config: OntologyConfig,
) -> None:
    """Log and collect validation errors, raising if continue_on_error is disabled."""
    assert errors is not None, "errors parameter is required"
    assert state is not None, "state parameter is required"
    assert config is not None, "config parameter is required"

    logger.error(f"Validation found {len(errors)} critical error(s)")
    for i, error in enumerate(errors, 1):
        logger.error(f"  [{i}] {error}")

    for error in errors:
        collect_error_if_enabled(
            state.error_collector, config, "error", "validation_error", f"Pre-save: {error}"
        )

    if not config.error_handling.continue_on_error:
        raise ValueError(f"Validation failed with {len(errors)} error(s). First: {errors[0]}")


def _log_validation_warnings(warnings: list[str]) -> None:
    """Log validation warnings."""
    assert warnings is not None, "warnings parameter is required"
    assert len(warnings) > 0, "warnings list must not be empty"

    logger.debug(f"Validation found {len(warnings)} warning(s)")
    for i, warning in enumerate(warnings, 1):
        logger.debug(f"  [{i}] {warning}")


def _prune_invalid_restrictions(
    schema: OntologySchema,
    entities: list[Entity] | None = None,
) -> list[str]:
    assert schema is not None, "schema parameter is required"
    assert hasattr(schema, "entity_types"), "schema must have entity_types"
    assert hasattr(schema, "relationship_types"), "schema must have relationship_types"

    _materialize_missing_inverse_relationship_types(schema)
    entity_type_names = set(schema.entity_types.keys())
    removed_messages: list[str] = []
    entity_type_index = _build_entity_label_to_type_index(entities or [], schema)

    for type_name, type_def in schema.entity_types.items():
        valid_restrictions: list = []
        for restriction in type_def.restrictions:
            reconciled_property = _reconcile_restriction_property_name(
                type_name,
                restriction,
                schema,
            )
            if reconciled_property is not None and reconciled_property != restriction.property:
                restriction.property = reconciled_property

            if restriction.on_class and restriction.on_class not in entity_type_names:
                reconciled_on_class = _reconcile_restriction_class_name(
                    restriction.on_class,
                    entity_type_index,
                )
                if reconciled_on_class is not None:
                    restriction.on_class = reconciled_on_class

            if (
                isinstance(restriction.value, str)
                and restriction.value not in entity_type_names
                and restriction.restriction_type
                in (
                    RestrictionType.SOME_VALUES_FROM,
                    RestrictionType.ALL_VALUES_FROM,
                )
            ):
                reconciled_value = _reconcile_restriction_class_name(
                    restriction.value,
                    entity_type_index,
                )
                if reconciled_value is not None:
                    restriction.value = reconciled_value

            if restriction.property not in schema.relationship_types:
                removed_messages.append(
                    f"Entity type '{type_name}': restriction removed due to unknown property '{restriction.property}'"
                )
                continue

            if restriction.on_class and restriction.on_class not in entity_type_names:
                removed_messages.append(
                    f"Entity type '{type_name}': restriction removed due to unknown class '{restriction.on_class}'"
                )
                continue

            if (
                isinstance(restriction.value, str)
                and restriction.value not in entity_type_names
                and restriction.restriction_type
                in (
                    RestrictionType.SOME_VALUES_FROM,
                    RestrictionType.ALL_VALUES_FROM,
                )
            ):
                removed_messages.append(
                    f"Entity type '{type_name}': restriction removed due to unknown class '{restriction.value}'"
                )
                continue

            valid_restrictions.append(restriction)

        type_def.restrictions = valid_restrictions

    return removed_messages


def _tokenize_relationship_like_text(text: str) -> list[str]:
    """Tokenize relationship/type-like text for conservative lexical reconciliation."""
    assert text is not None, "text parameter is required"
    spaced = split_identifier_words(text).replace("_", " ").replace("-", " ")
    return [token.lower() for token in spaced.split() if token]


def _normalize_relation_token(token: str) -> str:
    """Apply a lightweight lemmatization heuristic for relationship tokens."""
    assert token is not None, "token parameter is required"
    lowered = token.lower()
    if lowered.endswith("ies") and len(lowered) > 4:
        return lowered[:-3] + "y"
    if lowered.endswith("ing") and len(lowered) > 5:
        return lowered[:-3]
    if lowered.endswith("ed") and len(lowered) > 4:
        root = lowered[:-2]
        return root if root.endswith("e") else root + "e"
    if lowered.endswith("es") and len(lowered) > 4:
        root = lowered[:-2]
        return root if root.endswith("e") else root + "e"
    if lowered.endswith("s") and len(lowered) > 3:
        return lowered[:-1]
    return lowered


def _relationship_match_key(text: str) -> str:
    """Build a compact lexical key for conservative relationship matching."""
    assert text is not None, "text parameter is required"
    return "".join(_normalize_relation_token(token) for token in _tokenize_relationship_like_text(text))


def _build_entity_label_to_type_index(
    entities: list[Entity],
    schema: OntologySchema,
) -> dict[str, set[str]]:
    """Index entity labels and aliases by their concrete schema type."""
    assert entities is not None, "entities parameter is required"
    assert schema is not None, "schema parameter is required"

    index: dict[str, set[str]] = {}
    placeholder_types = {"entity", "thing", "object", "concept", "misc", "unknown"}
    for entity in entities:
        if entity.type not in schema.entity_types:
            continue
        if entity.type.strip().lower() in placeholder_types:
            continue
        for text in [entity.label, *(entity.alias_names or [])]:
            if not text:
                continue
            for match_key in _build_shape_match_keys(text):
                index.setdefault(match_key, set()).add(entity.type)
    return index


def _reconcile_restriction_class_name(
    class_name: str,
    entity_type_index: dict[str, set[str]],
) -> str | None:
    """Map unknown restriction class names to a unique entity-backed schema type."""
    assert class_name is not None, "class_name parameter is required"
    assert entity_type_index is not None, "entity_type_index parameter is required"

    matched_types: set[str] = set()
    for match_key in _build_shape_match_keys(class_name):
        matched_types.update(entity_type_index.get(match_key, set()))

    if len(matched_types) != 1:
        return None

    return next(iter(matched_types))


def _bounded_edit_distance(left: str, right: str, max_distance: int) -> int:
    """Compute a bounded Levenshtein distance for small lexical reconciliation checks."""
    assert left is not None, "left parameter is required"
    assert right is not None, "right parameter is required"
    assert isinstance(max_distance, int), "max_distance must be an integer"

    if left == right:
        return 0
    if abs(len(left) - len(right)) > max_distance:
        return max_distance + 1

    previous = list(range(len(right) + 1))
    for i, left_char in enumerate(left, start=1):
        current = [i]
        row_min = current[0]
        for j, right_char in enumerate(right, start=1):
            cost = 0 if left_char == right_char else 1
            current.append(
                min(
                    previous[j] + 1,
                    current[j - 1] + 1,
                    previous[j - 1] + cost,
                )
            )
            row_min = min(row_min, current[-1])
        if row_min > max_distance:
            return max_distance + 1
        previous = current
    return previous[-1]


def _restriction_context_tokens(type_name: str, restriction) -> set[str]:
    """Collect class-side context tokens that can justify endpoint-qualified restriction properties."""
    assert type_name is not None, "type_name parameter is required"
    assert restriction is not None, "restriction parameter is required"

    context_tokens: set[str] = set()
    for text in (type_name, restriction.on_class):
        if text:
            context_tokens.update(_normalize_relation_token(token) for token in _tokenize_relationship_like_text(text))
    if isinstance(restriction.value, str):
        context_tokens.update(
            _normalize_relation_token(token) for token in _tokenize_relationship_like_text(restriction.value)
        )
    return {token for token in context_tokens if token}


def _restriction_target_type_name(
    restriction,
    schema: OntologySchema,
) -> str | None:
    """Resolve the class-valued target type for a restriction when available."""
    assert restriction is not None, "restriction parameter is required"
    assert schema is not None, "schema parameter is required"

    class_valued_restrictions = {
        RestrictionType.SOME_VALUES_FROM,
        RestrictionType.ALL_VALUES_FROM,
        RestrictionType.MIN_QUALIFIED_CARDINALITY,
        RestrictionType.MAX_QUALIFIED_CARDINALITY,
        RestrictionType.EXACT_QUALIFIED_CARDINALITY,
    }

    if restriction.on_class and restriction.on_class in schema.entity_types:
        return restriction.on_class

    if (
        restriction.restriction_type in class_valued_restrictions
        and isinstance(restriction.value, str)
        and restriction.value in schema.entity_types
    ):
        return restriction.value

    return None


def _are_schema_types_compatible(
    left_type: str | None,
    right_type: str | None,
    schema: OntologySchema,
) -> bool:
    """Return True when schema types are equal or in the same ancestor chain."""
    assert schema is not None, "schema parameter is required"

    if not left_type or not right_type:
        return False
    if left_type == right_type:
        return True
    if left_type not in schema.entity_types or right_type not in schema.entity_types:
        return False

    left_ancestors = set(_finalize_ancestor_chain(left_type, schema))
    right_ancestors = set(_finalize_ancestor_chain(right_type, schema))
    return left_type in right_ancestors or right_type in left_ancestors


def _inverse_restriction_alias_keys(existing_name: str) -> set[str]:
    """Return lexical keys that represent the inverse request for an existing relation name."""
    assert existing_name is not None, "existing_name parameter is required"

    tokens = [_normalize_relation_token(token) for token in _tokenize_relationship_like_text(existing_name)]
    tokens = [token for token in tokens if token]
    if not tokens:
        return set()

    alias_keys = {"".join(tokens)}
    if tokens[-1] == "by" and len(tokens) > 1:
        alias_keys.add("".join(tokens[:-1]))
    return {key for key in alias_keys if key}


def _materialize_requested_inverse_restriction_property(
    type_name: str,
    restriction,
    schema: OntologySchema,
) -> str | None:
    """Create a requested restriction property when a unique reverse-compatible relation exists."""
    assert type_name is not None, "type_name parameter is required"
    assert restriction is not None, "restriction parameter is required"
    assert schema is not None, "schema parameter is required"

    target_type = _restriction_target_type_name(restriction, schema)
    if not target_type:
        return None

    property_tokens = [_normalize_relation_token(token) for token in _tokenize_relationship_like_text(restriction.property)]
    property_tokens = [token for token in property_tokens if token]
    if not property_tokens:
        return None

    property_key = "".join(property_tokens)
    target_tokens = [_normalize_relation_token(token) for token in _tokenize_relationship_like_text(target_type)]
    target_tokens = [token for token in target_tokens if token]
    scored_candidates: list[tuple[int, str]] = []

    for existing_name, rel_def in schema.relationship_types.items():
        if not _are_schema_types_compatible(rel_def.from_type, target_type, schema):
            continue
        if not _are_schema_types_compatible(rel_def.to_type, type_name, schema):
            continue

        score = 0
        if property_key in _inverse_restriction_alias_keys(existing_name):
            score = 100
        elif property_tokens[0] == "has" and property_tokens[1:] == target_tokens:
            score = 95

        if score <= 0:
            continue

        scored_candidates.append((score, existing_name))

    if not scored_candidates:
        return None

    scored_candidates.sort(key=lambda item: (-item[0], item[1]))
    best_score, best_name = scored_candidates[0]
    if len(scored_candidates) > 1 and scored_candidates[1][0] == best_score:
        return None

    best_def = schema.relationship_types[best_name]
    if restriction.property not in schema.relationship_types:
        schema.relationship_types[restriction.property] = RelationshipTypeDefinition(
            is_core=False,
            from_type=type_name,
            to_type=target_type,
            direction=best_def.direction,
            created_at=best_def.created_at,
            characteristics=list(best_def.characteristics),
            inverse_of=best_name,
            equivalent_properties=list(best_def.equivalent_properties),
            sub_property_of=None,
            property_chain=None,
            disjoint_with=list(best_def.disjoint_with),
        )
    if not best_def.inverse_of:
        best_def.inverse_of = restriction.property

    return restriction.property


def _reconcile_restriction_property_name(
    type_name: str,
    restriction,
    schema: OntologySchema,
) -> str | None:
    """Map unknown restriction properties to a unique strong existing relationship type match."""
    assert type_name is not None, "type_name parameter is required"
    assert restriction is not None, "restriction parameter is required"
    assert schema is not None, "schema parameter is required"

    if restriction.property in schema.relationship_types:
        return restriction.property

    property_tokens = [_normalize_relation_token(token) for token in _tokenize_relationship_like_text(restriction.property)]
    property_tokens = [token for token in property_tokens if token]
    if not property_tokens:
        return None

    property_key = "".join(property_tokens)
    context_tokens = _restriction_context_tokens(type_name, restriction)
    target_type = _restriction_target_type_name(restriction, schema)
    scored_candidates: list[tuple[int, str]] = []

    for existing_name, rel_def in schema.relationship_types.items():
        existing_tokens = [_normalize_relation_token(token) for token in _tokenize_relationship_like_text(existing_name)]
        existing_tokens = [token for token in existing_tokens if token]
        if not existing_tokens:
            continue

        score = 0
        existing_key = "".join(existing_tokens)
        if property_key == existing_key:
            score = 100
        elif (
            len(property_tokens) > len(existing_tokens)
            and property_tokens[: len(existing_tokens)] == existing_tokens
            and set(property_tokens[len(existing_tokens) :]).issubset(context_tokens)
        ):
            score = 90 - len(property_tokens[len(existing_tokens) :])
        elif (
            property_tokens[0] == "has"
            and property_tokens[1:]
            and set(property_tokens[1:]).issubset(context_tokens)
            and _are_schema_types_compatible(rel_def.from_type, type_name, schema)
            and (
                (
                    target_type is not None
                    and _are_schema_types_compatible(rel_def.to_type, target_type, schema)
                )
                or rel_def.to_type == "entity"
            )
        ):
            score = 72
        else:
            distance = _bounded_edit_distance(property_key, existing_key, 1)
            if distance <= 1:
                score = 80 - distance

        if score <= 0:
            continue

        if rel_def.from_type == "entity":
            score += 2
        elif _are_schema_types_compatible(rel_def.from_type, type_name, schema):
            score += 3

        if rel_def.to_type == "entity":
            score += 1
        elif target_type is not None and _are_schema_types_compatible(rel_def.to_type, target_type, schema):
            score += 3
        elif isinstance(restriction.value, str) and rel_def.to_type == restriction.value:
            score += 1

        scored_candidates.append((score, existing_name))

    if not scored_candidates:
        return _materialize_requested_inverse_restriction_property(type_name, restriction, schema)

    scored_candidates.sort(key=lambda item: (-item[0], item[1]))
    best_score, best_name = scored_candidates[0]
    if len(scored_candidates) > 1 and scored_candidates[1][0] == best_score:
        return None

    return best_name


def _materialize_missing_inverse_relationship_types(schema: OntologySchema) -> int:
    """Create lightweight inverse relationship definitions when inverse_of references them."""
    assert schema is not None, "schema parameter is required"
    assert hasattr(schema, "relationship_types"), "schema must have relationship_types"

    created = 0
    for rel_name, rel_def in list(schema.relationship_types.items()):
        inverse_name = rel_def.inverse_of
        if not inverse_name or inverse_name in schema.relationship_types:
            continue

        schema.relationship_types[inverse_name] = RelationshipTypeDefinition(
            is_core=rel_def.is_core,
            from_type=rel_def.to_type,
            to_type=rel_def.from_type,
            direction=rel_def.direction,
            created_at=rel_def.created_at,
            characteristics=list(rel_def.characteristics),
            inverse_of=rel_name,
            equivalent_properties=list(rel_def.equivalent_properties),
            sub_property_of=None,
            property_chain=None,
            disjoint_with=list(rel_def.disjoint_with),
        )
        created += 1

    return created


def _is_taxonomic_relationship_type(rel_type: str) -> bool:
    """Return True for relationship types that express subclass hierarchy."""
    assert rel_type is not None, "rel_type must not be None"

    normalized = rel_type.lower().replace("_", "").replace("-", "")
    return normalized in {"isa", "subclassof", "typeof", "kindof"}


def _build_shape_match_key(text: str) -> str:
    """Build a separator-insensitive comparison key for ontology shape checks."""
    assert text is not None, "text must not be None"
    return "".join(ch for ch in split_identifier_words(text).lower() if ch.isalnum())


def _build_shape_match_keys(text: str) -> set[str]:
    """Build spelling-tolerant comparison keys for ontology shape checks."""
    assert text is not None, "text must not be None"
    from taxonomy_ontology_accelerator.ontology_engine.utils.spelling_variants import (
        convert_spelling_compound,
    )

    variants = {
        text,
        convert_spelling_compound(text, "US"),
        convert_spelling_compound(text, "UK"),
    }
    return {_build_shape_match_key(variant) for variant in variants if variant}


def _is_schema_proxy_entity(entity: Entity, schema: OntologySchema) -> bool:
    """Return True when an entity appears to mirror a schema type label."""
    assert entity is not None, "entity must not be None"
    assert schema is not None, "schema must not be None"

    if entity.type not in schema.entity_types:
        return False
    if entity.type.strip().lower() in {"entity", "thing", "object", "concept", "misc", "unknown"}:
        return False

    return bool(_build_shape_match_keys(entity.label) & _build_shape_match_keys(entity.type))


def _merge_schema_proxy_annotations_into_type(
    entity: Entity,
    type_def: EntityTypeDefinition,
) -> None:
    """Preserve low-risk schema-like annotations from a proxy entity on its class."""
    assert entity is not None, "entity must not be None"
    assert type_def is not None, "type_def must not be None"

    if entity.description:
        if not type_def.description:
            type_def.description = entity.description
        elif entity.description not in type_def.description:
            type_def.description = f"{type_def.description}\n{entity.description}"

    if entity.aliases:
        for alias_name in entity.alias_names:
            if alias_name not in type_def.aliases:
                type_def.aliases.append(alias_name)

    source_urls = entity.properties.get("sourceUrls")
    if isinstance(source_urls, list) and source_urls:
        metadata_urls = type_def.metadata.setdefault("sourceUrls", [])
        for url in source_urls:
            if url not in metadata_urls:
                metadata_urls.append(url)


def _is_preservable_schema_proxy_property_value(value: object) -> bool:
    """Return True when a proxy property can safely move into class metadata."""
    if value in (None, "", [], {}):
        return True
    if isinstance(value, str | int | float | bool):
        return True
    if isinstance(value, list):
        return all(item is None or isinstance(item, str | int | float | bool) for item in value)
    return False


def _schema_proxy_properties_are_preservable(properties: dict[str, object]) -> bool:
    """Return True when all proxy properties can be preserved as class metadata."""
    assert properties is not None, "properties must not be None"
    return all(_is_preservable_schema_proxy_property_value(value) for value in properties.values())


def _merge_schema_proxy_properties_into_type_metadata(
    entity: Entity,
    type_def: EntityTypeDefinition,
) -> None:
    """Preserve scalar/list proxy properties on the class metadata."""
    assert entity is not None, "entity must not be None"
    assert type_def is not None, "type_def must not be None"

    for key, value in entity.properties.items():
        if value in (None, "", [], {}):
            continue
        if not _is_preservable_schema_proxy_property_value(value):
            continue

        existing = type_def.metadata.get(key)
        if existing is None:
            type_def.metadata[key] = list(value) if isinstance(value, list) else value
            continue

        if isinstance(existing, list):
            if isinstance(value, list):
                for item in value:
                    if item not in existing:
                        existing.append(item)
            elif value not in existing:
                existing.append(value)
            continue

        if isinstance(value, list):
            merged = [existing]
            for item in value:
                if item not in merged:
                    merged.append(item)
            type_def.metadata[key] = merged
            continue

        if existing != value:
            type_def.metadata[key] = [existing, value]


def _collapse_zero_degree_schema_proxy_entities(state: ExtractionState) -> int:
    """Remove exact schema exemplars that contribute no graph structure."""
    assert state is not None, "state must not be None"
    assert state.ontology_schema is not None, "ontology_schema must be present"

    relationship_degree: dict[str, int] = {}
    for relationship in state.relationships:
        relationship_degree[relationship.from_] = relationship_degree.get(relationship.from_, 0) + 1
        relationship_degree[relationship.to] = relationship_degree.get(relationship.to, 0) + 1

    retained: list[Entity] = []
    collapsed = 0

    for entity in state.entities:
        if not _is_schema_proxy_entity(entity, state.ontology_schema):
            retained.append(entity)
            continue

        if relationship_degree.get(entity.id, 0) != 0:
            retained.append(entity)
            continue

        if not _schema_proxy_properties_are_preservable(entity.properties):
            retained.append(entity)
            continue

        type_def = state.ontology_schema.entity_types.get(entity.type)
        if type_def is None:
            retained.append(entity)
            continue

        _merge_schema_proxy_annotations_into_type(entity, type_def)
        _merge_schema_proxy_properties_into_type_metadata(entity, type_def)
        collapsed += 1

    if collapsed == 0:
        return 0

    state.entities = retained
    return collapsed


def _restriction_exists_for_class(
    type_def: EntityTypeDefinition,
    property_name: str,
    value_class: str,
) -> bool:
    """Return True when an equivalent someValuesFrom restriction already exists."""
    assert type_def is not None, "type_def must not be None"
    assert property_name is not None, "property_name must not be None"
    assert value_class is not None, "value_class must not be None"

    return any(
        restriction.property == property_name
        and restriction.restriction_type == RestrictionType.SOME_VALUES_FROM
        and restriction.value == value_class
        for restriction in type_def.restrictions
    )


def _apply_schema_proxy_relationship_to_schema(
    source_class: str,
    target_class: str,
    relationship_type: str,
    schema: OntologySchema,
) -> bool:
    """Lift a proxy-backed graph edge into schema semantics when safe."""
    assert source_class is not None, "source_class must not be None"
    assert target_class is not None, "target_class must not be None"
    assert relationship_type is not None, "relationship_type must not be None"
    assert schema is not None, "schema must not be None"

    if source_class not in schema.entity_types or target_class not in schema.entity_types:
        return False
    if relationship_type not in schema.relationship_types:
        return False

    if _is_taxonomic_relationship_type(relationship_type):
        source_def = schema.entity_types[source_class]
        if source_class == target_class:
            return True
        if source_def.parent_type in (None, "", "entity", "thing", "object", "concept", "unknown"):
            if not _can_assign_parent_type(source_class, target_class, schema):
                return False
            source_def.parent_type = target_class
            return True
        return source_def.parent_type == target_class

    source_def = schema.entity_types[source_class]
    if _restriction_exists_for_class(source_def, relationship_type, target_class):
        return True

    source_def.restrictions.append(
        OWLRestriction(
            property=relationship_type,
            restriction_type=RestrictionType.SOME_VALUES_FROM,
            value=target_class,
        )
    )
    return True


def _collapse_relational_schema_proxy_entities(state: ExtractionState) -> int:
    """Collapse schema-proxy entities with convertible relationships into schema semantics."""
    assert state is not None, "state must not be None"
    assert state.ontology_schema is not None, "ontology_schema must be present"
    config = state.config
    assert config is not None, "config must be present"

    entity_by_id = {entity.id: entity for entity in state.entities}
    incident_relationships: dict[str, list[Relationship]] = {}
    for relationship in state.relationships:
        incident_relationships.setdefault(relationship.from_, []).append(relationship)
        incident_relationships.setdefault(relationship.to, []).append(relationship)

    removed_entity_ids: set[str] = set()
    removed_relationship_ids: set[str] = set()
    collapsed = 0

    for entity in state.entities:
        if not _is_schema_proxy_entity(entity, state.ontology_schema):
            continue
        if entity.id in removed_entity_ids:
            continue

        relationships = incident_relationships.get(entity.id, [])
        if not relationships:
            continue

        if not _schema_proxy_properties_are_preservable(entity.properties):
            continue

        type_def = state.ontology_schema.entity_types.get(entity.type)
        if type_def is None:
            continue

        converted_relationships: list[Relationship] = []
        can_convert_all = True
        for relationship in relationships:
            source_entity = entity_by_id.get(relationship.from_)
            target_entity = entity_by_id.get(relationship.to)
            if source_entity is None or target_entity is None:
                can_convert_all = False
                break
            if _is_placeholder_entity(source_entity, config) or _is_placeholder_entity(target_entity, config):
                can_convert_all = False
                break
            source_class = source_entity.type
            target_class = target_entity.type
            if not _apply_schema_proxy_relationship_to_schema(
                source_class,
                target_class,
                relationship.type,
                state.ontology_schema,
            ):
                can_convert_all = False
                break
            converted_relationships.append(relationship)

        if not can_convert_all:
            continue

        _merge_schema_proxy_annotations_into_type(entity, type_def)
        _merge_schema_proxy_properties_into_type_metadata(entity, type_def)
        removed_entity_ids.add(entity.id)
        removed_relationship_ids.update(rel.id for rel in converted_relationships)
        collapsed += 1

    if collapsed == 0:
        return 0

    state.entities = [entity for entity in state.entities if entity.id not in removed_entity_ids]
    state.relationships = [
        relationship for relationship in state.relationships if relationship.id not in removed_relationship_ids
    ]
    return collapsed


def _compute_hierarchy_max_depth(schema: OntologySchema) -> int:
    """Compute maximum type hierarchy depth in schema."""
    assert schema is not None, "schema must not be None"

    max_depth = 0
    for type_name in schema.entity_types:
        depth = 0
        current = type_name
        visited: set[str] = set()
        while current in schema.entity_types and current not in visited:
            visited.add(current)
            parent = schema.entity_types[current].parent_type
            if parent is None:
                break
            depth += 1
            current = parent
        max_depth = max(max_depth, depth)
    return max_depth


def _compute_ontology_shape_metrics(state: ExtractionState) -> dict[str, int | float]:
    """Compute structural ontology quality metrics from the final schema and graph."""
    assert state is not None, "state parameter is required"
    assert state.ontology_schema is not None, "ontology_schema must be present"

    config = state.config
    assert config is not None, "config must be present"

    graph = state.graph or OntologyGraph(
        domain=state.domain,
        schema_version=state.ontology_schema.version,
        entities=state.entities,
        relationships=state.relationships,
    )
    core_entity_name = config.schema_evolution.core_entity_type.name
    entity_by_id = {entity.id: entity for entity in graph.entities}
    placeholder_type_count = sum(
        1
        for type_name in state.ontology_schema.entity_types
        if type_name.strip().lower() in {"entity", "thing", "object", "concept", "misc", "unknown"}
    )
    placeholder_entity_count = sum(
        1
        for entity in graph.entities
        if entity.type.strip().lower() in {"entity", "thing", "object", "concept", "misc", "unknown"}
    )
    schema_proxy_entity_count = sum(
        1 for entity in graph.entities if _is_schema_proxy_entity(entity, state.ontology_schema)
    )
    subclass_relationships = [
        rel for rel in graph.relationships if _is_taxonomic_relationship_type(rel.type)
    ]
    same_type_subclass_count = 0
    for rel in subclass_relationships:
        source = entity_by_id.get(rel.from_)
        target = entity_by_id.get(rel.to)
        if source is None or target is None:
            continue
        if source.type == target.type:
            same_type_subclass_count += 1

    concrete_type_count = 0
    root_type_count = 0
    for type_name, type_def in state.ontology_schema.entity_types.items():
        if type_name == core_entity_name:
            continue
        if type_def.metadata.get("scaffold_type"):
            continue
        concrete_type_count += 1
        if type_def.parent_type in (None, core_entity_name):
            root_type_count += 1

    subclass_relationship_count = len(subclass_relationships)
    same_type_ratio = (
        round(same_type_subclass_count / subclass_relationship_count, 3)
        if subclass_relationship_count > 0
        else 0.0
    )
    relationship_type_count = len(state.ontology_schema.relationship_types)
    relationship_type_to_type_ratio = round(
        safe_divide(relationship_type_count, concrete_type_count),
        3,
    )
    child_type_counts: dict[str, int] = {}
    for type_name, type_def in state.ontology_schema.entity_types.items():
        parent_type = type_def.parent_type
        if parent_type:
            child_type_counts[parent_type] = child_type_counts.get(parent_type, 0) + 1

    abstract_class_direct_instance_count = 0
    abstract_class_direct_instance_types: set[str] = set()
    for entity in graph.entities:
        if entity.type == core_entity_name or entity.type not in state.ontology_schema.entity_types:
            continue
        if _is_schema_proxy_entity(entity, state.ontology_schema):
            continue

        type_def = state.ontology_schema.entity_types[entity.type]
        if type_def.metadata.get("scaffold_type") or child_type_counts.get(entity.type, 0) > 0:
            abstract_class_direct_instance_count += 1
            abstract_class_direct_instance_types.add(entity.type)

    return {
        "placeholder_type_count": placeholder_type_count,
        "placeholder_entity_count": placeholder_entity_count,
        "auto_created_entity_count": state.auto_created_entity_count,
        "schema_proxy_entity_count": schema_proxy_entity_count,
        "subclass_relationship_count": subclass_relationship_count,
        "same_type_subclass_count": same_type_subclass_count,
        "same_type_subclass_ratio": same_type_ratio,
        "concrete_type_count": concrete_type_count,
        "relationship_type_count": relationship_type_count,
        "relationship_type_to_type_ratio": relationship_type_to_type_ratio,
        "root_type_count": root_type_count,
        "hierarchy_max_depth": _compute_hierarchy_max_depth(state.ontology_schema),
        "abstract_class_direct_instance_count": abstract_class_direct_instance_count,
        "abstract_class_direct_instance_type_count": len(abstract_class_direct_instance_types),
    }


def _validate_ontology_shape_metrics(metrics: dict[str, int | float]) -> list[str]:
    """Convert ontology shape metrics into actionable structural warnings."""
    assert metrics is not None, "metrics must not be None"

    warnings: list[str] = []
    placeholder_type_count = int(metrics.get("placeholder_type_count", 0))
    placeholder_entity_count = int(metrics.get("placeholder_entity_count", 0))
    auto_created_entity_count = int(metrics.get("auto_created_entity_count", 0))
    schema_proxy_entity_count = int(metrics.get("schema_proxy_entity_count", 0))
    subclass_relationship_count = int(metrics.get("subclass_relationship_count", 0))
    same_type_subclass_count = int(metrics.get("same_type_subclass_count", 0))
    same_type_subclass_ratio = float(metrics.get("same_type_subclass_ratio", 0.0))
    concrete_type_count = int(metrics.get("concrete_type_count", 0))
    relationship_type_count = int(metrics.get("relationship_type_count", 0))
    relationship_type_to_type_ratio = float(metrics.get("relationship_type_to_type_ratio", 0.0))
    root_type_count = int(metrics.get("root_type_count", 0))
    hierarchy_max_depth = int(metrics.get("hierarchy_max_depth", 0))
    abstract_class_direct_instance_count = int(metrics.get("abstract_class_direct_instance_count", 0))
    abstract_class_direct_instance_type_count = int(
        metrics.get("abstract_class_direct_instance_type_count", 0)
    )

    if placeholder_type_count > 1 or (placeholder_type_count > 0 and placeholder_entity_count > 0):
        warnings.append(
            f"Ontology shape: {placeholder_type_count} placeholder type(s) remain in schema."
        )
    if placeholder_entity_count > 0:
        warnings.append(
            f"Ontology shape: {placeholder_entity_count} entity instance(s) still use placeholder types."
        )
    if auto_created_entity_count > 0:
        warnings.append(
            f"Ontology shape: {auto_created_entity_count} auto-created entity node(s) were needed during relationship building."
        )
    if schema_proxy_entity_count > 0:
        warnings.append(
            f"Ontology shape: {schema_proxy_entity_count} schema-proxy entity node(s) mirror class names and should stay in the schema layer."
        )
    if subclass_relationship_count > 0 and same_type_subclass_count > 0:
        warnings.append(
            "Ontology shape: same-type is_a relationships remain in the graph "
            f"({same_type_subclass_count}/{subclass_relationship_count}, ratio {same_type_subclass_ratio:.3f})."
        )
    if concrete_type_count >= FLAT_HIERARCHY_WARNING_MIN_TYPES and root_type_count >= max(
        FLAT_HIERARCHY_MIN_ROOTS,
        int(concrete_type_count * FLAT_HIERARCHY_ROOT_RATIO_THRESHOLD),
    ):
        warnings.append(
            f"Ontology shape: {root_type_count} concrete root types remain, indicating a flat hierarchy."
        )
    if (
        concrete_type_count >= FLAT_HIERARCHY_WARNING_MIN_TYPES
        and hierarchy_max_depth <= MIN_ACCEPTABLE_HIERARCHY_DEPTH
    ):
        warnings.append(
            f"Ontology shape: hierarchy max depth is only {hierarchy_max_depth}, indicating insufficient layering."
        )
    if (
        concrete_type_count >= RELATIONSHIP_TYPE_PRESSURE_MIN_TYPES
        and relationship_type_to_type_ratio >= RELATIONSHIP_TYPE_PRESSURE_RATIO_THRESHOLD
    ):
        warnings.append(
            "Ontology shape: relationship type vocabulary is growing faster than the class structure "
            f"({relationship_type_count} relationship types / {concrete_type_count} concrete types, "
            f"ratio {relationship_type_to_type_ratio:.3f})."
        )
    if abstract_class_direct_instance_count >= ABSTRACT_CLASS_INSTANCE_PRESSURE_MIN_INSTANCES:
        warnings.append(
            "Ontology shape: broad classes are carrying too many direct individuals "
            f"({abstract_class_direct_instance_count} direct individuals across "
            f"{abstract_class_direct_instance_type_count} broad classes)."
        )

    return warnings


def _prune_redundant_taxonomic_relationships(
    relationships: list[Relationship],
    entities: list[Entity],
) -> int:
    """Remove taxonomic relationships after schema hierarchy has been inferred."""
    assert relationships is not None, "relationships must not be None"
    assert entities is not None, "entities must not be None"

    retained: list[Relationship] = []
    removed_count = 0

    for rel in relationships:
        if not _is_taxonomic_relationship_type(rel.type):
            retained.append(rel)
            continue

        removed_count += 1

    if removed_count > 0:
        relationships[:] = retained

    return removed_count


def _is_placeholder_entity(entity: Entity, config: OntologyConfig) -> bool:
    """Return True when an entity is a synthetic placeholder/default-type node."""
    assert entity is not None, "entity must not be None"
    assert config is not None, "config must not be None"

    default_type = config.relationship_processing.auto_created_entity_default_type
    return bool(entity.metadata.get("auto_created")) or entity.type == default_type


def _build_placeholder_match_key(
    label: str,
    config: OntologyConfig,
    cache: dict[str, str],
) -> str:
    """Build a spelling-aware comparison key for placeholder reconciliation."""
    assert label is not None, "label must not be None"
    assert config is not None, "config must not be None"

    normalized = normalize_text(label, config, cache=cache)
    normalized = convert_spelling(
        normalized,
        config.naming_conventions.spelling_variant,
        config.naming_conventions.spelling_variant,
    )
    return re.sub(r"[^a-z0-9]+", "", normalized.lower())


def _collapse_placeholder_entities_into_concrete_matches(state: ExtractionState) -> int:
    """
    Merge placeholder entities into concrete entities when their normalized labels match.

    This removes synthetic fallback nodes created during relationship recovery/building
    once a proper typed entity with the same normalized label exists in the graph.
    """
    assert state is not None, "state must not be None"
    config = state.config
    assert config is not None

    cache = state.normalization_cache or {}
    concrete_by_label: dict[str, Entity] = {}

    for entity in state.entities:
        if not entity.label or _is_placeholder_entity(entity, config):
            continue
        normalized = _build_placeholder_match_key(entity.label, config, cache)
        if not normalized:
            continue

        existing = concrete_by_label.get(normalized)
        if existing is None:
            concrete_by_label[normalized] = entity
            continue

        existing_conf = validate_confidence(existing.metadata.get("confidence"), 0.0)
        current_conf = validate_confidence(entity.metadata.get("confidence"), 0.0)
        if current_conf > existing_conf:
            concrete_by_label[normalized] = entity

    if not concrete_by_label:
        return 0

    retained: list[Entity] = []
    collapsed = 0

    for entity in state.entities:
        if not entity.label or not _is_placeholder_entity(entity, config):
            retained.append(entity)
            continue

        normalized = _build_placeholder_match_key(entity.label, config, cache)
        concrete = concrete_by_label.get(normalized)
        if concrete is None or concrete.id == entity.id:
            retained.append(entity)
            continue

        _, mapping = merge_new_with_existing(
            entity,
            concrete,
            config,
            cache,
            merge_reason="placeholder_concrete_label_match",
        )
        state.entity_id_mapping.update(mapping)
        collapsed += 1

    if collapsed == 0:
        return 0

    state.entities = retained
    resolved_mapping = resolve_chain_mappings(state.entity_id_mapping)
    for rel in state.relationships:
        rel.from_ = resolved_mapping.get(rel.from_, rel.from_)
        rel.to = resolved_mapping.get(rel.to, rel.to)

    return collapsed


def _normalize_entity_identity_tokens(
    text: str,
    config: OntologyConfig,
    cache: dict[str, str],
) -> list[str]:
    """Normalize entity text into comparable tokens for conservative identity checks."""
    assert text is not None, "text must not be None"
    assert config is not None, "config must not be None"

    normalized = normalize_text(split_identifier_words(text), config, cache=cache)
    return [token for token in normalized.lower().split() if token]


def _build_type_content_match_keys(
    entity: Entity,
    config: OntologyConfig,
    cache: dict[str, str],
) -> set[str]:
    """
    Build conservative same-type content keys by removing entity type tokens.

    Keys are only emitted when at least one type token is removed, which keeps this pass
    focused on duplicate-like cases where the type words are merely repeated in the label.
    """
    assert entity is not None, "entity must not be None"
    assert config is not None, "config must not be None"

    if not entity.type:
        return set()

    type_tokens = set(_normalize_entity_identity_tokens(entity.type, config, cache))
    if not type_tokens:
        return set()

    candidate_texts = [entity.label, *(entity.alias_names or []), entity.canonical_key.replace("_", " ")]
    keys: set[str] = set()

    for text in candidate_texts:
        if not text:
            continue

        tokens = _normalize_entity_identity_tokens(text, config, cache)
        if not tokens:
            continue

        stripped_tokens = [token for token in tokens if token not in type_tokens]
        if not stripped_tokens or stripped_tokens == tokens:
            continue

        key = "".join(stripped_tokens)
        if len(key) >= 4:
            keys.add(key)

    return keys


def _collapse_duplicate_like_entities_by_type_content(state: ExtractionState) -> int:
    """
    Merge same-type entities when their type-stripped content keys match exactly.

    This is intentionally conservative. It catches duplicates such as
    `FasterDecisionProcessingService` vs `FasterDecisionService` while avoiding
    broad semantic deduplication at final export time.
    """
    assert state is not None, "state must not be None"
    config = state.config
    assert config is not None, "config must not be None"

    from taxonomy_ontology_accelerator.ontology_engine.processing.entity_deduplicator import (
        _merge_entities,
    )

    cache = state.normalization_cache or {}
    retained: list[Entity] = []
    signature_to_idx: dict[tuple[str, str], int] = {}
    merged_count = 0

    for entity in state.entities:
        if _is_placeholder_entity(entity, config):
            retained.append(entity)
            continue

        type_key = normalize_text(entity.type or "", config, cache=cache).lower()
        if not type_key:
            retained.append(entity)
            continue

        match_keys = _build_type_content_match_keys(entity, config, cache)
        if not match_keys:
            retained.append(entity)
            continue

        matched_idx = next(
            (
                signature_to_idx[(type_key, match_key)]
                for match_key in match_keys
                if (type_key, match_key) in signature_to_idx
            ),
            None,
        )
        if matched_idx is None:
            retained.append(entity)
            retained_idx = len(retained) - 1
            for match_key in match_keys:
                signature_to_idx[(type_key, match_key)] = retained_idx
            continue

        retained[matched_idx] = _merge_entities(retained[matched_idx], entity, config)
        state.entity_id_mapping[entity.id] = retained[matched_idx].id
        merged_count += 1

        for match_key in _build_type_content_match_keys(retained[matched_idx], config, cache):
            signature_to_idx[(type_key, match_key)] = matched_idx

    if merged_count == 0:
        return 0

    state.entities = retained
    resolved_mapping = resolve_chain_mappings(state.entity_id_mapping)
    for rel in state.relationships:
        rel.from_ = resolved_mapping.get(rel.from_, rel.from_)
        rel.to = resolved_mapping.get(rel.to, rel.to)

    return merged_count


def _build_entity_content_token_set(
    entity: Entity,
    config: OntologyConfig,
    cache: dict[str, str],
) -> set[str]:
    """Collect normalized content tokens for conservative direct-instance retyping."""
    assert entity is not None, "entity must not be None"
    assert config is not None, "config must not be None"

    tokens: set[str] = set()
    candidate_texts = [entity.label, *(entity.alias_names or []), entity.canonical_key.replace("_", " ")]
    for key, value in (entity.properties or {}).items():
        if key not in _DIRECT_INSTANCE_RETYPE_TEXT_PROPERTY_KEYS:
            continue
        if isinstance(value, list):
            candidate_texts.extend(str(item) for item in value if item)
        elif value:
            candidate_texts.append(str(value))
    for text in candidate_texts:
        if not text:
            continue
        tokens.update(_normalize_entity_identity_tokens(text, config, cache))
    return {token for token in tokens if token}


def _match_existing_child_type_for_broad_instance(
    entity: Entity,
    child_types: list[str],
    config: OntologyConfig,
    cache: dict[str, str],
    schema: OntologySchema | None = None,
    outgoing_relationships: list[Relationship] | None = None,
    entity_type_by_id: dict[str, str] | None = None,
) -> str | None:
    """Return a unique direct child type when its lexical signature matches the entity content."""
    assert entity is not None, "entity must not be None"
    assert child_types is not None, "child_types must not be None"
    assert config is not None, "config must not be None"

    parent_tokens = set(_normalize_entity_identity_tokens(entity.type, config, cache))
    if not parent_tokens:
        return None

    entity_tokens = _build_entity_content_token_set(entity, config, cache)
    if not entity_tokens or entity_tokens == parent_tokens:
        return None

    candidates: list[tuple[int, str]] = []
    for child_type in child_types:
        child_tokens = set(_normalize_entity_identity_tokens(child_type, config, cache))
        signature_tokens = child_tokens - parent_tokens
        if not signature_tokens:
            continue
        if not signature_tokens.issubset(entity_tokens):
            continue
        candidates.append((len(signature_tokens), child_type))

    if not candidates:
        if not schema or not outgoing_relationships or not entity_type_by_id:
            return None

        evidence_candidates: list[tuple[int, str]] = []
        for child_type in child_types:
            child_def = schema.entity_types.get(child_type)
            if child_def is None:
                continue

            evidence_score = 0
            for restriction in child_def.restrictions:
                target_type = _restriction_target_type_name(restriction, schema)
                if not target_type:
                    continue
                for relationship in outgoing_relationships:
                    if relationship.type != restriction.property:
                        continue
                    observed_target_type = entity_type_by_id.get(relationship.to)
                    if observed_target_type and _are_schema_types_compatible(
                        observed_target_type,
                        target_type,
                        schema,
                    ):
                        evidence_score += 1
                        break

            if evidence_score > 0:
                evidence_candidates.append((evidence_score, child_type))

        if not evidence_candidates:
            return None

        evidence_candidates.sort(key=lambda item: (-item[0], item[1]))
        best_score, best_type = evidence_candidates[0]
        if len(evidence_candidates) > 1 and evidence_candidates[1][0] == best_score:
            return None
        return best_type

    candidates.sort(key=lambda item: (-item[0], item[1]))
    best_score, best_type = candidates[0]
    if len(candidates) > 1 and candidates[1][0] == best_score:
        return None

    return best_type


def _retype_direct_instances_to_existing_child_types(state: ExtractionState) -> int:
    """Retype direct instances off broad parents when one existing child class is an exact lexical fit."""
    assert state is not None, "state must not be None"
    assert state.ontology_schema is not None, "ontology_schema must not be None"
    config = state.config
    assert config is not None, "config must not be None"

    child_type_map: dict[str, list[str]] = {}
    for type_name, type_def in state.ontology_schema.entity_types.items():
        parent_type = type_def.parent_type
        if parent_type:
            child_type_map.setdefault(parent_type, []).append(type_name)

    if not child_type_map:
        return 0

    cache = state.normalization_cache or {}
    entity_type_by_id = {entity.id: entity.type for entity in state.entities}
    outgoing_relationships_by_entity: dict[str, list[Relationship]] = {}
    for relationship in state.relationships:
        outgoing_relationships_by_entity.setdefault(relationship.from_, []).append(relationship)
    changed = 0
    for entity in state.entities:
        if entity.type not in child_type_map:
            continue
        if _is_placeholder_entity(entity, config):
            continue
        if _is_schema_proxy_entity(entity, state.ontology_schema):
            continue

        matched_child = _match_existing_child_type_for_broad_instance(
            entity,
            child_type_map[entity.type],
            config,
            cache,
            state.ontology_schema,
            outgoing_relationships_by_entity.get(entity.id),
            entity_type_by_id,
        )
        if matched_child is None or matched_child == entity.type:
            continue

        entity.type = matched_child
        changed += 1

    return changed


def _finalize_ancestor_chain(type_name: str, schema: OntologySchema) -> list[str]:
    """Return a type's ancestor chain including itself."""
    assert type_name is not None, "type_name must not be None"
    assert schema is not None, "schema must not be None"

    chain: list[str] = [type_name]
    visited = {type_name}
    current = type_name
    while current in schema.entity_types:
        parent = schema.entity_types[current].parent_type
        if parent is None or parent in visited:
            break
        chain.append(parent)
        visited.add(parent)
        current = parent
    return chain


def _finalize_type_depth(type_name: str, schema: OntologySchema) -> int:
    """Compute type depth for finalization-time common-parent selection."""
    assert type_name is not None, "type_name must not be None"
    assert schema is not None, "schema must not be None"

    depth = 0
    current = type_name
    visited: set[str] = set()
    while current and current not in visited and current in schema.entity_types:
        visited.add(current)
        parent = schema.entity_types[current].parent_type
        if parent is None:
            break
        depth += 1
        current = parent
    return depth


def _find_finalize_common_parent(
    type_names: set[str],
    schema: OntologySchema,
    core_entity_name: str,
) -> str | None:
    """Find the most specific common parent for a set of observed types."""
    assert type_names is not None, "type_names must not be None"
    assert schema is not None, "schema must not be None"
    assert core_entity_name is not None, "core_entity_name must not be None"

    if not type_names:
        return None
    if len(type_names) == 1:
        return next(iter(type_names))

    ancestor_sets = [set(_finalize_ancestor_chain(type_name, schema)) for type_name in type_names]
    common = set.intersection(*ancestor_sets) if ancestor_sets else set()
    if not common:
        return core_entity_name

    preferred = [
        type_name
        for type_name in common
        if type_name != core_entity_name
        and type_name.lower() not in {"entity", "thing", "object", "concept", "unknown"}
    ]
    if preferred:
        return max(preferred, key=lambda type_name: _finalize_type_depth(type_name, schema))

    # For larger mixed samples, fall back to the best-supported non-trivial ancestor
    # instead of leaving the endpoint at the generic core entity.
    if len(type_names) < 4:
        return max(common, key=lambda type_name: _finalize_type_depth(type_name, schema))

    ancestor_support: dict[str, int] = {}
    for type_name in type_names:
        for ancestor in _finalize_ancestor_chain(type_name, schema)[1:]:
            if ancestor == core_entity_name:
                continue
            if ancestor.lower() in {"entity", "thing", "object", "concept", "unknown"}:
                continue
            ancestor_support[ancestor] = ancestor_support.get(ancestor, 0) + 1

    min_support = max(3, math.ceil(len(type_names) * 0.6))
    supported = [
        ancestor
        for ancestor, count in ancestor_support.items()
        if count >= min_support
    ]
    if supported:
        return max(
            supported,
            key=lambda type_name: (ancestor_support[type_name], _finalize_type_depth(type_name, schema)),
        )

    return max(common, key=lambda type_name: _finalize_type_depth(type_name, schema))


def _find_finalize_weighted_supported_parent(
    type_counts: Counter[str],
    schema: OntologySchema,
    core_entity_name: str,
) -> str | None:
    """Find a non-trivial ancestor supported by the weighted majority of observations."""
    assert type_counts is not None, "type_counts must not be None"
    assert schema is not None, "schema must not be None"
    assert core_entity_name is not None, "core_entity_name must not be None"

    filtered_counts = Counter(
        {
            type_name: count
            for type_name, count in type_counts.items()
            if count > 0 and type_name in schema.entity_types
        }
    )
    if not filtered_counts:
        return None

    total = sum(filtered_counts.values())
    if total <= 0:
        return None

    ancestor_support: Counter[str] = Counter()
    for type_name, count in filtered_counts.items():
        for ancestor in _finalize_ancestor_chain(type_name, schema):
            if ancestor == core_entity_name:
                continue
            if ancestor.lower() in {"entity", "thing", "object", "concept", "unknown"}:
                continue
            ancestor_support[ancestor] += count

    min_support = max(3, math.ceil(total * 0.6))
    supported = [
        ancestor
        for ancestor, support in ancestor_support.items()
        if support >= min_support
    ]
    if not supported:
        return None

    return max(
        supported,
        key=lambda type_name: (ancestor_support[type_name], _finalize_type_depth(type_name, schema)),
    )


def _is_weak_relationship_endpoint_type(
    type_name: str | None,
    schema: OntologySchema,
    core_entity_name: str,
) -> bool:
    """Return True when a relationship endpoint type is too weak to keep."""
    assert schema is not None, "schema must not be None"
    assert core_entity_name is not None, "core_entity_name must not be None"

    if not type_name or not type_name.strip():
        return True

    normalized = type_name.strip().lower()
    if normalized in {
        core_entity_name.strip().lower(),
        "entity",
        "thing",
        "object",
        "concept",
        "unknown",
    }:
        return True

    return type_name not in schema.entity_types


def _collect_relationship_endpoint_observations_from_schema_restrictions(
    schema: OntologySchema,
) -> tuple[dict[str, Counter[str]], dict[str, Counter[str]]]:
    """Collect relationship endpoint observations from class restrictions."""
    assert schema is not None, "schema must not be None"

    observed_from: dict[str, Counter[str]] = {}
    observed_to: dict[str, Counter[str]] = {}
    class_valued_restrictions = {
        RestrictionType.SOME_VALUES_FROM,
        RestrictionType.ALL_VALUES_FROM,
        RestrictionType.MIN_QUALIFIED_CARDINALITY,
        RestrictionType.MAX_QUALIFIED_CARDINALITY,
        RestrictionType.EXACT_QUALIFIED_CARDINALITY,
    }

    for type_name, type_def in schema.entity_types.items():
        for restriction in type_def.restrictions:
            if restriction.property not in schema.relationship_types:
                continue

            observed_from.setdefault(restriction.property, Counter())[type_name] += 1

            target_type: str | None = None
            if restriction.on_class and restriction.on_class in schema.entity_types:
                target_type = restriction.on_class
            elif (
                restriction.restriction_type in class_valued_restrictions
                and isinstance(restriction.value, str)
                and restriction.value in schema.entity_types
            ):
                target_type = restriction.value

            if target_type is not None:
                observed_to.setdefault(restriction.property, Counter())[target_type] += 1

    return observed_from, observed_to


def _tighten_relationship_type_constraints_from_graph(state: ExtractionState) -> int:
    """Tighten weak relationship endpoint constraints from final graph evidence."""
    assert state is not None, "state must not be None"
    assert state.ontology_schema is not None, "ontology_schema must not be None"
    config = state.config
    assert config is not None, "config must not be None"

    core_entity_name = config.schema_evolution.core_entity_type.name
    entity_by_id = {entity.id: entity for entity in state.entities}
    observed_from: dict[str, Counter[str]] = {}
    observed_to: dict[str, Counter[str]] = {}
    restriction_from, restriction_to = _collect_relationship_endpoint_observations_from_schema_restrictions(
        state.ontology_schema
    )

    for rel in state.relationships:
        rel_def = state.ontology_schema.relationship_types.get(rel.type)
        if rel_def is None:
            continue
        from_entity = entity_by_id.get(rel.from_)
        to_entity = entity_by_id.get(rel.to)
        if from_entity is None or to_entity is None:
            continue
        if _is_placeholder_entity(from_entity, config) or _is_placeholder_entity(to_entity, config):
            continue

        observed_from.setdefault(rel.type, Counter())[from_entity.type] += 1
        observed_to.setdefault(rel.type, Counter())[to_entity.type] += 1

    changed = 0
    for rel_name, rel_def in state.ontology_schema.relationship_types.items():
        from_types = {
            type_name
            for type_name in (
                set(observed_from.get(rel_name, Counter()).keys())
                | set(restriction_from.get(rel_name, Counter()).keys())
            )
            if type_name in state.ontology_schema.entity_types
        }
        to_types = {
            type_name
            for type_name in (
                set(observed_to.get(rel_name, Counter()).keys())
                | set(restriction_to.get(rel_name, Counter()).keys())
            )
            if type_name in state.ontology_schema.entity_types
        }

        from_type_counts = Counter(
            {
                type_name: observed_from.get(rel_name, Counter()).get(type_name, 0)
                + restriction_from.get(rel_name, Counter()).get(type_name, 0)
                for type_name in from_types
            }
        )
        to_type_counts = Counter(
            {
                type_name: observed_to.get(rel_name, Counter()).get(type_name, 0)
                + restriction_to.get(rel_name, Counter()).get(type_name, 0)
                for type_name in to_types
            }
        )

        if _is_weak_relationship_endpoint_type(rel_def.from_type, state.ontology_schema, core_entity_name) and from_types:
            common_parent = _find_finalize_common_parent(
                from_types,
                state.ontology_schema,
                core_entity_name,
            )
            if common_parent == core_entity_name:
                common_parent = _find_finalize_weighted_supported_parent(
                    from_type_counts,
                    state.ontology_schema,
                    core_entity_name,
                ) or common_parent
            if common_parent and common_parent != rel_def.from_type:
                rel_def.from_type = common_parent
                changed += 1

        if _is_weak_relationship_endpoint_type(rel_def.to_type, state.ontology_schema, core_entity_name) and to_types:
            common_parent = _find_finalize_common_parent(
                to_types,
                state.ontology_schema,
                core_entity_name,
            )
            if common_parent == core_entity_name:
                common_parent = _find_finalize_weighted_supported_parent(
                    to_type_counts,
                    state.ontology_schema,
                    core_entity_name,
                ) or common_parent
            if common_parent and common_parent != rel_def.to_type:
                rel_def.to_type = common_parent
                changed += 1

    return changed


def _prune_unused_relationship_type_definitions(state: ExtractionState) -> int:
    """Drop relationship types that have no surviving usage or schema references."""
    assert state is not None, "state must not be None"
    assert state.ontology_schema is not None, "ontology_schema must not be None"

    schema = state.ontology_schema
    used_relationship_types: set[str] = {
        rel.type for rel in state.relationships if rel.type in schema.relationship_types
    }

    for type_def in schema.entity_types.values():
        for restriction in type_def.restrictions or []:
            if restriction.property in schema.relationship_types:
                used_relationship_types.add(restriction.property)

    referenced_relationship_types = set(used_relationship_types)
    stack = list(used_relationship_types)

    while stack:
        rel_name = stack.pop()
        rel_def = schema.relationship_types.get(rel_name)
        if rel_def is None:
            continue

        related_names = set(rel_def.equivalent_properties) | set(rel_def.disjoint_with)
        if rel_def.inverse_of:
            related_names.add(rel_def.inverse_of)
        if rel_def.sub_property_of:
            related_names.add(rel_def.sub_property_of)
        if rel_def.property_chain is not None:
            related_names.update(rel_def.property_chain.properties)

        for related_name in related_names:
            if (
                related_name in schema.relationship_types
                and related_name not in referenced_relationship_types
            ):
                referenced_relationship_types.add(related_name)
                stack.append(related_name)

    prunable_names = [
        rel_name
        for rel_name in schema.relationship_types
        if rel_name not in referenced_relationship_types
    ]

    for rel_name in prunable_names:
        del schema.relationship_types[rel_name]

    return len(prunable_names)


def repair_graph_semantics(state: ExtractionState) -> dict[str, int]:
    """Apply bounded semantic-repair passes before graph validation."""
    assert state is not None, "state must not be None"
    assert state.ontology_schema is not None, "ontology_schema must not be None"

    counts = {
        "collapsed_placeholder_entities": 0,
        "collapsed_duplicate_like_entities": 0,
        "retyped_direct_instances": 0,
        "tightened_relationship_type_constraints": 0,
        "collapsed_relational_schema_proxy_entities": 0,
        "collapsed_zero_degree_schema_proxy_entities": 0,
        "pruned_redundant_taxonomic_relationships": 0,
        "passes": 0,
    }

    collapsed_placeholder_entities = _collapse_placeholder_entities_into_concrete_matches(state)
    counts["collapsed_placeholder_entities"] = collapsed_placeholder_entities
    if collapsed_placeholder_entities > 0:
        logger.info(
            "Collapsed "
            f"{collapsed_placeholder_entities} placeholder entity node(s) into concrete label matches before semantic repair"
        )

    collapsed_duplicate_like_entities = _collapse_duplicate_like_entities_by_type_content(state)
    counts["collapsed_duplicate_like_entities"] = collapsed_duplicate_like_entities
    if collapsed_duplicate_like_entities > 0:
        logger.info(
            "Collapsed "
            f"{collapsed_duplicate_like_entities} duplicate-like entity node(s) by same-type content matching before semantic repair"
        )

    for pass_number in range(1, SEMANTIC_REPAIR_MAX_PASSES + 1):
        pass_changes = 0

        retyped_direct_instances = _retype_direct_instances_to_existing_child_types(state)
        counts["retyped_direct_instances"] += retyped_direct_instances
        pass_changes += retyped_direct_instances

        tightened_relationship_types = _tighten_relationship_type_constraints_from_graph(state)
        counts["tightened_relationship_type_constraints"] += tightened_relationship_types
        pass_changes += tightened_relationship_types

        collapsed_relational_schema_proxy_entities = _collapse_relational_schema_proxy_entities(state)
        counts["collapsed_relational_schema_proxy_entities"] += collapsed_relational_schema_proxy_entities
        pass_changes += collapsed_relational_schema_proxy_entities

        collapsed_schema_proxy_entities = _collapse_zero_degree_schema_proxy_entities(state)
        counts["collapsed_zero_degree_schema_proxy_entities"] += collapsed_schema_proxy_entities
        pass_changes += collapsed_schema_proxy_entities

        removed_taxonomic_relationships = _prune_redundant_taxonomic_relationships(
            state.relationships,
            state.entities,
        )
        counts["pruned_redundant_taxonomic_relationships"] += removed_taxonomic_relationships
        pass_changes += removed_taxonomic_relationships

        collapsed_schema_proxy_entities_post_prune = _collapse_zero_degree_schema_proxy_entities(state)
        counts["collapsed_zero_degree_schema_proxy_entities"] += (
            collapsed_schema_proxy_entities_post_prune
        )
        pass_changes += collapsed_schema_proxy_entities_post_prune

        tightened_relationship_types_post_prune = _tighten_relationship_type_constraints_from_graph(state)
        counts["tightened_relationship_type_constraints"] += tightened_relationship_types_post_prune
        pass_changes += tightened_relationship_types_post_prune

        if pass_changes == 0:
            counts["passes"] = pass_number
            break

        logger.info(
            "Semantic repair pass "
            f"{pass_number}: retyped={retyped_direct_instances}, "
            f"tightened={tightened_relationship_types + tightened_relationship_types_post_prune}, "
            f"proxy_collapses={collapsed_relational_schema_proxy_entities + collapsed_schema_proxy_entities + collapsed_schema_proxy_entities_post_prune}, "
            f"taxonomic_prunes={removed_taxonomic_relationships}"
        )
        counts["passes"] = pass_number

    state.semantic_repair_counts = counts
    state.semantic_repair_completed = True
    return counts


def build_and_validate_graph(state: ExtractionState) -> None:
    """
    Build final ontology graph and run validation checks.

    Creates the OntologyGraph object and validates:
    1. Post-merge validation (entity/relationship integrity)
    2. Schema conformance (types, constraints)
    3. Required fields present
    4. Relationship endpoint validity

    Raises ValueError if critical validation errors found (unless
    continue_on_error is enabled in config).

    Args:
        state: Extraction state to populate with graph
    """
    config = state.config
    assert config is not None
    assert state.ontology_schema is not None

    if not getattr(state, "semantic_repair_completed", False):
        repair_graph_semantics(state)

    state.graph = OntologyGraph(
        domain=state.domain,
        schema_version=state.ontology_schema.version,
        entities=state.entities,
        relationships=state.relationships,
    )

    # Post-merge validation
    # Post-merge validation
    _is_valid, warnings = validate_merged_graph(state.graph)
    if warnings:
        logger.warning(f"Post-merge validation found {len(warnings)} issue(s)")
        logger.debug(f"First warning: {warnings[0] if warnings else 'none'}")

    removed_restrictions = _prune_invalid_restrictions(state.ontology_schema, state.entities)
    for msg in removed_restrictions:
        logger.warning(msg)
        collect_error_if_enabled(
            state.error_collector,
            config,
            "warning",
            "validation_warning",
            f"Pre-save: {msg}",
        )

    pruned_relationship_types = _prune_unused_relationship_type_definitions(state)
    if pruned_relationship_types > 0:
        logger.info(
            f"Pruned {pruned_relationship_types} unused relationship type definition(s) before validation"
        )

    # Validate before saving
    # NOTE: During incremental extraction with periodic flushing, entities may reference
    # types not yet in schema (schema evolution happens at end). This is expected.
    errors, val_warnings = validate_ontology(state.ontology_schema, state.graph)

    if errors:
        _handle_validation_errors(errors, state, config)

    if val_warnings:
        _log_validation_warnings(val_warnings)

    state.ontology_shape_metrics = _compute_ontology_shape_metrics(state)
    shape_warnings = _validate_ontology_shape_metrics(state.ontology_shape_metrics)
    for warning in shape_warnings:
        logger.warning(warning)
        if state.error_collector is not None:
            collect_error_if_enabled(
                state.error_collector,
                config,
                "warning",
                "ontology_shape_warning",
                warning,
            )


def save_schema_and_graph(state: ExtractionState) -> tuple[bool, bool, Path | str, Path | str]:
    """
    Save schema and graph JSON files to output directory.

    Saves:
    - schema.json: Ontology schema with entity/relationship type definitions
    - graph.json: Ontology graph with entities and relationships

    Uses file locking to prevent concurrent writes. Schema includes
    a graph representation for visualization tools.

    Args:
        state: Extraction state with schema and graph to save

    Returns:
        Tuple of (schema_saved, graph_saved, schema_path, graph_path)
    """
    config = state.config
    assert config is not None
    assert state.output_dir is not None
    assert state.ontology_schema is not None
    assert state.graph is not None

    schema_path = join_path(state.output_dir, config.output.schema_filename)
    graph_path = join_path(state.output_dir, config.output.graph_filename)

    # Prepare schema with graph representation
    # Prepare schema with graph representation
    schema_dict = state.ontology_schema.model_dump(mode="json")
    try:
        schema_dict["graph"] = schema_to_graph(state.ontology_schema)
    except Exception as e:
        logger.warning(f"Failed to generate schema graph visualization: {e}")
        logger.debug(f"Schema graph generation error details: {type(e).__name__}")

    schema_saved = _save_file(schema_path, schema_dict, "schema", state)
    graph_saved = _save_file(graph_path, state.graph.model_dump(mode="json"), "graph", state)

    # Update checkpoint after final save.
    # With periodic flushing, completion is updated in perform_periodic_flush; here we cover
    # flush_interval_batches=0 (no intermediate flushes) so the only save is this one.
    # Update checkpoint after final save.
    # With periodic flushing, completion is updated in perform_periodic_flush; here we cover
    # flush_interval_batches=0 (no intermediate flushes) so the only save is this one.
    if state.checkpoint_manager:
        if state.file_processing_status and schema_saved and graph_saved:
            _update_checkpoint_for_completed_files(state)
        elif not state.file_processing_status:
            _handle_checkpoint(state, schema_saved, graph_saved)

    return schema_saved, graph_saved, schema_path, graph_path


def _save_file(path: Path | str, data: dict, file_type: str, state: ExtractionState) -> bool:
    """
    Save a single output file with error handling.

    Uses file locking to prevent concurrent writes. Supports pretty
    printing and compression based on config settings.

    Args:
        path: Output file path
        data: Dictionary data to serialize as JSON
        file_type: Type name for error messages ("schema" or "graph")
        state: Extraction state for config and error collection

    Returns:
        True if saved successfully, False on error
    """
    assert path is not None, "path parameter is required"
    config = state.config
    assert config is not None

    # Use file locking only for local filesystem
    import contextlib

    from taxonomy_ontology_accelerator.commons.io.fsspec_utils import get_default_filesystem

    output_fs = state.output_fs or state.fs
    use_lock = isinstance(output_fs, type(get_default_filesystem()))
    lock_context = FileLock(Path(path)) if use_lock else contextlib.nullcontext()

    try:
        with lock_context:
            safe_write_json(
                path,
                data,
                fs=output_fs,
                pretty=config.output.pretty_print,
                compress=config.output.compress_output,
            )
        return True
    except OSError as e:
        logger.error(f"Failed to save {file_type}: {e}")
        collect_error_if_enabled(
            state.error_collector, config, "error", "file_error", f"Failed to save {file_type}: {e}"
        )
        return False
    except Exception as e:
        logger.error(f"Unexpected error saving {file_type}: {e}", exc_info=True)
        collect_error_if_enabled(
            state.error_collector, config, "error", "file_error", f"Unexpected error: {e}"
        )
        return False


def _mark_checkpoint_completed(state: ExtractionState) -> None:
    """Mark files as completed in checkpoint."""
    assert state is not None, "state parameter is required"
    assert state.checkpoint_manager is not None, "checkpoint_manager must be set"

    if state.file_processing_status:
        for file_path in state.file_processing_status:
            state.checkpoint_manager.remove_from_failed(file_path)
            state.checkpoint_manager.mark_file_completed(file_path)
        state.checkpoint_manager.log_checkpoint_summary("STORAGE COMPLETED")
        logger.info(
            f"[Persistence] Marked {len(state.file_processing_status)} file(s) as completed"
        )
    elif state.source_file_path:
        state.checkpoint_manager.remove_from_failed(state.source_file_path)
        state.checkpoint_manager.mark_file_completed(state.source_file_path)
        state.checkpoint_manager.log_checkpoint_summary("STORAGE COMPLETED")


def _mark_checkpoint_failed(
    state: ExtractionState, extraction_ok: bool, schema_saved: bool, graph_saved: bool
) -> None:
    """Mark files as failed in checkpoint with appropriate logging."""
    assert state is not None, "state parameter is required"
    assert state.checkpoint_manager is not None, "checkpoint_manager must be set"

    if not extraction_ok:
        logger.warning("[Persistence] Extraction produced no results - marking file as failed")
        logger.debug(f"Entities: {len(state.entities)}, Relationships: {len(state.relationships)}")
    else:
        logger.warning(
            f"[Persistence] Save errors detected | Schema: {'✓' if schema_saved else '✗'} | Graph: {'✓' if graph_saved else '✗'}"
        )

    if state.file_processing_status:
        for file_path in state.file_processing_status:
            state.checkpoint_manager.mark_file_failed(file_path)
        state.checkpoint_manager.log_checkpoint_summary("STORAGE FAILED")
    elif state.source_file_path:
        state.checkpoint_manager.mark_file_failed(state.source_file_path)
        state.checkpoint_manager.log_checkpoint_summary("STORAGE FAILED")


def _handle_checkpoint(state: ExtractionState, schema_saved: bool, graph_saved: bool) -> None:
    """
    Handle checkpoint status after saving outputs.

    Updates checkpoint manager based on save results:
    - If both saved and extraction produced results: mark completed
    - Otherwise: mark failed for retry on next run

    Args:
        state: Extraction state with checkpoint_manager
        schema_saved: Whether schema was saved successfully
        graph_saved: Whether graph was saved successfully
    """
    assert state is not None, "state parameter is required"
    assert isinstance(schema_saved, bool), "schema_saved must be a boolean"
    if not state.checkpoint_manager:
        return

    if not state.file_processing_status and not state.source_file_path:
        return

    extraction_ok = len(state.entities) > 0 or len(state.relationships) > 0

    if schema_saved and graph_saved and extraction_ok:
        _mark_checkpoint_completed(state)
    else:
        _mark_checkpoint_failed(state, extraction_ok, schema_saved, graph_saved)


def _build_export_path(state: ExtractionState, config: OntologyConfig) -> Path | str:
    """Build the final OWL/RDF export path for the current run."""
    assert state.output_dir is not None, "output_dir must be set"
    ext = ".ttl" if config.output.export.format == "turtle" else ".owl"
    return join_path(state.output_dir, f"{config.output.export.filename}{ext}")


def _build_export_status_path(state: ExtractionState, config: OntologyConfig) -> Path | str:
    """Build the status artifact path for OWL/RDF export."""
    assert state.output_dir is not None, "output_dir must be set"
    return join_path(state.output_dir, config.output.export.status_filename)


def _write_export_status(
    state: ExtractionState,
    status_path: Path | str,
    payload: dict[str, object],
) -> None:
    """Persist an OWL/RDF export status artifact next to the run outputs."""
    try:
        safe_write_json(
            status_path,
            payload,
            fs=state.output_fs or state.fs,
            pretty=True,
        )
    except Exception as status_error:
        logger.warning(f"[OWL Export] Failed to update export status artifact: {status_error}")


def _sync_export_stage_timings(
    state: ExtractionState,
    export_metrics: dict[str, float],
    total_seconds: float,
) -> None:
    """Record detailed export timings on the extraction state."""
    state.stage_timings["owl_export_total"] = total_seconds
    if "graph_assembly_seconds" in export_metrics:
        state.stage_timings["owl_export_graph_assembly"] = export_metrics["graph_assembly_seconds"]
    if "serialization_seconds" in export_metrics:
        state.stage_timings["owl_export_serialization"] = export_metrics["serialization_seconds"]
    if "upload_seconds" in export_metrics:
        state.stage_timings["owl_export_upload"] = export_metrics["upload_seconds"]


def _existing_export_in_progress_or_done(
    state: ExtractionState,
    status_path: Path | str,
    export_path: Path | str,
) -> bool:
    """Check whether this run already has an active or completed export artifact."""
    fs = state.output_fs or state.fs
    try:
        raw_status = safe_read_file(status_path, fs=fs)
        payload = json.loads(raw_status)
    except Exception:
        return False

    existing_status = str(payload.get("status", "")).lower()
    existing_output = str(payload.get("output_path", ""))
    return existing_status in {"pending", "running", "completed"} and existing_output == str(
        export_path
    )


def _build_async_export_payload(
    state: ExtractionState,
    schema_path: Path | str,
    graph_path: Path | str,
    export_path: Path | str,
    status_path: Path | str,
) -> Path:
    """Create a local async export job payload with schema/graph snapshots."""
    assert state.config is not None, "config must be loaded"
    assert state.ontology_schema is not None, "schema must be available"
    assert state.graph is not None, "graph must be available"

    config = state.config
    temp_dir = Path(tempfile.mkdtemp(prefix="toa-export-job-"))
    schema_snapshot = temp_dir / "schema.json"
    graph_snapshot = temp_dir / "graph.json"
    job_path = temp_dir / "job.json"

    safe_write_json(
        schema_snapshot,
        state.ontology_schema.model_dump(mode="json"),
        pretty=config.output.pretty_print,
    )
    safe_write_json(
        graph_snapshot,
        state.graph.model_dump(mode="json"),
        pretty=config.output.pretty_print,
    )
    safe_write_json(
        job_path,
        {
            "schema_snapshot": str(schema_snapshot),
            "graph_snapshot": str(graph_snapshot),
            "schema_path": str(schema_path),
            "graph_path": str(graph_path),
            "output_path": str(export_path),
            "status_path": str(status_path),
            "format": config.output.export.format,
            "ontology_config": config.model_dump(mode="json"),
            "queued_at": get_current_timestamp(config),
            "working_dir": str(temp_dir),
        },
        pretty=True,
    )
    return job_path


def _spawn_async_export_worker(job_path: Path) -> None:
    """Launch the detached worker process that completes OWL/RDF export."""
    repo_root = Path(__file__).resolve().parents[3]
    env = os.environ.copy()
    existing_pythonpath = env.get("PYTHONPATH")
    repo_root_str = str(repo_root)
    env["PYTHONPATH"] = (
        f"{repo_root_str}{os.pathsep}{existing_pythonpath}"
        if existing_pythonpath
        else repo_root_str
    )

    subprocess.Popen(
        [
            sys.executable,
            "-m",
            "taxonomy_ontology_accelerator.ontology_engine.storage.async_export_worker",
            str(job_path),
        ],
        cwd=repo_root_str,
        env=env,
        start_new_session=True,
    )


def export_to_owl_format(state: ExtractionState) -> None:
    """
    Export ontology to OWL/RDF format if configured.

    Exports the ontology to standard semantic web formats:
    - Turtle (.ttl): Human-readable RDF format
    - RDF/XML (.owl): W3C standard format

    Requires rdflib library. Export is optional and controlled by config.

    Args:
        state: Extraction state with schema and graph to export
    """
    config = state.config
    assert config is not None
    assert state.output_dir is not None
    assert state.ontology_schema is not None
    assert state.graph is not None

    if not config.output.export.enabled:
        return

    export_path = _build_export_path(state, config)
    status_path = _build_export_status_path(state, config)
    schema_path = join_path(state.output_dir, config.output.schema_filename)
    graph_path = join_path(state.output_dir, config.output.graph_filename)

    if _existing_export_in_progress_or_done(state, status_path, export_path):
        state.owl_export_requested = True
        state.owl_export_mode = config.output.export.mode
        state.owl_export_output_path = export_path
        state.owl_export_status_path = status_path
        logger.info(
            f"[OWL Export] Skipping export because status artifact already exists | Path: {Path(str(export_path)).name}"
        )
        return

    if state.owl_export_requested:
        logger.info(
            f"[OWL Export] Skipping duplicate export request | Mode: {state.owl_export_mode or config.output.export.mode} "
            f"| Path: {Path(str(state.owl_export_output_path or export_path)).name}"
        )
        return

    state.owl_export_requested = True
    state.owl_export_mode = config.output.export.mode
    state.owl_export_output_path = export_path
    state.owl_export_status_path = status_path

    try:
        if config.output.export.mode == "async":
            queue_started = time.perf_counter()
            _write_export_status(
                state,
                status_path,
                {
                    "status": "pending",
                    "mode": "async",
                        "format": config.output.export.format,
                        "output_path": str(export_path),
                        "schema_path": str(schema_path),
                        "graph_path": str(graph_path),
                        "queued_at": get_current_timestamp(config),
                    },
                )
            job_path = _build_async_export_payload(
                state,
                schema_path=schema_path,
                graph_path=graph_path,
                export_path=export_path,
                status_path=status_path,
            )
            try:
                _spawn_async_export_worker(job_path)
            except Exception as async_error:
                logger.warning(
                    f"[OWL Export] Async export scheduling failed, falling back to sync export: {async_error}"
                )
                state.owl_export_mode = "sync"
            else:
                enqueue_seconds = time.perf_counter() - queue_started
                state.stage_timings["owl_export_enqueue"] = enqueue_seconds
                logger.save(
                    f"[OWL Export] Queued async OWL/RDF export | Format: {config.output.export.format.upper()} | "
                    f"Path: {Path(str(export_path)).name}"
                )
                logger.debug(f"[OWL Export] Status path: {status_path}")
                return

        export_metrics: dict[str, float] = {}
        export_started = time.perf_counter()
        _write_export_status(
            state,
            status_path,
            {
                "status": "running",
                "mode": "sync",
                    "format": config.output.export.format,
                    "output_path": str(export_path),
                    "schema_path": str(schema_path),
                    "graph_path": str(graph_path),
                    "started_at": get_current_timestamp(config),
                },
            )

        export_to_owl_rdf(
            schema=state.ontology_schema,
            graph=state.graph,
            output_path=export_path,
            format=config.output.export.format,
            export_config=config.output.export,
            fs=state.output_fs or state.fs,
            ontology_config=config,
            export_metrics=export_metrics,
        )
        export_total = time.perf_counter() - export_started
        _sync_export_stage_timings(state, export_metrics, export_total)
        _write_export_status(
            state,
            status_path,
            {
                "status": "completed",
                "mode": "sync",
                    "format": config.output.export.format,
                    "output_path": str(export_path),
                    "schema_path": str(schema_path),
                    "graph_path": str(graph_path),
                    "completed_at": get_current_timestamp(config),
                    "timings": export_metrics,
                    "total_seconds": export_total,
                },
        )
        logger.save(
            f"[OWL Export] OWL/RDF exported | Format: {config.output.export.format.upper()} | Path: {Path(str(export_path)).name}"
        )
        logger.debug(f"[OWL Export] Full export path: {export_path}")
    except ImportError as e:
        _write_export_status(
            state,
            status_path,
            {
                "status": "failed",
                "mode": state.owl_export_mode or config.output.export.mode,
                    "format": config.output.export.format,
                    "output_path": str(export_path),
                    "schema_path": str(schema_path),
                    "graph_path": str(graph_path),
                    "failed_at": get_current_timestamp(config),
                    "error": str(e),
                },
            )
        collect_error_if_enabled(
            state.error_collector, config, "warning", "export_error", f"rdflib not available: {e}"
        )
        logger.warning(
            "OWL/RDF export skipped - rdflib not installed (install with: pip install rdflib)"
        )
    except (OSError, ValueError, FileNotFoundError) as e:
        _write_export_status(
            state,
            status_path,
            {
                "status": "failed",
                "mode": state.owl_export_mode or config.output.export.mode,
                    "format": config.output.export.format,
                    "output_path": str(export_path),
                    "schema_path": str(schema_path),
                    "graph_path": str(graph_path),
                    "failed_at": get_current_timestamp(config),
                    "error": str(e),
                },
            )
        collect_error_if_enabled(
            state.error_collector, config, "warning", "export_error", f"Export failed: {e}"
        )
        logger.warning(f"OWL/RDF export failed: {e}")
        logger.debug(f"Export error type: {type(e).__name__}")
    except Exception as e:
        _write_export_status(
            state,
            status_path,
            {
                "status": "failed",
                "mode": state.owl_export_mode or config.output.export.mode,
                    "format": config.output.export.format,
                    "output_path": str(export_path),
                    "schema_path": str(schema_path),
                    "graph_path": str(graph_path),
                    "failed_at": get_current_timestamp(config),
                    "error": str(e),
                },
            )
        collect_error_if_enabled(
            state.error_collector, config, "error", "export_error", f"Unexpected error: {e}"
        )
        logger.error(f"Unexpected error during OWL/RDF export: {e}", exc_info=True)


def _calculate_cost_estimate(state: ExtractionState) -> float | None:
    """Calculate cost estimate using genai-prices if available."""
    assert state is not None, "state parameter is required"
    assert state.config is not None, "state.config is required"
    if state.input_tokens == 0 or not HAS_GENAI_PRICES:
        return None

    try:
        from genai_prices import Usage as GenaiUsage
        from genai_prices import calc_price

        usage = GenaiUsage(
            input_tokens=state.input_tokens,
            output_tokens=state.output_tokens,
            cache_read_tokens=state.cache_read_tokens,
            cache_write_tokens=state.cache_write_tokens,
        )
        model_ref = str(state.config.llm.model)
        if ":" in model_ref:
            model_ref = model_ref.split(":", 1)[1]
        result = calc_price(usage, model_ref)
        return float(result.total_price)
    except Exception as e:
        logger.debug(f"Could not calculate cost estimate: {e}")
        return None


def _build_processing_metadata(
    state: ExtractionState, processing_time: float
) -> ProcessingMetadata:
    """Build processing metadata from extraction state."""
    assert state is not None, "state parameter is required"
    assert processing_time >= 0, "processing_time must be non-negative"

    estimated_cost = _calculate_cost_estimate(state)

    # Round stage timings
    # Round stage timings
    stage_timings = {name: round(duration, 3) for name, duration in state.stage_timings.items()}

    # Calculate throughput
    entities_per_sec = len(state.entities) / processing_time if processing_time > 0 else 0
    rels_per_sec = len(state.relationships) / processing_time if processing_time > 0 else 0
    ontology_shape_metrics = (
        state.ontology_shape_metrics
        if state.ontology_shape_metrics
        else _compute_ontology_shape_metrics(state)
        if state.ontology_schema is not None
        else {}
    )
    total_llm_tokens = (
        state.input_tokens
        + state.output_tokens
        + state.estimated_llm_input_tokens
        + state.estimated_llm_output_tokens
    )

    return ProcessingMetadata(
        total_entities_extracted=len(state.all_concepts),
        total_relationships_extracted=len(state.all_relationships),
        entities_after_deduplication=len(state.entities),
        relationships_after_deduplication=len(state.relationships),
        new_entity_types_created=state.new_entity_types,
        new_relationship_types_created=state.new_relationship_types,
        processing_time_seconds=processing_time,
        llm_calls_made=state.llm_calls,
        embeddings_generated=state.embeddings_generated,
        input_tokens=state.input_tokens,
        output_tokens=state.output_tokens,
        cache_read_tokens=state.cache_read_tokens,
        cache_write_tokens=state.cache_write_tokens,
        estimated_llm_input_tokens=state.estimated_llm_input_tokens,
        estimated_llm_output_tokens=state.estimated_llm_output_tokens,
        llm_usage_missing_calls=state.llm_usage_missing_calls,
        embedding_input_tokens=state.embedding_input_tokens,
        embedding_output_tokens=state.embedding_output_tokens,
        embedding_cache_read_tokens=state.embedding_cache_read_tokens,
        embedding_cache_write_tokens=state.embedding_cache_write_tokens,
        total_tokens=total_llm_tokens,
        estimated_cost_usd=estimated_cost,
        stage_timings=stage_timings,
        throughput_entities_per_sec=round(entities_per_sec, 2),
        throughput_relationships_per_sec=round(rels_per_sec, 2),
        cache_hit_rates={},
        peak_memory_mb=None,
        avg_memory_mb=None,
        ontology_shape_metrics=ontology_shape_metrics,
    )


def finalize_extraction_output(
    state: ExtractionState, schema_path: Path | str, graph_path: Path | str
) -> OntologyOutput:
    """Build processing metadata and return final OntologyOutput."""
    assert state.ontology_schema is not None
    assert state.graph is not None
    assert state.config is not None
    config = state.config

    if state.output_dir is not None:
        run_pipeline_alignment(state.output_dir, config, state.output_fs or state.fs)

    processing_time = time.time() - state.start_time
    metadata = _build_processing_metadata(state, processing_time)

    if state.output_dir and state.graph.entities and config.output.emit_pipeline_stage_lists:
        emit_entity_list(
            state.graph.entities,
            state.output_dir,
            stage="final",
            fs=state.output_fs or state.fs,
        )
        emit_relationship_list(
            state.graph.relationships,
            state.graph.entities,
            state.output_dir,
            stage="final",
            fs=state.output_fs or state.fs,
        )
        stage_stats = {
            "raw_extracted": {
                "entities": len(state.all_concepts),
                "relationships": len(state.all_relationships),
            },
            "after_deduplication": {
                "entities": metadata.entities_after_deduplication,
                "relationships": metadata.relationships_after_deduplication,
            },
            "after_merge": {
                "entities": len(state.graph.entities),
                "relationships": len(state.graph.relationships),
            },
        }
        emit_vocabulary(
            state.ontology_schema,
            state.graph,
            state.output_dir,
            stage_stats,
            fs=state.output_fs or state.fs,
        )
        logger.processing(
            f"[Stage 3] Emitted final output: {len(state.graph.entities)} entities, "
            f"{len(state.graph.relationships)} relationships"
        )

    _log_summary(state, processing_time)

    return OntologyOutput(
        ontology_schema=state.ontology_schema,
        graph=state.graph,
        metadata=metadata,
        errors=state.error_collector.to_list(),
        schema_path=str(schema_path),
        graph_path=str(graph_path),
    )


def _count_errors_and_warnings(
    error_collector: ErrorCollector | None,
) -> tuple[int, int, dict[str, int]]:
    """Count errors and warnings separately from error collector, with warning breakdown by type."""
    assert error_collector is None or hasattr(error_collector, "errors"), "invalid error_collector"
    assert isinstance(error_collector, object), "error_collector must be an object or None"
    if not error_collector:
        return 0, 0, {}
    errors = 0
    warnings = 0
    warning_types: dict[str, int] = {}
    for e in error_collector.errors:
        if e.get("severity", "error") == "error":
            errors += 1
        else:
            warnings += 1
            error_type = str(e.get("type", "unknown"))
            warning_types[error_type] = warning_types.get(error_type, 0) + 1
    return errors, warnings, warning_types


def _get_file_count(state: ExtractionState) -> int:
    """Determine actual file count from state."""
    assert state is not None, "state parameter is required"
    assert state.fs is not None, "state.fs must be initialized"
    if not state.source_file_path:
        return 1
    if state.fs.isdir(str(state.source_file_path)) and state.text_sources:
        return len(set(state.text_sources))
    return 1


def _log_summary(state: ExtractionState, processing_time: float) -> None:
    """Log extraction summary."""
    assert state.ontology_schema is not None
    assert state.output_dir is not None

    ent_per_sec = safe_divide(len(state.entities), processing_time)
    rel_per_sec = safe_divide(len(state.relationships), processing_time)
    avg_llm_time = safe_divide(processing_time, state.llm_calls)
    chunks_count = len(state.chunks) if state.chunks else 0
    file_count = _get_file_count(state)
    error_count, warning_count, warning_types = _count_errors_and_warnings(state.error_collector)
    scale = (
        f" | SCALE: {len(state.entities):,} nodes, {len(state.relationships):,} edges"
        if len(state.entities) > LARGE_GRAPH_SCALE_THRESHOLD
        else ""
    )

    logger.separator("=", 80, "bold green")
    logger.banner("ONTOLOGY EXTRACTION COMPLETE", emoji="🎉")
    logger.separator("=", 80, "bold green")
    logger.stats(
        f"Graph Size: {len(state.entities):,} entities, {len(state.relationships):,} relationships{scale}"
    )
    logger.stats(f"⏱️  Processing: {processing_time:.2f}s | Avg LLM: {avg_llm_time:.2f}s")
    logger.stats(
        f"📊 Input: {file_count} file(s) | {len(state.texts)} segments | {chunks_count} chunks"
    )
    logger.stats(
        f"🔍 Entities: {len(state.all_concepts)} → {len(state.entities)} final | {ent_per_sec:.1f}/sec"
    )
    logger.stats(
        f"🔗 Rels: {len(state.all_relationships)} → {len(state.relationships)} final | {rel_per_sec:.1f}/sec"
    )
    logger.stats(
        f"📋 Schema v{state.ontology_schema.version}: {len(state.ontology_schema.entity_types)} types (+{state.new_entity_types})"
    )
    if state.ontology_shape_metrics:
        logger.stats(
            "🧱 Structure: "
            f"{int(state.ontology_shape_metrics.get('root_type_count', 0))} concrete roots | "
            f"depth {int(state.ontology_shape_metrics.get('hierarchy_max_depth', 0))} | "
            f"placeholder types {int(state.ontology_shape_metrics.get('placeholder_type_count', 0))} | "
            f"auto-created {int(state.ontology_shape_metrics.get('auto_created_entity_count', 0))}"
        )
    logger.stats(f"🤖 LLM: {state.llm_calls} calls | {state.embeddings_generated} embeddings")
    logger.data(f"📦 Output: {state.output_dir}")

    if error_count > 0:
        logger.error(f"❌ Errors: {error_count}")
    if warning_count > 0:
        breakdown = ", ".join(
            f"{count} {wtype.replace('_', ' ')}" for wtype, count in warning_types.items()
        )
        logger.info(f"⚠️  Warnings: {warning_count} ({breakdown})")
    if error_count == 0 and warning_count == 0:
        logger.success("✨ No errors or warnings")


def should_perform_flush(state: ExtractionState, is_final: bool) -> bool:
    """
    Check if periodic flush should be performed.

    Flush triggers:
    1. Batch count reached (batches_processed >= flush_interval_batches)
    2. Timeout reached (time_since_flush >= flush_timeout_seconds)
    3. Final flush (is_final=True)

    Args:
        state: Current extraction state
        is_final: Whether this is the final flush at job end

    Returns:
        True if flush should be performed, False otherwise
    """
    assert state is not None, "state parameter is required"
    assert state.config is not None, "state.config must be set"
    assert hasattr(state.config, "checkpointing"), "config must have checkpointing"

    # Always flush on final
    # Always flush on final
    if is_final:
        return True

    flush_interval = state.config.checkpointing.flush_interval_batches
    flush_timeout = state.config.checkpointing.flush_timeout_seconds

    # If flush disabled (interval=0), only flush on final
    # If flush disabled (interval=0), only flush on final
    if flush_interval == 0:
        return False

    # Check batch count trigger
    # Check batch count trigger
    if state.batches_processed_since_flush >= flush_interval:
        return True

    # Check timeout trigger (if enabled)
    if flush_timeout > 0:
        time_since_flush = time.time() - state.last_flush_time
        if time_since_flush >= flush_timeout:
            return True

    return False


def _resolve_flush_canonical_key_collisions(merged_entities: list, state: ExtractionState) -> None:
    """
    Detect and resolve duplicate canonical_keys in the merged entity list.

    Called after the ID/label-based merge pass in _merge_entities_with_existing to
    catch collisions caused by generate_canonical_key() collapsing different separators
    (e.g. "British Nationals" and "British-Nationals" both → "british_nationals").

    The first entity with a given canonical_key is kept as canonical.  Subsequent
    duplicates are fully merged into it (no data loss) and removed from the list.
    ID remappings are registered in state.entity_id_mapping so that
    _merge_relationships_with_existing() redirects relationship endpoints correctly via
    resolve_chain_mappings().
    """
    assert merged_entities is not None, "merged_entities parameter is required"
    assert state is not None, "state parameter is required"

    from taxonomy_ontology_accelerator.ontology_engine.processing.entity_deduplicator import (
        _merge_entities,
    )

    config = state.config
    assert config is not None

    canonical_key_to_idx: dict[str, int] = {}
    indices_to_remove: list[int] = []

    for idx, entity in enumerate(merged_entities):
        if entity.canonical_key in canonical_key_to_idx:
            canonical_idx = canonical_key_to_idx[entity.canonical_key]
            canonical = merged_entities[canonical_idx]
            # Merge all data from duplicate into canonical — no information lost.
            # _merge_entities returns a NEW object, so we update the list slot immediately
            # and read the surviving ID from the new object (defensive: never rely on the
            # pre-merge canonical reference after the slot has been replaced).
            # Merge all data from duplicate into canonical — no information lost.
            # _merge_entities returns a NEW object, so we update the list slot immediately
            # and read the surviving ID from the new object (defensive: never rely on the
            # pre-merge canonical reference after the slot has been replaced).
            merged_entities[canonical_idx] = _merge_entities(canonical, entity, config)
            surviving_id = merged_entities[canonical_idx].id

            # Register remapping so relationships pointing to entity.id are redirected
            state.entity_id_mapping[entity.id] = surviving_id
            logger.warning(
                f"Duplicate canonical_key '{entity.canonical_key}' for entity '{entity.id}' "
                f"- merging into canonical '{surviving_id}'"
            )
            indices_to_remove.append(idx)
        else:
            canonical_key_to_idx[entity.canonical_key] = idx

    # Remove duplicates in reverse order to preserve correct indices
    # Remove duplicates in reverse order to preserve correct indices
    for idx in reversed(indices_to_remove):
        merged_entities.pop(idx)


def _merge_entities_with_existing(state: ExtractionState) -> list:
    """Merge new entities with existing, using _merge_entities for zero information loss.

    When a new entity matches an existing one (by ID or normalized label), their
    properties, aliases, descriptions, and metadata are merged — not dropped.
    After the ID/label pass, a canonical_key collision pass ensures no duplicate
    canonical_keys reach the saved graph.
    """
    assert state is not None, "state parameter is required"
    assert hasattr(state, "entities"), "state must have entities attribute"

    from taxonomy_ontology_accelerator.ontology_engine.processing.entity_deduplicator import (
        _merge_entities,
    )

    config = state.config
    assert config is not None

    existing_entities = state.existing_graph.entities if state.existing_graph else []
    # Index by ID for O(1) lookup and in-place merge
    # Index by ID for O(1) lookup and in-place merge
    entity_by_id: dict[str, int] = {e.id: idx for idx, e in enumerate(existing_entities)}
    existing_labels: dict[str, str] = {
        normalize_text(e.label, config): e.id for e in existing_entities if e.label
    }

    merged_entities = list(existing_entities)
    for entity in state.entities:
        # Match by ID — merge properties into existing entity
        # Match by ID — merge properties into existing entity
        if entity.id in entity_by_id:
            idx = entity_by_id[entity.id]
            merged_entities[idx] = _merge_entities(merged_entities[idx], entity, config)
            continue

        # Match by normalized label — merge and map ID for relationship resolution
        normalized = normalize_text(entity.label, config) if entity.label else ""
        if normalized and normalized in existing_labels:
            existing_id = existing_labels[normalized]
            state.entity_id_mapping[entity.id] = existing_id
            idx = entity_by_id[existing_id]
            merged_entities[idx] = _merge_entities(merged_entities[idx], entity, config)
            continue
        # Genuinely new entity
        # Genuinely new entity
        entity_by_id[entity.id] = len(merged_entities)
        merged_entities.append(entity)
        if normalized:
            existing_labels[normalized] = entity.id

    # Resolve any canonical_key collisions not caught by ID/label matching
    # (e.g. "British Nationals" vs "British-Nationals" — same canonical_key, different label)
    # Resolve any canonical_key collisions not caught by ID/label matching
    # (e.g. "British Nationals" vs "British-Nationals" — same canonical_key, different label)
    _resolve_flush_canonical_key_collisions(merged_entities, state)

    return merged_entities


def _merge_relationships_with_existing(state: ExtractionState) -> list:
    """Merge new relationships with existing relationships, deduplicating by key.

    Entity existence is guaranteed: every relationship endpoint either already had
    a matching entity or was auto-created by _auto_create_missing_entity() during
    the relationship-building stage (relationship_builder.py).  After entity merging,
    all endpoints are remapped via resolve_chain_mappings so no orphaned relationships
    can occur, and explicit orphan removal is not needed here.
    """
    assert state is not None, "state parameter is required"
    assert hasattr(state, "relationships"), "state must have relationships attribute"

    config = state.config
    assert config is not None

    # Resolve entity ID mappings so relationship endpoints use canonical IDs
    # Resolve entity ID mappings so relationship endpoints use canonical IDs
    resolved_mapping = resolve_chain_mappings(state.entity_id_mapping)

    existing_relationships = state.existing_graph.relationships if state.existing_graph else []

    # Build fresh copies of existing relationship objects — NOT a shallow list copy — so
    # that applying resolved_mapping to endpoints does NOT mutate the original objects
    # inside state.existing_graph.relationships.  model_copy(update=...) creates a new
    # Pydantic object; the remapping is applied inline so the index is already canonical.
    merged_relationships = [
        rel.model_copy(
            update={
                "from_": resolved_mapping.get(rel.from_, rel.from_),
                "to": resolved_mapping.get(rel.to, rel.to),
            }
        )
        for rel in existing_relationships
    ]

    # Build lookup: (from, to, type) → index in merged list for in-place merging
    # Built AFTER remapping so keys reflect canonical IDs
    # Build lookup: (from, to, type) → index in merged list for in-place merging
    # Built AFTER remapping so keys reflect canonical IDs
    existing_rel_index: dict[tuple[str, str, str], int] = {}
    for idx, rel in enumerate(merged_relationships):
        existing_rel_index[(rel.from_, rel.to, rel.type)] = idx

    _integrate_new_relationships(
        state.relationships, merged_relationships, existing_rel_index, resolved_mapping, config
    )

    # Filter any pre-existing self-referential relationships (can arise after ID remapping)
    # Filter any pre-existing self-referential relationships (can arise after ID remapping)
    self_loop_count = sum(1 for r in merged_relationships if r.from_ == r.to)
    if self_loop_count > 0:
        merged_relationships = [r for r in merged_relationships if r.from_ != r.to]
        logger.debug(f"Removed {self_loop_count} self-referential relationship(s) from merged set")

    return merged_relationships


def _integrate_new_relationships(
    new_rels: list,
    merged: list,
    index: dict,
    resolved_mapping: dict,
    config: "OntologyConfig",
) -> None:
    """Remap endpoints for each new rel and either merge into existing or append."""
    assert new_rels is not None, "new_rels parameter is required"
    assert merged is not None, "merged parameter is required"

    for rel in new_rels:
        rel.from_ = resolved_mapping.get(rel.from_, rel.from_)
        rel.to = resolved_mapping.get(rel.to, rel.to)

        if rel.from_ == rel.to:
            logger.debug(
                f"Skipping self-referential relationship '{rel.type}' on entity '{rel.from_}'"
            )
            continue

        rel_key = (rel.from_, rel.to, rel.type)
        if rel_key in index:
            existing_rel = merged[index[rel_key]]
            _merge_flush_relationship_metadata(existing_rel, rel, config)
        else:
            index[rel_key] = len(merged)
            merged.append(rel)


def _merge_flush_relationship_metadata(
    existing_rel: Relationship, new_rel: Relationship, config: OntologyConfig
) -> None:
    """Merge metadata from a new relationship into an existing one during flush.

    Mirrors the behaviour of _merge_duplicate_relationship() in relationship_builder.py
    (the main incremental path) to guarantee that both code paths produce identical
    metadata for duplicate relationships.
    """
    assert existing_rel is not None, "existing_rel parameter is required"
    assert new_rel is not None, "new_rel parameter is required"
    assert config is not None, "config parameter is required"

    # Resolve confidences — validate_confidence() correctly handles 0.0 (unlike `float(x or 1.0)`
    # which evaluates 0.0 as falsy and returns the default, destroying valid zero-confidence values).
    # Resolve confidences — validate_confidence() correctly handles 0.0 (unlike `float(x or 1.0)`
    # which evaluates 0.0 as falsy and returns the default, destroying valid zero-confidence values).
    exist_conf = validate_confidence(existing_rel.metadata.get("confidence"), 1.0)
    new_conf = validate_confidence(new_rel.metadata.get("confidence"), 1.0)

    # Merge properties: confidence-weighted, config-aware merge (mirrors main path).
    # Wraps in try/except with safe fallback — mirrors _merge_duplicate_relationship() in
    # relationship_builder.py (lines 1053-1065) to handle malformed/nested property values.
    try:
        existing_rel.properties = merge_properties(
            existing_rel.properties or {},
            new_rel.properties or {},
            exist_conf,
            new_conf,
            config=config,
        )
    except Exception as e:
        logger.warning(f"Failed to merge flush relationship properties: {e}")
        existing_rel.properties = _merge_relationship_properties_safe(
            existing_rel.properties or {}, new_rel.properties or {}
        )

    # Merge confidence + timestamp atomically via _merge_relationship_metadata —
    # uses merge_metadata_confidence() for confidence and key-existence check + max() for
    # timestamps. Mirrors _merge_duplicate_relationship() exactly (no string comparison,
    # no falsy check that skips timestamp=0).
    # Merge confidence + timestamp atomically via _merge_relationship_metadata —
    # uses merge_metadata_confidence() for confidence and key-existence check + max() for
    # timestamps. Mirrors _merge_duplicate_relationship() exactly (no string comparison,
    # no falsy check that skips timestamp=0).
    _merge_relationship_metadata(existing_rel, new_rel, exist_conf, new_conf)

    # Append to merged_from audit trail (mirrors main path _merge_duplicate_relationship)
    if "merged_from" not in existing_rel.metadata:
        existing_rel.metadata["merged_from"] = []
    existing_rel.metadata["merged_from"].append(
        {
            "relationship_id": new_rel.id,
            "type": new_rel.type,
            "merge_reason": "flush_deduplication",
            "timestamp": get_current_timestamp(config),
        }
    )


def _collect_successfully_processed_files(state: ExtractionState) -> list[str]:
    """Collect files that were fully processed without failures."""
    assert state is not None, "state parameter is required"
    assert hasattr(state, "file_processing_status"), "state must have file_processing_status"

    successfully_processed_files = []

    for file_path, status in state.file_processing_status.items():
        total_chunks = status["total_chunks"]
        processed_chunks = status["processed_chunks"]
        has_failed = status["has_failed_chunks"]

        # Skip files with invalid state
        if total_chunks <= 0:
            logger.warning(
                f"Skipping checkpoint for file with invalid total_chunks ({total_chunks}): {file_path}"
            )
            continue

        if processed_chunks < 0:
            logger.warning(
                f"Skipping checkpoint for file with negative processed_chunks ({processed_chunks}): {file_path}"
            )
            continue

        # Validate chunk counts
        # Validate chunk counts
        if processed_chunks > total_chunks:
            logger.warning(
                f"File has more processed chunks ({processed_chunks}) than total ({total_chunks}): {file_path}"
            )

        # Mark as completed if all chunks processed successfully
        # Mark as completed if all chunks processed successfully
        if not has_failed and processed_chunks >= total_chunks:
            successfully_processed_files.append(file_path)

    return successfully_processed_files


def _update_checkpoint_for_completed_files(state: ExtractionState) -> None:
    """Update checkpoint manager with successfully completed files."""
    assert state is not None, "state parameter is required"
    assert state.checkpoint_manager is not None, "checkpoint_manager must be set"

    successfully_processed_files = _collect_successfully_processed_files(state)

    try:
        for file_path in successfully_processed_files:
            state.checkpoint_manager.mark_file_completed(file_path)

        if successfully_processed_files:
            logger.debug(
                f"Marked {len(successfully_processed_files)} files as completed in checkpoint"
            )
    except Exception as checkpoint_error:
        logger.error(
            f"Failed to update checkpoint after successful flush: {checkpoint_error}. "
            f"Data was saved successfully, but {len(successfully_processed_files)} files not marked as completed."
        )

    state.current_flush_files = []


def _reset_flush_counters(state: ExtractionState) -> None:
    """Reset flush-related counters after successful flush."""
    assert state is not None, "state parameter is required"
    assert hasattr(state, "batches_processed_since_flush"), (
        "state must have batches_processed_since_flush"
    )

    state.batches_processed_since_flush = 0
    state.last_flush_time = time.time()
    state.flush_count += 1


def _clear_accumulated_data_if_needed(state: ExtractionState, is_final: bool) -> None:
    """Clear accumulated data to free memory if not final flush."""
    assert state is not None, "state parameter is required"
    assert hasattr(state, "all_concepts"), "state must have all_concepts attribute"

    if not is_final:
        concepts_cleared = len(state.all_concepts)
        relationships_cleared = len(state.all_relationships)
        entities_cleared = len(state.entities)
        rels_cleared = len(state.relationships)
        state.all_concepts.clear()
        state.all_relationships.clear()
        state.entities.clear()
        state.relationships.clear()
        logger.debug(
            f"Cleared accumulated data: {concepts_cleared} concepts, "
            f"{relationships_cleared} relationships, "
            f"{entities_cleared} entities, {rels_cleared} built relationships"
        )


async def _initialize_schema_if_needed(state: ExtractionState) -> None:
    """Initialize or evolve schema if needed (fresh extraction or periodic flush).

    For periodic flushes, evolves schema with current entities so that
    the saved schema includes type definitions for all entities being flushed.
    Uses state.entities (Entity objects) not state.all_concepts (ExtractedConcept).
    """
    assert state is not None, "state parameter is required"
    assert state.config is not None, "state.config must be set"

    if state.existing_schema is None:
        state.existing_schema, new_entity_types, new_rel_types = await evolve_schema(
            None,
            state.entities,
            state.relationships,
            state.domain,
            state.config,
            state.error_collector,
        )
        state.new_entity_types += new_entity_types
        state.new_relationship_types += new_rel_types
        if new_entity_types > 0 or new_rel_types > 0:
            # evolve_schema already bumped the version; mark as done so
            # _increment_schema_version_if_final does not bump again.
            # evolve_schema already bumped the version; mark as done so
            # _increment_schema_version_if_final does not bump again.
            state.schema_version_incremented = True
        logger.debug("Initialized schema with current entities for extraction")
    elif (state.entities or state.relationships) and state.error_collector is not None:
        # Evolve existing schema with current processed entities/relationships
        state.existing_schema, new_entity_types, new_rel_types = await evolve_schema(
            state.existing_schema,
            state.entities,
            state.relationships,
            state.domain,
            state.config,
            state.error_collector,
        )
        state.new_entity_types += new_entity_types
        state.new_relationship_types += new_rel_types
        if new_entity_types > 0 or new_rel_types > 0:
            # evolve_schema already bumped the version; mark as done so
            # _increment_schema_version_if_final does not bump again.
            # evolve_schema already bumped the version; mark as done so
            # _increment_schema_version_if_final does not bump again.
            state.schema_version_incremented = True
            logger.debug(
                f"Schema evolved during flush: +{new_entity_types} entity types, "
                f"+{new_rel_types} relationship types"
            )


def _calculate_progress_string(state: ExtractionState) -> str:
    """Calculate and format progress string."""
    assert state is not None, "state parameter is required"
    assert hasattr(state, "total_batches"), "state must have total_batches attribute"

    if state.total_batches > 0:
        completion_pct = int((state.batches_completed / state.total_batches) * 100)
        return f" | Progress: {state.batches_completed}/{state.total_batches} batches ({completion_pct}%)"
    return ""


def _increment_schema_version_if_final(state: ExtractionState, is_final: bool) -> None:
    """Increment schema version if this is the final flush."""
    assert state is not None, "state parameter is required"
    assert state.config is not None, "state.config must be set"

    if is_final and not state.schema_version_incremented:
        assert state.existing_schema is not None, "existing_schema must be set"
        strategy = state.config.schema_evolution.version_increment
        state.existing_schema.version = increment_schema_version(
            state.existing_schema.version, strategy
        )
        state.schema_version_incremented = True
        logger.debug(f"Schema version incremented to {state.existing_schema.version}")


def _handle_flush_error(
    state: ExtractionState, flush_num: int, flush_type: str, e: Exception, is_final: bool
) -> None:
    """Handle flush error by tracking and logging appropriately."""
    assert state is not None, "state parameter is required"
    assert e is not None, "exception parameter is required"

    state.flush_errors.append((flush_num, flush_type, e))
    logger.error(f"❌ Flush #{flush_num} ({flush_type}) FAILED: {type(e).__name__}: {e}")

    if is_final:
        logger.error("⚠️  CRITICAL: Final flush failed - data integrity cannot be guaranteed")
        raise

    logger.warning(
        f"⚠️  Intermediate flush #{flush_num} failed, but extraction will continue. "
        f"Data will be retried in next flush or final flush."
    )
    logger.warning(
        f"⚠️  Accumulated data NOT cleared (memory usage will increase). "
        f"Current: {len(state.all_concepts)} concepts, {len(state.all_relationships)} relationships"
    )

    # Still increment counters to avoid infinite retry loops
    # Still increment counters to avoid infinite retry loops
    state.batches_processed_since_flush = 0
    state.last_flush_time = time.time()
    state.flush_count += 1


async def perform_periodic_flush(state: ExtractionState, is_final: bool) -> None:
    """
    Flush accumulated data to disk. Intermediate failures continue processing,
    final failures raise. Errors tracked in state.flush_errors.
    """
    assert state is not None, "state parameter is required"
    assert state.config is not None, "state.config must be set"
    assert state.output_dir is not None, "state.output_dir must be set"

    await _initialize_schema_if_needed(state)

    flush_num = state.flush_count + 1
    flush_type = "FINAL" if is_final else "intermediate"
    progress_str = _calculate_progress_string(state)

    logger.info(
        f"🔄 Periodic flush #{flush_num} "
        f"({flush_type}) - "
        f"{len(state.entities)} entities, {len(state.relationships)} relationships{progress_str}"
    )

    try:
        merged_entities = _merge_entities_with_existing(state)
        merged_relationships = _merge_relationships_with_existing(state)

        # Increment schema version on final flush (not intermediate flushes).
        # Must be called after schema evolution (_initialize_schema_if_needed) and
        # before saving, so the saved schema carries the incremented version.
        _increment_schema_version_if_final(state, is_final)

        await _save_flush_files(
            state=state,
            entities=merged_entities,
            relationships=merged_relationships,
        )

        if state.checkpoint_manager:
            _update_checkpoint_for_completed_files(state)

        _reset_flush_counters(state)
        _clear_accumulated_data_if_needed(state, is_final)

        logger.success(
            f"✅ Flush #{state.flush_count} complete - "
            f"{len(merged_entities)} entities, {len(merged_relationships)} relationships saved"
        )
        logger.separator("=", 80, "bold green")

        if not is_final and state.error_collector is not None:
            await _reload_existing_data(state)
            logger.debug(
                f"Reload complete - ready to process next batch group "
                f"({len(state.existing_graph.entities) if state.existing_graph else 0} entities in memory)"
            )

    except Exception as e:
        _handle_flush_error(state, flush_num, flush_type, e, is_final)


async def _save_flush_files(
    state: ExtractionState,
    entities: list[Entity],
    relationships: list,
) -> None:
    """
    Save graph and schema files atomically.

    Args:
        state: Current extraction state
        entities: Merged entities to save
        relationships: Merged relationships to save
    """
    assert state is not None, "state parameter is required"
    assert state.output_dir is not None, "state.output_dir must be set"
    assert state.config is not None, "state.config must be set"
    assert state.existing_schema is not None, "state.existing_schema must be set"

    output_dir = str(state.output_dir)

    # Create graph object
    # Create graph object
    graph = OntologyGraph(
        domain=state.domain,
        schema_version=state.existing_schema.version,
        entities=entities,
        relationships=relationships,
    )

    config = state.config
    pretty = config.output.pretty_print
    compress = config.output.compress_output

    # Save graph (every flush for checkpointing).
    # Use config filenames (not hardcoded) so flush and final-save write to the same file
    # regardless of whether the user has customised graph_filename/schema_filename.
    # Use mode="json" so Pydantic serializes datetime/UUID fields as JSON-safe strings
    # (matches save_schema_and_graph() in the non-flush path).
    # Save graph (every flush for checkpointing).
    # Use config filenames (not hardcoded) so flush and final-save write to the same file
    # regardless of whether the user has customised graph_filename/schema_filename.
    # Use mode="json" so Pydantic serializes datetime/UUID fields as JSON-safe strings
    # (matches save_schema_and_graph() in the non-flush path).
    graph_path = f"{output_dir}/{config.output.graph_filename}"
    safe_write_json(
        graph_path,
        graph.model_dump(mode="json"),
        fs=state.output_fs or state.fs,
        pretty=pretty,
        compress=compress,
    )
    logger.debug(f"Saved graph to {graph_path}")

    # Save schema (every flush for checkpointing)
    schema_path = f"{output_dir}/{config.output.schema_filename}"
    safe_write_json(
        schema_path,
        state.existing_schema.model_dump(mode="json"),
        fs=state.output_fs or state.fs,
        pretty=pretty,
        compress=compress,
    )
    logger.debug(f"Saved schema to {schema_path}")


def _rebuild_entity_map_after_reload(
    state: ExtractionState, existing_data_entity_map: dict[str, str] | None = None
) -> None:
    """Rebuild entity map and reset pre-merge caches from reloaded graph."""
    assert state is not None, "state parameter is required"
    assert state.config is not None, "state.config must be set"

    # Reset pre-merged data so Stage 13 rebuilds from fresh reloaded data
    # Reset pre-merged data so Stage 13 rebuilds from fresh reloaded data
    state.pre_merged_entity_by_label = None
    state.pre_merged_entity_id_mapping = None

    if existing_data_entity_map:
        # Use the full entity map from load_existing_data (includes labels + aliases)
        state.existing_entity_map = dict(existing_data_entity_map)
        logger.debug(
            f"Rebuilt entity map with {len(state.existing_entity_map)} entries "
            f"(labels + aliases) from reloaded data"
        )
    elif state.existing_graph and state.existing_graph.entities:
        # Fallback: rebuild from graph labels only (no alias coverage)
        from taxonomy_ontology_accelerator.ontology_engine.utils.text_normalization import (
            normalize_text,
        )

        state.existing_entity_map = {
            normalize_text(entity.label, state.config): entity.id
            for entity in state.existing_graph.entities
        }
        logger.debug(
            f"Rebuilt entity map with {len(state.existing_entity_map)} label entries (no aliases)"
        )
    else:
        state.existing_entity_map = {}
        logger.debug("Reloaded 0 existing entities")


async def _reload_existing_data(state: ExtractionState) -> None:
    """
    Reload existing graph and embeddings after flush.

    This ensures next batch group deduplicates against the latest flushed data.
    Also rebuilds the existing_entity_map for correct entity ID reuse.
    If reload fails, logs warning and continues with stale data to avoid
    crashing the entire extraction process.

    Args:
        state: Current extraction state
    """
    assert state is not None, "state parameter is required"
    assert state.output_dir is not None, "state.output_dir must be set"

    from taxonomy_ontology_accelerator.ontology_engine.storage.data_loader import (
        load_existing_data,
    )

    assert state.config is not None, "state.config must be set"
    logger.debug("Reloading existing data after flush (validation skipped - schema evolves at end)")

    try:
        # Skip validation during intermediate reload - schema evolution happens at job end
        # Skip validation during intermediate reload - schema evolution happens at job end
        existing_data = load_existing_data(
            output_dir=state.output_dir,
            config=state.config,
            error_collector=state.error_collector,
            validate=False,
        )

        state.existing_graph = existing_data.graph
        state.existing_schema = existing_data.ontology_schema
        state.existing_embeddings = existing_data.embeddings or {}

        _rebuild_entity_map_after_reload(state, existing_data.entity_map)

    except Exception as e:
        logger.warning(
            f"Failed to reload data after flush: {e} - continuing with stale data. "
            f"Next batch group will use previous state for deduplication."
        )
        logger.debug(f"Reload error details: {type(e).__name__}: {e}")
