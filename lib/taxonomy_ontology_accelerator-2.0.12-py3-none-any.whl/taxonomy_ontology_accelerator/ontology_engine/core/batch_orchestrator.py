from __future__ import annotations

import asyncio
import uuid
from dataclasses import dataclass
from typing import Any

from taxonomy_ontology_accelerator.ontology_engine.core.batch_result_parser import ParsedBatchResult
from taxonomy_ontology_accelerator.ontology_engine.storage.checkpoint_manager import (
    CheckpointManager,
)

MAX_REQUESTS_PER_BATCH = 100_000


@dataclass
class OrchestratorResult:
    processed_files: list[str]
    failed_files: list[str]
    results: list[ParsedBatchResult]
    total_batches: int
    dry_run: bool


class BatchOrchestrator:
    def __init__(
        self, client: Any, builder: Any, parser: Any, checkpoint_manager: Any, config: Any
    ) -> None:
        self._client = client
        self._builder = builder
        self._parser = parser
        self._checkpoint_manager = checkpoint_manager
        self._config = config

    async def run(
        self,
        file_chunks: dict[str, list[str]],
        model: str,
        dry_run: bool = False,
    ) -> OrchestratorResult:
        filtered_file_chunks = self._filter_completed_files(file_chunks)
        max_per_batch = int(
            getattr(
                self._config,
                "bedrock_batch_max_records_per_job",
                getattr(self._config, "max_requests_per_batch", MAX_REQUESTS_PER_BATCH),
            )
        )
        max_per_batch = max(1, min(max_per_batch, MAX_REQUESTS_PER_BATCH))

        processed_files: set[str] = set()
        failed_files: set[str] = set()
        parsed_results: list[ParsedBatchResult] = []
        total_batches = 0
        validated_dry_run = False
        request_offset = 0

        pending_pairs: list[tuple[str, str]] = []
        for file_path, chunks in filtered_file_chunks.items():
            for chunk in chunks:
                pending_pairs.append((file_path, chunk))
                if len(pending_pairs) < max_per_batch:
                    continue

                total_batches += 1
                (
                    batch_parsed_results,
                    batch_processed_files,
                    batch_failed_files,
                ) = await self._process_batch(
                    pending_pairs,
                    model,
                    dry_run=dry_run and not validated_dry_run,
                    request_offset=request_offset,
                )
                request_offset += len(pending_pairs)
                if dry_run and not validated_dry_run:
                    validated_dry_run = True
                parsed_results.extend(batch_parsed_results)
                processed_files.update(batch_processed_files)
                failed_files.update(batch_failed_files)
                pending_pairs = []

        if pending_pairs:
            total_batches += 1
            (
                batch_parsed_results,
                batch_processed_files,
                batch_failed_files,
            ) = await self._process_batch(
                pending_pairs,
                model,
                dry_run=dry_run and not validated_dry_run,
                request_offset=request_offset,
            )
            parsed_results.extend(batch_parsed_results)
            processed_files.update(batch_processed_files)
            failed_files.update(batch_failed_files)

        if total_batches == 0:
            return OrchestratorResult([], [], [], 0, dry_run)

        final_processed_files = sorted(processed_files - failed_files)
        final_failed_files = sorted(failed_files)

        self._update_checkpoints(final_processed_files, final_failed_files)

        return OrchestratorResult(
            processed_files=final_processed_files,
            failed_files=final_failed_files,
            results=parsed_results,
            total_batches=total_batches,
            dry_run=dry_run,
        )

    async def _process_batch(
        self,
        chunk_file_pairs: list[tuple[str, str]],
        model: str,
        dry_run: bool,
        request_offset: int,
    ) -> tuple[list[ParsedBatchResult], set[str], set[str]]:
        requests = self._builder.build_batch_requests(
            [chunk for _, chunk in chunk_file_pairs],
            self._config,
            model,
        )
        if len(requests) > len(chunk_file_pairs):
            requests = list(requests[request_offset : request_offset + len(chunk_file_pairs)])
        else:
            requests = list(requests[: len(chunk_file_pairs)])
        if not requests:
            return [], set(), set()

        if dry_run:
            self._run_dry_run_validation(requests[0])

        request_file_map = {
            request["recordId"]: file_path
            for request, (file_path, _) in zip(requests, chunk_file_pairs, strict=False)
        }
        batch_request_map = {request["recordId"]: request for request in requests}
        batch_files = {
            request_file_map[record_id]
            for record_id in batch_request_map
            if record_id in request_file_map
        }

        max_attempts = int(getattr(self._config, "bedrock_batch_job_retries", 1))
        max_attempts = max(1, max_attempts)

        for attempt in range(max_attempts):
            try:
                jsonl = self._builder.build_jsonl_string(requests)
                job_name = f"toa-{uuid.uuid4().hex[:8]}"
                input_s3_uri = await self._client.upload_input_jsonl(jsonl, job_name)
                job_arn = await self._client.submit_batch(
                    job_name=job_name,
                    model_id=model,
                    input_s3_uri=input_s3_uri,
                    timeout_hours=getattr(self._config, "bedrock_batch_timeout_hours", 24),
                )
                await self._poll_until_complete(job_arn)
                jsonl_content = await self._client.download_results(job_arn)
                batch_parsed_results = self._parser.parse_batch_results(
                    jsonl_content, batch_request_map
                )

                batch_failed_files = {
                    request_file_map[getattr(result, "record_id")]
                    for result in batch_parsed_results
                    if getattr(result, "record_id", None) in request_file_map
                    and getattr(result, "status", "succeeded") != "succeeded"
                }
                batch_processed_files = batch_files - batch_failed_files
                return batch_parsed_results, batch_processed_files, batch_failed_files
            except Exception:
                if attempt >= max_attempts - 1:
                    return [], set(), set(batch_files)
                await asyncio.sleep(min(2**attempt, 30))

    def _filter_completed_files(self, file_chunks: dict[str, list[str]]) -> dict[str, list[str]]:
        if self._checkpoint_manager is None:
            return file_chunks

        filtered: dict[str, list[str]] = {}
        for file_path, chunks in file_chunks.items():
            if hasattr(self._checkpoint_manager, "is_file_completed") and (
                self._checkpoint_manager.is_file_completed(file_path) is True
            ):
                continue
            filtered[file_path] = chunks
        return filtered

    def _run_dry_run_validation(self, request: dict[str, Any]) -> None:
        if not self._builder.validate_request_shape(request):
            raise ValueError("Dry-run request validation failed")

    def _group_request_batches(self, requests: list[dict[str, Any]]) -> list[list[dict[str, Any]]]:
        max_per_batch = int(
            getattr(
                self._config,
                "bedrock_batch_max_records_per_job",
                getattr(self._config, "max_requests_per_batch", MAX_REQUESTS_PER_BATCH),
            )
        )
        max_per_batch = max(1, min(max_per_batch, MAX_REQUESTS_PER_BATCH))
        return [requests[i : i + max_per_batch] for i in range(0, len(requests), max_per_batch)]

    async def _poll_until_complete(self, batch_id: str) -> None:
        terminal_statuses = {"Completed", "Failed", "Stopped", "PartiallyCompleted", "Expired"}
        poll_interval_seconds = float(
            getattr(self._config, "bedrock_batch_poll_interval_seconds", 60.0)
        )
        poll_interval_seconds = max(1.0, poll_interval_seconds)
        while True:
            status = await self._client.poll_batch(batch_id)
            if status.processing_status in terminal_statuses:
                return
            await asyncio.sleep(poll_interval_seconds)

    def _update_checkpoints(self, processed_files: list[str], failed_files: list[str]) -> None:
        if self._checkpoint_manager is None:
            return

        if isinstance(self._checkpoint_manager, CheckpointManager):
            self._checkpoint_manager.mark_files_batch(processed_files, failed_files)
            return

        if hasattr(self._checkpoint_manager, "mark_file_completed"):
            for file_path in processed_files:
                self._checkpoint_manager.mark_file_completed(file_path)
        if hasattr(self._checkpoint_manager, "mark_file_failed"):
            for file_path in failed_files:
                self._checkpoint_manager.mark_file_failed(file_path)
