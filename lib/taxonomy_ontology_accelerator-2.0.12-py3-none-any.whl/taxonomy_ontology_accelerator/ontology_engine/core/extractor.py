"""
Core ontology extraction implementation.

Implements the full extraction pipeline following the design document.
All configuration must come from config files - no hardcoded values.

Architecture:
- extract_ontology(): Main entry point, orchestrates the pipeline
- Delegates to pipeline modules for specific stages
- Clean separation of concerns with ExtractionState as central state container
"""


# Disable tqdm progress bars globally (pydantic_ai uses them internally)
# This must be set before any imports that use tqdm
import os

os.environ["TQDM_DISABLE"] = "1"  # Force disable tqdm progress bars

import hashlib
import time
from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal

from pydantic_ai import Agent

if TYPE_CHECKING:
    from taxonomy_ontology_accelerator.ontology_engine.storage.state_checkpoint_manager import (
        StateCheckpointManager,
    )

from taxonomy_ontology_accelerator.commons.io.file_utils import normalize_path
from taxonomy_ontology_accelerator.commons.utils.logger import get_logger
from taxonomy_ontology_accelerator.ontology_engine.config.config import OntologyConfig
from taxonomy_ontology_accelerator.ontology_engine.core.batch_api_client import BedrockBatchClient
from taxonomy_ontology_accelerator.ontology_engine.core.batch_orchestrator import BatchOrchestrator
from taxonomy_ontology_accelerator.ontology_engine.core.batch_request_builder import (
    build_batch_requests,
    build_jsonl_string,
    validate_request_shape,
)
from taxonomy_ontology_accelerator.ontology_engine.core.batch_result_parser import (
    parse_batch_results,
)
from taxonomy_ontology_accelerator.ontology_engine.core.cross_file_merge import merge_file_results
from taxonomy_ontology_accelerator.ontology_engine.core.extraction_finalize import (
    build_and_validate_graph,
    export_to_owl_format,
    finalize_extraction_output,
    merge_and_deduplicate_relationships,
    merge_with_existing_graph,
    repair_graph_semantics,
    save_schema_and_graph,
)
from taxonomy_ontology_accelerator.ontology_engine.core.extraction_pipeline import (
    ExtractionState,
    _initialize_checkpoint_manager,
    _sync_runtime_output_context,
    load_domain_prompt,
    load_existing_ontology_data,
    load_input_content,
    setup_logging,
    setup_output_directory,
    validate_input_parameters,
)
from taxonomy_ontology_accelerator.ontology_engine.core.extraction_router import (
    run_configured_extraction,
)
from taxonomy_ontology_accelerator.ontology_engine.core.extraction_stages import (
    build_entity_relationships,
    chunk_input_text,
    deduplicate_extracted_entities,
    enforce_extraction_limits,
    evolve_ontology_schema,
    extract_file_level_scaffold,
    infer_upper_ontology,
    resolve_conflicting_relationships,
)
from taxonomy_ontology_accelerator.ontology_engine.core.file_worker_pool import (
    process_files_parallel,
)
from taxonomy_ontology_accelerator.ontology_engine.core.models import (
    ExtractionResult,
    OntologyOutput,
)
from taxonomy_ontology_accelerator.ontology_engine.core.per_file_state import create_per_file_state
from taxonomy_ontology_accelerator.ontology_engine.utils.list_emitter import (
    emit_entity_list,
    emit_raw_entity_list,
    emit_raw_relationship_list,
    emit_relationship_list,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.validation import estimate_tokens

logger = get_logger()

def _should_resume_from_checkpoint(state: ExtractionState, resume: bool | Literal["auto"]) -> bool:
    """
    Determine if we should attempt to resume from a checkpoint.

    Args:
        state: Current ExtractionState
        resume: Resume control parameter

    Returns:
        True if should attempt resume, False otherwise

    Raises:
        ValueError: If resume=True but checkpointing is disabled
    """
    assert state is not None, "state must not be None"
    assert state.config is not None, "config must be loaded"

    config = state.config

    # resume parameter overrides config
    # resume parameter overrides config
    if resume is False:
        logger.info("[Checkpoint] Resume disabled via parameter, starting fresh")
        return False

    if not config.checkpointing.persist_state or not state.output_dir:
        if resume is True:
            raise ValueError(
                "resume=True but checkpointing is not enabled. "
                "Set checkpointing.persist_state=True in config."
            )
        return False

    if resume == "auto" and not config.checkpointing.auto_resume:
        logger.info("[Checkpoint] Auto-resume disabled in config, starting fresh")
        return False

    return True

def _load_checkpoint_state(
    state_manager: "StateCheckpointManager",
    domain: str,
    resume_required: bool,
) -> tuple[ExtractionState | None, dict[str, Any] | None]:
    """
    Load the latest checkpoint state if available.

    Args:
        state_manager: Checkpoint manager instance
        domain: Domain name for validation
        resume_required: Whether resume is required (resume=True)

    Returns:
        Tuple of (loaded_state, checkpoint_info) or (None, None) if not found

    Raises:
        ValueError: If resume_required but checkpoint not found or invalid
    """
    assert state_manager is not None, "state_manager must not be None"
    assert domain is not None, "domain must not be None"

    # Get latest checkpoint info
    # Get latest checkpoint info
    latest_info = state_manager.get_latest_checkpoint_info()
    if not latest_info:
        if resume_required:
            raise ValueError(
                "resume=True but no checkpoint found. Run extraction first to create a checkpoint."
            )
        return None, None

                                       
    # Try to load the latest checkpoint
    loaded_state = state_manager.load_state_checkpoint(latest_info["stage"], domain=domain)
    if not loaded_state:
        if resume_required:
            raise ValueError(
                f"resume=True but failed to load checkpoint for stage '{latest_info['stage']}'. "
                "Checkpoint may be corrupted or incompatible."
            )
        return None, None

    return loaded_state, latest_info

def _restore_runtime_fields(loaded_state: ExtractionState, original_state: ExtractionState) -> None:
    """
    Restore non-serialized runtime fields from original state to loaded state.

    Args:
        loaded_state: State loaded from checkpoint
        original_state: Original state with runtime fields
    """
    assert loaded_state is not None, "loaded_state must not be None"
    assert original_state is not None, "original_state must not be None"

    loaded_state.config = original_state.config
    loaded_state.checkpoint_manager = original_state.checkpoint_manager
    loaded_state.fs = original_state.fs
    loaded_state.output_fs = original_state.output_fs
    loaded_state.coordinator = original_state.coordinator
    loaded_state.lock_provider = original_state.lock_provider

def _try_resume_from_checkpoint(
    state: ExtractionState,
    resume: bool | Literal["auto"] = "auto",
) -> ExtractionState:
    """
    Try to resume from a state checkpoint if available.

    Args:
        state: Current ExtractionState (will be replaced if checkpoint found)
        resume: Resume control - True (require checkpoint), False (never resume),
               "auto" (resume if available, respecting config)

    Returns:
        Either the loaded state from checkpoint or the original state

    Raises:
        ValueError: If resume=True but no checkpoint found or invalid
    """
    assert state is not None, "state must not be None"
    assert state.config is not None, "config must be loaded"

    # Check if we should attempt resume
    # Check if we should attempt resume
    if not _should_resume_from_checkpoint(state, resume):
        return state

                               
    # Create checkpoint manager
    from taxonomy_ontology_accelerator.ontology_engine.storage.state_checkpoint_manager import (
        StateCheckpointManager,
    )

    config = state.config
    assert state.output_dir is not None, "output_dir must be set for checkpointing"

    state_manager = StateCheckpointManager(
        output_dir=state.output_dir,
        enabled=config.checkpointing.persist_state,
        checkpoint_stages=config.checkpointing.state_checkpoint_stages,
        max_checkpoints=config.checkpointing.max_state_checkpoints,
        fs=state.fs,
    )

    # Load checkpoint state
    # Load checkpoint state
    loaded_state, latest_info = _load_checkpoint_state(
        state_manager, state.domain, resume_required=(resume is True)
    )
    if not loaded_state or not latest_info:
        return state

                            
    # Restore runtime fields
    _restore_runtime_fields(loaded_state, state)

    assert latest_info is not None, "latest_info must be set when loaded_state exists"
    logger.success(
        f"🔄 Resumed from checkpoint: {latest_info['stage']} stage "
        f"(saved {time.time() - latest_info['timestamp'] / 1000:.1f}s ago)"
    )

    return loaded_state

def _handle_extraction_failure(state: ExtractionState, reason: str) -> None:
    """Handle extraction failure by marking file as failed in checkpoint."""
    assert state is not None, "State must not be None"
    assert reason, "Reason must not be empty"

    try:
        if state.checkpoint_manager:
                                                                                         
            # For directory input: mark individual files based on their processing status
            if state.file_processing_status:
                for file_path in state.file_processing_status:
                    state.checkpoint_manager.mark_file_failed(file_path)
                state.checkpoint_manager.log_checkpoint_summary(reason)
                logger.warning(
                    f"[{reason}] Marked {len(state.file_processing_status)} file(s) as failed in checkpoint"
                )
                logger.debug(f"Checkpoint saved with failure reason: {reason}")
            # For single file input: fall back to source_file_path
            # For single file input: fall back to source_file_path
            elif state.source_file_path:
                state.checkpoint_manager.mark_file_failed(state.source_file_path)
                state.checkpoint_manager.log_checkpoint_summary(reason)
                logger.warning(
                    f"[{reason}] Marked file as failed in checkpoint: {state.source_file_path}"
                )
                logger.debug(f"Checkpoint saved with failure reason: {reason}")
    except Exception as e:
        logger.error(f"Failed to save checkpoint after extraction failure: {e}")

def _check_and_report_flush_errors(state: ExtractionState) -> None:
    """Check flush errors and fail job if any occurred. Marks file as failed in checkpoint."""
    assert state is not None, "State must not be None"
    assert hasattr(state, "flush_errors"), "State must have flush_errors attribute"

    if not state.flush_errors:
        return  # No errors, all good

    # Report all flush errors
    _ = logger.separator("=", 70, "bold red")  # pyright: ignore[reportAttributeAccessIssue]
    logger.error(f"⚠️  EXTRACTION COMPLETED WITH {len(state.flush_errors)} FLUSH FAILURE(S)")
    _ = logger.separator("=", 70, "bold red")  # pyright: ignore[reportAttributeAccessIssue]

    for flush_num, flush_type, error in state.flush_errors:
        logger.error(f"  • Flush #{flush_num} ({flush_type}): {type(error).__name__}: {error}")

    _ = logger.separator("=", 70, "bold red")  # pyright: ignore[reportAttributeAccessIssue]

    # Mark file as failed in checkpoint
    # Mark file as failed in checkpoint
    _handle_extraction_failure(state, "EXTRACTION COMPLETED WITH FLUSH FAILURES")

                                 
    # Raise error to fail the job
    error_summary = f"{len(state.flush_errors)} flush(es) failed during extraction"
    raise RuntimeError(
        f"Extraction completed all batches but {error_summary}. "
        f"Data integrity may be compromised. See logs for details."
    )

def _handle_keyboard_interrupt(state: ExtractionState):
    """Handle keyboard interrupt during extraction."""
    assert state is not None, "State must not be None"
    assert hasattr(state, "start_time"), "State must have start_time"

    elapsed = time.time() - state.start_time
    _ = logger.separator("=", 70, "bold red")  # pyright: ignore[reportAttributeAccessIssue]
    logger.error(f"Extraction interrupted by user after {elapsed:.2f}s")
    _ = logger.separator("=", 70, "bold red")  # pyright: ignore[reportAttributeAccessIssue]
    _handle_extraction_failure(state, "EXTRACTION INTERRUPTED")

def _handle_exception(state: ExtractionState, e: Exception):
    """Handle exception during extraction."""
    assert state is not None, "State must not be None"
    assert e is not None, "Exception must not be None"

    elapsed = time.time() - state.start_time
    _ = logger.separator("=", 70, "bold red")  # pyright: ignore[reportAttributeAccessIssue]
    logger.error(f"Extraction failed after {elapsed:.2f}s: {type(e).__name__}: {e}")
    _ = logger.separator("=", 70, "bold red")  # pyright: ignore[reportAttributeAccessIssue]
    logger.exception("Full error traceback:")
    _handle_extraction_failure(state, "EXTRACTION FAILED (EXCEPTION)")

def _run_configuration_stage(
    state: ExtractionState,
    resume: bool | Literal["auto"] = "auto",
) -> ExtractionState:
    """
    Run configuration and validation stage.

    Args:
        state: Extraction state
        resume: Resume control - passed to _try_resume_from_checkpoint

    Returns:
        ExtractionState (may be replaced by checkpoint if resuming)
    """
    assert state is not None, "State must not be None"
    assert state.input_path is not None, "Input path must be set in state"
    assert state.output_dir is not None, "Output directory must be set in state"

    # Note: config is already loaded in state by extract_ontology()
    # Note: config is already loaded in state by extract_ontology()
    validate_input_parameters(state)
    if state.prompt_path:
        load_domain_prompt(str(state.prompt_path), state)
    load_input_content(str(state.input_path), state)
    setup_output_directory(str(state.output_dir), state)

    # Try to resume from state checkpoint
    # Try to resume from state checkpoint
    state = _try_resume_from_checkpoint(state, resume=resume)

    load_existing_ontology_data(state)

    return state

async def _run_extraction_stage(
    extraction_agent: Agent[None, ExtractionResult], extraction_prompt: str, state: ExtractionState
):
    """Run LLM extraction stage with injected agent dependency."""
    assert extraction_agent is not None, "Extraction agent must not be None"
    assert extraction_prompt is not None, "Extraction prompt must not be None"
    assert state is not None, "State must not be None"

    await run_configured_extraction(extraction_agent, extraction_prompt, state)
    enforce_extraction_limits(state)

    # Save state checkpoint after LLM extraction (most expensive stage!)
    # Save state checkpoint after LLM extraction (most expensive stage!)
    from taxonomy_ontology_accelerator.ontology_engine.core.extraction_stages import (
        _save_state_checkpoint,
    )

    _save_state_checkpoint(state, "extraction")

async def _run_entity_processing_stage(state: ExtractionState):
    """Run entity processing stage."""
    assert state is not None, "State must not be None"
    assert isinstance(state.entities, list), "State must have entities list"

    await deduplicate_extracted_entities(state)

                                               
    # Save state checkpoint after deduplication
    from taxonomy_ontology_accelerator.ontology_engine.core.extraction_stages import (
        _save_state_checkpoint,
    )

    _save_state_checkpoint(state, "deduplication")

    await build_entity_relationships(state)
    await evolve_ontology_schema(state)
    await infer_upper_ontology(state)
    resolve_conflicting_relationships(state)

async def _run_merge_and_build_stage(state: ExtractionState) -> tuple[Path, Path]:
    """Run merge and build stage."""
    assert state is not None, "State must not be None"
    assert state.config is not None, "Config must be loaded"

    merge_with_existing_graph(state)
    await merge_and_deduplicate_relationships(state)
    repair_graph_semantics(state)
    build_and_validate_graph(state)
    _schema_saved, _graph_saved, schema_path, graph_path = save_schema_and_graph(state)
    export_to_owl_format(state)
    return schema_path, graph_path

def _format_retry_info(config: OntologyConfig) -> str:
    """Format retry strategy info for logging."""
    assert config is not None, "Config must not be None"
    assert config.llm is not None, "LLM config must not be None"

    retry_info = f"{config.llm.retries} retries"
    if config.llm.retry_strategy.enabled:
        retry_info = (
            f"{config.llm.retries} retries ({config.llm.retry_strategy.strategy_type} backoff, "
            f"{config.llm.retry_strategy.initial_delay}s-{config.llm.retry_strategy.max_delay}s)"
        )
    return retry_info

def _initialize_extraction_state(
    domain: str,
    config: OntologyConfig,
    has_domain_config: bool,
) -> ExtractionState:
    """Initialize extraction state and setup logging."""
    assert domain, "Domain must not be empty"
    assert config is not None, "Config must not be None"

                                       
    # Initialize filesystem from config
    from taxonomy_ontology_accelerator.commons.io.fsspec_utils import (
        get_default_filesystem,
        get_filesystem_from_config,
    )

    if config.filesystem and config.filesystem.protocol != "local":
        fs = get_filesystem_from_config(
            protocol=config.filesystem.protocol, options=config.filesystem.options or {}
        )
    else:
        fs = get_default_filesystem()

    state = ExtractionState(
        domain=domain,
        incremental=config.features.incremental_updates,
        fs=fs,
    )

    setup_logging()

    _ = logger.banner(  # pyright: ignore[reportAttributeAccessIssue]
        f"ONTOLOGY EXTRACTION | Domain: {domain} | Incremental: {config.features.incremental_updates}",
        emoji="🎯",
    )

    # Configuration logging (after banner)
    # Configuration logging (after banner)
    if has_domain_config:
        logger.config(f"[Config] Loaded {domain}/config.yaml (merged with library defaults)")
    else:
        logger.config("[Config] No domain-specific config found, using defaults")

                                        
    # Log model and checkpointing status
    checkpoint_status = "enabled" if config.checkpointing.enabled else "disabled"
    flush_info = ""
    if config.checkpointing.enabled and config.checkpointing.flush_interval_batches > 0:
        flush_info = f" | Flush: every {config.checkpointing.flush_interval_batches} batches"

    retry_info = _format_retry_info(config)
    logger.llm(
        f"[Config] LLM: {config.llm.model} | Embedding: {config.embeddings.model} | "
        f"Max tokens: {config.llm.max_tokens:,} | Retries: {retry_info} | "
        f"Checkpointing: {checkpoint_status}{flush_info}"
    )

    return state

def _extract_retry_after(error: Exception) -> float | None:
    """
    Extract Retry-After value from error message.

    Args:
        error: Exception that may contain Retry-After information

    Returns:
        Retry delay in seconds if found, None otherwise
    """
    assert error is not None, "Error must not be None"
    assert isinstance(error, Exception), "Error must be an Exception"

    error_str = str(error)
    import re

    # Pattern: "Retry-After: 60" or "retry after 60 seconds"
    # Pattern: "Retry-After: 60" or "retry after 60 seconds"
    patterns = [
        r"retry[- ]after[:\s]+(\d+)",
        r"retry in (\d+) seconds?",
    ]

    for pattern in patterns:
        match = re.search(pattern, error_str, re.IGNORECASE)
        if match:
            try:
                return float(match.group(1))
            except (ValueError, IndexError):
                continue

    return None

def _calculate_retry_delay(attempt: int, retry_config, use_jitter: bool = True) -> float:
    """Calculate retry delay based on strategy type."""
    import random

    assert attempt >= 0, "Attempt must be non-negative"
    assert retry_config is not None, "retry_config must be set"

    if retry_config.strategy_type == "constant":
        delay = retry_config.initial_delay
    elif retry_config.strategy_type == "linear":
        delay = retry_config.initial_delay + (attempt * retry_config.backoff_multiplier)
    else:  # exponential
        delay = retry_config.initial_delay * (retry_config.backoff_multiplier**attempt)

    delay = min(delay, retry_config.max_delay)

    if use_jitter and retry_config.jitter:
        jitter_amount = delay * 0.2
        delay = delay + random.uniform(-jitter_amount, jitter_amount)
        delay = max(0.0, delay)

    return delay

def _should_retry_error(
    error: Exception, attempt: int, config: OntologyConfig, retry_config
) -> float | None:
    """Determine if should retry and return delay in seconds."""
    from pydantic_ai.exceptions import ModelRetry

    assert error is not None, "Error must not be None"
    assert attempt >= 0, "Attempt must be non-negative"

    if attempt >= config.llm.retries:
        return None

    error_type = type(error).__name__.lower()
    error_msg = str(error).lower()

    # Determine if we should retry and get error description
    # Determine if we should retry and get error description
    error_desc = None

                       
    # Rate limit errors
    if retry_config.retry_on_rate_limit and ("rate" in error_type or "429" in error_msg):
        retry_after = _extract_retry_after(error)
        if retry_after is not None:
            logger.warning(f"Rate limit hit, retrying after {retry_after}s (Retry-After header)")
            return retry_after
        error_desc = "Rate limit hit"

    # Timeout errors
    # Timeout errors
    elif retry_config.retry_on_timeout and ("timeout" in error_type or "timeout" in error_msg):
        error_desc = "Timeout error"

                       
    # Connection errors
    elif "connection" in error_type or "connect" in error_msg:
        error_desc = "Connection error"

    # Model retry exceptions
    # Model retry exceptions
    elif isinstance(error, ModelRetry):
        error_desc = "Model retry requested"

                                                 
    # If we should retry, calculate delay and log
    if error_desc:
        delay = _calculate_retry_delay(attempt, retry_config)
        logger.warning(f"{error_desc}, retrying in {delay:.1f}s (attempt {attempt + 1})")
        return delay

    return None

def _build_retry_strategy(config: OntologyConfig) -> int:
    """Build pydantic-ai retry count from config.

    Returns int for pydantic-ai Agent's retries parameter.
    Custom backoff logic is handled separately in _execute_llm_call.
    """
    assert config is not None, "Config must not be None"
    assert config.llm is not None, "LLM config must not be None"
    return config.llm.retries


def _is_bedrock_routing_enabled(config: OntologyConfig) -> bool:
    """Return True when extraction should use Bedrock routing."""
    assert config is not None, "Config must not be None"
    assert config.llm is not None, "LLM config must not be None"
    model_str = str(config.llm.model)
    return bool(config.llm.aws_bedrock_enabled) or model_str.startswith("bedrock:")


def _build_model_settings(config: OntologyConfig) -> Any:
    """Build pydantic-ai model settings from config."""
    from typing import cast

    from pydantic_ai import ModelSettings

    assert config is not None, "Config must not be None"
    assert config.llm is not None, "LLM config must not be None"

    settings_dict: dict[str, Any] = {}
    if config.llm.max_tokens is not None:
        settings_dict["max_tokens"] = config.llm.max_tokens
    if config.llm.temperature is not None:
        settings_dict["temperature"] = config.llm.temperature
    if _is_bedrock_routing_enabled(config) and config.llm.bedrock_enable_context_1m_beta:
        settings_dict["bedrock_additional_model_requests_fields"] = {
            "anthropic_beta": [config.llm.bedrock_context_1m_beta_flag]
        }
        logger.llm(
            "[LLM Agent] Bedrock 1M beta enabled "
            f"(anthropic_beta={config.llm.bedrock_context_1m_beta_flag})"
        )

    if not settings_dict:
        return None

    return cast("ModelSettings", settings_dict)

def _create_default_extraction_agent(
    state: ExtractionState, extraction_prompt: str
) -> Agent[None, ExtractionResult]:
    """Create default extraction agent with config-based prompts."""
    assert state is not None, "State must not be None"
    assert state.config is not None, "Config must not be None"

    from taxonomy_ontology_accelerator.ontology_engine.core.cache_utils import (
        get_cacheable_system_prompt,
    )
    from taxonomy_ontology_accelerator.ontology_engine.core.extraction_stages import (
        _build_naming_instructions,
        _get_model_instance,
    )

    config = state.config
    naming_instructions = _build_naming_instructions(config.naming_conventions)
    model = _get_model_instance(config)
    chars_per_token = config.text_processing.chunking.chars_per_token_estimate

    model_settings = _build_model_settings(config)
    retry_strategy = _build_retry_strategy(config)

    extraction_agent = Agent(
        model,
        output_type=ExtractionResult,
        retries=retry_strategy,
        output_retries=retry_strategy,
        model_settings=model_settings,
    )

                                        
    use_caching = config.prompt_caching_enabled

    if use_caching:
                                                                                
        cached_prompts = get_cacheable_system_prompt(
            config,
            extraction_prompt=extraction_prompt,
            naming_instructions=naming_instructions,
            domain_prompt=state.domain_prompt,
        )

                                                                        
        @extraction_agent.system_prompt
        def cached_system_prompt(_ctx) -> list[dict[str, Any]]:
            return cached_prompts
    else:
                                                                         
        @extraction_agent.system_prompt
        def extraction_instructions(_ctx) -> str:
            assert extraction_prompt, "extraction_prompt cannot be empty"
            assert len(extraction_prompt) > 0, "extraction_prompt must have content"
            return extraction_prompt

        @extraction_agent.system_prompt
        def naming_conventions(_ctx) -> str:
            assert isinstance(naming_instructions, str), "naming_instructions must be a string"
            assert not naming_instructions or len(naming_instructions) > 0, (
                "if set, must have content"
            )
            return naming_instructions if naming_instructions else ""

        @extraction_agent.system_prompt
        def domain_instructions(_ctx) -> str:
            domain_prompt = state.domain_prompt
            assert domain_prompt is None or isinstance(domain_prompt, str), "must be string or None"
            assert not domain_prompt or len(domain_prompt) > 0, "if set, must have content"
            return domain_prompt if domain_prompt else ""

    system_prompt_tokens = sum(
        estimate_tokens(section, chars_per_token)
        for section in (extraction_prompt, naming_instructions, state.domain_prompt)
        if section and section.strip()
    )
    logger.info(
        f"[LLM Prompt Budget] Estimated system prompt tokens: {system_prompt_tokens:,} "
        f"(caching={'enabled' if use_caching else 'disabled'})"
    )

    return extraction_agent

def _prepare_extraction_agent(
    state: ExtractionState, extraction_agent: Agent[None, ExtractionResult] | None
) -> tuple[Agent[None, ExtractionResult], str]:
    """Prepare extraction agent and prompt."""
    from taxonomy_ontology_accelerator.ontology_engine.core.extraction_stages import (
        _load_extraction_prompt,
    )

    assert state is not None, "State must not be None"
    assert state.config is not None, "config must be set before extraction"

    extraction_prompt = _load_extraction_prompt(state.config)
    if extraction_agent is None:
        extraction_agent = _create_default_extraction_agent(state, extraction_prompt)

    return extraction_agent, extraction_prompt

def _emit_processed_stage_lists(state: ExtractionState) -> None:
    """Emit processed stage entity/relationship lists if enabled."""
    assert state is not None, "State must not be None"
    assert state.entities is not None, "Entities must not be None"
    assert state.config is not None, "Config must not be None"

    if state.output_dir and state.entities and state.config.output.emit_pipeline_stage_lists:
        emit_entity_list(
            state.entities,
            state.output_dir,
            stage="processed",
            fs=state.output_fs or state.fs,
        )
        emit_relationship_list(
            state.relationships,
            state.entities,
            state.output_dir,
            stage="processed",
            fs=state.output_fs or state.fs,
        )
        logger.processing(
            f"[Stage 2] Emitted processed data: {len(state.entities)} entities, "
            f"{len(state.relationships)} relationships"
        )

async def _run_extraction_pipeline(
    state: ExtractionState,
    extraction_agent: Agent[None, ExtractionResult] | None = None,
    resume: bool | Literal["auto"] = "auto",
) -> OntologyOutput:
    """Run complete extraction pipeline with error handling."""
    assert state is not None, "State must not be None"
    assert state.input_path is not None, "Input path must be set in state"

    try:
        # Configuration & Input Loading (may resume from checkpoint)
        start = time.perf_counter()
        state = _run_configuration_stage(state, resume=resume)
        state.stage_timings["configuration"] = time.perf_counter() - start
        logger.debug(f"Stage 'configuration' took {state.stage_timings['configuration']:.3f}s")

        # Prepare extraction agent once so file-level scaffold extraction and chunk
        # extraction share the same model/runtime configuration.
        extraction_agent, extraction_prompt = _prepare_extraction_agent(state, extraction_agent)

        # File-level scaffold extraction (schema-first guidance for later chunks)
        start = time.perf_counter()
        await extract_file_level_scaffold(extraction_agent, state)
        state.stage_timings["file_level_scaffold"] = time.perf_counter() - start
        logger.debug(
            f"Stage 'file_level_scaffold' took {state.stage_timings['file_level_scaffold']:.3f}s"
        )

        # Chunking (may return early if already processed)
        start = time.perf_counter()
        early_return = await chunk_input_text(state)
        state.stage_timings["text_chunking"] = time.perf_counter() - start
        logger.debug(f"Stage 'text_chunking' took {state.stage_timings['text_chunking']:.3f}s")
        if early_return:
            return early_return

        # LLM Extraction
        start = time.perf_counter()
        await _run_extraction_stage(extraction_agent, extraction_prompt, state)
        state.stage_timings["llm_extraction"] = time.perf_counter() - start
        logger.debug(f"Stage 'llm_extraction' took {state.stage_timings['llm_extraction']:.3f}s")

        # Entity Processing
        start = time.perf_counter()
        await _run_entity_processing_stage(state)
        state.stage_timings["entity_processing"] = time.perf_counter() - start
        logger.debug(
            f"Stage 'entity_processing' took {state.stage_timings['entity_processing']:.3f}s"
        )
        _emit_processed_stage_lists(state)

        # Merge & Build
        start = time.perf_counter()
        schema_path, graph_path = await _run_merge_and_build_stage(state)
        merge_elapsed = time.perf_counter() - start
        state.stage_timings["graph_building"] = merge_elapsed
        state.stage_timings["finalization_merge"] = merge_elapsed
        logger.debug(f"Stage 'finalization_merge' took {merge_elapsed:.3f}s")

                                                            
        # Check for flush errors after successful extraction
        _check_and_report_flush_errors(state)

        finalization_start = time.perf_counter()
        output = finalize_extraction_output(state, schema_path, graph_path)
        state.stage_timings["result_finalization"] = time.perf_counter() - finalization_start
        logger.debug(
            f"Stage 'result_finalization' took {state.stage_timings['result_finalization']:.3f}s"
        )
        return output

    except KeyboardInterrupt:
        _handle_keyboard_interrupt(state)
        raise
    except Exception as e:
        _handle_exception(state, e)
        raise

def _load_domain_config_and_paths(domain: str) -> tuple[Any, Path, Path, Path, bool]:
    """Load config and resolve paths for domain."""
    from taxonomy_ontology_accelerator.commons.io.fsspec_utils import (
        get_default_filesystem,
    )
    from taxonomy_ontology_accelerator.ontology_engine.config.config import OntologyConfigLoader
    from taxonomy_ontology_accelerator.ontology_engine.utils.domain_resolver import DomainResolver

    assert domain, "Domain must not be empty"
    assert isinstance(domain, str), "Domain must be a string"

    config = OntologyConfigLoader.load_for_domain(domain)

    # Get filesystem
    # Get filesystem
    fs = get_default_filesystem()

                                            
    # Check if domain-specific config exists
    domain_folder = DomainResolver.validate_domain_folder(domain)
    domain_config_path = domain_folder / "config.yaml"
    has_domain_config = fs.exists(str(domain_config_path))

    input_path = DomainResolver.resolve_input_path(domain, config)
    prompt_path = DomainResolver.resolve_prompt_path(domain, config)
    output_dir = DomainResolver.resolve_output_directory(domain, config)

    return config, input_path, prompt_path, output_dir, has_domain_config

def _prepare_extraction_state(
    domain: str,
    config: Any,
    input_path: Path,
    prompt_path: Path,
    output_dir: Path,
    has_domain_config: bool,
) -> ExtractionState:
    """Initialize and populate extraction state."""
    assert domain, "Domain must not be empty"
    assert config is not None, "Config must not be None"

    state = _initialize_extraction_state(
        domain=domain, config=config, has_domain_config=has_domain_config
    )
    state.config = config
    state.input_path = input_path
    state.prompt_path = prompt_path
    state.source_file_path = str(input_path)
    state.output_dir = output_dir
    _sync_runtime_output_context(state, config)

    assert state.config is not None, "Config must be loaded"
    assert state.input_path is not None, "Input path must be resolved"
    assert state.output_dir is not None, "Output directory must be resolved"

    return state

class _BatchRequestBuilderAdapter:
    def build_batch_requests(self, chunks: list[str], config: OntologyConfig, model: str):
        return build_batch_requests(chunks, config, model)

    def validate_request_shape(self, request: dict[str, Any]) -> bool:
        return validate_request_shape(request)

    def build_jsonl_string(self, requests: list[dict]) -> str:
        return build_jsonl_string(requests)

class _BatchResultParserAdapter:
    def parse_batch_results(self, jsonl_content: str, request_map: dict[str, Any]):
        return parse_batch_results(jsonl_content, request_map)

class _NoOpCheckpointManager:
    def is_file_completed(self, _file_path: str) -> bool:
        return False

    def mark_file_completed(self, _file_path: str) -> None:
        return None

    def mark_file_failed(self, _file_path: str) -> None:
        return None

class _FileMergePayload:
    def __init__(
        self,
        entities: list[Any] | None = None,
        relationships: list[Any] | None = None,
        *,
        llm_calls: int = 0,
        input_tokens: int = 0,
        output_tokens: int = 0,
        cache_read_tokens: int = 0,
        cache_write_tokens: int = 0,
        estimated_llm_input_tokens: int = 0,
        estimated_llm_output_tokens: int = 0,
        llm_usage_missing_calls: int = 0,
        embedding_input_tokens: int = 0,
        embedding_output_tokens: int = 0,
        embedding_cache_read_tokens: int = 0,
        embedding_cache_write_tokens: int = 0,
        embeddings_generated: int = 0,
    ):
        self.entities = entities or []
        self.relationships = relationships or []
        self.llm_calls = llm_calls
        self.input_tokens = input_tokens
        self.output_tokens = output_tokens
        self.cache_read_tokens = cache_read_tokens
        self.cache_write_tokens = cache_write_tokens
        self.estimated_llm_input_tokens = estimated_llm_input_tokens
        self.estimated_llm_output_tokens = estimated_llm_output_tokens
        self.llm_usage_missing_calls = llm_usage_missing_calls
        self.embedding_input_tokens = embedding_input_tokens
        self.embedding_output_tokens = embedding_output_tokens
        self.embedding_cache_read_tokens = embedding_cache_read_tokens
        self.embedding_cache_write_tokens = embedding_cache_write_tokens
        self.embeddings_generated = embeddings_generated


def _build_file_merge_payload(result: Any) -> _FileMergePayload:
    """Normalize per-file worker results into a mergeable payload."""
    metadata = getattr(result, "metadata", None)
    graph = getattr(result, "graph", None)
    entities = getattr(result, "entities", None)
    relationships = getattr(result, "relationships", None)

    if entities is None:
        entities = getattr(graph, "entities", None)
    if relationships is None:
        relationships = getattr(graph, "relationships", None)

    return _FileMergePayload(
        entities=entities,
        relationships=relationships,
        llm_calls=int(
            getattr(result, "llm_calls", getattr(metadata, "llm_calls_made", 0)) or 0
        ),
        input_tokens=int(getattr(result, "input_tokens", getattr(metadata, "input_tokens", 0)) or 0),
        output_tokens=int(
            getattr(result, "output_tokens", getattr(metadata, "output_tokens", 0)) or 0
        ),
        cache_read_tokens=int(
            getattr(result, "cache_read_tokens", getattr(metadata, "cache_read_tokens", 0)) or 0
        ),
        cache_write_tokens=int(
            getattr(result, "cache_write_tokens", getattr(metadata, "cache_write_tokens", 0)) or 0
        ),
        estimated_llm_input_tokens=int(
            getattr(
                result,
                "estimated_llm_input_tokens",
                getattr(metadata, "estimated_llm_input_tokens", 0),
            )
            or 0
        ),
        estimated_llm_output_tokens=int(
            getattr(
                result,
                "estimated_llm_output_tokens",
                getattr(metadata, "estimated_llm_output_tokens", 0),
            )
            or 0
        ),
        llm_usage_missing_calls=int(
            getattr(
                result,
                "llm_usage_missing_calls",
                getattr(metadata, "llm_usage_missing_calls", 0),
            )
            or 0
        ),
        embedding_input_tokens=int(
            getattr(
                result,
                "embedding_input_tokens",
                getattr(metadata, "embedding_input_tokens", 0),
            )
            or 0
        ),
        embedding_output_tokens=int(
            getattr(
                result,
                "embedding_output_tokens",
                getattr(metadata, "embedding_output_tokens", 0),
            )
            or 0
        ),
        embedding_cache_read_tokens=int(
            getattr(
                result,
                "embedding_cache_read_tokens",
                getattr(metadata, "embedding_cache_read_tokens", 0),
            )
            or 0
        ),
        embedding_cache_write_tokens=int(
            getattr(
                result,
                "embedding_cache_write_tokens",
                getattr(metadata, "embedding_cache_write_tokens", 0),
            )
            or 0
        ),
        embeddings_generated=int(
            getattr(
                result,
                "embeddings_generated",
                getattr(metadata, "embeddings_generated", 0),
            )
            or 0
        ),
    )


def _merge_file_payload_usage_into_state(state: ExtractionState, payload: _FileMergePayload) -> None:
    """Accumulate per-file usage counters into the shared extraction state."""
    state.llm_calls += payload.llm_calls
    state.input_tokens += payload.input_tokens
    state.output_tokens += payload.output_tokens
    state.cache_read_tokens += payload.cache_read_tokens
    state.cache_write_tokens += payload.cache_write_tokens
    state.estimated_llm_input_tokens += payload.estimated_llm_input_tokens
    state.estimated_llm_output_tokens += payload.estimated_llm_output_tokens
    state.llm_usage_missing_calls += payload.llm_usage_missing_calls
    state.embedding_input_tokens += payload.embedding_input_tokens
    state.embedding_output_tokens += payload.embedding_output_tokens
    state.embedding_cache_read_tokens += payload.embedding_cache_read_tokens
    state.embedding_cache_write_tokens += payload.embedding_cache_write_tokens
    state.embeddings_generated += payload.embeddings_generated

def _resolve_input_files(input_path: Path) -> list[str]:
    assert input_path is not None, "input_path must not be None"
    from taxonomy_ontology_accelerator.commons.io.fsspec_utils import get_default_filesystem
    fs = get_default_filesystem()
    if fs.isfile(str(input_path)):
        return [str(input_path)]
    if fs.isdir(str(input_path)):
        return sorted(str(file_path) for file_path in input_path.rglob("*") if fs.isfile(str(file_path)))
    return []

def _select_pipeline_mode(
    config: OntologyConfig,
) -> Literal["sequential_sync", "batch", "parallel_sync", "parallel_batch"]:
    assert config is not None, "Config must not be None"
    if config.batch_api_enabled and config.parallel_files > 1:
        return "parallel_batch"
    if config.batch_api_enabled:
        return "batch"
    if config.parallel_files > 1:
        return "parallel_sync"
    return "sequential_sync"

async def _run_sequential_sync(
    state: ExtractionState,
    extraction_agent: Agent[None, ExtractionResult] | None = None,
    resume: bool | Literal["auto"] = "auto",
) -> OntologyOutput:
    return await _run_extraction_pipeline(state, extraction_agent=extraction_agent, resume=resume)

async def _finalize_from_current_state(state: ExtractionState) -> OntologyOutput:
    schema_path, graph_path = await _run_merge_and_build_stage(state)
    _check_and_report_flush_errors(state)
    return finalize_extraction_output(state, schema_path, graph_path)

def _ingest_batch_results_into_state(state: ExtractionState, parsed_results: list[Any]) -> None:
    for parsed in parsed_results:
        if getattr(parsed, "status", "") != "succeeded":
            continue
        extraction_result = getattr(parsed, "result", None)
        if extraction_result is None:
            continue
        state.all_concepts.extend(getattr(extraction_result, "concepts", []) or [])
        state.all_relationships.extend(getattr(extraction_result, "relationships", []) or [])

def _parallel_raw_output_dir(base_output_dir: Path, file_path: str) -> Path:
    digest = hashlib.sha1(file_path.encode("utf-8")).hexdigest()[:10]
    return base_output_dir / "_parallel_raw" / f"{Path(file_path).stem}-{digest}"

def _update_parallel_checkpoints(
    checkpoint_manager: Any,
    completed_files: list[str],
    failed_files: list[str],
) -> None:
    if hasattr(checkpoint_manager, "mark_files_batch"):
        checkpoint_manager.mark_files_batch(completed_files, failed_files)
        return

    if hasattr(checkpoint_manager, "mark_file_completed"):
        for file_path in completed_files:
            checkpoint_manager.mark_file_completed(file_path)

    if hasattr(checkpoint_manager, "mark_file_failed"):
        for file_path in failed_files:
            checkpoint_manager.mark_file_failed(file_path)

async def _build_batch_file_chunks(
    file_paths: list[str],
    state: ExtractionState,
    checkpoint_manager: Any,
) -> dict[str, list[str]]:
    config = state.config
    assert config is not None, "Config must not be None"

    file_chunks: dict[str, list[str]] = {}
    for file_path in file_paths:
        if checkpoint_manager.is_file_completed(file_path):
            continue

        file_state = create_per_file_state(file_path, config)
        file_state.input_path = Path(file_path)
        file_state.output_dir = state.output_dir
        file_state.prompt_path = state.prompt_path
        file_state.source_file_path = str(file_path)

        load_input_content(str(file_state.input_path), file_state)
        early_return = await chunk_input_text(file_state)
        if early_return is not None:
            continue

        chunks = list(getattr(file_state, "chunks", []) or [])
        if chunks:
            file_chunks[file_path] = chunks
    return file_chunks

async def _run_batch_with_chunks(
    state: ExtractionState,
    file_chunks: dict[str, list[str]],
    checkpoint_manager: Any,
    extraction_agent: Agent[None, ExtractionResult] | None,
    resume: bool | Literal["auto"],
) -> OntologyOutput:
    config = state.config
    assert config is not None, "Config must not be None"

    orchestrator = BatchOrchestrator(
        BedrockBatchClient(
            s3_bucket=config.bedrock_batch_s3_bucket,
            s3_prefix=config.bedrock_batch_s3_prefix or "toa-batch",
            role_arn=config.bedrock_batch_role_arn,
            region=config.bedrock_batch_region or None,
        ),
        _BatchRequestBuilderAdapter(),
        _BatchResultParserAdapter(),
        checkpoint_manager,
        config,
    )
    result = await orchestrator.run(
        file_chunks=file_chunks, model=str(config.llm.model), dry_run=False
    )
    parsed_results = getattr(result, "results", [])
    _ingest_batch_results_into_state(state, parsed_results)

    if state.fs is None:
        return await _run_sequential_sync(state, extraction_agent=extraction_agent, resume=resume)

    await _run_entity_processing_stage(state)
    _emit_processed_stage_lists(state)
    return await _finalize_from_current_state(state)

async def _run_batch(
    file_paths: list[str],
    state: ExtractionState,
    extraction_agent: Agent[None, ExtractionResult] | None = None,
    resume: bool | Literal["auto"] = "auto",
) -> OntologyOutput:
    config = state.config
    assert config is not None, "Config must not be None"

    checkpoint_manager = state.checkpoint_manager or _NoOpCheckpointManager()

    if state.input_path is not None and state.output_dir is not None:
        validate_input_parameters(state)
        setup_output_directory(str(state.output_dir), state)
        load_existing_ontology_data(state)
        if config.checkpointing.enabled and state.checkpoint_manager is None:
            _initialize_checkpoint_manager(state, config)
            checkpoint_manager = state.checkpoint_manager or checkpoint_manager
    file_chunks = await _build_batch_file_chunks(file_paths, state, checkpoint_manager)
    return await _run_batch_with_chunks(
        state,
        file_chunks,
        checkpoint_manager,
        extraction_agent,
        resume,
    )

async def _run_parallel_sync(
    file_paths: list[str],
    state: ExtractionState,
    extraction_agent: Agent[None, ExtractionResult] | None = None,
    resume: bool | Literal["auto"] = "auto",
) -> OntologyOutput:
    config = state.config
    assert config is not None, "Config must not be None"

    checkpoint_manager = state.checkpoint_manager or _NoOpCheckpointManager()

    if state.input_path is None or state.output_dir is None:

        async def _process_file_legacy(file_path: str, file_state: Any) -> Any:
            file_state.input_files = [file_path]
            file_state.input_path = Path(file_path)
            file_state.output_dir = state.output_dir
            file_state.prompt_path = state.prompt_path
            file_state.fs = state.fs
            file_state.output_fs = state.output_fs
            agent, _prompt = _prepare_extraction_agent(file_state, None)
            return await _run_extraction_pipeline(file_state, extraction_agent=agent, resume="auto")

        file_results = await process_files_parallel(
            file_paths=file_paths,
            process_fn=_process_file_legacy,
            shared_config=config,
            checkpoint_manager=checkpoint_manager,
            max_workers=config.parallel_files,
        )

        successful_results = []
        for result in file_results:
            if not result.success or result.result is None:
                continue

            result.result = _build_file_merge_payload(result.result)
            _merge_file_payload_usage_into_state(state, result.result)
            successful_results.append(result)

        merged = merge_file_results(successful_results)
        state.entities = merged.entities
        state.relationships = merged.relationships
        return await _run_sequential_sync(state, extraction_agent=extraction_agent, resume=resume)

    validate_input_parameters(state)
    if state.prompt_path:
        load_domain_prompt(str(state.prompt_path), state)
    setup_output_directory(str(state.output_dir), state)
    assert state.output_dir is not None, "Output directory must be set"
    parallel_output_dir = state.output_dir
    load_existing_ontology_data(state)
    if config.checkpointing.enabled and state.checkpoint_manager is None:
        _initialize_checkpoint_manager(state, config)
    checkpoint_manager = state.checkpoint_manager or checkpoint_manager

    shared_agent, shared_prompt = _prepare_extraction_agent(state, extraction_agent)

    async def _process_file(file_path: str, file_state: Any) -> Any:
        worker_config = config.model_copy(deep=True)
        worker_config.checkpointing.flush_interval_batches = 0
        file_state.config = worker_config

        file_state.input_path = Path(file_path)
        file_state.output_dir = _parallel_raw_output_dir(parallel_output_dir, file_path)
        file_state.prompt_path = state.prompt_path
        file_state.domain_prompt = state.domain_prompt
        file_state.source_file_path = str(file_path)
        file_state.fs = state.fs
        file_state.output_fs = state.output_fs

        load_input_content(str(file_state.input_path), file_state)
        early_return = await chunk_input_text(file_state)
        if early_return is not None:
            return _FileMergePayload(entities=[], relationships=[])

        await _run_extraction_stage(shared_agent, shared_prompt, file_state)
        enforce_extraction_limits(file_state)

        return _FileMergePayload(
            entities=list(getattr(file_state, "all_concepts", []) or []),
            relationships=list(getattr(file_state, "all_relationships", []) or []),
            llm_calls=int(getattr(file_state, "llm_calls", 0) or 0),
            input_tokens=int(getattr(file_state, "input_tokens", 0) or 0),
            output_tokens=int(getattr(file_state, "output_tokens", 0) or 0),
            cache_read_tokens=int(getattr(file_state, "cache_read_tokens", 0) or 0),
            cache_write_tokens=int(getattr(file_state, "cache_write_tokens", 0) or 0),
            estimated_llm_input_tokens=int(
                getattr(file_state, "estimated_llm_input_tokens", 0) or 0
            ),
            estimated_llm_output_tokens=int(
                getattr(file_state, "estimated_llm_output_tokens", 0) or 0
            ),
            llm_usage_missing_calls=int(getattr(file_state, "llm_usage_missing_calls", 0) or 0),
            embedding_input_tokens=int(getattr(file_state, "embedding_input_tokens", 0) or 0),
            embedding_output_tokens=int(getattr(file_state, "embedding_output_tokens", 0) or 0),
            embedding_cache_read_tokens=int(
                getattr(file_state, "embedding_cache_read_tokens", 0) or 0
            ),
            embedding_cache_write_tokens=int(
                getattr(file_state, "embedding_cache_write_tokens", 0) or 0
            ),
            embeddings_generated=int(getattr(file_state, "embeddings_generated", 0) or 0),
        )

    file_results = await process_files_parallel(
        file_paths=file_paths,
        process_fn=_process_file,
        shared_config=config,
        checkpoint_manager=_NoOpCheckpointManager(),
        max_workers=config.parallel_files,
    )
    completed_paths: list[str] = []
    failed_paths: list[str] = []
    successful_results = []
    for result in file_results:
        if not result.success or result.result is None:
            failed_paths.append(result.file_path)
            continue

        completed_paths.append(result.file_path)

        result.result = _build_file_merge_payload(result.result)
        _merge_file_payload_usage_into_state(state, result.result)
        successful_results.append(result)

    merged = merge_file_results(successful_results)
    state.all_concepts = list(merged.entities)
    state.all_relationships = list(merged.relationships)

    if config.output.emit_pipeline_stage_lists:
        emit_raw_entity_list(state.all_concepts, state.output_dir, fs=state.output_fs or state.fs)
        emit_raw_relationship_list(
            state.all_relationships,
            state.output_dir,
            fs=state.output_fs or state.fs,
        )

    await _run_entity_processing_stage(state)
    _emit_processed_stage_lists(state)
    output = await _finalize_from_current_state(state)
    _update_parallel_checkpoints(checkpoint_manager, completed_paths, failed_paths)
    return output

async def _run_parallel_batch(
    file_paths: list[str],
    state: ExtractionState,
    extraction_agent: Agent[None, ExtractionResult] | None = None,
    resume: bool | Literal["auto"] = "auto",
) -> OntologyOutput:
    config = state.config
    assert config is not None, "Config must not be None"

    checkpoint_manager = state.checkpoint_manager or _NoOpCheckpointManager()

    if state.input_path is not None and state.output_dir is not None:
        validate_input_parameters(state)
        setup_output_directory(str(state.output_dir), state)
        load_existing_ontology_data(state)
        if config.checkpointing.enabled and state.checkpoint_manager is None:
            _initialize_checkpoint_manager(state, config)
            checkpoint_manager = state.checkpoint_manager or checkpoint_manager

    async def _prepare_file_chunks(file_path: str, file_state: Any) -> Any:
        file_state.input_path = Path(file_path)
        file_state.output_dir = state.output_dir
        file_state.prompt_path = state.prompt_path
        file_state.source_file_path = str(file_path)
        file_state.fs = state.fs
        file_state.output_fs = state.output_fs

        load_input_content(str(file_state.input_path), file_state)
        early_return = await chunk_input_text(file_state)
        if early_return is not None:
            return []
        return list(getattr(file_state, "chunks", []) or [])

    file_results = await process_files_parallel(
        file_paths=file_paths,
        process_fn=_prepare_file_chunks,
        shared_config=config,
        checkpoint_manager=_NoOpCheckpointManager(),
        max_workers=config.parallel_files,
    )

    file_chunks: dict[str, list[str]] = {}
    for result in file_results:
        if not result.success or result.result is None:
            continue
        chunks = list(result.result)
        if chunks:
            file_chunks[result.file_path] = chunks

    return await _run_batch_with_chunks(
        state,
        file_chunks,
        checkpoint_manager,
        extraction_agent,
        resume,
    )

async def extract_ontology(
    domain: str,
    extraction_agent: Agent[None, ExtractionResult] | None = None,
    resume: bool | Literal["auto"] = "auto",
    output_dir_override: Path | str | None = None,
) -> OntologyOutput:
    """
    Extract ontology for a specific domain.

    Args:
        domain: Domain name (e.g., "travel", "medical")
        extraction_agent: Optional custom Agent for extraction. If not provided,
                         creates default agent with config-based prompts.
        resume: Resume control:
               - "auto" (default): Resume if checkpoint available and config allows
               - True: Require checkpoint (raise error if not found)
               - False: Never resume, always start fresh
        output_dir_override: Optional explicit output directory for this run

    Returns:
        Complete OntologyOutput with schema, graph, and metadata

    Raises:
        ValueError: If resume=True but no valid checkpoint found
    """
    assert domain, "Domain must not be empty"
    assert isinstance(domain, str), "Domain must be a string"
    assert output_dir_override is None or isinstance(output_dir_override, Path | str), (
        "output_dir_override must be Path, str, or None"
    )

    try:
        config, input_path, prompt_path, output_dir, has_domain_config = (
            _load_domain_config_and_paths(domain)
        )
        if output_dir_override is not None:
            if (
                isinstance(output_dir_override, str)
                and getattr(config.filesystem, "protocol", "local") != "local"
            ):
                output_dir = output_dir_override.rstrip("/")
            else:
                output_dir = normalize_path(output_dir_override)
    except (ValueError, FileNotFoundError) as e:
        logger.error(f"Failed to resolve domain paths for '{domain}': {e}")
        raise
    except Exception as e:
        logger.error(f"Unexpected error during domain resolution for '{domain}': {e}")
        raise

    state = _prepare_extraction_state(
        domain, config, input_path, prompt_path, output_dir, has_domain_config
    )

    file_paths = _resolve_input_files(input_path)
    pipeline_mode = _select_pipeline_mode(config)

    if pipeline_mode == "parallel_batch":
        return await _run_parallel_batch(
            file_paths,
            state=state,
            extraction_agent=extraction_agent,
            resume=resume,
        )
    if pipeline_mode == "batch":
        return await _run_batch(
            file_paths,
            state=state,
            extraction_agent=extraction_agent,
            resume=resume,
        )
    if pipeline_mode == "parallel_sync":
        return await _run_parallel_sync(
            file_paths,
            state=state,
            extraction_agent=extraction_agent,
            resume=resume,
        )
    return await _run_sequential_sync(state, extraction_agent=extraction_agent, resume=resume)
