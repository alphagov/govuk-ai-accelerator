import asyncio
import time
from collections import deque
from dataclasses import dataclass

@dataclass
class BedrockQuotaGovernorConfig:
    enabled: bool = False
    requests_per_minute: int = 100
    tokens_per_minute: int = 100_000
    max_concurrency: int = 8
    window_seconds: int = 60
    jitter_min_seconds: float = 0.2
    jitter_max_seconds: float = 1.5

class BedrockQuotaGovernor:
    """Sliding-window rate limiter for AWS Bedrock API calls.

    Uses deques to track request timestamps and token usage within a
    rolling window.  When a new ``acquire()`` would exceed either the
    request-per-minute or token-per-minute cap, the exact sleep duration
    is computed deterministically (no polling loop).
    """

    def __init__(self, cfg: BedrockQuotaGovernorConfig) -> None:
        assert cfg is not None, "cfg parameter is required"
        self._cfg = cfg
        self._lock = asyncio.Lock()
        self._sem = asyncio.Semaphore(cfg.max_concurrency)
        self._req_timestamps: deque[float] = deque()
        self._tok_timestamps: deque[tuple[float, int]] = deque()

    async def __aenter__(self):
        await self._sem.acquire()
        return self

    async def __aexit__(self, exc_type, exc, tb):
        self._sem.release()

                                                                        
                                                                                              
                                                                        

    async def acquire(self, estimated_tokens: int) -> None:
        if not self._cfg.enabled:
            return
        if estimated_tokens < 1:
            estimated_tokens = 1

        async with self._lock:
            now = time.monotonic()
            window = float(self._cfg.window_seconds)

                                                         
            self._evict_old_entries(now, window)

                                                                      
            wait = self._calculate_wait(now, window, estimated_tokens)

            if wait > 0:
                await asyncio.sleep(wait)
                now = time.monotonic()
                self._evict_old_entries(now, window)

                                 
            self._req_timestamps.append(now)
            self._tok_timestamps.append((now, estimated_tokens))

                                                                        
                      
                                                                        

    def _evict_old_entries(self, now: float, window: float) -> None:
        """Remove timestamps older than the sliding window."""
        assert now > 0, "now must be positive"
        assert window > 0, "window must be positive"
        while self._req_timestamps and now - self._req_timestamps[0] >= window:
            self._req_timestamps.popleft()
        while self._tok_timestamps and now - self._tok_timestamps[0][0] >= window:
            self._tok_timestamps.popleft()

    def _calculate_wait(self, now: float, window: float, estimated_tokens: int) -> float:
        """Compute the exact sleep duration needed before this request can proceed."""
        assert now > 0, "now must be positive"
        assert window > 0, "window must be positive"
        assert estimated_tokens >= 1, "estimated_tokens must be >= 1"
        wait = 0.0

                                  
        if len(self._req_timestamps) >= self._cfg.requests_per_minute:
            oldest_req = self._req_timestamps[0]
            wait = max(wait, window - (now - oldest_req))

                                
        current_tokens = sum(t for _, t in self._tok_timestamps)
        if current_tokens + estimated_tokens > self._cfg.tokens_per_minute:
            if self._tok_timestamps:
                oldest_tok = self._tok_timestamps[0][0]
                wait = max(wait, window - (now - oldest_tok))

        return wait
