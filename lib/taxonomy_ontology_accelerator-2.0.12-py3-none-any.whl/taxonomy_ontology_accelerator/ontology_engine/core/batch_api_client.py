from __future__ import annotations

import asyncio
from functools import partial
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any, Literal
from urllib.parse import urlparse

try:
    import boto3
except ImportError:
    boto3 = None

from taxonomy_ontology_accelerator.ontology_engine.utils.aws_client_config import (
    build_aws_client_config,
)

BatchResultType = Literal["succeeded", "errored", "expired", "canceled"]

@dataclass
class BatchStatus:
    batch_id: str
    processing_status: str
    request_counts: dict[str, int]

@dataclass
class BatchResult:
    record_id: str
    result_type: BatchResultType
    content: Any | None = None
    error: Any | None = None

class BedrockBatchClient:
    def __init__(
        self,
        *,
        s3_bucket: str,
        s3_prefix: str = "toa-batch",
        role_arn: str,
        region: str | None = None,
        boto_session: Any | None = None,
        time_provider: Callable[[], float] | None = None,
    ) -> None:
        if not s3_bucket:
            raise ValueError("s3_bucket must not be empty")
        if not s3_prefix:
            raise ValueError("s3_prefix must not be empty")
        if not role_arn:
            raise ValueError("role_arn must not be empty")
        if boto3 is None and boto_session is None:
            raise ImportError("boto3 is required for Bedrock batch client; install with [bedrock]")

        session = boto_session or boto3.Session()
        region_name = region or None
        client_kwargs: dict[str, Any] = {"region_name": region_name}
        client_config = build_aws_client_config()
        if client_config is not None:
            client_kwargs["config"] = client_config

        self._bedrock = session.client("bedrock", **client_kwargs)
        self._s3 = session.client("s3", **client_kwargs)
        self._bucket = s3_bucket
        self._prefix = s3_prefix.strip("/")
        self._role_arn = role_arn
        self._time_provider = time_provider or __import__("time").monotonic
        self._last_poll_at: dict[str, float] = {}

    async def upload_input_jsonl(self, jsonl_content: str, job_name: str) -> str:
        if not job_name:
            raise ValueError("job_name must not be empty")

        s3_key = f"{self._prefix}/input/{job_name}.jsonl"
        put_call = partial(
            self._s3.put_object,
            Bucket=self._bucket,
            Key=s3_key,
            Body=jsonl_content.encode("utf-8"),
        )
        await asyncio.to_thread(put_call)
        return f"s3://{self._bucket}/{s3_key}"

    async def submit_batch(
        self,
        *,
        job_name: str,
        model_id: str,
        input_s3_uri: str,
        timeout_hours: int = 24,
    ) -> str:
        if not job_name:
            raise ValueError("job_name must not be empty")
        if not model_id:
            raise ValueError("model_id must not be empty")
        if not input_s3_uri:
            raise ValueError("input_s3_uri must not be empty")

        output_s3_uri = f"s3://{self._bucket}/{self._prefix}/output/{job_name}/"
        submit_call = partial(
            self._bedrock.create_model_invocation_job,
            jobName=job_name,
            roleArn=self._role_arn,
            modelId=model_id,
            inputDataConfig={
                "s3InputDataConfig": {
                    "s3InputFormat": "JSONL",
                    "s3Uri": input_s3_uri,
                }
            },
            outputDataConfig={"s3OutputDataConfig": {"s3Uri": output_s3_uri}},
            timeoutDurationInHours=timeout_hours,
        )
        response = await asyncio.to_thread(submit_call)
        job_arn = response.get("jobArn")
        if not isinstance(job_arn, str) or not job_arn:
            raise ValueError("Bedrock response did not include jobArn")
        return job_arn

    async def poll_batch(
        self,
        job_arn: str,
        *,
        min_poll_interval_seconds: float = 60.0,
    ) -> BatchStatus:
        now = self._time_provider()
        last_poll_time = self._last_poll_at.get(job_arn)
        if last_poll_time is not None and now - last_poll_time < min_poll_interval_seconds:
            raise ValueError(
                f"poll_batch called before min_poll_interval_seconds={min_poll_interval_seconds}"
            )

        poll_call = partial(self._bedrock.get_model_invocation_job, jobIdentifier=job_arn)
        response = await asyncio.to_thread(poll_call)
        self._last_poll_at[job_arn] = now

        counts_source = response.get("requestCounts")
        if not isinstance(counts_source, dict):
            counts_source = {}
        request_counts = {
            "processing": int(counts_source.get("processing", 0)),
            "succeeded": int(counts_source.get("succeeded", 0)),
            "errored": int(counts_source.get("errored", 0)),
            "expired": int(counts_source.get("expired", 0)),
            "canceled": int(counts_source.get("canceled", 0)),
        }
        return BatchStatus(
            batch_id=job_arn,
            processing_status=str(response.get("status", "Unknown")),
            request_counts=request_counts,
        )

    async def download_results(self, job_arn: str) -> str:
        poll_call = partial(self._bedrock.get_model_invocation_job, jobIdentifier=job_arn)
        response = await asyncio.to_thread(poll_call)
        output_uri = (
            response.get("outputDataConfig", {}).get("s3OutputDataConfig", {}).get("s3Uri", "")
        )
        bucket, key_prefix = _parse_s3_uri(output_uri)

        list_call = partial(self._s3.list_objects_v2, Bucket=bucket, Prefix=key_prefix)
        listed = await asyncio.to_thread(list_call)
        keys = sorted(
            item.get("Key", "")
            for item in listed.get("Contents", [])
            if item.get("Key") and not str(item.get("Key", "")).endswith("/")
        )
        if not keys:
            return ""

        lines: list[str] = []
        for key in keys:
            get_call = partial(self._s3.get_object, Bucket=bucket, Key=key)
            object_response = await asyncio.to_thread(get_call)
            payload = object_response["Body"].read()
            if isinstance(payload, bytes):
                text = payload.decode("utf-8")
            else:
                text = str(payload)
            if text and not text.endswith("\n"):
                text = f"{text}\n"
            lines.append(text)

        return "".join(lines)

def _parse_s3_uri(s3_uri: str) -> tuple[str, str]:
    parsed = urlparse(s3_uri)
    if parsed.scheme != "s3" or not parsed.netloc:
        raise ValueError(f"Invalid S3 URI: {s3_uri!r}")

    key = parsed.path.lstrip("/")
    return parsed.netloc, key

                                            
BatchApiClient = BedrockBatchClient
