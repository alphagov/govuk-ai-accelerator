from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable

from taxonomy_ontology_accelerator.ontology_engine.core.file_worker_pool import (
    FileWorkerResult,
)


@dataclass
class MergeResult:
    entities: list[Any] = field(default_factory=list)
    relationships: list[Any] = field(default_factory=list)
    source_file_count: int = 0
    total_raw_entities: int = 0


def merge_file_results(
    file_results: list[FileWorkerResult],
    deduplicate_fn: Callable[[list[Any]], list[Any]] | None = None,
) -> MergeResult:
    assert isinstance(file_results, list), "file_results must be a list"

    all_entities: list[Any] = []
    all_relationships: list[Any] = []
    successful_count = 0
    for result in file_results:
        if not result.success or result.result is None:
            continue
        successful_count += 1
        all_entities.extend(getattr(result.result, "entities", []) or [])
        all_relationships.extend(getattr(result.result, "relationships", []) or [])

    total_raw = len(all_entities)

    if deduplicate_fn and all_entities:
        deduped = deduplicate_fn(all_entities)
    else:
        deduped = all_entities

    return MergeResult(
        entities=deduped,
        relationships=all_relationships,
        source_file_count=successful_count,
        total_raw_entities=total_raw,
    )
