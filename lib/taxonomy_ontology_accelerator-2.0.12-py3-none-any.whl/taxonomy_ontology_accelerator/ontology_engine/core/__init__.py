"""
Core ontology engine components.

Contains the main extraction logic, data models, and LLM processing.
"""

from taxonomy_ontology_accelerator.ontology_engine.core.extractor import extract_ontology
from taxonomy_ontology_accelerator.ontology_engine.core.models import (
    Entity,
    EntityTypeDefinition,
    ExtractedConcept,
    ExtractedRelationship,
    ExtractionResult,
    OntologyGraph,
    OntologyOutput,
    OntologySchema,
    ProcessingMetadata,
    Relationship,
    RelationshipTypeDefinition,
)

__all__ = [
    "Entity",
    "EntityTypeDefinition",
    "ExtractedConcept",
    "ExtractedRelationship",
    "ExtractionResult",
    "OntologyGraph",
    "OntologyOutput",
    "OntologySchema",
    "ProcessingMetadata",
    "Relationship",
    "RelationshipTypeDefinition",
    "extract_ontology",
]
