"""
Extraction pipeline for ontology extraction.

This module implements a staged pipeline pattern for the extract_ontology function,
breaking the massive 491-statement function into manageable, testable stages.

Architecture:
- ExtractionState: Dataclass holding all state across stages
- Stage functions: Each handles one logical step of extraction
- Pipeline orchestration: Main function coordinates stages
"""

import logging
import time
from pathlib import Path
from typing import Any, TypedDict, cast

import fsspec
from pydantic import BaseModel, Field

from taxonomy_ontology_accelerator.commons.errors import ErrorCollector
from taxonomy_ontology_accelerator.commons.io.file_utils import (
    join_path,
    normalize_path,
    safe_read_file,
)
from taxonomy_ontology_accelerator.commons.io.fsspec_utils import (
    get_default_filesystem,
    get_filesystem_from_config,
)
from taxonomy_ontology_accelerator.commons.utils.logger import RichLogger, get_logger
from taxonomy_ontology_accelerator.ontology_engine.config.config import (
    OntologyConfig,
    OntologyConfigLoader,
)
from taxonomy_ontology_accelerator.ontology_engine.core.models import (
    Entity,
    ExtractedConcept,
    ExtractedRelationship,
    OntologyGraph,
    OntologySchema,
    Relationship,
)
from taxonomy_ontology_accelerator.ontology_engine.processing.entity_processor import (
    merge_existing_entities,
)
from taxonomy_ontology_accelerator.ontology_engine.processing.relationship_builder import (
    resolve_chain_mappings,
)
from taxonomy_ontology_accelerator.ontology_engine.storage.checkpoint_manager import (
    CheckpointManager,
)
from taxonomy_ontology_accelerator.ontology_engine.storage.data_loader import (
    ExistingData,
    load_existing_data,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.error_helpers import (
    raise_validation_error,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.file_loading import (
    ensure_output_directory,
    load_input_file,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.runtime_context import (
    format_runtime_prefix,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.text_normalization import (
    normalize_text,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.timing import stage_timer

logger = cast("RichLogger", get_logger())


class FileProcessingStatus(TypedDict):
    """Status tracking for file processing during extraction."""

    has_failed_chunks: bool
    processed_chunks: int
    total_chunks: int  # Total chunks for this file


# Threshold for displaying file count scale info
LARGE_FILE_COUNT_THRESHOLD = 100
_CLOUD_PROTOCOLS = ("s3", "gs", "gcs", "az", "hdfs")


def _resolve_output_filesystem(output_dir: Path | str | None, config: OntologyConfig):
    """Resolve the filesystem for output artifacts from the final output path."""
    assert config is not None, "config is required"

    if output_dir is None:
        return get_default_filesystem()

    output_dir_str = str(output_dir)
    for protocol in _CLOUD_PROTOCOLS:
        if output_dir_str.startswith(f"{protocol}://") or output_dir_str.startswith(f"{protocol}::"):
            options = config.filesystem.options or {}
            if getattr(config.filesystem, "protocol", "local") == protocol:
                return get_filesystem_from_config(protocol, options)
            return get_filesystem_from_config(protocol, {})

    return get_default_filesystem()


def _sync_runtime_output_context(state: "ExtractionState", config: OntologyConfig):
    """Keep runtime output path and filesystem aligned for later write stages."""
    assert state.output_dir is not None, "output_dir must be set"
    output_fs = _resolve_output_filesystem(state.output_dir, config)
    state.output_fs = output_fs
    config._runtime_output_dir = str(state.output_dir)
    return output_fs


class ExtractionState(BaseModel):
    """
    Central state container for the extraction pipeline.

    Holds all intermediate data as it flows through extraction stages.
    Using a state object reduces argument counts and makes the pipeline
    easier to understand and test.
    """

    model_config = {"arbitrary_types_allowed": True, "extra": "allow"}

    # Input parameters
    # Input parameters
    domain: str
    incremental: bool

    # Configuration
    # Configuration
    config: OntologyConfig | None = Field(default=None, exclude=True)
    error_collector: ErrorCollector = Field(default_factory=ErrorCollector, exclude=True)

    # Filesystem and coordination (for cloud storage and distributed processing)
    fs: Any = Field(
        default=None, exclude=True
    )  # AbstractFileSystem instance for cloud storage (S3, GCS, etc.)
    output_fs: Any = Field(
        default=None, exclude=True
    )  # Filesystem for output artifacts (may differ from input fs)
    coordinator: Any = Field(
        default=None, exclude=True
    )  # WorkCoordinator for multi-worker scenarios (optional)
    lock_provider: Any = Field(
        default=None, exclude=True
    )  # DistributedLock provider for coordination (optional)

    # Timing
    # Timing
    start_time: float = Field(default_factory=time.time)
    stage_timings: dict[str, float] = Field(default_factory=dict)

    # Input data
    texts: list[str] = Field(default_factory=list)
    text_sources: list[str] | None = None
    source_file_path: str | None = None
    domain_prompt: str | None = None

    # Resolved paths for convention-over-configuration
    # Resolved paths for convention-over-configuration
    input_path: Path | str | None = None
    prompt_path: Path | str | None = None

    # Output directory
    output_dir: Path | str | None = None

    # Checkpoint management
    # Checkpoint management
    checkpoint_manager: CheckpointManager | None = Field(default=None, exclude=True)
    file_processing_status: dict[str, FileProcessingStatus] = Field(default_factory=dict)

    # Existing data (for incremental)
    existing_data: ExistingData | None = None
    existing_schema: OntologySchema | None = None
    existing_graph: OntologyGraph | None = None
    existing_embeddings: dict[str, list[float]] = Field(default_factory=dict)
    existing_entity_map: dict[str, str] = Field(default_factory=dict)

    # Pre-merged data
    # Pre-merged data
    pre_merged_entity_by_label: dict[str, Entity] | None = None
    pre_merged_entity_id_mapping: dict[str, str] | None = None
    normalization_cache: dict[str, str] | None = None

    # Chunked data
    # Chunked data
    chunks: list[str] = Field(default_factory=list)
    chunk_sources: list[str] | None = None
    scaffold_by_source: dict[str, str] = Field(default_factory=dict)
    scaffold_summary: str | None = None

    # LLM extraction results
    all_concepts: list[ExtractedConcept] = Field(default_factory=list)
    all_relationships: list[ExtractedRelationship] = Field(default_factory=list)
    llm_calls: int = 0
    input_tokens: int = 0
    output_tokens: int = 0
    cache_read_tokens: int = 0
    cache_write_tokens: int = 0
    estimated_llm_input_tokens: int = 0
    estimated_llm_output_tokens: int = 0
    llm_usage_missing_calls: int = 0
    embedding_input_tokens: int = 0
    embedding_output_tokens: int = 0
    embedding_cache_read_tokens: int = 0
    embedding_cache_write_tokens: int = 0

    # Processed data
    # Processed data
    entities: list[Entity] = Field(default_factory=list)
    entity_label_to_id: dict[str, str] = Field(default_factory=dict)
    all_embeddings: dict[str, list[float]] = Field(default_factory=dict)
    embeddings_generated: int = 0
    semantic_duplicate_info: dict[str, tuple[str, float, tuple[Any, ...]]] | None = None

    # Relationships
    # Relationships
    relationships: list[Relationship] = Field(default_factory=list)
    entity_id_mapping: dict[str, str] = Field(default_factory=dict)

    # Schema
    ontology_schema: OntologySchema | None = None
    new_entity_types: int = 0
    new_relationship_types: int = 0
    auto_created_entity_count: int = 0
    ontology_shape_metrics: dict[str, int | float] = Field(default_factory=dict)

    # Final graph
    # Final graph
    graph: OntologyGraph | None = None

    # Export coordination
    owl_export_requested: bool = False
    owl_export_mode: str | None = None
    owl_export_status_path: Path | str | None = None
    owl_export_output_path: Path | str | None = None

    # Periodic flushing state
    batches_processed_since_flush: int = 0
    last_flush_time: float = Field(default_factory=time.time)
    current_flush_files: list[str] = Field(default_factory=list)
    flush_count: int = 0
    schema_version_incremented: bool = False
    flush_errors: list[tuple[int, str, Exception]] = Field(
        default_factory=list
    )  # (flush_num, flush_type, error)

    # Batch progress tracking
    total_batches: int = 0  # Total batches to process
    batches_completed: int = 0  # Batches completed so far

    bedrock_quota_governor: Any = Field(default=None, exclude=True)


def setup_logging() -> None:
    """
    Configure library logging levels for third-party dependencies.

    Reduces noise from verbose libraries during extraction:
    - pydantic_ai: INFO level (show key events)
    - anthropic: INFO level (show key events)
    - httpx: WARNING level (reduce HTTP noise)
    """
    assert logging is not None, "logging module must be available"
    assert hasattr(logging, "getLogger"), "logging.getLogger must be callable"

    logging.getLogger("pydantic_ai").setLevel(logging.INFO)
    logging.getLogger("anthropic").setLevel(logging.INFO)
    logging.getLogger("httpx").setLevel(logging.WARNING)


def calculate_input_scale(input_file: str | Path | None, fs=None) -> str:
    """
    Calculate an input scale indicator for logging.

    For directory inputs with many files, returns a string like
    " | scale: 150 files" to give visibility into processing scope.

    Args:
        input_file: Path to input file or directory

    Returns:
        Scale indicator string (empty if not applicable or <100 files)
    """
    assert LARGE_FILE_COUNT_THRESHOLD > 0, "threshold must be positive"
    assert isinstance(LARGE_FILE_COUNT_THRESHOLD, int), "threshold must be int"

    if not input_file:
        return ""
    try:
        fs = fs or fsspec.filesystem("file")
        input_path = str(input_file)
        if fs.isdir(input_path):
            supported = {
                ".txt",
                ".text",
                ".md",
                ".markdown",
                ".json",
                ".html",
                ".htm",
                ".xml",
                ".yaml",
                ".yml",
            }
            file_count = sum(
                1
                for f in fs.find(input_path)
                if fs.isfile(f) and Path(f).suffix.lower() in supported
            )
            if file_count > LARGE_FILE_COUNT_THRESHOLD:
                return f" | scale: {file_count} files"
    except Exception:
        pass
    return ""


def load_configuration(state: ExtractionState) -> None:
    """
    Load and cache ontology configuration.

    Loads configuration from YAML files (default.yaml merged with domain-specific).
    Configuration is cached for efficiency across multiple extractions.

    If config is already pre-loaded (e.g., from extract_ontology with domain-specific config),
    skips loading and uses the existing config.

    Args:
        state: Extraction state to populate with config
    """
    assert state is not None, "state must not be None"
    assert isinstance(state, ExtractionState), "state must be ExtractionState"

    with stage_timer("Configuration loaded"):
        if state.config is None:
            state.config = OntologyConfigLoader.load_for_domain(state.domain)


def validate_input_parameters(state: ExtractionState) -> None:
    """
    Validate input parameters for extraction.

    Validates:
    - input_path is set in state (required)
    - Domain parameter is set (required for output organization)

    Args:
        state: Extraction state with input_path and domain

    Raises:
        ValueError: If validation fails
    """
    assert state is not None, "state must not be None"
    assert state.input_path is not None, "input_path must be set in state"

    with stage_timer("Input parameters validated"):
        if not state.input_path:
            raise_validation_error(2, 9, "input_path must be set in state.")
        if not state.domain:
            raise_validation_error(2, 9, "Domain parameter is required.")


def load_domain_prompt(
    domain_prompt_file: str | Path | None,
    state: ExtractionState,
) -> None:
    """
    Load domain-specific extraction prompt from file.

    Domain prompts contain specialized instructions for the LLM to extract
    domain-specific entity types and relationships (e.g., medical, travel).

    Args:
        domain_prompt_file: Path to prompt file (optional, extraction uses generic if None)
        state: Extraction state to populate with domain_prompt

    Raises:
        FileNotFoundError: If prompt file doesn't exist
        OSError: If file cannot be read
        ValueError: If prompt file is empty
    """
    assert state is not None, "state must not be None"
    assert isinstance(state, ExtractionState), "state must be ExtractionState"

    with stage_timer("Loading domain prompt"):
        if domain_prompt_file is None:
            logger.info("📂 [Domain Prompt] No domain prompt - using library generic prompt only")
            return

        from taxonomy_ontology_accelerator.commons.io.fsspec_utils import get_default_filesystem

        if state.fs is None:
            state.fs = get_default_filesystem()

        state.prompt_path = normalize_path(domain_prompt_file)
        prompt_path = str(state.prompt_path)
        logger.info(f"📂 [Domain Prompt] Domain prompt: {domain_prompt_file}")

        if not state.fs.exists(prompt_path):
            raise FileNotFoundError(f"Domain prompt file not found: {prompt_path}")

        try:
            state.domain_prompt = safe_read_file(prompt_path, fs=state.fs).strip()
            if not state.domain_prompt:
                raise ValueError(f"Domain prompt file is empty: {prompt_path}")
        except Exception as e:
            raise OSError(f"Failed to read domain prompt file {prompt_path}: {e}") from e


def load_input_content(
    input_file: str | Path,
    state: ExtractionState,
) -> None:
    """
    Load and normalize input content for extraction.

    Supports multiple input sources:
    - Single file (.txt, .md, .json, etc.)
    - Directory of files (recursively processes all supported types)

    Normalizes text (whitespace, encoding) and tracks source files for provenance.

    Args:
        input_file: Path to file or directory (required)
        state: Extraction state to populate with texts and text_sources

    Raises:
        ValueError: If no valid input text found after loading
    """
    config = state.config
    assert config is not None, "config must be loaded before loading input"
    assert input_file is not None, "input_file must not be None"

    with stage_timer("Loading input"):
        # Input location will be logged by _log_input_source after loading
        # Input location will be logged by _log_input_source after loading
        _load_from_file(input_file, state)

        if not state.texts:
            raise ValueError("No input text loaded. Input file(s) may be empty or invalid.")


def _load_from_file(input_file: str | Path, state: ExtractionState) -> None:
    """
    Load input from file or directory.

    Supports:
    - Single files: .txt, .md, .json, .html, .xml, .yaml
    - Directories: recursively loads all supported file types
    - Tracks file paths for source provenance

    Args:
        input_file: Path to file or directory
        state: Extraction state to populate with texts and sources
    """
    config = state.config
    assert config is not None, "config must be initialized"
    assert input_file is not None, "input_file must not be None"

    input_path = normalize_path(input_file)
    state.texts, state.text_sources = load_input_file(input_file, config, fs=state.fs)

    if (
        config.source_grounding.enabled
        and state.text_sources
        and len(state.text_sources) != len(state.texts)
    ):
        state.text_sources = _align_sources(state.text_sources, len(state.texts), config)

    total_chars = sum(len(text) for text in state.texts)
    _log_input_source(input_path, state.texts, total_chars, fs=state.fs)

    if input_file:
        try:
            state.source_file_path = str(normalize_path(input_file))
        except (OSError, ValueError) as e:
            logger.warning(f"Failed to normalize source file path '{input_file}': {e}")
            state.source_file_path = str(Path(input_file))


def _align_sources(sources: list[str], num_texts: int, config: OntologyConfig) -> list[str]:
    """
    Align text sources list to match the number of texts.

    When text chunking creates more texts than sources, extends the sources
    list by repeating the last source. When there are more sources than texts,
    truncates the list.

    Args:
        sources: List of source identifiers
        num_texts: Target number of texts to align to
        config: Ontology configuration (for fallback prefix)

    Returns:
        Aligned list of sources matching num_texts length
    """
    assert sources is not None, "sources must not be None"
    assert num_texts >= 0, "num_texts must be non-negative"

    if len(sources) < num_texts:
        last = sources[-1] if sources else f"{config.source_grounding.fallback_source_prefix}_0"
        sources.extend([last] * (num_texts - len(sources)))
    else:
        sources = sources[:num_texts]
    return sources


def _log_input_source(input_path: Path | str, texts: list[str], total_chars: int, fs=None) -> None:
    """
    Log information about the loaded input source.

    Formats log message differently for files vs directories,
    including file size (for files) or file count (for directories).

    Args:
        input_path: Path to input file or directory
        texts: List of loaded text content (may be split into paragraphs)
        total_chars: Total character count across all texts
    """
    assert input_path is not None, "input_path must not be None"
    assert texts is not None, "texts must not be None"

    # Calculate approximate tokens (using 4 chars per token as rough estimate)
    # Calculate approximate tokens (using 4 chars per token as rough estimate)
    total_tokens = int(total_chars / 4)

    fs = fs or fsspec.filesystem("file")
    resolved = str(input_path)
    context_prefix = format_runtime_prefix()
    if fs.isfile(resolved):
        logger.load(f"{context_prefix}[Input Loading] Input: 1 file, ~{total_tokens:,} tokens")
    elif fs.isdir(resolved):
        file_count = sum(1 for item in fs.ls(resolved) if fs.isfile(item))
        logger.load(
            f"{context_prefix}[Input Loading] Input: {file_count} files, ~{total_tokens:,} tokens"
        )
    else:
        logger.load(f"{context_prefix}[Input Loading] Input: ~{total_tokens:,} tokens")


def setup_output_directory(output_dir: str | Path | None, state: ExtractionState) -> None:
    """
    Configure output directory and initialize checkpoint manager.

    Sets up:
    - Output directory path (custom or default based on domain)
    - Creates directory if it doesn't exist
    - Checkpoint manager for resumable extraction (if enabled)

    Args:
        output_dir: Custom output directory (optional, uses config default if None)
        state: Extraction state to populate with output_dir and checkpoint_manager
    """
    config = state.config
    assert config is not None, "config must be initialized"
    assert state.domain, "domain must be set"

    _resolve_output_path(output_dir, state, config)

    if config.checkpointing.enabled:
        _initialize_checkpoint_manager(state, config)


def _is_cloud_uri(path: str) -> bool:
    return any(path.startswith(f"{proto}://") for proto in ["s3", "gs", "gcs", "az", "hdfs"])


def _resolve_output_subdir(base_path: str, domain: str) -> str:
    stripped = base_path.rstrip("/")
    if stripped.split("/")[-1] != domain:
        return f"{stripped}/{domain}/output"
    return f"{stripped}/output"


def _resolve_output_path(
    output_dir: str | Path | None, state: ExtractionState, config: OntologyConfig
) -> None:
    """Resolve and create the output directory path."""
    assert config is not None, "config is required"
    assert state.domain, "domain must be set"

    with stage_timer("Determining output directory"):
        # Check if output_dir is already resolved (e.g., from extract_ontology)
        if state.output_dir is not None:
            logger.info(f"💾 [Output] Output: {state.output_dir}")
        elif output_dir is None:
            base_path = normalize_path(config.output.base_directory)
            if isinstance(base_path, str) and _is_cloud_uri(base_path):
                state.output_dir = _resolve_output_subdir(base_path, state.domain)
            else:
                state.output_dir = Path(base_path) / state.domain / "output"
            logger.data(f"[Output] Output directory: {state.output_dir}")
        else:
            output_path = normalize_path(output_dir)
            if isinstance(output_path, str) and _is_cloud_uri(output_path):
                state.output_dir = _resolve_output_subdir(output_path, state.domain)
            else:
                output_path_obj = Path(output_path)
                if output_path_obj.name != state.domain:
                    state.output_dir = output_path_obj / state.domain / "output"
                else:
                    state.output_dir = output_path_obj / "output"
            logger.data(f"[Output] Output directory: {state.output_dir}")

        output_fs = _sync_runtime_output_context(state, config)
        ensure_output_directory(state.output_dir, output_fs)


def _initialize_checkpoint_manager(state: ExtractionState, config: OntologyConfig) -> None:
    """Initialize checkpoint manager and handle resume logic."""
    assert state.output_dir is not None, "output_dir must be set before creating CheckpointManager"
    assert config.checkpointing.enabled, "checkpointing must be enabled"

    state.checkpoint_manager = CheckpointManager(
        output_dir=state.output_dir,
        checkpoint_filename=config.checkpointing.checkpoint_filename,
        enabled=True,
        clear_first=False,
        fs=state.output_fs or state.fs,
    )
    resume_info = state.checkpoint_manager.get_resume_info()
    if resume_info["can_resume"]:
        logger.info(
            f"[Output] 🔄 Checkpoint resume: "
            f"{resume_info['completed_files']} file(s) completed, "
            f"{resume_info['failed_files']} file(s) failed (will retry)"
        )
        original_texts = list(state.texts)
        original_sources = (
            list(state.text_sources) if state.text_sources is not None else None
        )
        _filter_completed_files(state)
        _recover_stale_checkpoint_if_needed(
            state=state,
            config=config,
            original_texts=original_texts,
            original_sources=original_sources,
        )


def _recover_stale_checkpoint_if_needed(
    state: ExtractionState,
    config: OntologyConfig,
    original_texts: list[str],
    original_sources: list[str] | None,
) -> None:
    """
    Recover from stale checkpoint state for non-incremental runs.

    Stale state occurs when checkpoint metadata says all files are completed,
    but output artifacts are missing. In that case, clear the checkpoint and
    restore full input so extraction can run again.
    """
    assert state.checkpoint_manager is not None, "checkpoint_manager must be set"
    assert config is not None, "config must be set"

    if state.incremental:
        return
    if state.texts:
        return
    if not original_texts:
        return
    if _has_existing_output_artifacts(state, config):
        return

    logger.warning(
        "[Output] Stale checkpoint detected: all files marked completed but no graph/schema output "
        "exists. Clearing checkpoint and reprocessing input."
    )
    state.checkpoint_manager.clear_checkpoint()
    state.texts = original_texts
    state.text_sources = original_sources


def _has_existing_output_artifacts(state: ExtractionState, config: OntologyConfig) -> bool:
    """Return True if graph/schema output already exists in the resolved output directory."""
    assert state.checkpoint_manager is not None, "checkpoint_manager must be set"
    assert state.output_dir is not None, "output_dir must be set"
    assert config is not None, "config must be set"

    output_root = state.output_dir
    graph_path = join_path(output_root, config.output.graph_filename)
    schema_path = join_path(output_root, config.output.schema_filename)
    fs = state.checkpoint_manager.fs

    return fs.exists(str(graph_path)) or fs.exists(str(schema_path))


def _filter_completed_files(state: ExtractionState) -> None:
    """
    Filter out completed files from texts and text_sources.

    When checkpointing is enabled and files are already completed,
    removes their texts/sources to avoid reprocessing.

    Args:
        state: Extraction state with checkpoint_manager, texts, and text_sources
    """
    assert state.checkpoint_manager is not None, "checkpoint_manager must be set"

    if state.text_sources is None:
        logger.debug("[Output] text_sources not loaded yet - deferring checkpoint file filtering")
        return

    if not state.texts or not state.text_sources:
        return

    # Build mapping of which texts belong to which files
    filtered_texts = []
    filtered_sources = []
    skipped_count = 0

    for text, source in zip(state.texts, state.text_sources, strict=False):
        # Check if this source file is already completed
        if state.checkpoint_manager.is_file_completed(source):
            skipped_count += 1
            continue
        filtered_texts.append(text)
        filtered_sources.append(source)

    if skipped_count > 0:
        completed_file_count = len(
            {
                source
                for source in state.text_sources
                if state.checkpoint_manager.is_file_completed(source)
            }
        )
        remaining_file_count = len(set(filtered_sources)) if filtered_sources else 0

        logger.info(
            f"[Output] ⏭️  Processing {remaining_file_count} remaining file(s) "
            f"({completed_file_count} already completed)"
        )
        state.texts = filtered_texts
        state.text_sources = filtered_sources

        # If ALL files are completed, log and continue (will load existing data)
        # If ALL files are completed, log and continue (will load existing data)
        if not filtered_texts:
            logger.success(
                "[Output] ✓ All input files already completed - loading existing results"
            )


def load_existing_ontology_data(state: ExtractionState) -> None:
    """
    Load existing schema, graph, and embeddings for incremental extraction.

    For incremental mode:
    - Loads existing schema.json, graph.json, and embeddings
    - Pre-merges existing entities into the entity map for deduplication
    - Sets up resolved ID mapping for entity deduplication

    For non-incremental mode:
    - Creates empty ExistingData (fresh extraction)

    Args:
        state: Extraction state to populate with existing_data, existing_schema, etc.
    """
    config = state.config
    assert config is not None, "config must be initialized"
    assert state.output_dir is not None, "output_dir must be set"

    with stage_timer("Loading existing data"):
        if state.incremental:
            state.existing_data = load_existing_data(
                state.output_dir, config, state.error_collector
            )
            if state.existing_data.graph:
                msg = (
                    f"[Input Loading] Found existing ontology | "
                    f"{len(state.existing_data.graph.entities)} entities, "
                    f"{len(state.existing_data.graph.relationships)} relationships"
                )
                logger.load(msg)
            else:
                logger.info("[Input Loading] No existing data found - starting fresh extraction")
        else:
            state.existing_data = ExistingData()
            logger.info("[Input Loading] Fresh extraction mode (incremental=False)")

        state.existing_schema = state.existing_data.ontology_schema
        state.existing_graph = state.existing_data.graph
        state.existing_embeddings = state.existing_data.embeddings or {}
        state.existing_entity_map = state.existing_data.entity_map or {}

        if state.existing_graph is not None:
            _premerge_existing_entities(state)


def _remap_existing_relationships_after_premerge(
    state: ExtractionState, resolved_mapping: dict[str, str]
) -> None:
    """Remap existing relationships to use canonical entity IDs after pre-merge."""
    assert state is not None, "state parameter is required"
    assert resolved_mapping is not None, "resolved_mapping parameter is required"

    if (
        not state.pre_merged_entity_id_mapping
        or state.existing_graph is None
        or not state.existing_graph.relationships
    ):
        return

    remapped_count = 0
    for rel in state.existing_graph.relationships:
        old_from, old_to = rel.from_, rel.to

        # Apply resolved mapping to relationship endpoints
        # Apply resolved mapping to relationship endpoints
        if rel.from_ in resolved_mapping:
            rel.from_ = resolved_mapping[rel.from_]
        if rel.to in resolved_mapping:
            rel.to = resolved_mapping[rel.to]

        # Track if this relationship was updated
        if old_from != rel.from_ or old_to != rel.to:
            remapped_count += 1

    if remapped_count > 0:
        logger.info(
            f"[6] Pre-merge: Remapped {remapped_count} existing relationship(s) "
            f"to canonical entity IDs from {len(state.pre_merged_entity_id_mapping)} entity merge(s)"
        )


def _premerge_existing_entities(state: ExtractionState) -> None:
    """Pre-merge existing entities with same normalized label."""
    config = state.config
    assert config is not None, "config must be initialized"
    assert state.existing_graph is not None, "existing_graph must be set"

    state.normalization_cache = {}

    entities_by_label: dict[str, list[Entity]] = {}
    for entity in state.existing_graph.entities:
        normalized = normalize_text(entity.label, config, cache=state.normalization_cache)
        if normalized not in entities_by_label:
            entities_by_label[normalized] = []
        entities_by_label[normalized].append(entity)

    state.pre_merged_entity_by_label = {}
    state.pre_merged_entity_id_mapping = {}

    for normalized_label, entity_list in entities_by_label.items():
        canonical, mapping = merge_existing_entities(entity_list, config, state.normalization_cache)
        state.pre_merged_entity_by_label[normalized_label] = canonical
        state.pre_merged_entity_id_mapping.update(mapping)

    resolved = resolve_chain_mappings(state.pre_merged_entity_id_mapping)
    for normalized_label, entity_id in list(state.existing_entity_map.items()):
        canonical_id = resolved.get(entity_id, entity_id)
        if normalized_label in state.pre_merged_entity_by_label:
            state.existing_entity_map[normalized_label] = state.pre_merged_entity_by_label[
                normalized_label
            ].id
        else:
            state.existing_entity_map[normalized_label] = canonical_id

    # Update existing_graph.entities with merged canonical entities
    # This prevents downstream stages from seeing stale, unmerged entities
    # Update existing_graph.entities with merged canonical entities
    # This prevents downstream stages from seeing stale, unmerged entities
    if state.pre_merged_entity_id_mapping:
        state.existing_graph.entities = list(state.pre_merged_entity_by_label.values())
        logger.debug(
            f"[6] Pre-merge: Updated existing_graph with "
            f"{len(state.existing_graph.entities)} canonical entities "
            f"(merged {len(state.pre_merged_entity_id_mapping)} duplicates)"
        )

    # Remap existing relationships immediately after entity pre-merge
    # This PREVENTS orphaned relationships from being created
    # Remap existing relationships immediately after entity pre-merge
    # This PREVENTS orphaned relationships from being created
    _remap_existing_relationships_after_premerge(state, resolved)
