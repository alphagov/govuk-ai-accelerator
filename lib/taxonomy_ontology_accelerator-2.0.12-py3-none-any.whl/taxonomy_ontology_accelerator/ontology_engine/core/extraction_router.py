from pydantic_ai import Agent

from taxonomy_ontology_accelerator.ontology_engine.core.extraction_pipeline import ExtractionState
from taxonomy_ontology_accelerator.ontology_engine.core.extraction_stages import (
    run_llm_extraction,
)
from taxonomy_ontology_accelerator.ontology_engine.core.models import ExtractionResult
from taxonomy_ontology_accelerator.ontology_engine.generation_stages.term_extraction import (
    adapter,
)
from taxonomy_ontology_accelerator.ontology_engine.generation_stages.term_extraction.runner import (
    run_term_extraction_path,
)


async def run_configured_extraction(
    extraction_agent: Agent[None, ExtractionResult],
    extraction_prompt: str,
    state: ExtractionState,
) -> None:
    config = state.config
    assert config is not None

    if not config.term_extraction.enabled:
        await _run_generic_extraction(extraction_agent, extraction_prompt, state)
        return

    if config.batch_api_enabled:
        raise ValueError("term_extraction.enabled is not supported with batch_api_enabled yet")

    await _run_term_candidate_extraction(extraction_agent, extraction_prompt, state)


async def _run_generic_extraction(
    extraction_agent: Agent[None, ExtractionResult],
    extraction_prompt: str,
    state: ExtractionState,
) -> None:
    await run_llm_extraction(extraction_agent, extraction_prompt, state)


async def _run_term_candidate_extraction(
    extraction_agent: Agent[None, ExtractionResult],
    extraction_prompt: str,
    state: ExtractionState,
) -> None:
    terms = await run_term_extraction_path(state)
    if not adapter.has_candidate_terms(terms):
        state.all_concepts = []
        state.all_relationships = []
        return

    candidate_context_provider = adapter.build_candidate_context_provider(terms)
    llm_calls_before_ontology_extraction = state.llm_calls
    await run_llm_extraction(
        extraction_agent,
        extraction_prompt,
        state,
        batch_context_provider=candidate_context_provider,
    )
    state.llm_calls += llm_calls_before_ontology_extraction
