"""Parse Bedrock Batch Inference S3 output JSONL into the pipeline's ExtractionResult model.

Batch results are matched to original requests via recordId (NOT by position,
as batch results are NOT ordered). Handles success and error modelOutput records.
"""

import json
from dataclasses import dataclass
from typing import Any

from taxonomy_ontology_accelerator.commons.utils.logger import get_logger
from taxonomy_ontology_accelerator.ontology_engine.core.models import ExtractionResult

logger = get_logger()

@dataclass
class ParsedBatchResult:
    """Wrapper around ExtractionResult for batch processing.

    This is NOT a replacement for ExtractionResult — it adds batch-specific
    metadata (record_id, status, error_message) around the existing model.
    """

    record_id: str
    status: str                                     
    result: ExtractionResult | None
    error_message: str | None

def _extract_text_content(content_blocks: list[dict[str, Any]]) -> str | None:
    """Extract the first text block from modelOutput content.

    Args:
        content_blocks: List of content block dicts from Bedrock model output.

    Returns:
        Text content string or None if no text block found.
    """
    assert content_blocks is not None, "content_blocks must not be None"
    assert isinstance(content_blocks, list), "content_blocks must be a list"

    for block in content_blocks:
        if block.get("type") == "text":
            text = block.get("text")
            if text and isinstance(text, str):
                return text
    return None

def _parse_succeeded_record(record_id: str, model_output: dict[str, Any]) -> ParsedBatchResult:
    """Parse a succeeded Bedrock batch record into ExtractionResult.

    Args:
        record_id: The recordId from the JSONL line.
        model_output: The modelOutput dict containing message content.

    Returns:
        ParsedBatchResult with parsed ExtractionResult or error on parse failure.
    """
    assert record_id is not None, "record_id must not be None"
    assert model_output is not None, "model_output must not be None"

    try:
        content = model_output.get("content", [])
        text = _extract_text_content(content)
        if text is None:
            logger.warning(f"Batch result {record_id}: no text content in succeeded result")
            return ParsedBatchResult(
                record_id=record_id,
                status="errored",
                result=None,
                error_message=f"No text content found in succeeded result {record_id}",
            )

        payload = json.loads(text)
        extraction = ExtractionResult.model_validate(payload)

        return ParsedBatchResult(
            record_id=record_id,
            status="succeeded",
            result=extraction,
            error_message=None,
        )
    except (json.JSONDecodeError, ValueError, KeyError) as e:
        logger.warning(f"Batch result {record_id}: failed to parse succeeded result — {e}")
        return ParsedBatchResult(
            record_id=record_id,
            status="errored",
            result=None,
            error_message=f"Parse error for {record_id}: {e}",
        )

def _parse_errored_record(record_id: str, error_info: dict[str, Any]) -> ParsedBatchResult:
    """Parse an errored Bedrock batch record.

    Args:
        record_id: The recordId from the JSONL line.
        error_info: The error dict from modelOutput.error.

    Returns:
        ParsedBatchResult with error details.
    """
    assert record_id is not None, "record_id must not be None"
    assert error_info is not None, "error_info must not be None"

    error_type = error_info.get("type", "unknown")
    error_msg = error_info.get("message", "Unknown error")

    logger.warning(f"Batch result {record_id}: errored — {error_type}: {error_msg}")

    return ParsedBatchResult(
        record_id=record_id,
        status="errored",
        result=None,
        error_message=f"{error_type}: {error_msg}",
    )

def parse_batch_results(
    jsonl_content: str,
    request_map: dict[str, Any],
) -> list[ParsedBatchResult]:
    """Parse Bedrock Batch Inference S3 output JSONL into ParsedBatchResult list.

    Results are matched to original requests via recordId (NOT by position).
    The returned list is ordered by request_map keys.

    Args:
        jsonl_content: JSONL string from S3 output. Each line contains
            {"recordId": "...", "modelOutput": {...}}.
        request_map: Map of record_id to original request context.

    Returns:
        List of ParsedBatchResult ordered by request_map keys.
    """
    assert jsonl_content is not None, "jsonl_content must not be None"
    assert request_map is not None, "request_map must not be None"

    lines = [line.strip() for line in jsonl_content.strip().split("\n") if line.strip()]

    if not lines and not request_map:
        return []

                                                         
    result_index: dict[str, ParsedBatchResult] = {}

    for line in lines:
        try:
            record = json.loads(line)
        except json.JSONDecodeError as e:
            logger.warning(f"Batch result: failed to parse JSONL line — {e}")
            continue

        record_id = record.get("recordId", "")
        model_output = record.get("modelOutput", {})

        if "error" in model_output:
            parsed = _parse_errored_record(record_id, model_output["error"])
        else:
            parsed = _parse_succeeded_record(record_id, model_output)

        if record_id not in request_map:
            logger.warning(f"Batch result {record_id}: not in request_map — including anyway")

        result_index[record_id] = parsed

                                                         
    ordered: list[ParsedBatchResult] = []
    for record_id in request_map:
        if record_id in result_index:
            ordered.append(result_index[record_id])
        else:
            logger.warning(f"Request {record_id}: no matching batch result — marking as missing")
            ordered.append(
                ParsedBatchResult(
                    record_id=record_id,
                    status="missing",
                    result=None,
                    error_message=f"No batch result found for {record_id}",
                )
            )

                                                                            
    for record_id, parsed in result_index.items():
        if record_id not in request_map:
            ordered.append(parsed)

    return ordered
