"""
Extraction stages 7-17 for ontology extraction pipeline.

This module continues the staged pipeline from extraction_pipeline.py,
handling chunking, LLM extraction, processing, and output stages.
"""

import json
import time
from pathlib import Path
from typing import Any

from pydantic_ai import Agent

from taxonomy_ontology_accelerator.commons.errors import ErrorCollector
from taxonomy_ontology_accelerator.commons.io.file_utils import join_path
from taxonomy_ontology_accelerator.commons.utils.logger import get_logger
from taxonomy_ontology_accelerator.ontology_engine.config.config import (
    NamingConventionsConfig,
    OntologyConfig,
)
from taxonomy_ontology_accelerator.ontology_engine.core.bedrock_quota_governor import (
    BedrockQuotaGovernor,
)
from taxonomy_ontology_accelerator.ontology_engine.core.bedrock_quota_governor import (
    BedrockQuotaGovernorConfig as RuntimeGovernorConfig,
)
from taxonomy_ontology_accelerator.ontology_engine.core.extraction_pipeline import ExtractionState
from taxonomy_ontology_accelerator.ontology_engine.core.llm_processor import (
    BatchContextProvider,
    BatchProcessingInput,
    _build_scaffold_aware_domain_prompt,
    process_batches,
)
from taxonomy_ontology_accelerator.ontology_engine.core.models import (
    Entity,
    ExtractedConcept,
    ExtractionResult,
    OntologyOutput,
    ProcessingMetadata,
)
from taxonomy_ontology_accelerator.ontology_engine.processing.conflict_resolution import (
    resolve_relationship_conflicts,
)
from taxonomy_ontology_accelerator.ontology_engine.processing.embeddings import (
    _text_hash,
    capture_embedding_usage,
    save_embeddings,
)
from taxonomy_ontology_accelerator.ontology_engine.processing.entity_processor import (
    EntityDeduplicationInput,
    normalize_and_deduplicate_entities,
)
from taxonomy_ontology_accelerator.ontology_engine.processing.relationship_builder import (
    RelationshipBuildInput,
    build_relationships,
)
from taxonomy_ontology_accelerator.ontology_engine.processing.schema_evolver import (
    apply_structural_upper_ontology_scaffold,
    apply_upper_ontology_map,
    evolve_schema,
)
from taxonomy_ontology_accelerator.ontology_engine.processing.text_processor import chunk_texts
from taxonomy_ontology_accelerator.ontology_engine.prompts import (
    DEFAULT_ONTOLOGY_PROMPT,
    FILE_LEVEL_SCAFFOLD_PROMPT,
    RELATIONSHIP_RECOVERY_PROMPT,
    TERM_SEEDED_ONTOLOGY_PROMPT,
    UPPER_ONTOLOGY_INFERENCE_PROMPT,
)
from taxonomy_ontology_accelerator.ontology_engine.storage.prompt_loader import PromptLoader
from taxonomy_ontology_accelerator.ontology_engine.utils.aws_client_config import (
    build_aws_client_config,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.error_helpers import (
    collect_error_if_enabled,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.id_generation import (
    generate_entity_id,
    get_current_timestamp,
    initialize_id_counter,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.list_emitter import (
    emit_raw_entity_list,
    emit_raw_relationship_list,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.llm_usage import (
    estimated_llm_usage_calls,
    get_or_estimate_llm_result_usage,
    is_estimated_llm_usage,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.prompt_utils import load_prompt
from taxonomy_ontology_accelerator.ontology_engine.utils.runtime_context import (
    format_runtime_prefix,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.text_normalization import (
    normalize_text,
    split_identifier_words,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.timing import stage_timer

logger = get_logger()


def _save_state_checkpoint(state: ExtractionState, stage: str) -> None:
    """Save state checkpoint if enabled."""
    assert state is not None, "state must not be None"
    assert stage is not None, "stage must not be None"

    config = state.config
    if not config or not config.checkpointing.persist_state:
        return

    if not state.output_dir:
        return

    from taxonomy_ontology_accelerator.ontology_engine.storage.state_checkpoint_manager import (
        StateCheckpointManager,
    )

    state_manager = StateCheckpointManager(
        output_dir=state.output_dir,
        enabled=config.checkpointing.persist_state,
        checkpoint_stages=config.checkpointing.state_checkpoint_stages,
        max_checkpoints=config.checkpointing.max_state_checkpoints,
        fs=state.fs,
    )
    state_manager.save_state_checkpoint(state, stage)


def _accumulate_usage(state: ExtractionState, usages: list) -> None:
    """Accumulate token usage from LLM calls into state."""
    assert state is not None, "state parameter is required"
    assert isinstance(usages, list), "usages must be a list"
    for usage in usages:
        if is_estimated_llm_usage(usage):
            state.estimated_llm_input_tokens += usage.input_tokens or 0
            state.estimated_llm_output_tokens += usage.output_tokens or 0
            state.llm_usage_missing_calls += estimated_llm_usage_calls(usage)
        else:
            state.input_tokens += usage.input_tokens or 0
            state.output_tokens += usage.output_tokens or 0
            state.cache_read_tokens += usage.cache_read_tokens or 0
            state.cache_write_tokens += usage.cache_write_tokens or 0


def _accumulate_embedding_usage(state: ExtractionState, usage) -> None:
    """Accumulate embedding API usage into run-scoped state."""
    assert state is not None, "state parameter is required"
    if usage is None:
        return

    state.embedding_input_tokens += usage.input_tokens or 0
    state.embedding_output_tokens += usage.output_tokens or 0
    state.embedding_cache_read_tokens += usage.cache_read_tokens or 0
    state.embedding_cache_write_tokens += usage.cache_write_tokens or 0


def _extract_first_json_object(raw_response: Any) -> dict[str, Any]:
    """Extract the first JSON object from an LLM response string."""
    if isinstance(raw_response, dict):
        return raw_response

    if not isinstance(raw_response, str):
        raise json.JSONDecodeError("Response is not valid JSON text", str(raw_response), 0)

    cleaned = raw_response.strip()
    decoder = json.JSONDecoder()
    search_index = 0
    last_error: json.JSONDecodeError | None = None

    while True:
        object_start = cleaned.find("{", search_index)
        if object_start == -1:
            if last_error is not None:
                raise last_error
            raise json.JSONDecodeError("No JSON object found", cleaned, 0)

        try:
            parsed, _end = decoder.raw_decode(cleaned, object_start)
        except json.JSONDecodeError as exc:
            last_error = exc
            search_index = object_start + 1
            continue

        if isinstance(parsed, dict):
            return parsed

        search_index = object_start + 1


def _reconcile_llm_call_count(llm_calls: int, usages: list) -> int:
    assert isinstance(llm_calls, int), "llm_calls must be an integer"
    assert usages is not None, "usages must not be None"

    usage_calls = 0
    for usage in usages:
        total_tokens = (
            (usage.input_tokens or 0)
            + (usage.output_tokens or 0)
            + (usage.cache_read_tokens or 0)
            + (usage.cache_write_tokens or 0)
        )
        if total_tokens > 0:
            usage_calls += 1
    # ========================================================================
    return max(llm_calls, usage_calls)


def _build_naming_instructions(naming_config: NamingConventionsConfig) -> str:
    """
    Build naming convention instructions from config.

    Args:
        naming_config: Naming conventions configuration

    Returns:
        Formatted naming instructions string (empty if disabled)
    """
    assert naming_config is not None, "naming_config parameter is required"
    assert isinstance(naming_config, NamingConventionsConfig), (
        "naming_config must be NamingConventionsConfig instance"
    )

    if not naming_config.enabled:
        return ""

    instructions = "# Output Naming Conventions\n\n"
    instructions += f"- Entity types: Use {naming_config.entity_type_casing}\n"
    instructions += f"- Relationship types: Use {naming_config.relationship_type_casing}\n"
    instructions += f"- Property keys: Use {naming_config.property_casing}\n"

    # Handle general spelling variant
    # Handle general spelling variant
    if naming_config.spelling_variant != "preserve":
        variant = naming_config.spelling_variant
        example = "organisation, colour" if variant == "UK" else "organization, color"
        instructions += f"\n- Spelling: Use {variant} English ({example})\n"
        instructions += (
            "- Canonical ontology identifiers (entity types, relationship types, property keys, "
            "and IRIs) must use this spelling variant consistently.\n"
        )

    # Handle entity label spelling variant (if different from general)
    if naming_config.entity_label_spelling_variant != "preserve":
        label_variant = naming_config.entity_label_spelling_variant
        if label_variant != naming_config.spelling_variant:
            example = "organisation, colour" if label_variant == "UK" else "organization, color"
            instructions += f"- Entity labels: Use {label_variant} English spelling ({example})\n"
            instructions += (
                "- Entity labels may use a different spelling variant from canonical ontology "
                "identifiers only when this is explicitly configured.\n"
            )

    return instructions.strip()


async def _create_early_return_output(state: ExtractionState, config) -> OntologyOutput:
    """Create OntologyOutput for early return when all files already processed."""
    assert state is not None, "state parameter is required"
    assert state.existing_graph is not None, "existing_graph must be set for early return"

    schema = state.existing_schema
    if schema is None:
        schema, _, _ = await evolve_schema(
            None, [], [], state.domain, config, state.error_collector
        )

    return OntologyOutput(
        ontology_schema=schema,
        graph=state.existing_graph,
        metadata=ProcessingMetadata(
            total_entities_extracted=0,
            total_relationships_extracted=0,
            entities_after_deduplication=len(state.existing_graph.entities),
            relationships_after_deduplication=len(state.existing_graph.relationships),
            new_entity_types_created=0,
            new_relationship_types_created=0,
            processing_time_seconds=0.0,
            llm_calls_made=0,
            embeddings_generated=0,
        ),
        errors=state.error_collector.to_list(),
        schema_path=str(join_path(state.output_dir, config.output.schema_filename))
        if state.output_dir
        else "",
        graph_path=str(join_path(state.output_dir, config.output.graph_filename))
        if state.output_dir
        else "",
    )


def _perform_chunking(state: ExtractionState, config) -> None:
    """Perform text chunking based on configuration."""
    assert state is not None, "state parameter is required"
    assert config is not None, "config parameter is required"

    source_grounding_enabled = (
        hasattr(config, "source_grounding")
        and config.source_grounding is not None
        and config.source_grounding.enabled
    )

    if source_grounding_enabled:
        state.chunks, state.chunk_sources = _chunk_with_sources(state)
    else:
        state.chunks, _ = chunk_texts(state.texts, config, None)
        state.chunk_sources = None

    if not state.chunks:
        logger.warning("[Chunking] Produced no chunks - input may be empty")
        state.chunks = []
        state.chunk_sources = [] if source_grounding_enabled else None


async def chunk_input_text(state: ExtractionState) -> OntologyOutput | None:
    """
    Split input texts into chunks for LLM processing.

    Uses configured chunking strategy (token-based with overlap) to create
    appropriately sized chunks for the LLM. Also checks if file was already
    processed via checkpoint (enables resumable extraction).

    Args:
        state: Extraction state with texts to chunk

    Returns:
        OntologyOutput if file already processed (skip extraction), None otherwise
    """
    assert state is not None, "state parameter is required"
    config = state.config
    assert config is not None

    with stage_timer("Chunking text"):
        # Check if all texts were filtered out by checkpoint resume
        # Check if all texts were filtered out by checkpoint resume
        if not state.texts:
            logger.success("[Chunking] All input already processed - skipping")
            state.chunks = []
            state.chunk_sources = None

            # Return early with existing data for directory mode
            if not state.existing_graph:
                raise ValueError("All files already processed but no existing data found.")

            logger.cache("[Chunking] Returning existing ontology data")
            return await _create_early_return_output(state, config)

        _perform_chunking(state, config)

        # Check checkpoint for already processed files
        # Check checkpoint for already processed files
        early_return = await _check_checkpoint_skip(state)
        if early_return:
            return early_return

        _log_chunking_summary(state, config)

        # Save state checkpoint after chunking
        # Save state checkpoint after chunking
        _save_state_checkpoint(state, "chunking")

        return None


def _log_chunking_summary(state: ExtractionState, config) -> None:
    """Log summary of chunking results with file count and source grounding status."""
    assert state is not None, "state must not be None"
    assert config is not None, "config must not be None"

    file_count = 1  # Default for single file
    if state.source_file_path and state.fs and state.text_sources:
        try:
            if state.fs.isdir(str(state.source_file_path)):
                file_count = len(set(state.text_sources))
        except Exception as e:
            # Some cloud IAM policies allow object read but deny directory/list checks.
            logger.debug(
                f"[Chunking] Unable to inspect source path type, defaulting to single-file: {e}"
            )

    source_grounding_enabled = (
        hasattr(config, "source_grounding")
        and config.source_grounding is not None
        and config.source_grounding.enabled
    )
    logger.processing(f"[Chunking] Chunks: {len(state.chunks)} chunks from {file_count} file(s)")
    logger.debug(
        f"[Chunking] Source grounding: {'enabled' if source_grounding_enabled else 'disabled'}"
    )


def _chunk_with_sources(state: ExtractionState) -> tuple[list[str], list[str] | None]:
    """
    Chunk texts while tracking source provenance.

    When source grounding is enabled, maintains mapping from each chunk
    back to its original source file for entity provenance tracking.

    Args:
        state: Extraction state with texts and text_sources

    Returns:
        Tuple of (chunks, chunk_sources)
    """
    assert state is not None, "state parameter is required"
    config = state.config
    assert config is not None

    try:
        chunks, chunk_sources = chunk_texts(state.texts, config, state.text_sources)
        chunk_sources = _validate_chunk_sources(chunks, chunk_sources, config)
        return chunks, chunk_sources
    except Exception as e:
        logger.error(f"[Chunking] Error during chunking: {e}. Falling back.")
        chunks, _ = chunk_texts(state.texts, config, None)
        chunk_sources = _generate_fallback_sources(len(chunks), config)
        return chunks, chunk_sources


def _validate_chunk_sources(
    chunks: list[str], sources: list[str] | None, config: OntologyConfig
) -> list[str] | None:
    """Validate and fix chunk sources to match chunks."""
    assert chunks is not None, "chunks parameter is required"
    assert config is not None, "config parameter is required"
    if not sources or len(sources) == len(chunks):
        return sources

    logger.warning(
        f"[Chunking] Source tracking mismatch detected: {len(sources)} sources for {len(chunks)} chunks - auto-fixing"
    )

    if len(sources) < len(chunks):
        last = sources[-1] if sources else f"{config.source_grounding.fallback_source_prefix}_0"
        sources.extend([last] * (len(chunks) - len(sources)))
    else:
        sources = sources[: len(chunks)]
    return sources


def _generate_fallback_sources(num_chunks: int, config: OntologyConfig) -> list[str]:
    """
    Generate fallback source IDs when actual sources are unavailable.

    Creates synthetic source IDs like "source_0", "source_1" based on
    the configured fallback prefix. Used when source tracking fails or
    when input comes from direct text strings.

    Args:
        num_chunks: Number of source IDs to generate
        config: Ontology configuration with fallback prefix

    Returns:
        List of generated source IDs
    """
    assert isinstance(num_chunks, int), "num_chunks must be an integer"
    assert config is not None, "config parameter is required"
    sources = [f"{config.source_grounding.fallback_source_prefix}_{i}" for i in range(num_chunks)]
    logger.warning(
        f"[Chunking] Generated {len(sources)} fallback source IDs (source tracking unavailable)"
    )
    logger.debug(f"[Chunking] Fallback prefix: {config.source_grounding.fallback_source_prefix}")
    return sources


async def _check_checkpoint_skip(state: ExtractionState) -> OntologyOutput | None:
    """
    Check if source file was already processed and return early if so.

    Enables resumable extraction by checking the checkpoint file for
    previously completed files. If file was processed, returns the
    existing data as OntologyOutput without re-extracting.

    Args:
        state: Extraction state with checkpoint_manager and source_file_path

    Returns:
        OntologyOutput with existing data if already processed, None otherwise
    """
    if not state.checkpoint_manager or not state.source_file_path:
        return None

    config = state.config
    assert config is not None
    assert state.output_dir is not None

    files_to_process = state.checkpoint_manager.filter_unprocessed_files([state.source_file_path])
    if files_to_process:
        return None

    logger.cache("[Chunking] File already processed in checkpoint - skipping extraction")
    logger.debug(f"[Chunking] Checkpoint file: {state.source_file_path}")

    if not state.existing_graph:
        raise ValueError("No files to process and no existing data found.")

    schema = state.existing_schema
    if schema is None:
        schema, _, _ = await evolve_schema(
            None, [], [], state.domain, config, state.error_collector
        )

    return OntologyOutput(
        ontology_schema=schema,
        graph=state.existing_graph,
        metadata=ProcessingMetadata(
            total_entities_extracted=0,
            total_relationships_extracted=0,
            entities_after_deduplication=len(state.existing_graph.entities),
            relationships_after_deduplication=len(state.existing_graph.relationships),
            new_entity_types_created=0,
            new_relationship_types_created=0,
            processing_time_seconds=0.0,
            llm_calls_made=0,
            embeddings_generated=0,
        ),
        errors=state.error_collector.to_list(),
        schema_path=str(join_path(state.output_dir, config.output.schema_filename)),
        graph_path=str(join_path(state.output_dir, config.output.graph_filename)),
    )


def _load_extraction_prompt(config: OntologyConfig) -> str:
    """
    Load extraction prompt from config or use built-in default.

    Args:
        config: Ontology configuration

    Returns:
        Extraction prompt string
    """
    assert config is not None, "config parameter is required"
    assert config.llm is not None, "config.llm must be set"

    if config.term_extraction.enabled:
        logger.debug("Using term-seeded ontology prompt for term extraction path")
        return TERM_SEEDED_ONTOLOGY_PROMPT

    if config.llm.extraction_prompt_file:
        extraction_prompt = load_prompt(config.llm.extraction_prompt_file)
        logger.debug(f"Loaded custom extraction prompt from: {config.llm.extraction_prompt_file}")
        return extraction_prompt

    logger.debug("Using built-in default extraction prompt")
    return DEFAULT_ONTOLOGY_PROMPT


def _group_texts_by_source(state: ExtractionState) -> list[tuple[str, str]]:
    """Return full-text content grouped by source file for scaffold extraction."""
    assert state is not None, "state parameter is required"

    if not state.texts:
        return []

    if state.text_sources and len(state.text_sources) == len(state.texts):
        grouped: dict[str, list[str]] = {}
        for text, source in zip(state.texts, state.text_sources, strict=False):
            source_key = source or f"source_{len(grouped) + 1}"
            grouped.setdefault(source_key, []).append(text)
        return [(source, "\n\n".join(parts)) for source, parts in grouped.items()]

    fallback_sources = state.text_sources or []
    grouped_pairs: list[tuple[str, str]] = []
    for idx, text in enumerate(state.texts, start=1):
        source = (
            fallback_sources[idx - 1]
            if idx - 1 < len(fallback_sources) and fallback_sources[idx - 1]
            else str(state.source_file_path)
            if state.source_file_path
            else f"source_{idx}"
        )
        grouped_pairs.append((source, text))
    return grouped_pairs


def _summarize_scaffold_result(
    result: ExtractionResult,
    config: OntologyConfig,
) -> str | None:
    """Build a compact scaffold summary from file-level extraction output."""
    assert result is not None, "result parameter is required"
    assert config is not None, "config parameter is required"

    concept_type_counts: dict[str, int] = {}
    for concept in result.concepts:
        concept_type = concept.concept_type.strip()
        if not concept_type:
            continue
        concept_type_counts[concept_type] = concept_type_counts.get(concept_type, 0) + 1

    relationship_type_counts: dict[str, int] = {}
    for relationship in result.relationships:
        relationship_type = relationship.type.strip()
        if not relationship_type:
            continue
        relationship_type_counts[relationship_type] = (
            relationship_type_counts.get(relationship_type, 0) + 1
        )

    ordered_types = sorted(
        concept_type_counts.items(),
        key=lambda item: (-item[1], item[0].casefold()),
    )[: config.batching.file_level_scaffold_max_types]
    ordered_relationships = sorted(
        relationship_type_counts.items(),
        key=lambda item: (-item[1], item[0].casefold()),
    )[: config.batching.file_level_scaffold_max_relationships]

    sections: list[str] = []
    if ordered_types:
        sections.append(
            "Classes:\n" + "\n".join(f"- {concept_type}" for concept_type, _ in ordered_types)
        )
    if ordered_relationships:
        sections.append(
            "Relationship Families:\n"
            + "\n".join(f"- {relationship_type}" for relationship_type, _ in ordered_relationships)
        )

    if not sections:
        return None

    return "\n\n".join(sections)


async def extract_file_level_scaffold(
    extraction_agent: Agent[None, ExtractionResult],
    state: ExtractionState,
) -> None:
    """Extract a compact schema-first scaffold per source file before chunk extraction."""
    assert extraction_agent is not None, "extraction_agent parameter is required"
    assert state is not None, "state parameter is required"
    config = state.config
    assert config is not None, "config must be set"

    if not config.batching.file_level_scaffold_enabled:
        return

    grouped_sources = _group_texts_by_source(state)
    if not grouped_sources:
        return

    logger.llm(
        f"{format_runtime_prefix()}[Scaffold] Building file-level scaffold for "
        f"{len(grouped_sources)} source file(s)..."
    )

    scaffold_by_source: dict[str, str] = {}
    scaffold_sections: list[str] = []

    for source, text in grouped_sources:
        prompt = PromptLoader.build_prompt(
            FILE_LEVEL_SCAFFOLD_PROMPT,
            domain_prompt=state.domain_prompt,
            input_text=text,
        )
        result = await extraction_agent.run(prompt)
        raw_output = getattr(result, "output", None)
        if raw_output is None:
            raw_output = getattr(result, "data", None)
        if raw_output is None:
            raise AttributeError("AgentRunResult has neither 'output' nor 'data'")
        if not isinstance(raw_output, ExtractionResult):
            raise TypeError("File-level scaffold extraction must return ExtractionResult")

        summary = _summarize_scaffold_result(raw_output, config)
        if summary:
            scaffold_by_source[source] = summary
            scaffold_sections.append(f"Source: {source}\n{summary}")

        state.llm_calls += 1
        usage = get_or_estimate_llm_result_usage(result, prompt, config)
        if usage:
            _accumulate_usage(state, [usage])

    state.scaffold_by_source = scaffold_by_source
    state.scaffold_summary = "\n\n".join(scaffold_sections) if scaffold_sections else None

    if scaffold_by_source:
        logger.processing(
            f"{format_runtime_prefix()}[Scaffold] Captured scaffold summaries for "
            f"{len(scaffold_by_source)} source file(s)"
        )


def _is_bedrock_routing_enabled(config: OntologyConfig, use_bedrock: bool | None = None) -> bool:
    """Decide whether Bedrock routing should be used."""
    assert config is not None, "config parameter is required"
    if use_bedrock is not None:
        assert isinstance(use_bedrock, bool), "use_bedrock must be a boolean when provided"

    model_str = str(config.llm.model)
    prefix_enabled = model_str.startswith("bedrock:")
    if use_bedrock is not None:
        return use_bedrock or prefix_enabled

    return bool(getattr(config.llm, "aws_bedrock_enabled", False)) or prefix_enabled


def _get_model_instance(config: OntologyConfig, use_bedrock: bool | None = None) -> Any:
    """
    Get the appropriate LLM model instance.

    Uses pydantic-ai auto-inference for all providers except Bedrock:
    - Gemini: Auto-inferred from "gemini-*" format
    - Anthropic: Auto-inferred from "anthropic:*" format
    - OpenAI: Auto-inferred from "openai:*" format
    - Other providers: Auto-inferred by pydantic-ai
    - AWS Bedrock: Custom logic with validation

    Args:
        config: Ontology configuration with LLM settings
        use_bedrock: Whether to force AWS Bedrock routing (optional).
            Bedrock is also auto-enabled when model uses `bedrock:` prefix.

    Returns:
        Model identifier string (pydantic-ai auto-infers) or BedrockConverseModel instance

    Raises:
        ImportError: If Bedrock is enabled but boto3 is not installed
    """
    assert config is not None, "config parameter is required"
    model_identifier = config.llm.model

    # Warn about Anthropic timeout if needed (10-minute timeout when max_tokens > 20000)
    ANTHROPIC_TIMEOUT_THRESHOLD = 20000  # Anthropic models timeout after 10 min if > 20k tokens
    ANTHROPIC_RECOMMENDED_MAX = 16000  # Safe value to avoid timeout
    model_str = str(config.llm.model)
    is_anthropic = ":" in model_str and model_str.split(":", 1)[0] == "anthropic"
    if (
        is_anthropic
        and config.llm.max_tokens
        and config.llm.max_tokens > ANTHROPIC_TIMEOUT_THRESHOLD
    ):
        recommended = ANTHROPIC_RECOMMENDED_MAX
        logger.warning(
            f"[LLM Agent] Token limit may cause timeout | Current: {config.llm.max_tokens:,} | "
            f"Recommended: ≤ {recommended:,}"
        )

    routing_uses_bedrock = _is_bedrock_routing_enabled(config, use_bedrock=use_bedrock)
    if model_str.startswith("bedrock:"):
        model_identifier = model_str[len("bedrock:") :]  # strip prefix before passing to Bedrock

    # Bedrock special case (custom validation logic)
    # Bedrock special case (custom validation logic)
    if routing_uses_bedrock:
        logger.llm(f"[LLM Agent] Using AWS Bedrock | Model: {model_identifier}")
        return _create_bedrock_model(config, model_identifier)

    # All other providers: Let pydantic-ai auto-infer from model string
    # All other providers: Let pydantic-ai auto-infer from model string
    logger.llm(f"[LLM Agent] LLM Agent ready | Model: {model_identifier}")
    logger.debug("[LLM Agent] Provider auto-inferred by pydantic-ai from model string")
    return model_identifier


def _create_bedrock_model(config: OntologyConfig, model_identifier: str) -> Any:
    """
    Create AWS Bedrock model instance using pydantic-ai's BedrockConverseModel.

    Uses AWS SDK default credential chain:
    1. Environment variables (AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, AWS_DEFAULT_REGION)
    2. AWS credentials file (~/.aws/credentials)
    3. IAM roles (if running on AWS)

    Args:
        model_identifier: Model identifier (e.g., "anthropic:claude-sonnet-4-20250514")

    Returns:
        BedrockConverseModel instance

    Raises:
        ImportError: If pydantic-ai[bedrock] is not installed
        ValueError: If AWS region not configured or model not supported on Bedrock
    """
    assert model_identifier is not None, "model_identifier parameter is required"
    assert isinstance(model_identifier, str), "model_identifier must be a string"
    try:
        import boto3
        from pydantic_ai.models.bedrock import BedrockConverseModel
        from pydantic_ai.providers.bedrock import BedrockProvider
    except ImportError as e:
        raise ImportError(
            "AWS Bedrock support requires pydantic-ai with Bedrock extras. "
            "Install with: uv sync --extra bedrock"
        ) from e

    # Validate AWS region is configured
    # Validate AWS region is configured
    _validate_aws_region()

    # Convert and validate model identifier
    try:
        bedrock_model_id = _convert_to_bedrock_model_id(model_identifier)
        session = boto3.Session()
        client_kwargs: dict[str, Any] = {}
        client_config = build_aws_client_config(config)
        if client_config is not None:
            client_kwargs["config"] = client_config
        bedrock_client = session.client("bedrock-runtime", **client_kwargs)
        provider = BedrockProvider(bedrock_client=bedrock_client)
        model = BedrockConverseModel(bedrock_model_id, provider=provider)

        logger.llm(f"[LLM Agent] AWS Bedrock model created: {bedrock_model_id}")
        logger.debug("[LLM Agent] Using AWS SDK default credential chain for authentication")

        return model

    except Exception as e:
        logger.error(f"[LLM Agent] Failed to create AWS Bedrock model: {e}")

        # Provide helpful error message for common issues
        if "region" in str(e).lower():
            raise ValueError(
                "AWS region not configured. Set AWS_DEFAULT_REGION environment variable "
                "or configure region in ~/.aws/config file."
            ) from e
        if "credentials" in str(e).lower() or "access" in str(e).lower():
            raise ValueError(
                "AWS credentials not found. Set AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY "
                "environment variables, or configure ~/.aws/credentials file."
            ) from e
        raise


def _validate_aws_region() -> None:
    """
    Validate that AWS region is configured.

    Raises:
        ValueError: If AWS region is not configured
    """
    assert True, "Validation function called"  # Placeholder assertion for entry
    assert callable(logger.config), "logger.config must be callable"
    import os

    # Check environment variable
    # Check environment variable
    region = os.environ.get("AWS_DEFAULT_REGION") or os.environ.get("AWS_REGION")
    if region:
        logger.config(f"[LLM Agent] AWS region from environment: {region}")
        return

    # Check AWS config file
    try:
        import boto3

        session = boto3.Session()
        region = session.region_name
        if region:
            logger.config(f"[LLM Agent] AWS region from config/profile: {region}")
            return
    except Exception:
        pass

    # No region found
    # No region found
    raise ValueError(
        "AWS region not configured. Set AWS_DEFAULT_REGION environment variable "
        "or configure region in ~/.aws/config file.\n"
        "Example: export AWS_DEFAULT_REGION=us-east-1"
    )


def _convert_to_bedrock_model_id(model_identifier: str, region_prefix: str = "us") -> str:
    """
    Convert standard model identifier to Bedrock model ID format.

    Args:
        model_identifier: Standard model ID (e.g., "anthropic:claude-sonnet-4-20250514")
        region_prefix: AWS region prefix for Bedrock model IDs (default: "us")

    Returns:
        Bedrock-compatible model ID

    Raises:
        ValueError: If model is not supported on Bedrock
    """
    assert model_identifier is not None, "model_identifier parameter is required"
    assert isinstance(model_identifier, str), "model_identifier must be a string"
    # Check for unsupported models
    # Check for unsupported models
    if model_identifier.startswith("gemini"):
        raise ValueError(
            f"Model '{model_identifier}' is not supported on AWS Bedrock. "
            "Bedrock only supports Anthropic Claude models. "
            "Either use direct API (set use_bedrock=False) or switch to a Claude model."
        )

    # Bedrock model ID mapping for Anthropic models
    if model_identifier.startswith("anthropic:"):
        model_name = model_identifier.replace("anthropic:", "")
    else:
        model_name = model_identifier

    # Check if it's already in Bedrock format (anthropic.*)
    if model_identifier.startswith("anthropic.") or ".anthropic." in model_identifier:
        logger.debug(f"[LLM Agent] Using Bedrock model ID as-is: {model_identifier}")
        return model_identifier

    # Unknown model format
    bedrock_model_id = f"{region_prefix}.anthropic.{model_name}:0"

    if not any(
        model_name.startswith(prefix)
        for prefix in [
            "claude-3-7-sonnet",
            "claude-sonnet-4",
            "claude-sonnet-4-5",
            "claude-sonnet-4-6",
            "claude-3-5-sonnet",
            "claude-3-opus",
        ]
    ):
        logger.warning(
            f"Model '{model_identifier}' not in known Bedrock mapping - "
            f"attempting to use as-is: {bedrock_model_id}"
        )
    # ========================================================================
    return bedrock_model_id


def _create_file_completion_callback(state: ExtractionState):
    """Create callback for tracking file completion status."""
    assert state is not None, "state parameter is required"
    assert hasattr(state, "file_processing_status"), "state must have file_processing_status"

    def update(file_path: str | None, success: bool) -> None:
        assert isinstance(success, bool), "success must be a boolean"
        assert state is not None, "state must be available in closure"
        if (
            not state.checkpoint_manager
            or not file_path
            or file_path not in state.file_processing_status
        ):
            return
        status = state.file_processing_status[file_path]
        if success:
            current_processed = status.get("processed_chunks", 0)
            total_chunks = status.get("total_chunks", 0)

            # Validate before incrementing to catch issues early
            # Validate before incrementing to catch issues early
            if current_processed >= total_chunks:
                logger.warning(
                    f"Chunk completion callback called but file already has all chunks processed: "
                    f"{file_path} ({current_processed}/{total_chunks})"
                )

            status["processed_chunks"] = current_processed + 1
        else:
            status["has_failed_chunks"] = True

    return update


def _calculate_batch_groups(batches: list, flush_interval: int) -> list[list]:
    """
    Group batches into chunks for periodic flushing.

    Args:
        batches: List of all batches to process
        flush_interval: Number of batches per group (0 = all in one group)

    Returns:
        List of batch groups, each containing up to flush_interval batches
    """
    assert batches is not None, "batches parameter is required"
    assert flush_interval >= 0, "flush_interval must be non-negative"

    if flush_interval == 0 or len(batches) <= flush_interval:
        # Flush disabled or fewer batches than interval - all in one group
        # Flush disabled or fewer batches than interval - all in one group
        return [batches]

    # Split into groups of flush_interval size
    groups = []
    for i in range(0, len(batches), flush_interval):
        groups.append(batches[i : i + flush_interval])

    return groups


async def _process_batch_group(
    batch_group: list,
    state: ExtractionState,
    batch_input_template: BatchProcessingInput,
    is_final_group: bool,
) -> None:
    """
    Process a single batch group and trigger flush.

    Args:
        batch_group: List of batches in this group
        state: Extraction state
        batch_input_template: Template for batch processing input
        is_final_group: Whether this is the last group (for final flush)
    """
    assert batch_group is not None, "batch_group parameter is required"
    assert state is not None, "state parameter is required"
    assert batch_input_template is not None, "batch_input_template parameter is required"

    from taxonomy_ontology_accelerator.ontology_engine.core.extraction_finalize import (
        perform_periodic_flush,
        should_perform_flush,
    )

    # Process this group of batches
    # Process this group of batches
    concepts, relationships, llm_calls, _, usages = await process_batches(batch_input_template)

    # Accumulate results
    state.all_concepts.extend(concepts)
    state.all_relationships.extend(relationships)
    state.llm_calls += llm_calls
    _accumulate_usage(state, usages)
    state.batches_processed_since_flush += len(batch_group)

    # Check if we should flush
    # Check if we should flush
    if should_perform_flush(state, is_final=is_final_group):
        await perform_periodic_flush(state, is_final=is_final_group)


def _initialize_file_processing_status(state: ExtractionState) -> None:
    """Initialize file processing status for checkpointing."""
    assert state is not None, "state parameter is required"
    assert hasattr(state, "checkpoint_manager"), "state must have checkpoint_manager attribute"

    if not state.checkpoint_manager:
        return

    if state.chunk_sources:
        # Directory input: track each unique source file
        from collections import Counter

        chunks_per_file = Counter(state.chunk_sources)

        for source_file, total_chunks in chunks_per_file.items():
            state.file_processing_status[source_file] = {
                "has_failed_chunks": False,
                "processed_chunks": 0,
                "total_chunks": total_chunks,
            }
        logger.debug(f"Tracking {len(chunks_per_file)} unique source files for checkpointing")
    elif state.source_file_path:
        # Single file input: track the single file
        # Single file input: track the single file
        state.file_processing_status[state.source_file_path] = {
            "has_failed_chunks": False,
            "processed_chunks": 0,
            "total_chunks": len(state.chunks),
        }
        logger.debug("Tracking 1 source file for checkpointing")


async def _create_flush_callback(state: ExtractionState, flush_interval: int):
    """Create flush callback for periodic flushing during batch processing."""
    assert state is not None, "state parameter is required"
    assert flush_interval > 0, "flush_interval must be positive"

    from taxonomy_ontology_accelerator.ontology_engine.core.extraction_finalize import (
        perform_periodic_flush,
        should_perform_flush,
    )

    async def _run_incremental_entity_dedup() -> None:
        cursor = getattr(state, "_flush_dedup_cursor", 0)
        if cursor < 0 or cursor > len(state.all_concepts):
            cursor = 0
            setattr(state, "_flush_entities_buffer", [])

        existing_buffer = getattr(state, "_flush_entities_buffer", None)
        if existing_buffer is None:
            existing_buffer = list(state.entities)
            setattr(state, "_flush_entities_buffer", existing_buffer)

        new_concepts = state.all_concepts[cursor:]
        if not new_concepts:
            return

        original_all_concepts = state.all_concepts
        state.all_concepts = new_concepts
        try:
            await deduplicate_extracted_entities(state)
            deduped_new_entities = list(state.entities)
        finally:
            state.all_concepts = original_all_concepts

        existing_ids = {
            entity.id if hasattr(entity, "id") else str(entity) for entity in existing_buffer
        }
        for entity in deduped_new_entities:
            entity_id = entity.id if hasattr(entity, "id") else str(entity)
            if entity_id in existing_ids:
                continue
            existing_buffer.append(entity)
            existing_ids.add(entity_id)
        state.entities = existing_buffer
        setattr(state, "_flush_dedup_cursor", len(state.all_concepts))

    async def flush_callback(
        group_num: int,
        total_groups: int,
        is_final: bool,
        group_concepts: list,
        group_relationships: list,
    ) -> None:
        """Callback to flush after each batch group."""
        assert group_num > 0, "group_num must be positive"
        assert total_groups > 0, "total_groups must be positive"
        assert group_concepts is not None, "group_concepts cannot be None"
        assert group_relationships is not None, "group_relationships cannot be None"
        flush_stage_start = time.perf_counter()

        logger.debug(
            f"Batch group {group_num}/{total_groups} complete: "
            f"{len(group_concepts)} concepts, {len(group_relationships)} relationships"
        )

        config = state.config
        assert config is not None

        if config.incremental_flush and not hasattr(state, "_flush_dedup_cursor"):
            setattr(state, "_flush_dedup_cursor", len(state.all_concepts))

        # Accumulate raw data
        state.all_concepts.extend(group_concepts)
        state.all_relationships.extend(group_relationships)

        if config.incremental_flush:
            await _run_incremental_entity_dedup()
        else:
            await deduplicate_extracted_entities(state)
        await build_entity_relationships(state)
        # Process ALL accumulated concepts/relationships so far

        # Update batch progress
        if is_final:
            state.batches_completed = state.total_batches
        else:
            state.batches_completed = min(group_num * flush_interval, state.total_batches)
        state.batches_processed_since_flush += flush_interval

        # Flush accumulated entities/relationships
        # Flush accumulated entities/relationships
        if should_perform_flush(state, is_final=is_final):
            flush_io_start = time.perf_counter()
            await perform_periodic_flush(state, is_final=is_final)
            logger.debug(
                f"Stage 'flush_callbacks.persist' for group {group_num}/{total_groups} "
                f"took {time.perf_counter() - flush_io_start:.3f}s"
            )

        flush_elapsed = time.perf_counter() - flush_stage_start
        state.stage_timings["flush_callbacks"] = (
            state.stage_timings.get("flush_callbacks", 0.0) + flush_elapsed
        )
        logger.debug(
            f"Stage 'flush_callbacks' for group {group_num}/{total_groups} "
            f"took {flush_elapsed:.3f}s"
        )

    return flush_callback


async def run_llm_extraction(
    extraction_agent: Agent[None, ExtractionResult],
    generic_prompt: str,
    state: ExtractionState,
    *,
    batch_context: str | None = None,
    batch_context_provider: BatchContextProvider | None = None,
) -> None:
    """Extract entities and relationships from chunks using LLM."""
    assert state is not None, "state parameter is required"
    config = state.config
    assert config is not None

    _initialize_file_processing_status(state)
    batch_domain_prompt = state.domain_prompt
    if state.scaffold_summary and not state.scaffold_by_source:
        batch_domain_prompt = _build_scaffold_aware_domain_prompt(
            state.domain_prompt,
            None,
            None,
            state.scaffold_summary,
            config.batching.file_level_scaffold_max_sources_in_prompt,
        )

    with stage_timer("Extracting entities and relationships"):
        logger.llm(
            f"{format_runtime_prefix()}[LLM Extraction] Starting LLM extraction from {len(state.chunks)} chunk(s)..."
        )
        _ensure_quota_governor(state)
        batch_input = BatchProcessingInput(
            chunks=state.chunks,
            generic_prompt=generic_prompt,
            domain_prompt=batch_domain_prompt,
            scaffold_by_source=state.scaffold_by_source,
            scaffold_summary=state.scaffold_summary,
            extraction_agent=extraction_agent,
            config=config,
            error_collector=state.error_collector,
            source_file_path=state.source_file_path,
            update_file_completion=_create_file_completion_callback(state),
            chunk_sources=state.chunk_sources if config.source_grounding.enabled else None,
            quota_governor=state.bedrock_quota_governor,
            batch_context=batch_context,
            batch_context_provider=batch_context_provider,
        )

        flush_interval = config.checkpointing.flush_interval_batches

        if flush_interval > 0:
            logger.info(
                f"{format_runtime_prefix()}Periodic flushing enabled: {flush_interval} batches per flush"
            )

            estimated_batch_size = min(flush_interval, len(state.chunks))
            state.total_batches = (
                len(state.chunks) + estimated_batch_size - 1
            ) // estimated_batch_size

            flush_callback = await _create_flush_callback(state, flush_interval)

            _, _, state.llm_calls, _, usages = await process_batches(
                batch_input,
                max_parallel_batches=flush_interval,
                on_group_complete=flush_callback,
            )
            _accumulate_usage(state, usages)
            state.llm_calls = _reconcile_llm_call_count(state.llm_calls, usages)
        else:
            (
                state.all_concepts,
                state.all_relationships,
                state.llm_calls,
                _,
                usages,
            ) = await process_batches(batch_input)
            _accumulate_usage(state, usages)
            state.llm_calls = _reconcile_llm_call_count(state.llm_calls, usages)

        await _recover_missing_relationships(extraction_agent, state)
        _finalize_file_completion(state)
        _emit_raw_extraction_results(state)


def _emit_raw_extraction_results(state: ExtractionState) -> None:
    """Emit raw extraction results to output directory."""
    assert state is not None, "state parameter is required"
    assert state.output_dir is not None, "output_dir must be set"
    assert state.config is not None, "config must be set"

    if state.output_dir and state.all_concepts and state.config.output.emit_pipeline_stage_lists:
        emit_raw_entity_list(state.all_concepts, state.output_dir, fs=state.output_fs or state.fs)
        emit_raw_relationship_list(
            state.all_relationships,
            state.output_dir,
            fs=state.output_fs or state.fs,
        )
        logger.processing(
            f"{format_runtime_prefix()}[Stage 1] Emitted raw extraction: {len(state.all_concepts)} entities, "
            f"{len(state.all_relationships)} relationships"
        )


def _build_relationship_recovery_domain_prompt(
    concepts: list[ExtractedConcept], config: OntologyConfig
) -> str:
    """Build compact recovery instructions from known extracted concepts."""
    assert concepts is not None, "concepts parameter is required"
    assert config is not None, "config parameter is required"

    max_entities = config.batching.relationship_recovery_max_entities_in_prompt
    scaffold_parent_map = config.schema_evolution.structural_scaffold.parent_map
    scaffold_label_keys = {
        split_identifier_words(type_name).strip().casefold() for type_name in scaffold_parent_map
    }

    def _concept_priority(concept: ExtractedConcept, original_index: int) -> tuple[int, float, int]:
        label_key = split_identifier_words(concept.label).strip().casefold()
        type_key = split_identifier_words(concept.concept_type).strip().casefold()
        is_exact_type_exemplar = label_key == type_key
        is_scaffold_anchor = (
            concept.concept_type in scaffold_parent_map or label_key in scaffold_label_keys
        )
        priority = 0
        if is_exact_type_exemplar:
            priority += 2
        if is_scaffold_anchor:
            priority += 1
        return (priority, -concept.confidence, original_index)

    seen_labels: set[str] = set()
    entity_lines: list[str] = []

    for _, concept in sorted(
        enumerate(concepts), key=lambda item: _concept_priority(item[1], item[0])
    ):
        normalized_label = concept.label.strip().casefold()
        if not normalized_label or normalized_label in seen_labels:
            continue
        seen_labels.add(normalized_label)
        entity_lines.append(f"- {concept.label} :: {concept.concept_type}")
        if len(entity_lines) >= max_entities:
            break

    return "\n".join(
        [
            "Known Entities",
            "Use only these exact entity labels as relationship endpoints:",
            *entity_lines,
        ]
    )


def _should_run_relationship_recovery(state: ExtractionState) -> bool:
    """Return True when a second relationship-only pass is justified."""
    assert state is not None, "state parameter is required"
    config = state.config
    assert config is not None, "config must be set"

    if not config.batching.relationship_recovery_enabled:
        return False
    if state.all_relationships:
        return False
    if len(state.all_concepts) < config.batching.relationship_recovery_min_concepts:
        return False
    return bool(state.chunks)


async def _recover_missing_relationships(
    extraction_agent: Agent[None, ExtractionResult], state: ExtractionState
) -> None:
    """Run a focused relationship-only recovery pass when extraction is too sparse."""
    assert state is not None, "state parameter is required"
    config = state.config
    assert config is not None, "config must be set"

    if not _should_run_relationship_recovery(state):
        return

    logger.llm(
        f"{format_runtime_prefix()}[LLM Extraction] Triggering relationship recovery pass for "
        f"{len(state.all_concepts)} extracted concepts with 0 relationships."
    )

    recovery_input = BatchProcessingInput(
        chunks=state.chunks,
        generic_prompt=RELATIONSHIP_RECOVERY_PROMPT,
        domain_prompt=_build_relationship_recovery_domain_prompt(state.all_concepts, config),
        extraction_agent=extraction_agent,
        config=config,
        error_collector=state.error_collector,
        source_file_path=state.source_file_path,
        update_file_completion=_create_file_completion_callback(state),
        chunk_sources=state.chunk_sources if config.source_grounding.enabled else None,
        quota_governor=state.bedrock_quota_governor,
    )

    recovered_concepts, recovered_relationships, llm_calls, _, usages = await process_batches(
        recovery_input
    )
    if recovered_concepts:
        logger.warning(
            f"{format_runtime_prefix()}[Relationship Recovery] Ignoring "
            f"{len(recovered_concepts)} unexpected concept(s) from recovery pass."
        )
    if recovered_relationships:
        state.all_relationships.extend(recovered_relationships)
        logger.processing(
            f"{format_runtime_prefix()}[Relationship Recovery] Recovered "
            f"{len(recovered_relationships)} relationships"
        )
    else:
        logger.warning(
            f"{format_runtime_prefix()}[Relationship Recovery] No relationships recovered."
        )

    state.llm_calls += llm_calls
    _accumulate_usage(state, usages)
    state.llm_calls = _reconcile_llm_call_count(state.llm_calls, usages)


def _finalize_file_completion(state: ExtractionState) -> None:
    """
    Finalize file processing status in checkpoint manager.

    For each file that had failed chunks during extraction, marks the
    file as failed in the checkpoint so it will be retried on next run.

    Args:
        state: Extraction state with checkpoint_manager and file_processing_status
    """
    assert state is not None, "state parameter is required"
    assert hasattr(state, "file_processing_status"), "state must have file_processing_status"
    if not state.checkpoint_manager:
        return
    for file_path, status in state.file_processing_status.items():
        if status["has_failed_chunks"]:
            state.checkpoint_manager.mark_file_failed(file_path)
            logger.warning(f"File marked as failed due to chunk errors: {file_path}")
            logger.debug(f"Processed chunks: {status['processed_chunks']}")


def enforce_extraction_limits(state: ExtractionState) -> None:
    """
    Enforce configured limits on extracted entities and relationships.

    Checks that extraction hasn't exceeded configured maximums.
    This is a safety check to prevent runaway extraction from consuming
    excessive resources.

    Args:
        state: Extraction state with all_concepts and all_relationships

    Raises:
        ValueError: If entity or relationship count exceeds configured limits
    """
    assert state is not None, "state parameter is required"
    config = state.config
    assert config is not None

    if (
        config.limits.max_entities is not None
        and len(state.all_concepts) > config.limits.max_entities
    ):
        raise ValueError(
            f"Extracted {len(state.all_concepts)} entities, exceeds limit of {config.limits.max_entities}."
        )

    if (
        config.limits.max_relationships is not None
        and len(state.all_relationships) > config.limits.max_relationships
    ):
        raise ValueError(
            f"Extracted {len(state.all_relationships)} relationships, exceeds limit of {config.limits.max_relationships}."
        )


def _update_entity_map(state: ExtractionState) -> None:
    """Update existing_entity_map to prevent duplicates after flush failure."""
    assert state is not None, "state must not be None"
    assert state.existing_entity_map is not None, "existing_entity_map must not be None"

    # This ensures next batch deduplicates against current batch's entities
    # even if flush fails and reload doesn't happen
    state.existing_entity_map.update(state.entity_label_to_id)
    logger.debug(
        f"Updated existing_entity_map with {len(state.entity_label_to_id)} new entity mappings "
        f"(total: {len(state.existing_entity_map)})"
    )


def _save_embeddings_if_new(state: ExtractionState, new_emb: dict, config, emb_path) -> None:
    """Save embeddings if new ones were generated."""
    assert state is not None, "state must not be None"
    assert new_emb is not None, "new_emb must not be None"

    state.all_embeddings = {**(state.existing_embeddings or {}), **new_emb}
    if new_emb:
        save_embeddings(state.all_embeddings, config, emb_path, fs=state.output_fs or state.fs)


def _emit_deduplication_logs_if_enabled(state: ExtractionState, merge_decisions: list) -> None:
    """Emit deduplication logs if enabled in config."""
    assert state is not None, "state parameter is required"
    assert state.config is not None, "config must be set"

    config = state.config
    if not config.output.emit_deduplication_logs or not merge_decisions:
        return

    from taxonomy_ontology_accelerator.ontology_engine.utils.deduplication_logger import (
        DeduplicationLogConfig,
        emit_deduplication_logs,
    )

    log_config = DeduplicationLogConfig(
        log_filename=config.output.deduplication_log_filename,
        summary_filename=config.output.deduplication_summary_filename,
        fs=state.output_fs or state.fs,
    )
    assert state.output_dir is not None, "output_dir must be set before emitting deduplication logs"
    log_path, summary_path = emit_deduplication_logs(
        merge_decisions,
        total_before=len(state.all_concepts),
        total_after=len(state.entities),
        output_dir=state.output_dir,
        config=log_config,
    )
    logger.save(
        f"[Deduplication] Logs emitted | {len(merge_decisions)} merges | "
        f"Log: {Path(str(log_path)).name} | Summary: {Path(str(summary_path)).name}"
    )


async def deduplicate_extracted_entities(state: ExtractionState) -> None:
    """Normalize labels and deduplicate entities using embeddings."""
    config = state.config
    assert config is not None
    assert state.output_dir is not None

    # Skip if already processed during periodic flush
    if state.entities and config.checkpointing.flush_interval_batches > 0:
        logger.debug(
            "[Entity Processing] Entities already processed during periodic flush, skipping"
        )
        return

    logger.dedupe(f"[Entity Processing] Deduplicating {len(state.all_concepts)} concepts...")
    emb_path = join_path(
        state.output_dir,
        config.output.embeddings_directory,
        config.output.embeddings_filename,
    )

    dedup_input = EntityDeduplicationInput(
        all_concepts=state.all_concepts,
        existing_entity_map=state.existing_entity_map,
        existing_embeddings=state.existing_embeddings,
        embeddings_path=emb_path,
        config=config,
        error_collector=state.error_collector or ErrorCollector(),
        existing_graph=state.existing_graph,
        normalization_cache=state.normalization_cache,
        fs=state.output_fs or state.fs,
    )
    with capture_embedding_usage(lambda usage: _accumulate_embedding_usage(state, usage)):
        (
            state.entities,
            state.entity_label_to_id,
            new_emb,
            state.embeddings_generated,
            state.semantic_duplicate_info,
            cross_session_mapping,
            merge_decisions,
        ) = await normalize_and_deduplicate_entities(dedup_input)

    # Propagate cross-session ID mappings so relationships resolve to existing entities
    # Propagate cross-session ID mappings so relationships resolve to existing entities
    if cross_session_mapping:
        state.entity_id_mapping.update(cross_session_mapping)

    _finalize_dedup_results(state, config, new_emb, emb_path, merge_decisions)


def _finalize_dedup_results(
    state: ExtractionState,
    config: "OntologyConfig",
    new_emb: dict[str, list[float]],
    emb_path: Path | str,
    merge_decisions: list,
) -> None:
    """Post-dedup: log results, save embeddings, update entity map, enforce limits."""
    assert config is not None, "config is required"
    assert state.entities is not None, "entities must be set after dedup"

    logger.dedupe(
        f"[Entity Processing] Deduplication: {len(state.all_concepts)} → {len(state.entities)} unique"
    )
    _process_semantic_duplicates(state)
    _save_embeddings_if_new(state, new_emb, config, emb_path)
    _update_entity_map(state)
    _emit_deduplication_logs_if_enabled(state, merge_decisions)

    if config.limits.max_entities and len(state.entities) > config.limits.max_entities:
        raise ValueError(
            f"After dedup: {len(state.entities)} entities exceeds limit {config.limits.max_entities}"
        )


def _build_text_hash_to_id_map(existing_graph) -> dict[str, str]:
    """Build text hash -> entity ID mapping from existing graph."""
    assert existing_graph is not None, "existing_graph parameter is required"
    assert hasattr(existing_graph, "entities"), "existing_graph must have entities"
    result: dict[str, str] = {}
    for entity in existing_graph.entities:
        txt = f"{entity.label} {' '.join(entity.alias_names)}" if entity.aliases else entity.label
        result[_text_hash(txt)] = entity.id
    return result


def _process_semantic_duplicates(state: ExtractionState) -> None:
    """Process semantic duplicates and merge them with existing entities."""
    assert state is not None, "state parameter is required"
    if not state.semantic_duplicate_info or not state.existing_graph:
        return

    config = state.config
    assert config is not None

    text_hash_to_id = _build_text_hash_to_id_map(state.existing_graph)
    counter = initialize_id_counter(state.entities, "id", config.output.entity_id_prefix)

    for _, (existing_hash, similarity, candidate) in state.semantic_duplicate_info.items():
        concept, norm_label, _, canonical_key = candidate
        actual_id = text_hash_to_id.get(existing_hash)
        if not actual_id:
            continue

        entity_id = generate_entity_id(counter, config)
        counter += 1
        ts = get_current_timestamp(config)

        entity = Entity(
            id=entity_id,
            canonical_key=canonical_key,
            label=norm_label,
            aliases=concept.aliases or [],
            type=normalize_text(concept.concept_type, config, cache=state.normalization_cache),
            description=concept.description,
            properties=concept.properties,
            metadata={
                "confidence": concept.confidence,
                "first_seen": ts,
                "last_updated": ts,
                "semantic_duplicate_of": actual_id,
                "semantic_similarity": similarity,
            },
        )
        state.entities.append(entity)
        state.entity_label_to_id[norm_label] = entity_id


async def build_entity_relationships(state: ExtractionState) -> None:
    """
    Build relationships between extracted entities.

    Converts extracted relationship triples (source_label, target_label, type)
    into Relationship objects with resolved entity IDs. Handles:
    - Entity label to ID resolution (exact match, alias lookup, semantic matching)
    - Existing entity mapping for incremental extraction
    - Auto-creation of stub entities for missing references (when enabled)
    - Batch-level duplicate relationship suppression

    Args:
        state: Extraction state to populate with relationships
    """
    assert state is not None, "state parameter is required"
    config = state.config
    assert config is not None

    # Skip if already processed during periodic flush
    if state.relationships and config.checkpointing.flush_interval_batches > 0:
        logger.debug(
            "[Relationship Building] Relationships already processed during periodic flush, skipping"
        )
        return

    rel_build_input = RelationshipBuildInput(
        all_relationships=state.all_relationships,
        entity_label_to_id=state.entity_label_to_id,
        existing_entity_map=state.existing_entity_map,
        existing_graph=state.existing_graph,
        config=config,
        error_collector=state.error_collector,
        entities=state.entities,
        all_embeddings=state.all_embeddings,
    )
    with capture_embedding_usage(lambda usage: _accumulate_embedding_usage(state, usage)):
        state.relationships = await build_relationships(rel_build_input)

    # Integrate auto-created entities into pipeline state
    # Integrate auto-created entities into pipeline state
    auto_created = rel_build_input.auto_created_entities
    if auto_created:
        logger.info(f"[Relationship Building] Auto-created {len(auto_created)} missing entities")
        state.auto_created_entity_count += len(auto_created)
        state.entities.extend(auto_created)
        for entity in auto_created:
            normalized = normalize_text(entity.label, config)
            state.entity_label_to_id[normalized] = entity.id
        state.existing_entity_map.update(state.entity_label_to_id)

    logger.processing(
        f"[Relationship Building] Built relationships | {len(state.all_relationships)} extracted → {len(state.relationships)} created"
    )
    logger.debug(
        f"[Relationship Building] Orphaned relationships filtered: {len(state.all_relationships) - len(state.relationships)}"
    )

    # Save state checkpoint after relationship building
    # Save state checkpoint after relationship building
    _save_state_checkpoint(state, "relationships")


async def evolve_ontology_schema(state: ExtractionState) -> None:
    """
    Evolve schema with new entity and relationship types.

    Schema evolution:
    1. Checks extracted entity types against existing schema
    2. Uses semantic similarity to match equivalent types
    3. Creates new types for genuinely novel entities
    4. Updates relationship type constraints based on usage
    5. Increments schema version on changes

    Args:
        state: Extraction state to populate with schema and type counts
    """
    assert state is not None, "state parameter is required"
    config = state.config
    assert config is not None

    logger.info("[Schema Evolution] Evolving schema (checking for new types)...")

    with capture_embedding_usage(lambda usage: _accumulate_embedding_usage(state, usage)):
        new_schema, new_entity_types, new_rel_types = await evolve_schema(
            state.existing_schema,
            state.entities,
            state.relationships,
            state.domain,
            config,
            state.error_collector,
        )
    state.ontology_schema = new_schema
    state.new_entity_types += new_entity_types
    state.new_relationship_types += new_rel_types

    if state.new_entity_types > 0 or state.new_relationship_types > 0:
        logger.info(
            f"[Schema Evolution] Schema evolved: {state.new_entity_types} new entity types, "
            f"{state.new_relationship_types} new relationship types (version {state.ontology_schema.version})"
        )
    else:
        logger.info(
            f"[Schema Evolution] Schema unchanged (version {state.ontology_schema.version})"
        )

    # Save state checkpoint after schema evolution
    # Save state checkpoint after schema evolution
    _save_state_checkpoint(state, "schema")


async def infer_upper_ontology(state: ExtractionState) -> None:
    """
    Infer upper ontology hierarchy for all extracted concept types.

    This stage runs after schema evolution. It collects the full vocabulary of
    concept_types from the evolved schema, calls an LLM with the
    UPPER_ONTOLOGY_INFERENCE_PROMPT to assign each type to an abstract parent,
    and applies the resulting hierarchy map to the schema.

    This introduces upper ontology anchors (Agent, Place, PolicyConstruct, etc.)
    and intermediate grouping classes (Requirement, Document, etc.) that are
    absent from source text but required for a well-formed multi-level ontology.

    Args:
        state: Extraction state with evolved ontology schema
    """
    assert state is not None, "state parameter is required"
    config = state.config
    assert config is not None

    if state.ontology_schema is None:
        logger.warning("[Upper Ontology] No schema available, skipping upper ontology inference")
        return

    scaffold_updates, scaffold_types = apply_structural_upper_ontology_scaffold(
        state.ontology_schema, config
    )
    if scaffold_updates > 0 or scaffold_types:
        logger.info(
            f"[Upper Ontology] Deterministic scaffold applied: {scaffold_updates} links, "
            f"{len(scaffold_types)} new abstract types"
        )

    if not getattr(config, "upper_ontology_enabled", False):
        logger.info("[Upper Ontology] Skipping LLM refinement (upper_ontology_enabled is False)")
        return

    concept_types = [
        ct
        for ct in state.ontology_schema.entity_types
        if ct
        != (config.schema_evolution.core_entity_type.name if config.schema_evolution else "entity")
    ]
    if not concept_types:
        logger.info("[Upper Ontology] No entity types in schema, skipping")
        return

    logger.info(
        f"[Upper Ontology] Inferring upper ontology hierarchy for {len(concept_types)} concept types..."
    )

    concept_list = "\n".join(f"- {ct}" for ct in sorted(concept_types))
    prompt = UPPER_ONTOLOGY_INFERENCE_PROMPT.format(concept_types=concept_list)
    if state.domain_prompt:
        prompt = "\n\n".join(
            [
                prompt,
                "## Domain Guidance",
                state.domain_prompt.strip(),
                (
                    "Respect the domain-specific modelling commitments above when they can be "
                    "satisfied using only the provided concept types."
                ),
            ]
        )

    model = _get_model_instance(config)
    agent: Agent[None, str] = Agent(model, output_type=str)

    try:
        result = await agent.run(prompt)
        raw_response = getattr(result, "output", None)
        if raw_response is None:
            raw_response = getattr(result, "data", None)
        if raw_response is None:
            raise AttributeError("AgentRunResult has neither 'output' nor 'data'")
        state.llm_calls += 1
        usage = get_or_estimate_llm_result_usage(result, prompt, config)
        if usage:
            _accumulate_usage(state, [usage])
    except Exception as e:
        logger.warning(f"[Upper Ontology] LLM call failed: {e}")
        return

    hierarchy_map: dict[str, str] = {}
    try:
        hierarchy_map = _extract_first_json_object(raw_response)
        if not isinstance(hierarchy_map, dict):
            logger.warning("[Upper Ontology] LLM returned non-dict response, skipping")
            return
    except json.JSONDecodeError as e:
        logger.warning(f"[Upper Ontology] Failed to parse LLM response as JSON: {e}")
        logger.debug(f"[Upper Ontology] Raw LLM response: {raw_response[:500]}")
        return

    # Filter map to only string->string entries
    hierarchy_map = {
        k: v for k, v in hierarchy_map.items() if isinstance(k, str) and isinstance(v, str)
    }
    logger.info(f"[Upper Ontology] Received hierarchy map with {len(hierarchy_map)} entries")

    updated_count, new_abstract_types = apply_upper_ontology_map(
        state.ontology_schema, hierarchy_map, config
    )

    if updated_count > 0 or new_abstract_types:
        logger.info(f"[Upper Ontology] Hierarchy applied: {updated_count} parent_type links set")
        _save_state_checkpoint(state, "upper_ontology")
    else:
        logger.info("[Upper Ontology] No hierarchy changes applied")


def resolve_conflicting_relationships(state: ExtractionState) -> None:
    """
    Resolve conflicting relationships based on configured strategy.

    Handles cases where multiple relationships of the same type exist between
    the same entities. Resolution strategies include:
    - Keep most recent (based on timestamp)
    - Keep highest confidence
    - Merge properties from both

    Only runs if conflict_resolution.enabled is true in config.

    Args:
        state: Extraction state with relationships to potentially resolve
    """
    assert state is not None, "state parameter is required"
    config = state.config
    assert config is not None

    if not config.conflict_resolution.enabled or not state.relationships:
        return

    existing_rels = state.existing_graph.relationships if state.existing_graph else None

    state.relationships, detected_conflicts = resolve_relationship_conflicts(
        state.relationships,
        config,
        existing_rels,
    )

    if detected_conflicts:
        logger.info(
            f"[Conflict Resolution] Resolved {len(detected_conflicts)} relationship conflicts"
        )
        for rel1, rel2, conflict_type in detected_conflicts:
            logger.debug(
                f"⚠️  Resolved {conflict_type} conflict: {rel1.from_} {rel1.type} {rel1.to} vs {rel2.from_} {rel2.type} {rel2.to}"
            )
            collect_error_if_enabled(
                state.error_collector,
                config,
                "warning",
                "conflicts_resolved",
                f"Resolved {conflict_type} conflict: {rel1.from_} {rel1.type} {rel1.to} vs {rel2.from_} {rel2.type} {rel2.to}",
            )

    # Enforce relationship limits
    # Enforce relationship limits
    if (
        config.limits.max_relationships is not None
        and len(state.relationships) > config.limits.max_relationships
    ):
        raise ValueError(
            f"Created {len(state.relationships)} relationships, exceeds limit of {config.limits.max_relationships}."
        )


def _ensure_quota_governor(state: ExtractionState) -> None:
    config = state.config
    assert config is not None
    if state.bedrock_quota_governor is not None:
        return
    if not _is_bedrock_routing_enabled(config):
        return
    gcfg = config.llm.bedrock_quota_governor
    state.bedrock_quota_governor = BedrockQuotaGovernor(
        RuntimeGovernorConfig(
            enabled=gcfg.enabled,
            requests_per_minute=gcfg.requests_per_minute,
            tokens_per_minute=gcfg.tokens_per_minute,
            max_concurrency=gcfg.max_concurrency,
            window_seconds=gcfg.window_seconds,
            jitter_min_seconds=gcfg.jitter_min_seconds,
            jitter_max_seconds=gcfg.jitter_max_seconds,
        )
    )
