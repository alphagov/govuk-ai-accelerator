from __future__ import annotations

import asyncio
import contextlib
from dataclasses import dataclass
from typing import Any, Awaitable, Callable

from taxonomy_ontology_accelerator.ontology_engine.core.per_file_state import (
    create_per_file_state,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.runtime_context import (
    reset_runtime_context,
    set_runtime_context,
)

@dataclass
class FileWorkerResult:
    file_path: str
    success: bool
    result: Any | None = None
    error: str | None = None

async def process_files_parallel(
    file_paths: list[str],
    process_fn: Callable[[str, Any], Awaitable[Any]],
    shared_config: Any,
    checkpoint_manager: Any,
    max_workers: int = 1,
) -> list[FileWorkerResult]:
    effective_workers = 1
    if shared_config is not None:
        effective_workers = max(1, int(getattr(shared_config, "parallel_files", 1)))
    effective_workers = max(1, min(int(max_workers), effective_workers))
    semaphore = asyncio.Semaphore(effective_workers)

    async def process_one(file_path: str, worker_index: int) -> FileWorkerResult:
        if checkpoint_manager.is_file_completed(file_path):
            return FileWorkerResult(file_path=file_path, success=True)

        state = create_per_file_state(file_path, shared_config)
        worker_tag = f"W{worker_index:02d}"
        async with semaphore:
            runtime_tokens = set_runtime_context(worker_tag, file_path)
            try:
                result = await process_fn(file_path, state)
                checkpoint_manager.mark_file_completed(file_path)
                return FileWorkerResult(file_path=file_path, success=True, result=result)
            except Exception as exc:                
                with contextlib.suppress(Exception):
                    checkpoint_manager.mark_file_failed(file_path)
                return FileWorkerResult(
                    file_path=file_path,
                    success=False,
                    error=str(exc),
                )
            finally:
                reset_runtime_context(runtime_tokens)

    tasks = [process_one(file_path, index) for index, file_path in enumerate(file_paths, start=1)]
    results = await asyncio.gather(*tasks)
    return list(results)
