from taxonomy_ontology_accelerator.ontology_engine.config.config import OntologyConfig
from taxonomy_ontology_accelerator.ontology_engine.core.extraction_pipeline import ExtractionState


def create_per_file_state(file_path: str, shared_config: OntologyConfig) -> ExtractionState:
    state = ExtractionState(
        domain=shared_config.domain_name or "unknown",
        incremental=shared_config.features.incremental_updates,
    )
    state.config = shared_config
    state.source_file_path = file_path
    return state
