"""Batch request builder for AWS Bedrock Batch Inference JSONL payloads.

Constructs properly formatted request payloads from pipeline chunks.
Each request gets a unique ``recordId`` and uses
``get_cacheable_system_prompt()`` from cache_utils for system messages.

Includes dry-run validation logic via ``validate_request_shape()``.
"""

import json
import uuid
from typing import Any

from taxonomy_ontology_accelerator.ontology_engine.core.cache_utils import (
    get_cacheable_system_prompt,
)

                                                                             
           
                                                                             

DEFAULT_MAX_TOKENS: int = 8192
"""Default max_tokens when config does not specify one."""

CHARS_PER_TOKEN_ESTIMATE: float = 4.0
"""Approximate characters per token for English text."""

OVERSIZED_TOKEN_THRESHOLD: int = 200_000
"""Chunks estimated above this token count are flagged for separate batch."""

BEDROCK_ANTHROPIC_VERSION: str = "bedrock-2023-05-31"
"""Required anthropic_version header for Bedrock Batch Inference."""

                                                                             
                  
                                                                             

def _extract_max_tokens(config: Any) -> int:
    """Extract max_tokens from config with a safe fallback.

    Tries ``config.llm.max_tokens`` first, then falls back to
    ``DEFAULT_MAX_TOKENS``.

    Args:
        config: Configuration object (may be ``None``).

    Returns:
        Positive integer max_tokens value.
    """
    assert isinstance(DEFAULT_MAX_TOKENS, int), "DEFAULT_MAX_TOKENS must be int"
    try:
        if config is not None and hasattr(config, "llm"):
            llm_cfg = config.llm
            if hasattr(llm_cfg, "max_tokens") and llm_cfg.max_tokens is not None:
                max_tokens = int(llm_cfg.max_tokens)
                if max_tokens > 0:
                    return max_tokens
    except (AttributeError, TypeError, ValueError):
        pass
    return DEFAULT_MAX_TOKENS

def _extract_system_prompt_text(config: Any) -> str:
    """Extract plain-text system prompt from the cacheable system prompt.

    ``get_cacheable_system_prompt`` returns::

        [{"role": "system", "content": [{"type": "text", "text": "...", "cache_control": {...}}]}]

    Bedrock expects ``modelInput.system`` as a plain string, so we strip the
    ``cache_control`` metadata and return just the text content.

    Args:
        config: Passed through to ``get_cacheable_system_prompt``.

    Returns:
        Plain text system prompt string.
    """
    system_prompt = get_cacheable_system_prompt(config)
    assert isinstance(system_prompt, list), "system_prompt must be a list"

    if system_prompt and isinstance(system_prompt[0], dict):
        content = system_prompt[0].get("content", [])
        if isinstance(content, list) and content:
            first_block = content[0]
            if isinstance(first_block, dict) and "text" in first_block:
                return first_block["text"]
    return ""

def _estimate_tokens(text: str) -> int:
    """Estimate token count for *text* using a simple character ratio.

    Args:
        text: Input text string.

    Returns:
        Estimated token count (always >= 0).
    """
    assert text is not None, "text must not be None"
    return max(0, int(len(text) / CHARS_PER_TOKEN_ESTIMATE))

def _is_oversized(chunk: str) -> bool:
    """Return ``True`` if *chunk* exceeds the oversized token threshold."""
    assert chunk is not None, "chunk must not be None"
    return _estimate_tokens(chunk) > OVERSIZED_TOKEN_THRESHOLD

def _generate_record_id() -> str:
    """Generate a unique ``recordId`` with the ``rec-`` prefix."""
    return f"rec-{uuid.uuid4()}"

                                                                             
            
                                                                             

def build_batch_requests(
    chunks: list[str],
    config: Any,
    model: str,
) -> list[dict[str, Any]]:
    """Build Bedrock Batch Inference request payloads from pipeline chunks.

    Each chunk is wrapped into a single request with a unique ``recordId``,
    the system prompt sourced from ``get_cacheable_system_prompt(config)``
    as a plain text string, and a user message containing the chunk text.

    Chunks estimated to exceed 200 000 tokens are flagged with
    ``_oversized: True`` in the returned dict for downstream handling.

    Note:
        The ``model`` parameter is accepted for interface compatibility but
        is NOT included in ``modelInput`` — Bedrock sets the model at the
        job level, not per-record.

    Args:
        chunks: List of text chunks from the extraction pipeline.
        config: Configuration object passed to ``get_cacheable_system_prompt``.
                May be ``None`` (uses default prompts).
        model: Model identifier (used for interface compatibility; not
               included in modelInput as Bedrock sets model at job level).

    Returns:
        List of request dicts in Bedrock Batch Inference format::

            {
                "recordId": "rec-<uuid4>",
                "modelInput": {
                    "anthropic_version": "bedrock-2023-05-31",
                    "max_tokens": <int>,
                    "system": "<plain text system prompt>",
                    "messages": [{"role": "user", "content": "<chunk>"}]
                }
            }
    """
    assert isinstance(chunks, list), "chunks must be a list"
    assert isinstance(model, str) and model, "model must be a non-empty string"

    if not chunks:
        return []

    max_tokens = _extract_max_tokens(config)
    system_text = _extract_system_prompt_text(config)

    requests: list[dict[str, Any]] = []
    for chunk in chunks:
        request: dict[str, Any] = {
            "recordId": _generate_record_id(),
            "modelInput": {
                "anthropic_version": BEDROCK_ANTHROPIC_VERSION,
                "max_tokens": max_tokens,
                "system": system_text,
                "messages": [
                    {"role": "user", "content": chunk},
                ],
            },
        }
        if _is_oversized(chunk):
            request["_oversized"] = True
        requests.append(request)

    return requests

def build_jsonl_string(requests: list[dict[str, Any]]) -> str:
    """Serialize a list of batch request dicts to a JSONL string.

    Each request dict is serialised as a single JSON line. Lines are
    separated by newline characters (``\\n``).

    Args:
        requests: List of Bedrock Batch Inference request dicts.

    Returns:
        A JSONL-formatted string (one JSON object per line).
    """
    assert isinstance(requests, list), "requests must be a list"
    return "\n".join(json.dumps(req) for req in requests)

def validate_request_shape(request: dict[str, Any]) -> bool:
    """Validate that *request* has the required shape for Bedrock Batch Inference.

    Checks:
    - Has ``recordId`` (str)
    - Has ``modelInput`` (dict)
    - ``modelInput.anthropic_version`` exists (str)
    - ``modelInput.messages`` exists and is a non-empty list

    Args:
        request: A single batch request dict.

    Returns:
        ``True`` if the request is structurally valid, ``False`` otherwise.
    """
    assert isinstance(request, dict), "request must be a dict"

    if "recordId" not in request:
        return False
    if not isinstance(request.get("recordId"), str):
        return False

    model_input = request.get("modelInput")
    if not isinstance(model_input, dict):
        return False

    if "anthropic_version" not in model_input or not isinstance(
        model_input["anthropic_version"], str
    ):
        return False

    messages = model_input.get("messages")
    if not isinstance(messages, list) or len(messages) == 0:
        return False

    return True
