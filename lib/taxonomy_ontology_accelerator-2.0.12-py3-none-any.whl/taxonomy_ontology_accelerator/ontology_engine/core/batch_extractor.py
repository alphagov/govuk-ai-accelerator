"""
Batch extraction processing for ontology extraction.
"""

import asyncio
import time
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any, cast

from pydantic_ai import Agent, AgentRunResult
from pydantic_ai.exceptions import UnexpectedModelBehavior
from pydantic_ai.usage import RunUsage

from taxonomy_ontology_accelerator.commons.errors import ErrorCollector
from taxonomy_ontology_accelerator.commons.utils.logger import get_logger
from taxonomy_ontology_accelerator.ontology_engine.config.config import OntologyConfig
from taxonomy_ontology_accelerator.ontology_engine.core.models import (
    ExtractedConcept,
    ExtractedRelationship,
    ExtractionResult,
)
from taxonomy_ontology_accelerator.ontology_engine.storage.cache import (
    cache_response,
    get_cached_response,
)
from taxonomy_ontology_accelerator.ontology_engine.storage.prompt_loader import PromptLoader
from taxonomy_ontology_accelerator.ontology_engine.utils.error_helpers import (
    collect_error_if_enabled,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.llm_usage import (
    get_or_estimate_llm_result_usage,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.math_utils import (
    safe_divide,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.timing import format_time_interval
from taxonomy_ontology_accelerator.ontology_engine.utils.validation import (
    estimate_tokens,
    validate_batch_size,
)

logger = get_logger()

BatchContextProvider = Callable[[list[str], list[str] | None], str | None]

# ========================================================================
# Constants
# ========================================================================

# Thresholds for progress logging intervals
LARGE_BATCH_THRESHOLD = 50  # Log every 10 batches for large jobs
BATCH_DATA_MIN_ELEMENTS = 5  # Minimum elements in batch data tuple
MEDIUM_BATCH_THRESHOLD = 20  # Log every 5 batches for medium jobs


# ========================================================================
# Helper Functions
# ========================================================================


def _calculate_progress_interval(total_chunks: int) -> int:
    """
    Calculate progress logging interval based on total chunks.

    Args:
        total_chunks: Total number of chunks to process

    Returns:
        Progress interval (log every N batches)
    """
    assert isinstance(total_chunks, int), "total_chunks must be an integer"
    assert total_chunks >= 0, "total_chunks must be non-negative"
    if total_chunks > LARGE_BATCH_THRESHOLD:
        return 10
    if total_chunks > MEDIUM_BATCH_THRESHOLD:
        return 5
    return 1


def _estimate_total_batches(chunks: int, initial_batch_size: int) -> int:
    """
    Estimate total number of batches for progress tracking.

    Args:
        chunks: Total number of chunks
        initial_batch_size: Initial batch size

    Returns:
        Estimated total batches
    """
    assert isinstance(chunks, int), "chunks must be an integer"
    assert isinstance(initial_batch_size, int), "initial_batch_size must be an integer"
    return max(1, chunks // initial_batch_size + 1)


# ========================================================================
# Single Batch Processing Helper Functions
# ========================================================================


@dataclass
class BatchPreparationContext:
    """Context for preparing batches."""

    available_tokens: int | None
    chars_per_token: float
    chunk_separator: str
    initial_batch_size: int
    batching_config: Any
    chunk_sources: list[str] | None
    config: OntologyConfig
    error_collector: ErrorCollector
    update_file_completion: Callable | None
    source_file_path: str | None
    batch_context: str | None = None
    batch_context_provider: BatchContextProvider | None = None


@dataclass
class BatchContext:
    """
    Context object for single batch processing.

    Encapsulates all parameters needed for batch processing to reduce
    function argument count and improve maintainability.
    """

    batch_num: int
    batch_chunks: list[str]
    prompt: str
    extraction_agent: Agent[None, ExtractionResult]
    config: OntologyConfig
    error_collector: ErrorCollector
    source_file_path: str | None = None
    update_file_completion: Callable | None = None
    chunk_start_idx: int = 0
    batch_chunk_sources: list[str] | None = None

    @property
    def batch_size(self) -> int:
        """Return number of chunks in this batch."""
        assert self.batch_chunks is not None, "batch_chunks must be initialized"
        assert isinstance(self.batch_chunks, list), "batch_chunks must be a list"
        return len(self.batch_chunks)


@dataclass
class BatchProcessingInput:
    """Input parameters for batch processing."""

    chunks: list[str]
    generic_prompt: str
    domain_prompt: str | None
    extraction_agent: Agent[None, ExtractionResult]
    config: OntologyConfig
    error_collector: ErrorCollector
    source_file_path: str | None = None
    update_file_completion: Callable | None = None
    chunk_sources: list[str] | None = None
    batch_context: str | None = None
    batch_context_provider: BatchContextProvider | None = None


def _check_response_cache(prompt: str, batch_num: int, config: OntologyConfig):
    """
    Check if a cached LLM response exists for the prompt.

    Args:
        prompt: The LLM prompt to check
        batch_num: Current batch number for logging
        config: Ontology configuration

    Returns:
        Cached result if found, None otherwise
    """
    assert prompt is not None, "prompt parameter is required"
    assert config is not None, "config parameter is required"
    if not config.performance.llm_cache_enabled:
        return None

    cached_result = get_cached_response(prompt)
    if cached_result is not None:
        logger.cache(f"Cache hit for batch {batch_num} - skipping LLM call")
    return cached_result


def _compute_backoff_delay(attempt: int, config: OntologyConfig) -> float | None:
    """Compute backoff delay for a transient LLM error, or None to stop retrying."""
    import random

    assert attempt >= 0, "attempt must be non-negative"
    assert config is not None, "config is required"

    retry_cfg = config.llm.retry_strategy
    if not retry_cfg.enabled or attempt >= config.llm.retries:
        return None

    if retry_cfg.strategy_type == "constant":
        delay = retry_cfg.initial_delay
    elif retry_cfg.strategy_type == "linear":
        delay = retry_cfg.initial_delay + (attempt * retry_cfg.backoff_multiplier)
    else:
        delay = retry_cfg.initial_delay * (retry_cfg.backoff_multiplier**attempt)

    delay = min(delay, retry_cfg.max_delay)
    if retry_cfg.jitter:
        delay = max(0.0, delay + random.uniform(-delay * 0.2, delay * 0.2))

    return delay


def _is_transient_error(error: BaseException) -> bool:
    """Check if an error is transient and worth retrying with backoff."""
    assert error is not None, "error is required"
    assert isinstance(error, BaseException), "error must be a BaseException"
    error_type = type(error).__name__.lower()
    error_msg = str(error).lower()
    return (
        isinstance(error, TimeoutError | ConnectionError)
        or "rate" in error_type
        or "429" in error_msg
        or "timeout" in error_msg
        or "connection" in error_msg
    )


async def _execute_extraction_call(ctx: BatchContext):
    """
    Execute the LLM extraction call with backoff for transient errors.

    Args:
        ctx: Batch context containing all parameters

    Returns:
        Tuple of (result, llm_calls_count, usage)

    Raises:
        TimeoutError, ConnectionError: On network errors after retries exhausted
        ValueError: On max errors exceeded
        Exception: On non-transient LLM errors
    """
    assert ctx is not None, "ctx parameter is required"
    assert ctx.extraction_agent is not None, "extraction_agent must be set"
    if ctx.config.logging.log_llm_calls:
        logger.llm(f"LLM call batch {ctx.batch_num} | {ctx.batch_size} chunk(s)")

    max_attempts = ctx.config.llm.retries + 1
    for attempt in range(max_attempts):
        try:
            result = await ctx.extraction_agent.run(ctx.prompt)
            if ctx.config.performance.llm_cache_enabled:
                cache_response(
                    ctx.prompt,
                    result,
                    max_cache_size_mb=ctx.config.performance.max_cache_size_mb,
                )
            return result, 1, get_or_estimate_llm_result_usage(result, ctx.prompt, ctx.config)
        except (KeyboardInterrupt, SystemExit, ValueError):
            raise
        except BaseException as e:
            if not _is_transient_error(e):
                raise
            delay = _compute_backoff_delay(attempt, ctx.config)
            if delay is None:
                raise
            logger.warning(
                f"Batch {ctx.batch_num}: transient error (attempt {attempt + 1}), "
                f"retrying in {delay:.1f}s — {e}"
            )
            await asyncio.sleep(delay)

    raise RuntimeError(f"Batch {ctx.batch_num}: all {max_attempts} attempts exhausted")


def _record_batch_failure(ctx: BatchContext, chunk_failures: list[int]) -> None:
    """
    Record batch failure by marking all chunks as failed.

    Args:
        ctx: Batch context containing file tracking info
        chunk_failures: List to append failed chunk indices to
    """
    assert ctx is not None, "ctx parameter is required"
    assert chunk_failures is not None, "chunk_failures parameter is required"
    if ctx.update_file_completion:
        for i, chunk_idx in enumerate(
            range(ctx.chunk_start_idx, ctx.chunk_start_idx + ctx.batch_size)
        ):
            # Use actual source file for this chunk if available
            source_file = (
                ctx.batch_chunk_sources[i]
                if ctx.batch_chunk_sources and i < len(ctx.batch_chunk_sources)
                else ctx.source_file_path
            )
            if source_file:
                ctx.update_file_completion(source_file, success=False)
            chunk_failures.append(chunk_idx)


def _handle_batch_error(
    ctx: BatchContext,
    error: BaseException,
    error_message: str,
    chunk_failures: list[int],
) -> tuple[list[ExtractedConcept], list[ExtractedRelationship], int, list[int]]:
    """
    Handle batch processing error.

    Args:
        ctx: Batch context
        error: The exception that occurred
        error_message: Error message for logging
        chunk_failures: List of failed chunk indices

    Returns:
        Empty results tuple

    Raises:
        ValueError: If check_max_errors raises
    """
    assert ctx is not None, "ctx parameter is required"
    assert error is not None, "error parameter is required"
    total_batches_est = _estimate_total_batches(
        ctx.chunk_start_idx + ctx.batch_size, ctx.batch_size
    )
    try:
        _handle_extraction_error(
            error,
            error_type="llm_error",
            message=error_message,
            batch_info=(ctx.batch_num, total_batches_est),
            config=ctx.config,
            error_collector=ctx.error_collector,
        )
    except ValueError:
        raise

    _record_batch_failure(ctx, chunk_failures)
    return [], [], 0, chunk_failures


def _validate_extraction_result(
    result: AgentRunResult[ExtractionResult],
    ctx: BatchContext,
    chunk_failures: list[int],
) -> tuple[bool, tuple[list[ExtractedConcept], list[ExtractedRelationship], int, list[int]] | None]:
    """
    Validate LLM result structure.

    Args:
        result: The LLM result to validate
        ctx: Batch context
        chunk_failures: List of failed chunk indices

    Returns:
        Tuple of (is_valid, error_response)
        - is_valid: True if result is valid
        - error_response: None if valid, else tuple of empty results
    """
    assert ctx is not None, "ctx parameter is required"
    assert chunk_failures is not None, "chunk_failures parameter is required"
    if result is None or not hasattr(result, "output") or result.output is None:
        total_batches_est = _estimate_total_batches(
            ctx.chunk_start_idx + ctx.batch_size, ctx.batch_size
        )
        error_msg = (
            f"LLM returned invalid result structure for batch {ctx.batch_num}: missing output"
        )
        _handle_extraction_error(
            ValueError("missing output"),
            error_type="llm_error",
            message=error_msg,
            batch_info=(ctx.batch_num, total_batches_est),
            config=ctx.config,
            error_collector=ctx.error_collector,
        )
        _record_batch_failure(ctx, chunk_failures)
        return False, ([], [], 0, chunk_failures)

    return True, None


def _apply_source_grounding(
    concepts: list[ExtractedConcept],
    relationships: list[ExtractedRelationship],
    ctx: BatchContext,
) -> tuple[list[ExtractedConcept], list[ExtractedRelationship]]:
    """
    Apply source grounding to extracted concepts and relationships.

    Args:
        concepts: Extracted concepts
        relationships: Extracted relationships
        ctx: Batch context containing source grounding settings

    Returns:
        Tuple of (grounded_concepts, grounded_relationships)
    """
    assert concepts is not None, "concepts parameter is required"
    assert ctx is not None, "ctx parameter is required"
    if not ctx.config.source_grounding.enabled:
        return concepts, relationships

    grounded_concepts = _apply_source_grounding_to_concepts(
        concepts,
        ctx.batch_chunk_sources,
        ctx.batch_chunks,
        ctx.config,
        ctx.chunk_start_idx,
    )
    grounded_relationships = _apply_source_grounding_to_relationships(
        relationships,
        ctx.batch_chunk_sources,
        ctx.batch_chunks,
        ctx.config,
        ctx.chunk_start_idx,
    )
    return grounded_concepts, grounded_relationships


def _record_batch_success(ctx: BatchContext) -> None:
    """
    Record batch success by marking all chunks as completed.

    Args:
        ctx: Batch context containing file tracking info
    """
    assert ctx is not None, "ctx parameter is required"
    assert hasattr(ctx, "source_file_path"), "ctx must have source_file_path attribute"
    if ctx.update_file_completion:
        for i in range(ctx.batch_size):
            # Use actual source file for this chunk if available
            source_file = (
                ctx.batch_chunk_sources[i]
                if ctx.batch_chunk_sources and i < len(ctx.batch_chunk_sources)
                else ctx.source_file_path
            )
            if source_file:
                ctx.update_file_completion(source_file, success=True)


async def _fetch_batch_result(ctx: BatchContext, chunk_failures: list[int]):
    """Fetch batch result from cache or execute LLM call, with structured error handling.

    Returns (result, llm_calls, usage) where llm_calls==-1 signals a handled error
    and result is an error tuple in that case.
    Re-raises critical exceptions: KeyboardInterrupt, SystemExit, ValueError,
    UnexpectedModelBehavior (e.g. output validator retries exhausted).
    """
    assert ctx is not None, "ctx parameter is required"
    assert ctx.prompt is not None, "ctx.prompt must be set"

    result = _check_response_cache(ctx.prompt, ctx.batch_num, ctx.config)
    if result is not None:
        return result, 0, None

    try:
        return await _execute_extraction_call(ctx)
    except (TimeoutError, ConnectionError) as e:
        return (
            _handle_batch_error(
                ctx, e, f"LLM API error for batch {ctx.batch_num}: {e}", chunk_failures
            ),
            -1,
            None,
        )
    except (KeyboardInterrupt, SystemExit, ValueError):
        raise
    except UnexpectedModelBehavior as e:
        if ctx.config.error_handling.continue_on_error:
            logger.warning(
                f"Batch {ctx.batch_num}: LLM output validation failed after retries "
                f"(continue_on_error=True, skipping batch) — {e}"
            )
            return (
                _handle_batch_error(
                    ctx,
                    e,
                    f"LLM output validation exhausted for batch {ctx.batch_num}: {e}",
                    chunk_failures,
                ),
                -1,
                None,
            )
        raise
    except Exception as e:
        return (
            _handle_batch_error(
                ctx, e, f"LLM extraction failed for batch {ctx.batch_num}: {e}", chunk_failures
            ),
            -1,
            None,
        )


async def _process_single_batch(
    ctx: BatchContext,
) -> tuple[list[ExtractedConcept], list[ExtractedRelationship], int, list[int], RunUsage | None]:
    """Process a single batch through LLM extraction. Returns (concepts, rels, calls, failures, usage)."""
    assert ctx is not None, "ctx parameter is required"
    assert ctx.prompt is not None, "ctx.prompt must be set"

    chunk_failures: list[int] = []
    result, llm_calls, usage = await _fetch_batch_result(ctx, chunk_failures)

    if llm_calls == -1:  # Error occurred - result is error tuple
        # Cast is safe: when llm_calls == -1, _fetch_batch_result returns error tuple
        error_tuple = cast(
            "tuple[list[ExtractedConcept], list[ExtractedRelationship], int, list[int]]", result
        )
        return (*error_tuple, None)

    # At this point, result is AgentRunResult[ExtractionResult]
    llm_result = cast("AgentRunResult[ExtractionResult]", result)
    is_valid, error_response = _validate_extraction_result(llm_result, ctx, chunk_failures)
    if not is_valid:
        # error_response is guaranteed to be the error tuple when is_valid is False
        error_tuple = cast(
            "tuple[list[ExtractedConcept], list[ExtractedRelationship], int, list[int]]",
            error_response,
        )
        return (*error_tuple, None)

    concepts, relationships = _apply_source_grounding(
        llm_result.output.concepts, llm_result.output.relationships, ctx
    )
    _record_batch_success(ctx)

    return list(concepts), list(relationships), llm_calls, chunk_failures, usage


# ========================================================================
# Source Grounding Helpers
# ========================================================================


def _normalize_source_id(source_id: str, config: OntologyConfig, fallback_idx: int) -> str:
    """Normalize source identifier."""
    assert config is not None, "config parameter is required"
    assert isinstance(fallback_idx, int), "fallback_idx must be an integer"
    if not source_id or not isinstance(source_id, str):
        return f"{config.source_grounding.fallback_source_prefix}_{fallback_idx}"
    source_id = source_id.strip()
    if not source_id:
        return f"{config.source_grounding.fallback_source_prefix}_{fallback_idx}"
    if (
        config.source_grounding.validate_source_format
        and len(source_id) > config.source_grounding.max_source_length
    ):
        source_id = source_id[: config.source_grounding.max_source_length]
    return source_id


def _extract_source_from_output(
    entity_or_rel: ExtractedConcept | ExtractedRelationship,
    config: OntologyConfig,
) -> str | None:
    """Extract source from LLM output (from SOURCE_URLS lines in prompt)."""
    assert entity_or_rel is not None, "entity_or_rel parameter is required"
    assert config is not None, "config parameter is required"
    source_prop_name = config.source_grounding.source_property_name
    llm_source = (
        entity_or_rel.properties.get(source_prop_name) if entity_or_rel.properties else None
    )

    if llm_source:
        if isinstance(llm_source, str) and llm_source.strip():
            normalized = _normalize_source_id(llm_source, config, 0)
            # Update properties with normalized value for consistency
            if entity_or_rel.properties is not None:
                entity_or_rel.properties[source_prop_name] = normalized
            return normalized
        if isinstance(llm_source, list) and llm_source:
            source_str = ", ".join(str(s).strip() for s in llm_source if s and str(s).strip())
            if source_str:
                normalized = _normalize_source_id(source_str, config, 0)
                if entity_or_rel.properties is not None:
                    entity_or_rel.properties[source_prop_name] = normalized
                return normalized

    return None


def _apply_source_to_item(
    item: ExtractedConcept | ExtractedRelationship,
    batch_chunk_sources: list[str] | None,
    config: OntologyConfig,
    chunk_start_idx: int,
) -> None:
    """Apply source grounding to entity/relationship."""
    assert item is not None, "item parameter is required"
    assert config is not None, "config parameter is required"
    if not config.source_grounding.enabled:
        return

    source_prop_name = config.source_grounding.source_property_name

    # Try to extract source from LLM output first (LLM should extract from SOURCE_URLS lines)
    source = _extract_source_from_output(item, config)

    # Always ensure a source is set (100% guarantee)
    if source:
        # LLM extracted source is already normalized, use it directly
        item.properties[source_prop_name] = source
    else:
        # Fallback: merge all unique sources from batch or use synthetic ID
        if batch_chunk_sources:
            # Normalize first, then deduplicate (handles trailing spaces, etc.)
            normalized_sources = [
                _normalize_source_id(s, config, chunk_start_idx)
                for s in batch_chunk_sources
                if s is not None
            ]
            # Filter out empty strings and deduplicate
            unique_normalized = [s for s in set(normalized_sources) if s and s.strip()]
            fallback = ", ".join(unique_normalized) if unique_normalized else None
        else:
            fallback = None

        if not fallback or not fallback.strip():
            fallback = f"{config.source_grounding.fallback_source_prefix}_{chunk_start_idx}"

        item.properties[source_prop_name] = fallback


def _apply_source_grounding_to_concepts(
    concepts: list[ExtractedConcept],
    batch_chunk_sources: list[str] | None,
    _batch_chunks: list[str],  # Reserved for future use
    config: OntologyConfig,
    chunk_start_idx: int,
) -> list[ExtractedConcept]:
    """Apply source grounding to extracted concepts."""
    assert concepts is not None, "concepts parameter is required"
    assert config is not None, "config parameter is required"
    if not config.source_grounding.enabled or not concepts:
        return concepts

    for concept in concepts:
        _apply_source_to_item(concept, batch_chunk_sources, config, chunk_start_idx)
    return concepts


def _apply_source_grounding_to_relationships(
    relationships: list[ExtractedRelationship],
    batch_chunk_sources: list[str] | None,
    _batch_chunks: list[str],  # Reserved for future use
    config: OntologyConfig,
    chunk_start_idx: int,
) -> list[ExtractedRelationship]:
    """Apply source grounding to extracted relationships."""
    assert relationships is not None, "relationships parameter is required"
    assert config is not None, "config parameter is required"
    if not config.source_grounding.enabled or not relationships:
        return relationships

    for rel in relationships:
        _apply_source_to_item(rel, batch_chunk_sources, config, chunk_start_idx)
    return relationships


# ========================================================================
# Error Handling
# ========================================================================


def _handle_extraction_error(
    error: BaseException,
    error_type: str,
    message: str,
    batch_info: tuple[int, int],  # (batch_num, total_batches)
    config: OntologyConfig,
    error_collector: ErrorCollector,
) -> None:
    """
    Handle LLM processing errors with consistent error collection and logging.

    Args:
        error: The exception that occurred
        error_type: Type identifier for error categorization
        message: Human-readable error message
        batch_info: Tuple of (batch_num, total_batches) for context
        config: Configuration for error handling settings
        error_collector: Error collector instance

    Raises:
        ValueError: If max error limit reached or continue_on_error is False
    """
    assert error is not None, "error parameter is required"
    assert config is not None, "config parameter is required"
    batch_num, total_batches = batch_info
    severity = "error"

    if isinstance(error, TimeoutError | ConnectionError):
        logger.error(f"Batch {batch_num}/{total_batches}: LLM API error (network/timeout): {error}")
    else:
        logger.error(f"Batch {batch_num}/{total_batches}: {message}")

    collect_error_if_enabled(
        error_collector,
        config,
        severity,
        error_type,
        message,
    )

    if not config.error_handling.continue_on_error:
        raise error


# ========================================================================
# Batch Processing Helper Functions
# ========================================================================


def _validate_and_normalize_sources(
    chunks: list[str],
    chunk_sources: list[str] | None,
    config: OntologyConfig,
) -> list[str] | None:
    """
    Validate and normalize source tracking for chunks.

    Args:
        chunks: List of text chunks
        chunk_sources: Optional list of source identifiers
        config: Ontology configuration

    Returns:
        Normalized chunk sources or None if source grounding is disabled
    """
    assert chunks is not None, "chunks parameter is required"
    assert config is not None, "config parameter is required"
    if not config.source_grounding.enabled:
        return None

    if chunk_sources is None:
        return [f"{config.source_grounding.fallback_source_prefix}_{i}" for i in range(len(chunks))]

    if len(chunk_sources) != len(chunks):
        if len(chunk_sources) < len(chunks):
            last_source = (
                chunk_sources[-1]
                if chunk_sources
                else f"{config.source_grounding.fallback_source_prefix}_0"
            )
            chunk_sources = [*chunk_sources, *([last_source] * (len(chunks) - len(chunk_sources)))]
        else:
            chunk_sources = chunk_sources[: len(chunks)]

    return [_normalize_source_id(s, config, i) for i, s in enumerate(chunk_sources)]


def _filter_empty_chunks(
    chunks: list[str],
    chunk_sources: list[str] | None,
    config: OntologyConfig,
) -> tuple[list[str], list[str] | None]:
    """
    Filter out empty chunks and adjust source tracking.

    Args:
        chunks: List of text chunks
        chunk_sources: Normalized chunk sources
        config: Ontology configuration

    Returns:
        Tuple of (valid_chunks, adjusted_sources)
    """
    assert chunks is not None, "chunks parameter is required"
    assert config is not None, "config parameter is required"
    valid_chunks = [chunk for chunk in chunks if chunk and chunk.strip()]

    if not config.source_grounding.enabled or not chunk_sources:
        return valid_chunks, chunk_sources

    valid_indices = [i for i, chunk in enumerate(chunks) if chunk and chunk.strip()]
    adjusted_sources = [
        chunk_sources[i]
        if i < len(chunk_sources)
        else f"{config.source_grounding.fallback_source_prefix}_{i}"
        for i in valid_indices
    ]
    return valid_chunks, adjusted_sources


def _calculate_prompt_overhead(
    context_text: str | None,
    chars_per_token: float,
) -> tuple[int, int, int]:
    """
    Calculate dynamic user-prompt overhead.

    Args:
        context_text: Optional dynamic prompt context
        chars_per_token: Characters per token estimate

    Returns:
        Tuple of (prompt_overhead, wrapper_tokens, context_tokens)
    """
    assert isinstance(chars_per_token, float | int), "chars_per_token must be numeric"
    context_tokens = 0
    if context_text and context_text.strip():
        context_tokens = estimate_tokens(context_text, chars_per_token)

    prompt_shell = PromptLoader.build_prompt(
        generic_prompt="",
        input_text="",
        include_instructions=False,
        context_text=context_text,
    )
    prompt_overhead = estimate_tokens(prompt_shell, chars_per_token)
    wrapper_tokens = max(0, prompt_overhead - context_tokens)
    return prompt_overhead, wrapper_tokens, context_tokens


def _combine_batch_context(*sections: str | None) -> str | None:
    """Combine dynamic batch context sections for the user prompt."""
    context_sections = [section.strip() for section in sections if section and section.strip()]
    if not context_sections:
        return None
    return "\n\n".join(context_sections)


def _build_provider_batch_context(
    provider: BatchContextProvider | None,
    batch_chunks: list[str],
    batch_sources: list[str] | None,
) -> str | None:
    if provider is None:
        return None
    return provider(batch_chunks, batch_sources)


def _resolve_batch_input_token_budget(config: OntologyConfig) -> int | None:
    """Resolve the input token budget used for batching."""
    assert config is not None, "config parameter is required"

    if config.batching.max_input_tokens is not None:
        return config.batching.max_input_tokens

    model_name = str(config.llm.model).lower()
    if "claude" in model_name:
        if config.llm.bedrock_enable_context_1m_beta:
            return 120_000
        return 32_000
    if "gemini" in model_name:
        return 64_000
    return None


def _get_batch_sources(
    chunk_sources: list[str] | None,
    batch_start: int,
    batch_size: int,
    batch_chunks: list[str],
    config: OntologyConfig,
) -> list[str] | None:
    """
    Get sources for chunks in a batch.

    Args:
        chunk_sources: Full list of chunk sources
        batch_start: Starting index for batch
        batch_size: Size of batch
        batch_chunks: Actual batch chunks
        config: Ontology configuration

    Returns:
        Batch chunk sources or None
    """
    assert batch_chunks is not None, "batch_chunks parameter is required"
    assert config is not None, "config parameter is required"
    if not config.source_grounding.enabled or not chunk_sources:
        return None

    batch_chunk_sources = chunk_sources[batch_start : batch_start + batch_size]

    if len(batch_chunk_sources) != len(batch_chunks):
        if len(batch_chunk_sources) < len(batch_chunks):
            last_source = (
                batch_chunk_sources[-1]
                if batch_chunk_sources
                else f"{config.source_grounding.fallback_source_prefix}_0"
            )
            batch_chunk_sources = [
                *batch_chunk_sources,
                *([last_source] * (len(batch_chunks) - len(batch_chunk_sources))),
            ]
        else:
            batch_chunk_sources = batch_chunk_sources[: len(batch_chunks)]

    return batch_chunk_sources


def _mark_chunks_failed(
    update_file_completion,
    source_file_path: str | None,
    chunk_start: int,
    chunk_end: int,
    chunk_failures: list[int],
    chunk_sources: list[str] | None = None,
) -> None:
    """
    Mark a range of chunks as failed.

    Args:
        update_file_completion: Callback function
        source_file_path: Source file path (fallback)
        chunk_start: Starting chunk index
        chunk_end: Ending chunk index (exclusive)
        chunk_failures: List to append failures to
        chunk_sources: Optional list of source files for each chunk
    """
    assert isinstance(chunk_start, int), "chunk_start must be an integer"
    assert chunk_failures is not None, "chunk_failures parameter is required"
    if update_file_completion:
        for chunk_idx in range(chunk_start, chunk_end):
            # Use actual source file for this chunk if available
            source_file = (
                chunk_sources[chunk_idx]
                if chunk_sources and chunk_idx < len(chunk_sources)
                else source_file_path
            )
            if source_file:
                update_file_completion(source_file, success=False)
            chunk_failures.append(chunk_idx)


def _truncate_text_at_boundary(text: str, max_len: int, min_ratio: float = 0.8) -> str:
    """Truncate text at a natural boundary (sentence, paragraph, or word)."""
    assert text is not None, "text parameter is required"
    assert max_len > 0, "max_len must be positive"

    if len(text) <= max_len:
        return text

    truncated = text[:max_len]
    for boundary in ["\n\n", "\n", ". ", ".\n", " "]:
        last_pos = truncated.rfind(boundary)
        if last_pos > max_len * min_ratio:
            return truncated[: last_pos + len(boundary)]
    return truncated


def _truncate_oversized_chunk(
    chunk: str, tokens: int, chars_per_token: float, batch_num: int
) -> str:
    """Truncate a single chunk that exceeds token limit."""
    assert chunk is not None, "chunk parameter is required"
    assert tokens > 0, "tokens must be positive"

    chunk_tokens = estimate_tokens(chunk, chars_per_token)
    if chunk_tokens <= tokens:
        return chunk

    max_chars = int(tokens * chars_per_token * 0.8)
    logger.warning(
        f"Batch {batch_num}: Single chunk ({chunk_tokens} tokens) exceeds limit "
        f"({tokens} tokens). Truncating to {max_chars:,} chars."
    )
    return _truncate_text_at_boundary(chunk, max_chars)


def _greedily_fill_batch(
    chunks: list[str],
    chunk_idx: int,
    end_index: int,
    tokens: int,
    chars_per_token: float,
    chunk_separator: str,
) -> list[str]:
    """Greedily add chunks to batch until token limit is reached."""
    assert chunks is not None, "chunks parameter is required"
    assert end_index >= chunk_idx, "end_index must be >= chunk_idx"

    batch_chunks: list[str] = []
    for j in range(chunk_idx, end_index):
        test_batch = [*batch_chunks, chunks[j]]
        test_text = chunk_separator.join(test_batch)
        if estimate_tokens(test_text, chars_per_token) <= tokens:
            batch_chunks = test_batch
        else:
            break
    return batch_chunks


def _optimize_and_validate_batch(
    batch_num: int, chunks: list[str], chunk_idx: int, ctx: dict
) -> tuple[list[str], str, int] | None:
    """Optimize batch size and validate batch text. Returns None on failure."""
    assert chunks is not None, "chunks parameter is required"
    assert ctx is not None, "ctx parameter is required"

    tokens = ctx["available_tokens"] if ctx["available_tokens"] is not None else 1_000_000
    max_batch_size = ctx["initial_batch_size"]
    chars_per_token = ctx["chars_per_token"]
    chunk_separator = ctx["chunk_separator"]

    end_index = min(chunk_idx + max_batch_size, len(chunks)) if max_batch_size else len(chunks)
    batch_chunks = _greedily_fill_batch(
        chunks, chunk_idx, end_index, tokens, chars_per_token, chunk_separator
    )

    # If no chunks fit, take single chunk with truncation
    if not batch_chunks and chunk_idx < len(chunks):
        truncated = _truncate_oversized_chunk(chunks[chunk_idx], tokens, chars_per_token, batch_num)
        batch_chunks = [truncated]

    if not batch_chunks:
        return None

    batch_text = chunk_separator.join(batch_chunks)

    # Enforce batch text length limit by removing trailing chunks first
    max_length = ctx["batching_config"].max_batch_text_length
    if max_length is not None and len(batch_text) > max_length:
        original_count = len(batch_chunks)
        # Remove trailing chunks until batch fits
        while len(batch_chunks) > 1:
            batch_chunks.pop()
            batch_text = chunk_separator.join(batch_chunks)
            if len(batch_text) <= max_length:
                break
        # If single chunk still exceeds, truncate it as last resort
        if len(batch_text) > max_length:
            batch_text = _truncate_text_at_boundary(batch_text, max_length)
        logger.warning(
            f"Batch {batch_num}: Batch text exceeded max_batch_text_length "
            f"({max_length:,} chars). Reduced from {original_count} to {len(batch_chunks)} chunks."
        )

    if not batch_text or not batch_text.strip():
        return None

    return batch_chunks, batch_text, len(batch_chunks)


def _build_batch_prompt(
    batch_num: int,
    batch_text: str,
    batch_chunks: list[str],
    batch_sources: list[str] | None,
    ctx: dict[str, Any],
    total_chunks: int,
) -> str | None:
    """Build prompt for batch. Returns None on failure."""
    assert batch_text is not None, "batch_text parameter is required"
    assert ctx is not None, "ctx parameter is required"

    config = ctx["config"]
    provider_context = _build_provider_batch_context(
        ctx.get("batch_context_provider"),
        batch_chunks,
        batch_sources,
    )
    batch_context = _combine_batch_context(ctx.get("batch_context"), provider_context)
    try:
        return PromptLoader.build_prompt(
            generic_prompt="",
            input_text=batch_text,
            chunk_sources=batch_sources if config.source_grounding.enabled else None,
            batch_chunks=batch_chunks if config.source_grounding.enabled else None,
            source_grounding_enabled=config.source_grounding.enabled,
            include_instructions=False,
            context_text=batch_context,
        )
    except ValueError as e:
        total_batches_est = _estimate_total_batches(total_chunks, ctx["initial_batch_size"])
        _handle_extraction_error(
            e,
            error_type="config_error",
            message=f"Failed to build prompt: {e}",
            batch_info=(batch_num, total_batches_est),
            config=config,
            error_collector=ctx["error_collector"],
        )
        return None


def _create_batch_entry(
    batch_num: int, chunks: list[str], chunk_idx: int, ctx: dict
) -> tuple[tuple | None, int]:
    """Create a single batch entry."""
    assert chunks is not None, "chunks parameter is required"
    assert ctx is not None, "ctx parameter is required"

    result = _optimize_and_validate_batch(batch_num, chunks, chunk_idx, ctx)
    if result is None:
        if chunk_idx >= len(chunks):
            return None, len(chunks)
        _mark_chunks_failed(
            ctx["update_file_completion"],
            ctx["source_file_path"],
            chunk_idx,
            len(chunks),
            ctx["chunk_failures"],
            ctx.get("chunk_sources"),
        )
        return None, len(chunks)

    batch_chunks, batch_text, current_batch_size = result
    batch_sources = _get_batch_sources(
        ctx["chunk_sources"], chunk_idx, current_batch_size, batch_chunks, ctx["config"]
    )
    prompt = _build_batch_prompt(
        batch_num, batch_text, batch_chunks, batch_sources, ctx, len(chunks)
    )

    if prompt is None:
        _mark_chunks_failed(
            ctx["update_file_completion"],
            ctx["source_file_path"],
            chunk_idx,
            chunk_idx + current_batch_size,
            ctx["chunk_failures"],
            ctx.get("chunk_sources"),
        )
        return None, chunk_idx + current_batch_size

    return (
        batch_num,
        batch_chunks,
        prompt,
        chunk_idx,
        batch_sources,
    ), chunk_idx + current_batch_size


def _handle_batch_exception(
    result: BaseException,
    batch_num: int,
    config: OntologyConfig,
    first_exception: BaseException | None,
) -> BaseException | None:
    """Handle exception from batch processing."""
    assert result is not None, "result parameter is required"
    assert config is not None, "config parameter is required"

    if isinstance(result, KeyboardInterrupt | SystemExit):
        raise result
    if isinstance(result, ValueError):
        raise result
    if isinstance(result, UnexpectedModelBehavior) and not config.error_handling.continue_on_error:
        raise result

    if not config.error_handling.continue_on_error and first_exception is None:
        first_exception = result

    logger.error(f"Batch {batch_num} failed with exception: {result}", exc_info=result)
    return first_exception


def _mark_failed_chunks(
    batch_idx: int,
    batches: list[tuple],
    update_file_completion,
    chunk_sources: list[str] | None,
    source_file_path: str | None,
    chunk_failures: list[int],
) -> None:
    """Mark chunks as failed in file completion tracking."""
    assert batches is not None, "batches parameter is required"
    assert chunk_failures is not None, "chunk_failures parameter is required"

    if not update_file_completion:
        return

    chunk_start_idx = batches[batch_idx][3]
    batch_size = len(batches[batch_idx][1])
    for chunk_idx in range(chunk_start_idx, chunk_start_idx + batch_size):
        source_file = (
            chunk_sources[chunk_idx]
            if chunk_sources and chunk_idx < len(chunk_sources)
            else source_file_path
        )
        if source_file:
            update_file_completion(source_file, success=False)
        chunk_failures.append(chunk_idx)


def _process_successful_batch_result(
    result: tuple,
    all_concepts: list[ExtractedConcept],
    all_relationships: list[ExtractedRelationship],
    usages: list[RunUsage],
) -> tuple[int, list[int]]:
    """Process successful batch result and update accumulators."""
    assert result is not None, "result parameter is required"
    assert all_concepts is not None, "all_concepts parameter is required"
    batch_concepts, batch_relationships, batch_llm_calls, batch_failures, batch_usage = result
    all_concepts.extend(batch_concepts)
    all_relationships.extend(batch_relationships)
    if batch_usage:
        usages.append(batch_usage)
    return batch_llm_calls, batch_failures


def _aggregate_batch_results(
    results: list,
    batches: list[tuple],
    config: OntologyConfig,
    update_file_completion,
    source_file_path: str | None,
    chunk_sources: list[str] | None = None,
) -> tuple[
    list[ExtractedConcept],
    list[ExtractedRelationship],
    int,
    list[int],
    BaseException | None,
    list[RunUsage],
]:
    """Aggregate results from parallel batch processing."""
    assert results is not None, "results parameter is required"
    assert config is not None, "config parameter is required"
    all_concepts: list[ExtractedConcept] = []
    all_relationships: list[ExtractedRelationship] = []
    llm_calls = 0
    chunk_failures: list[int] = []
    first_exception: BaseException | None = None
    usages: list[RunUsage] = []

    for idx, result in enumerate(results):
        if isinstance(result, BaseException):
            batch_num = batches[idx][0]
            first_exception = _handle_batch_exception(result, batch_num, config, first_exception)
            _mark_failed_chunks(
                idx,
                batches,
                update_file_completion,
                chunk_sources,
                source_file_path,
                chunk_failures,
            )
            continue

        batch_llm_calls, batch_failures = _process_successful_batch_result(
            result, all_concepts, all_relationships, usages
        )
        llm_calls += batch_llm_calls
        chunk_failures.extend(batch_failures)

    return all_concepts, all_relationships, llm_calls, chunk_failures, first_exception, usages


def _log_batch_completion(
    batches: list[tuple],
    all_concepts: list[ExtractedConcept],
    all_relationships: list[ExtractedRelationship],
    llm_calls: int,
    batch_start_time: float,
    total_chunks: int,
) -> None:
    """
    Log batch processing completion statistics.

    Args:
        batches: List of processed batches
        all_concepts: All extracted concepts
        all_relationships: All extracted relationships
        llm_calls: Total LLM calls made
        batch_start_time: Start time of batch processing
        total_chunks: Total number of chunks
    """
    assert batches is not None, "batches parameter is required"
    assert isinstance(llm_calls, int), "llm_calls must be an integer"
    _calculate_progress_interval(total_chunks)

    if len(batches) > 0:
        elapsed = time.time() - batch_start_time
        rate = safe_divide(len(batches), elapsed)
        elapsed_str = format_time_interval(elapsed)

        logger.complete(
            f"Completed {len(batches)} batches (100%)",
            f"Extracted: {len(all_concepts)} concepts, {len(all_relationships)} relationships",
        )
        logger.stats(f"LLM calls: {llm_calls} | Time: {elapsed_str} | Rate: {rate:.2f} batches/sec")

    total_batch_time = time.time() - batch_start_time
    logger.complete(
        f"LLM extraction complete in {total_batch_time:.1f}s",
        f"{len(all_concepts)} concepts, {len(all_relationships)} relationships from {llm_calls} LLM call(s)",
    )


# ========================================================================
# Batch Processing
# ========================================================================


def _prepare_all_batches(
    chunks: list[str],
    ctx: BatchPreparationContext,
) -> tuple[list[tuple[int, list[str], str, int, list[str] | None]], list[int]]:
    """
    Prepare all batches for processing.

    Returns:
        Tuple of (batches, chunk_failures)
    """
    assert chunks is not None, "chunks parameter is required"
    assert ctx is not None, "ctx parameter is required"
    batches: list[tuple[int, list[str], str, int, list[str] | None]] = []
    chunk_failures: list[int] = []
    batch_ctx = {
        "available_tokens": ctx.available_tokens,
        "chars_per_token": ctx.chars_per_token,
        "chunk_separator": ctx.chunk_separator,
        "initial_batch_size": ctx.initial_batch_size,
        "batching_config": ctx.batching_config,
        "chunk_sources": ctx.chunk_sources,
        "batch_context": ctx.batch_context,
        "batch_context_provider": ctx.batch_context_provider,
        "config": ctx.config,
        "error_collector": ctx.error_collector,
        "chunk_failures": chunk_failures,
        "update_file_completion": ctx.update_file_completion,
        "source_file_path": ctx.source_file_path,
    }
    i = 0
    batch_num = 0

    while i < len(chunks):
        batch_num += 1
        batch_entry, i = _create_batch_entry(batch_num, chunks, i, batch_ctx)
        if batch_entry:
            batches.append(batch_entry)

    return batches, chunk_failures


def _setup_batch_processing(batch_input: BatchProcessingInput):
    """Setup batch processing configuration and validate inputs."""
    assert batch_input is not None, "batch_input parameter is required"
    assert batch_input.config is not None, "batch_input.config must be set"

    config = batch_input.config
    chunks = batch_input.chunks
    chunk_sources = _validate_and_normalize_sources(chunks, batch_input.chunk_sources, config)
    chunks, chunk_sources = _filter_empty_chunks(chunks, chunk_sources, config)

    chars_per_token = config.text_processing.chunking.chars_per_token_estimate
    if chars_per_token <= 0:
        raise ValueError(f"chars_per_token ({chars_per_token}) must be positive")

    dynamic_context = _combine_batch_context(batch_input.batch_context)
    prompt_overhead, wrapper_tokens, context_tokens = _calculate_prompt_overhead(
        dynamic_context, chars_per_token
    )

    max_input_tokens = _resolve_batch_input_token_budget(config)
    if max_input_tokens is None:
        available_tokens = None
    else:
        available_tokens = max_input_tokens - prompt_overhead
        if available_tokens <= 0:
            raise ValueError(
                "dynamic prompt overhead exceeds configured batch input budget "
                f"({prompt_overhead} >= {max_input_tokens})"
            )

    logger.info(
        "[LLM Prompt Budget] "
        f"Estimated dynamic context tokens: {context_tokens:,} | "
        f"Prompt wrapper tokens: {wrapper_tokens:,} | "
        f"Available batch text tokens: "
        f"{available_tokens if available_tokens is not None else 'unbounded'}"
    )

    # Use configured batch size (no provider-specific optimization needed)
    optimal_batch_size = config.batching.chunks_per_batch
    initial_batch_size = validate_batch_size(
        optimal_batch_size, config.batching.min_batch_size, None, config
    )

    return chunks, chunk_sources, available_tokens, chars_per_token, initial_batch_size


def _handle_batch_setup_error(
    batch_input: BatchProcessingInput,
    error: Exception,
) -> tuple[list[ExtractedConcept], list[ExtractedRelationship], int, list[int], list[RunUsage]]:
    """Handle setup errors before concrete batch contexts exist."""
    config = batch_input.config
    _handle_extraction_error(
        error,
        error_type="llm_error",
        message=f"LLM extraction setup failed: {error}",
        batch_info=(1, 1),
        config=config,
        error_collector=batch_input.error_collector,
    )

    chunk_failures: list[int] = []
    for chunk_idx, _chunk in enumerate(batch_input.chunks):
        source_file = (
            batch_input.chunk_sources[chunk_idx]
            if batch_input.chunk_sources and chunk_idx < len(batch_input.chunk_sources)
            else batch_input.source_file_path
        )
        if batch_input.update_file_completion and source_file:
            batch_input.update_file_completion(source_file, success=False)
        chunk_failures.append(chunk_idx)

    return [], [], 0, chunk_failures, []


def _create_batch_prep_context(
    batch_input: BatchProcessingInput,
    available_tokens: int | None,
    chars_per_token: float,
    initial_batch_size: int,
    chunk_sources: list[str] | None,
) -> BatchPreparationContext:
    """Create batch preparation context."""
    assert batch_input is not None, "batch_input parameter is required"
    assert batch_input.config is not None, "batch_input.config must be set"
    return BatchPreparationContext(
        available_tokens=available_tokens,
        chars_per_token=chars_per_token,
        chunk_separator=batch_input.config.batching.chunk_separator,
        initial_batch_size=initial_batch_size,
        batching_config=batch_input.config.batching,
        chunk_sources=chunk_sources,
        config=batch_input.config,
        error_collector=batch_input.error_collector,
        update_file_completion=batch_input.update_file_completion,
        source_file_path=batch_input.source_file_path,
        batch_context=batch_input.batch_context,
        batch_context_provider=batch_input.batch_context_provider,
    )


async def _process_batch_groups(
    batches: list[tuple],
    run_batch,
    max_parallel_batches: int,
    on_group_complete,
    batch_input: BatchProcessingInput,
    config: OntologyConfig,
) -> list:
    """Process batches in groups with optional callback after each group."""
    assert batches is not None, "batches parameter is required"
    assert max_parallel_batches > 0, "max_parallel_batches must be positive"

    logger.debug(f"Processing {len(batches)} batches in groups of {max_parallel_batches}")
    all_results = []
    num_groups = (len(batches) + max_parallel_batches - 1) // max_parallel_batches

    for i in range(0, len(batches), max_parallel_batches):
        batch_group = batches[i : i + max_parallel_batches]
        group_num = i // max_parallel_batches + 1
        is_final_group = i + max_parallel_batches >= len(batches)

        logger.info(
            f"Processing batch group {group_num}/{num_groups} "
            f"(batches {i + 1}-{i + len(batch_group)} of {len(batches)})"
        )
        logger.debug(
            f"Processing batch group {group_num}/{num_groups}: "
            f"batches {i + 1}-{i + len(batch_group)} of {len(batches)}"
        )
        group_results = await asyncio.gather(
            *[run_batch(b) for b in batch_group], return_exceptions=True
        )
        all_results.extend(group_results)

        if on_group_complete is not None:
            group_concepts, group_rels, _group_calls, _group_fail, group_exc, _group_usage = (
                _aggregate_batch_results(
                    group_results,
                    batch_group,
                    config,
                    None,  # _process_single_batch already fired update_file_completion
                    batch_input.source_file_path,
                    batch_input.chunk_sources,
                )
            )
            if group_exc:
                raise group_exc
            await on_group_complete(
                group_num, num_groups, is_final_group, group_concepts, group_rels
            )

    return all_results


def _create_batch_runner(batch_input: BatchProcessingInput, config: OntologyConfig, sem):
    """Create batch runner function with semaphore."""
    assert batch_input is not None, "batch_input parameter is required"
    assert config is not None, "config parameter is required"

    async def run_batch(bd):
        assert bd is not None, "batch data parameter is required"
        assert len(bd) >= BATCH_DATA_MIN_ELEMENTS, "batch data must have required elements"
        async with sem:
            return await _process_single_batch(
                BatchContext(
                    batch_num=bd[0],
                    batch_chunks=bd[1],
                    prompt=bd[2],
                    extraction_agent=batch_input.extraction_agent,
                    config=config,
                    error_collector=batch_input.error_collector,
                    source_file_path=batch_input.source_file_path,
                    update_file_completion=batch_input.update_file_completion,
                    chunk_start_idx=bd[3],
                    batch_chunk_sources=bd[4],
                )
            )

    return run_batch


async def _execute_batches(
    batches: list[tuple],
    run_batch,
    max_parallel_batches: int | None,
    on_group_complete,
    batch_input: BatchProcessingInput,
    config: OntologyConfig,
) -> list:
    """Execute batches either in groups or all at once."""
    assert batches is not None, "batches parameter is required"
    assert run_batch is not None, "run_batch parameter is required"

    if max_parallel_batches is not None and max_parallel_batches > 0:
        return await _process_batch_groups(
            batches, run_batch, max_parallel_batches, on_group_complete, batch_input, config
        )
    return await asyncio.gather(*[run_batch(b) for b in batches], return_exceptions=True)


async def process_batches(
    batch_input: BatchProcessingInput,
    max_parallel_batches: int | None = None,
    on_group_complete: Any = None,  # pyright: ignore[reportExplicitAny]
) -> tuple[list[ExtractedConcept], list[ExtractedRelationship], int, list[int], list[RunUsage]]:
    """
    Process text chunks in batches through LLM extraction.

    Args:
        batch_input: Input configuration for batch processing
        max_parallel_batches: Maximum number of batches to run in parallel.
                             If None, runs all batches in parallel (old behavior).
                             If set, processes batches in groups of this size.
        on_group_complete: Optional async callback called after each batch group.
                          Signature: async def callback(group_num, total_groups, is_final, concepts, relationships)

    Returns:
        Tuple of (concepts, relationships, llm_calls, chunk_failures, usages)
    """
    assert batch_input is not None, "batch_input parameter is required"
    assert batch_input.chunks is not None, "batch_input.chunks must be set"

    if not batch_input.chunks:
        return [], [], 0, [], []

    try:
        chunks, chunk_sources, avail_tokens, chars_per_tok, init_batch_size = _setup_batch_processing(
            batch_input
        )
    except ValueError as e:
        if (
            not batch_input.config.error_handling.continue_on_error
            or batch_input.update_file_completion is None
        ):
            raise
        return _handle_batch_setup_error(batch_input, e)
    if not chunks:
        return [], [], 0, [], []

    config, start_time = batch_input.config, time.time()
    max_conc = min(10, max(5, len(chunks) // init_batch_size // 10 + 1))
    logger.debug(f"Processing {len(chunks)} chunks | Batch size: {init_batch_size}")
    prep_ctx = _create_batch_prep_context(
        batch_input, avail_tokens, chars_per_tok, init_batch_size, chunk_sources
    )
    batches, chunk_failures = _prepare_all_batches(chunks, prep_ctx)
    sem = asyncio.Semaphore(max_conc)

    run_batch = _create_batch_runner(batch_input, config, sem)
    results = await _execute_batches(
        batches, run_batch, max_parallel_batches, on_group_complete, batch_input, config
    )

    concepts, rels, calls, agg_fail, exc, usages = _aggregate_batch_results(
        results,
        batches,
        config,
        batch_input.update_file_completion if on_group_complete is None else None,
        batch_input.source_file_path,
        batch_input.chunk_sources,
    )
    chunk_failures.extend(agg_fail)
    if exc:
        raise exc
    _log_batch_completion(batches, concepts, rels, calls, start_time, len(chunks))
    return concepts, rels, calls, chunk_failures, usages
