"""
Ontology Engine - Main Module

This module provides the main entry point for ontology extraction.
All public APIs are re-exported here for backward compatibility.
"""

# Main entry point
# Configuration
from taxonomy_ontology_accelerator.ontology_engine.config.config import (
    OntologyConfig,
    OntologyConfigLoader,
)
from taxonomy_ontology_accelerator.ontology_engine.core.extractor import extract_ontology

# Core models (commonly used)
from taxonomy_ontology_accelerator.ontology_engine.core.models import (
    Entity,
    EntityTypeDefinition,
    ExtractedConcept,
    ExtractedRelationship,
    ExtractionResult,
    OntologyGraph,
    OntologyOutput,
    OntologySchema,
    ProcessingMetadata,
    Relationship,
    RelationshipTypeDefinition,
)

# Processing utilities
from taxonomy_ontology_accelerator.ontology_engine.processing.conflict_resolution import (
    detect_contradictory_relationships,
    resolve_conflict,
    resolve_relationship_conflicts,
)
from taxonomy_ontology_accelerator.ontology_engine.processing.embeddings import (
    cosine_similarity,
    find_semantic_duplicates,
    generate_embedding,
    generate_embeddings_batch,
    load_embeddings,
    save_embeddings,
)
from taxonomy_ontology_accelerator.ontology_engine.processing.entity_processor import (
    normalize_and_deduplicate_entities,
)
from taxonomy_ontology_accelerator.ontology_engine.processing.relationship_builder import (
    build_relationships,
)
from taxonomy_ontology_accelerator.ontology_engine.processing.schema_evolver import evolve_schema
from taxonomy_ontology_accelerator.ontology_engine.processing.text_processor import chunk_texts
from taxonomy_ontology_accelerator.ontology_engine.processing.type_similarity import (
    check_type_similarity_before_creation,
    find_similar_type,
)
from taxonomy_ontology_accelerator.ontology_engine.processing.validation import validate_ontology

# Storage utilities
from taxonomy_ontology_accelerator.ontology_engine.storage.cache import (
    cache_llm_response,
    get_cached_llm_response,
)
from taxonomy_ontology_accelerator.ontology_engine.storage.data_loader import (
    ExistingData,
    load_existing_data,
)
from taxonomy_ontology_accelerator.ontology_engine.storage.export import (
    export_to_owl_rdf,
    export_to_owl_rdf_from_files,
)
from taxonomy_ontology_accelerator.ontology_engine.storage.file_locking import FileLock
from taxonomy_ontology_accelerator.ontology_engine.storage.prompt_loader import PromptLoader

# Utilities
from taxonomy_ontology_accelerator.ontology_engine.utils.file_loading import (
    ensure_output_directory,
    load_input_file,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.id_generation import (
    generate_entity_id,
    generate_relationship_id,
    get_current_timestamp,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.text_normalization import (
    generate_canonical_key,
    normalize_input_texts,
    normalize_text,
    normalize_text_with_hash,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.validation import (
    estimate_tokens,
    validate_and_merge_chunks,
    validate_batch_size,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.versioning import increment_schema_version

# Validators
from taxonomy_ontology_accelerator.ontology_engine.validators import (
    EntityCountValidator,
    OWLConsistencyValidator,
    OWLPropertyConstraintValidator,
    SchemaConsistencyValidator,
    StageValidator,
    ValidationResult,
)

__all__ = [
    # Core models
    "Entity",
    "EntityCountValidator",
    "EntityTypeDefinition",
    "ExistingData",
    "ExtractedConcept",
    "ExtractedRelationship",
    "ExtractionResult",
    "FileLock",
    # Configuration
    "OWLConsistencyValidator",
    "OWLPropertyConstraintValidator",
    "OntologyConfig",
    "OntologyConfigLoader",
    "OntologyGraph",
    "OntologyOutput",
    "OntologySchema",
    "ProcessingMetadata",
    "PromptLoader",
    "Relationship",
    "RelationshipTypeDefinition",
    "SchemaConsistencyValidator",
    "StageValidator",
    "ValidationResult",
    "build_relationships",
    # Storage
    "cache_llm_response",
    "check_type_similarity_before_creation",
    "chunk_texts",
    "cosine_similarity",
    "detect_contradictory_relationships",
    # Utilities
    "ensure_output_directory",
    "estimate_tokens",
    "evolve_schema",
    "export_to_owl_rdf",
    "export_to_owl_rdf_from_files",
    # Main entry point
    "extract_ontology",
    "find_semantic_duplicates",
    "find_similar_type",
    "generate_canonical_key",
    "generate_embedding",
    "generate_embeddings_batch",
    "generate_entity_id",
    "generate_relationship_id",
    "get_cached_llm_response",
    "get_current_timestamp",
    "increment_schema_version",
    "load_embeddings",
    "load_existing_data",
    "load_input_file",
    "normalize_and_deduplicate_entities",
    "normalize_input_texts",
    "normalize_text",
    "normalize_text_with_hash",
    "resolve_conflict",
    "resolve_relationship_conflicts",
    "save_embeddings",
    "validate_and_merge_chunks",
    "validate_batch_size",
    # Processing
    "validate_ontology",
]
