"""
Ontology testing utilities for readable assertions and validation.

API:
- validate() - Works everywhere (runtime, pipeline, tests) with simple and fluent APIs
"""

from taxonomy_ontology_accelerator.ontology_engine.testing.validation import (
    validate,
)

__all__ = [
    "validate",
]
