"""
Validation DSL - works across runtime, pipeline, and tests.

Two behaviors:
1. Tests: Assertions execute immediately and raise AssertionError
2. LLM retry mode: Call .or_retry() first, then assertions convert to ModelRetry

Same API, different failure handling based on usage.
"""

from typing import Any

from pydantic_ai.exceptions import ModelRetry

from taxonomy_ontology_accelerator.ontology_engine.core.models import (
    Entity,
    ExtractionResult,
    OntologyGraph,
    OntologyOutput,
    Relationship,
)


class EntityAssertion:
    """Fluent assertions for a single entity."""

    def __init__(self, entity: Entity | None, label: str, context: "ValidationContext"):
        assert context is not None, "Context must not be None"
        assert label, "Label must not be empty"

        self._entity = entity
        self._label = label
        self._context = context

    def exists(self) -> "EntityAssertion":
        """Assert entity exists."""
        assert self._entity is not None, f"Entity '{self._label}' does not exist"
        assert self._entity is not None, f"Entity should exist after check: {self._label}"

        return self

    def has_type(self, expected_type: str) -> "EntityAssertion":
        """Assert entity has specific type."""
        assert self._entity is not None, "Entity must exist before checking type"

        self.exists()
        actual = self._entity.type
        assert actual == expected_type, (
            f"Entity '{self._label}' has type '{actual}', expected '{expected_type}'"
        )
        return self

    def has_property(self, key: str, value: Any = None) -> "EntityAssertion":
        """Assert entity has property (optionally with specific value)."""
        assert self._entity is not None, "Entity must exist before checking property"

        self.exists()
        props = self._entity.properties

        if key not in props:
            available = ", ".join(props.keys()) if props else "none"
            msg = (
                f"Entity '{self._label}' missing property '{key}'. "
                f"Available properties: {available}"
            )
            raise AssertionError(msg)

        if value is not None:
            actual = props[key]
            assert actual == value, (
                f"Entity '{self._label}' property '{key}' is {actual!r}, expected {value!r}"
            )

        return self

    def has_alias(self, alias: str) -> "EntityAssertion":
        """Assert entity has specific alias."""
        assert self._entity is not None, "Entity must exist before checking alias"

        self.exists()
        assert alias in self._entity.aliases, (
            f"Entity '{self._label}' missing alias '{alias}'. Aliases: {self._entity.aliases}"
        )
        return self

    def has_confidence_above(self, threshold: float) -> "EntityAssertion":
        """Assert entity confidence is above threshold."""
        assert 0.0 <= threshold <= 1.0, "Threshold must be between 0 and 1"
        assert self._entity is not None, "Entity must exist before checking confidence"

        self.exists()
        confidence = self._entity.metadata.get("confidence", 0.0)
        assert confidence > threshold, (
            f"Entity '{self._label}' confidence {confidence} not above {threshold}"
        )
        return self


class RelationshipAssertion:
    """Fluent assertions for relationships (single or collection)."""

    def __init__(
        self,
        relationships: list[Relationship],
        context: "ValidationContext",
        description: str = "all",
    ):
        assert context is not None, "Context must not be None"
        assert relationships is not None, "Relationships must not be None"

        self._relationships = relationships
        self._context = context
        self._description = description

    def exists(self, from_label: str, rel_type: str, to_label: str) -> "RelationshipAssertion":
        """Assert specific relationship exists and return single-relationship assertion."""
        assert from_label, "From label must not be empty"
        assert to_label, "To label must not be empty"

        from_entity = self._context._find_entity_by_label(from_label)
        to_entity = self._context._find_entity_by_label(to_label)

        if from_entity is None:
            msg = f"Source entity '{from_label}' not found"
            raise AssertionError(msg)

        if to_entity is None:
            msg = f"Target entity '{to_label}' not found"
            raise AssertionError(msg)

        matching = [
            r
            for r in self._relationships
            if r.from_ == from_entity.id and r.to == to_entity.id and r.type == rel_type
        ]

        if not matching:
            msg = f"Relationship '{from_label}' -[{rel_type}]-> '{to_label}' not found"
            raise AssertionError(msg)

        # Return a single-relationship assertion
        return RelationshipAssertion(
            [matching[0]], self._context, f"{from_label}-[{rel_type}]->{to_label}"
        )

    def of_type(self, rel_type: str) -> "RelationshipAssertion":
        """Filter to relationships of specific type."""
        assert self._relationships is not None, "Relationships must not be None"
        assert rel_type, "Relationship type must not be empty"

        matching = [r for r in self._relationships if r.type == rel_type]
        return RelationshipAssertion(matching, self._context, f"of type '{rel_type}'")

    def from_type(self, entity_type: str) -> "RelationshipAssertion":
        """Filter to relationships from entities of specific type."""
        assert self._context._ontology_graph is not None, "Graph must be available"
        assert entity_type, "Entity type must not be empty"

        from_entities = {
            e.id for e in self._context._ontology_graph.entities if e.type == entity_type
        }
        matching = [r for r in self._relationships if r.from_ in from_entities]
        return RelationshipAssertion(matching, self._context, f"from {entity_type}")

    def to_type(self, entity_type: str) -> "RelationshipAssertion":
        """Filter to relationships to entities of specific type."""
        assert self._context._ontology_graph is not None, "Graph must be available"
        assert entity_type, "Entity type must not be empty"

        to_entities = {
            e.id for e in self._context._ontology_graph.entities if e.type == entity_type
        }
        matching = [r for r in self._relationships if r.to in to_entities]
        return RelationshipAssertion(matching, self._context, f"to {entity_type}")

    def has_property(self, key: str, value: Any = None) -> "RelationshipAssertion":
        """Assert relationship(s) have property (optionally with specific value)."""
        assert len(self._relationships) > 0, "Must have at least one relationship"

        # Only check the first relationship (for single-relationship assertions)
        rel = self._relationships[0]
        props = rel.properties

        if key not in props:
            available = ", ".join(props.keys()) if props else "none"
            msg = f"Relationship missing property '{key}'. Available properties: {available}"
            raise AssertionError(msg)

        if value is not None:
            actual = props[key]
            assert actual == value, (
                f"Relationship property '{key}' is {actual!r}, expected {value!r}"
            )

        return self

    def has_confidence_above(self, threshold: float) -> "RelationshipAssertion":
        """Assert relationship confidence is above threshold."""
        assert 0.0 <= threshold <= 1.0, "Threshold must be between 0 and 1"
        assert len(self._relationships) > 0, "Must have at least one relationship"

        # Only check the first relationship (for single-relationship assertions)
        rel = self._relationships[0]
        confidence = rel.metadata.get("confidence", 0.0)
        assert confidence > threshold, f"Relationship confidence {confidence} not above {threshold}"
        return self

    def count(self) -> int:
        """Get count of matching relationships."""
        assert self._relationships is not None, "Relationships must not be None"
        assert isinstance(self._relationships, list), "Relationships must be a list"
        return len(self._relationships)

    def has_count(self, expected: int) -> "RelationshipAssertion":
        """Assert collection has specific count."""
        assert self._relationships is not None, "Relationships must not be None"

        actual = len(self._relationships)
        assert actual == expected, (
            f"Relationships {self._description}: expected {expected}, found {actual}"
        )
        return self

    def has_at_least(self, minimum: int) -> "RelationshipAssertion":
        """Assert collection has at least N items."""
        assert self._relationships is not None, "Relationships must not be None"

        actual = len(self._relationships)
        assert actual >= minimum, (
            f"Relationships {self._description}: expected >={minimum}, found {actual}"
        )
        return self


class ValidationContext:
    """
    Validation that works in runtime and test contexts.

    Two behaviors:
    - Tests: Assertions execute immediately and raise AssertionError
    - LLM retry: Pass raise_model_retry=True to convert to ModelRetry
    """

    def __init__(
        self,
        data: ExtractionResult | OntologyGraph | OntologyOutput,
        raise_model_retry: bool = False,
    ):
        assert data is not None, "Data must not be None"
        assert isinstance(data, ExtractionResult | OntologyGraph | OntologyOutput), (
            f"Data must be ExtractionResult, OntologyGraph, or OntologyOutput, got {type(data)}"
        )

        self._raise_model_retry = raise_model_retry

        # Handle different input types
        if isinstance(data, ExtractionResult):
            self._extraction = data
            self._ontology_graph = None
        elif isinstance(data, OntologyOutput):
            self._extraction = None
            self._ontology_graph = data.graph
        elif isinstance(data, OntologyGraph):
            self._extraction = None
            self._ontology_graph = data
        else:
            msg = f"Unsupported data type: {type(data)}"
            raise TypeError(msg)

    def _raise_error(self, message: str) -> None:
        """Raise appropriate error based on mode."""
        assert message, "Message must not be empty"
        assert isinstance(self._raise_model_retry, bool), "Retry mode must be boolean"

        if self._raise_model_retry:
            raise ModelRetry(f"Validation failed: {message}")
        raise AssertionError(message)

    def entity(self, label: str) -> EntityAssertion:
        """Get assertions for specific entity by label (fluent API)."""
        assert label, "Label must not be empty"
        assert self._ontology_graph is not None, "Graph required for fluent API"

        if self._ontology_graph is None:
            msg = "Cannot use fluent API directly with ExtractionResult. Use require_* methods."
            raise NotImplementedError(msg)

        entity = self._find_entity_by_label(label)
        return EntityAssertion(entity, label, self)

    def entities(self, type: str | None = None) -> list[Entity]:
        """Get entities for iteration."""
        assert self._extraction is not None or self._ontology_graph is not None, (
            "Must have extraction or graph"
        )
        assert type is None or isinstance(type, str), "Type must be None or string"

        if self._extraction:
            if type:
                return [c for c in self._extraction.concepts if c.concept_type == type]
            return self._extraction.concepts

        if self._ontology_graph:
            if type:
                return [e for e in self._ontology_graph.entities if e.type == type]
            return self._ontology_graph.entities

        return []

    def entity_count(self, type: str | None = None) -> int:
        """Get entity count."""
        assert self._extraction is not None or self._ontology_graph is not None, (
            "Must have extraction or graph"
        )
        assert type is None or isinstance(type, str), "Type must be None or string"

        if self._extraction:
            if type:
                return len([c for c in self._extraction.concepts if c.concept_type == type])
            return len(self._extraction.concepts)

        if self._ontology_graph:
            if type:
                return len([e for e in self._ontology_graph.entities if e.type == type])
            return len(self._ontology_graph.entities)

        return 0

    def relationships(self) -> RelationshipAssertion:
        """Get relationship assertions (fluent API)."""
        assert self._ontology_graph is not None, "Graph must be available for fluent API"
        assert hasattr(self._ontology_graph, "relationships"), (
            "Graph must have relationships attribute"
        )

        if self._ontology_graph is None:
            msg = "Cannot use fluent API directly with ExtractionResult. Use require_* methods."
            raise NotImplementedError(msg)

        return RelationshipAssertion(self._ontology_graph.relationships, self)

    def require_entity_count(self, min_count: int, type: str | None = None):
        """Require minimum entity count - executes immediately."""
        assert min_count > 0, "Minimum count must be positive"
        assert self._extraction is not None or self._ontology_graph is not None, (
            "Must have data to validate"
        )

        actual = self.entity_count(type)
        type_str = f"of type '{type}'" if type else "total"
        if actual < min_count:
            self._raise_error(f"Expected at least {min_count} entities {type_str}, found {actual}")

        return self

    def require_entity(self, label: str, type: str | None = None):
        """Require specific entity exists - executes immediately."""
        assert self._extraction is not None or self._ontology_graph is not None, (
            "Must have data to validate"
        )
        assert label.strip() == label, "Label must not have leading/trailing whitespace"

        if self._extraction:
            # Check in extraction concepts
            found = None
            for concept in self._extraction.concepts:
                if concept.label.lower() == label.lower():
                    found = concept
                    break

            if found is None:
                self._raise_error(f"Entity '{label}' does not exist")
                return self  # unreachable, but helps type narrowing

            if type:
                actual_type = found.concept_type
                if actual_type != type:
                    self._raise_error(
                        f"Entity '{label}' has type '{actual_type}', expected '{type}'"
                    )
        else:
            entity = self.entity(label)
            entity.exists()
            if type:
                entity.has_type(type)

        return self

    def require_relationship(self, from_label: str, rel_type: str, to_label: str):
        """Require specific relationship exists - executes immediately."""
        assert self._extraction is not None or self._ontology_graph is not None, (
            "Must have data to validate"
        )
        assert from_label != to_label, "From and to labels must be different"

        if self._extraction:
            # Check in extraction relationships
            found = False
            for rel in self._extraction.relationships:
                if (
                    rel.source_label.lower() == from_label.lower()
                    and rel.type == rel_type
                    and rel.target_label.lower() == to_label.lower()
                ):
                    found = True
                    break

            if not found:
                self._raise_error(
                    f"Relationship '{from_label}' -[{rel_type}]-> '{to_label}' not found"
                )
        else:
            self.relationships().exists(from_label, rel_type, to_label)

        return self

    def matches_spine(self, spine_items: list[str], type: str | None = None):
        """
        Validate output matches spine exactly - all items present, no extras.

        Checks:
        1. All spine items are extracted (completeness)
        2. Only spine items are extracted (no hallucinations)
        """
        assert spine_items, "Spine items must not be empty"
        assert len(spine_items) > 0, "Spine must have at least one item"
        assert len(spine_items) == len(set(spine_items)), "Spine items must be unique"
        assert self._extraction is not None or self._ontology_graph is not None, (
            "Must have data to validate"
        )

        # Get extracted entities
        if self._extraction:
            if type:
                extracted = {
                    c.label.lower() for c in self._extraction.concepts if c.concept_type == type
                }
            else:
                extracted = {c.label.lower() for c in self._extraction.concepts}
        elif self._ontology_graph:
            if type:
                extracted = {
                    e.label.lower() for e in self._ontology_graph.entities if e.type == type
                }
            else:
                extracted = {e.label.lower() for e in self._ontology_graph.entities}
        else:
            extracted = set()

        spine_set = {item.lower() for item in spine_items}

        # Check completeness: all spine items are extracted
        missing = spine_set - extracted
        if missing:
            type_str = f" of type '{type}'" if type else ""
            self._raise_error(f"Missing spine items{type_str}: {sorted(missing)}")

        # Check correctness: no extras beyond spine
        extras = extracted - spine_set
        if extras:
            type_str = f" of type '{type}'" if type else ""
            self._raise_error(f"Extracted items not in spine{type_str}: {sorted(extras)}")

        return self

    def _get_relationship_pairs(self, rel_type: str) -> list[tuple[str, str]]:
        """Extract relationship pairs for given type."""
        assert rel_type, "Relationship type must not be empty"
        assert self._extraction is not None or self._ontology_graph is not None, "Must have data"

        pairs: list[tuple[str, str]] = []

        if self._extraction:
            for rel in self._extraction.relationships:
                if rel.type != rel_type:
                    continue
                pairs.append((rel.source_label.lower(), rel.target_label.lower()))
        elif self._ontology_graph:
            entities = self._ontology_graph.entities
            for rel in self._ontology_graph.relationships:
                if rel.type != rel_type:
                    continue
                from_entity = next((e for e in entities if e.id == rel.from_), None)
                to_entity = next((e for e in entities if e.id == rel.to), None)
                if not from_entity or not to_entity:
                    continue
                pairs.append((from_entity.label.lower(), to_entity.label.lower()))

        return pairs

    def matches_spine_relationships(self, spine_map: dict[str, str], rel_type: str):
        """
        Validate relationships match spine exactly.

        Args:
            spine_map: Dict mapping from_label -> to_label (e.g., {"France": "Paris"})
            rel_type: Relationship type to validate

        Checks:
        1. All spine relationships exist (completeness)
        2. Only spine relationships exist (no extras)
        """
        assert spine_map, "Spine map must not be empty"
        assert len(spine_map) > 0, "Spine must have at least one relationship"
        assert all(k and v for k, v in spine_map.items()), "Spine keys and values must not be empty"
        assert self._extraction is not None or self._ontology_graph is not None, (
            "Must have data to validate"
        )

        actual_pairs = self._get_relationship_pairs(rel_type)
        spine_pairs = {(k.lower(), v.lower()) for k, v in spine_map.items()}
        actual_pairs_set = set(actual_pairs)

        # Check completeness
        missing = spine_pairs - actual_pairs_set
        if missing:
            missing_strs = [f"{f} -> {t}" for f, t in sorted(missing)]
            self._raise_error(f"Missing spine relationships [{rel_type}]: {missing_strs}")

        # Check correctness
        extras = actual_pairs_set - spine_pairs
        if extras:
            extras_strs = [f"{f} -> {t}" for f, t in sorted(extras)]
            self._raise_error(f"Extra relationships not in spine [{rel_type}]: {extras_strs}")

        return self

    def require_relationship_count(self, min_count: int, rel_type: str | None = None):
        """Require minimum relationship count - executes immediately."""
        assert min_count > 0, "Minimum count must be positive"
        assert self._extraction is not None or self._ontology_graph is not None, (
            "Must have data to validate"
        )

        if self._extraction:
            if rel_type:
                actual = len([r for r in self._extraction.relationships if r.type == rel_type])
                type_str = f"of type '{rel_type}'"
            else:
                actual = len(self._extraction.relationships)
                type_str = "total"

            if actual < min_count:
                self._raise_error(
                    f"Expected at least {min_count} relationships {type_str}, found {actual}"
                )
        elif rel_type:
            self.relationships().of_type(rel_type).has_at_least(min_count)
        else:
            self.relationships().has_at_least(min_count)

        return self

    def _find_entity_by_label(self, label: str) -> Entity | None:
        """Find entity by label (case-insensitive)."""
        assert self._ontology_graph is not None, "Graph must be available"
        assert self._ontology_graph.entities is not None, "Graph entities must be available"

        label_lower = label.lower()
        for entity in self._ontology_graph.entities:
            if entity.label.lower() == label_lower:
                return entity
        return None


# ============================================================================
# Convenience functions for common use cases
# ============================================================================


def validate(
    data: ExtractionResult | OntologyGraph | OntologyOutput,
    raise_model_retry: bool = False,
) -> ValidationContext:
    """
    Create validation context - assertions execute immediately.

    Args:
        data: ExtractionResult, OntologyGraph, or OntologyOutput to validate
        raise_model_retry: If True, convert AssertionError to ModelRetry for LLM feedback

    Examples:
        # Test validation (default)
        validate(result).require_entity_count(5)
        validate(result).require_entity("France")

        # Chain multiple validations
        validate(result).require_entity_count(5).require_relationship_count(10)

        # Testing expected failures with pytest.raises
        with pytest.raises(AssertionError):
            validate(result).require_entity_count(100)

        # Runtime validation (LLM retries)
        validate(result, raise_model_retry=True).require_entity_count(5)

        # Fluent API (also executes immediately)
        validate(graph).entity("France").exists().has_type("Destination")
        validate(graph).relationships().exists("France", "requires", "Visa")
    """
    assert data is not None, "Data must not be None"
    assert isinstance(data, ExtractionResult | OntologyGraph | OntologyOutput), (
        f"Data must be ExtractionResult, OntologyGraph, or OntologyOutput, got {type(data)}"
    )

    return ValidationContext(data, raise_model_retry=raise_model_retry)
