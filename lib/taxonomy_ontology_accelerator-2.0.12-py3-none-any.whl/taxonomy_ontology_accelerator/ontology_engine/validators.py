"""
Validator framework for ontology extraction pipeline.

Provides protocol for custom validators that can be injected between pipeline stages
to validate intermediate results and ensure data quality.
"""

from dataclasses import dataclass
from typing import Any, Protocol

from taxonomy_ontology_accelerator.commons.utils.logger import get_logger
from taxonomy_ontology_accelerator.ontology_engine.core.models import OntologySchema

logger = get_logger()


# ========================================================================
# Validation Result
# ========================================================================


@dataclass(frozen=True)
class ValidationResult:
    """Result of a validation check."""

    success: bool
    message: str | None = None
    details: dict[str, Any] | None = None

    @staticmethod
    def ok(message: str | None = None) -> "ValidationResult":
        """Create successful validation result."""
        assert message is None or isinstance(message, str), "Message must be string or None"
        assert message is None or len(message) >= 0, "Message must be valid string if provided"
        return ValidationResult(success=True, message=message)

    @staticmethod
    def fail(message: str, details: dict[str, Any] | None = None) -> "ValidationResult":
        """Create failed validation result."""
        assert message is not None, "Failure message must not be None"
        assert isinstance(message, str), "Failure message must be string"
        return ValidationResult(success=False, message=message, details=details)


# ========================================================================
# Stage Validator Protocol
# ========================================================================


class StageValidator(Protocol):
    """
    Protocol for validators that run between pipeline stages.

    Validators check intermediate results and ensure data quality.
    Failed validation stops the pipeline with a clear error message.
    """

    def validate(self, **kwargs: Any) -> ValidationResult:
        """
        Validate stage output.

        Args:
            **kwargs: Stage-specific outputs (entities, relationships, schema, etc.)

        Returns:
            ValidationResult indicating success or failure
        """
        assert kwargs is not None, "kwargs must not be None"
        assert isinstance(kwargs, dict), "kwargs must be a dictionary"
        ...


# ========================================================================
# Built-in Validators
# ========================================================================


class EntityCountValidator:
    """Validator that ensures minimum number of entities extracted."""

    def __init__(self, min_count: int = 1):
        """
        Initialize validator.

        Args:
            min_count: Minimum number of entities required
        """
        assert min_count > 0, "min_count must be positive"
        assert isinstance(min_count, int), "min_count must be an integer"
        self.min_count = min_count

    def validate(self, **kwargs: Any) -> ValidationResult:
        """
        Validate entity count.

        Args:
            **kwargs: Must contain 'entities' list (can be Entity, ExtractedConcept, or dict)

        Returns:
            ValidationResult indicating success or failure
        """
        assert "entities" in kwargs, "entities must be in kwargs"
        entities = kwargs["entities"]

        assert entities is not None, "entities must not be None"
        assert isinstance(entities, list), "entities must be a list"

        entity_count = len(entities)

        if entity_count < self.min_count:
            return ValidationResult.fail(
                f"Only {entity_count} entities extracted. "
                f"Expected at least {self.min_count}. "
                f"Check your prompts or input data.",
                details={"entity_count": entity_count, "min_count": self.min_count},
            )

        return ValidationResult.ok(f"Extracted {entity_count} entities (minimum: {self.min_count})")


class SchemaConsistencyValidator:
    """Validator that checks schema consistency after evolution."""

    def validate(self, **kwargs: Any) -> ValidationResult:
        """
        Validate schema consistency.

        Args:
            **kwargs: Must contain 'schema' OntologySchema

        Returns:
            ValidationResult indicating success or failure
        """
        assert "schema" in kwargs, "schema must be in kwargs"
        schema = kwargs["schema"]

        assert schema is not None, "schema must not be None"
        assert isinstance(schema, OntologySchema), "schema must be OntologySchema"

        # Check all relationship types reference valid entity types
        errors: list[str] = []
        entity_type_names = set(schema.entity_types.keys())

        for rel_type_name, rel_type_def in schema.relationship_types.items():
            # Check from_type constraint
            if rel_type_def.from_type and rel_type_def.from_type not in entity_type_names:
                errors.append(
                    f"Relationship '{rel_type_name}' references "
                    f"unknown from_type: '{rel_type_def.from_type}'"
                )

            # Check to_type constraint
            if rel_type_def.to_type and rel_type_def.to_type not in entity_type_names:
                errors.append(
                    f"Relationship '{rel_type_name}' references "
                    f"unknown to_type: '{rel_type_def.to_type}'"
                )

        if errors:
            return ValidationResult.fail(
                f"Schema consistency check failed: {len(errors)} errors",
                details={"errors": errors},
            )

        return ValidationResult.ok(
            f"Schema is consistent: {len(schema.entity_types)} entity types, "
            f"{len(schema.relationship_types)} relationship types"
        )


# ========================================================================
# OWL Validators (require owlready2)
# ========================================================================

# Try to import owlready2 (optional dependency)
try:
    from owlready2 import (  # type: ignore[import-untyped]
        Nothing,
        Thing,
        get_ontology,
        sync_reasoner_pellet,
    )

    OWLREADY2_AVAILABLE = True
except ImportError:
    OWLREADY2_AVAILABLE = False
    logger.debug("owlready2 not available - OWL validators will be disabled")


class OWLPropertyConstraintValidator:
    """
    Validator that checks OWL property constraints (domain/range).

    Validates that relationship types have valid domain and range constraints
    that reference existing entity types.
    """

    def validate(self, **kwargs: Any) -> ValidationResult:
        """
        Validate OWL property constraints.

        Args:
            **kwargs: Must contain 'schema' OntologySchema

        Returns:
            ValidationResult indicating success or failure
        """
        assert "schema" in kwargs, "schema must be in kwargs"
        schema = kwargs["schema"]

        assert schema is not None, "schema must not be None"
        assert isinstance(schema, OntologySchema), "schema must be OntologySchema"

        errors: list[str] = []
        entity_type_names = set(schema.entity_types.keys())

        for rel_type_name, rel_type_def in schema.relationship_types.items():
            # Check domain constraint (from_type)
            if rel_type_def.from_type and rel_type_def.from_type not in entity_type_names:
                errors.append(
                    f"Property '{rel_type_name}' has invalid domain: "
                    f"'{rel_type_def.from_type}' does not exist"
                )

            # Check range constraint (to_type)
            if rel_type_def.to_type and rel_type_def.to_type not in entity_type_names:
                errors.append(
                    f"Property '{rel_type_name}' has invalid range: "
                    f"'{rel_type_def.to_type}' does not exist"
                )

        if errors:
            return ValidationResult.fail(
                f"Found {len(errors)} OWL property constraint violations",
                details={"errors": errors},
            )

        return ValidationResult.ok(
            f"All {len(schema.relationship_types)} properties have valid constraints"
        )


def _create_owl_classes(onto: Any, entity_types: dict) -> None:
    """Create OWL classes from entity types."""
    assert onto is not None, "ontology must not be None"
    assert entity_types is not None, "entity_types must not be None"

    for entity_type_name in entity_types:
        type(
            entity_type_name,
            (Thing,),
            {"namespace": onto},
        )


def _check_unsatisfiable_classes(onto: Any) -> list[str]:
    """Check for unsatisfiable classes in ontology."""
    assert onto is not None, "ontology must not be None"
    assert hasattr(onto, "classes"), "ontology must have classes method"

    unsatisfiable = []
    for cls in onto.classes():
        if Nothing in cls.equivalent_to:
            unsatisfiable.append(cls.name)
    return unsatisfiable


def _run_pellet_and_check(onto: Any, schema: "OntologySchema") -> "ValidationResult":
    """Run Pellet reasoner inside an owlready2 ontology context and return a ValidationResult.

    Distinguishes between environment failures (Java incompatibility) and genuine
    OWL inconsistencies so the caller can handle them differently.
    """
    assert onto is not None, "onto parameter is required"
    assert schema is not None, "schema parameter is required"

    with onto:
        _create_owl_classes(onto, schema.entity_types)
        try:
            sync_reasoner_pellet(infer_property_values=True)
        except Exception as e:
            err_str = str(e)
            # Java version mismatch — Pellet could not start; no conclusion about ontology.
            if "UnsupportedClassVersionError" in err_str or (
                "java" in err_str.lower() and "class" in err_str.lower()
            ):
                return ValidationResult.ok(
                    "OWL validation skipped (Pellet reasoner requires a newer Java version)"
                )
            return ValidationResult.fail(
                f"OWL ontology is inconsistent: {e!s}",
                details={"error": str(e)},
            )

    unsatisfiable = _check_unsatisfiable_classes(onto)
    if unsatisfiable:
        return ValidationResult.fail(
            f"Found {len(unsatisfiable)} unsatisfiable classes",
            details={"unsatisfiable_classes": unsatisfiable},
        )
    return ValidationResult.ok(
        f"OWL ontology is consistent with {len(schema.entity_types)} classes"
    )


def _run_pellet_and_check(onto: Any, schema: "OntologySchema") -> ValidationResult:
    """Run Pellet reasoner and check for unsatisfiable classes.

    Returns a ValidationResult (ok or fail). Skips gracefully if the Java runtime
    is too old to run the bundled Pellet JARs.
    """
    assert onto is not None, "onto must not be None"
    assert schema is not None, "schema must not be None"

    with onto:
        _create_owl_classes(onto, schema.entity_types)
        try:
            sync_reasoner_pellet(infer_property_values=True)
        except Exception as e:
            err_str = str(e)
            # Java version mismatch: Pellet JARs need a newer JVM — cannot reason.
            if "UnsupportedClassVersionError" in err_str or (
                "java" in err_str.lower() and "class" in err_str.lower()
            ):
                return ValidationResult.ok(
                    "OWL validation skipped (Pellet reasoner requires a newer Java version)"
                )
            return ValidationResult.fail(
                f"OWL ontology is inconsistent: {e!s}",
                details={"error": str(e)},
            )

    unsatisfiable = _check_unsatisfiable_classes(onto)
    if unsatisfiable:
        return ValidationResult.fail(
            f"Found {len(unsatisfiable)} unsatisfiable classes",
            details={"unsatisfiable_classes": unsatisfiable},
        )
    return ValidationResult.ok(
        f"OWL ontology is consistent with {len(schema.entity_types)} classes"
    )


class OWLConsistencyValidator:
    """
    Validator that checks OWL ontology consistency using owlready2 reasoner.

    Requires owlready2 optional dependency: pip install taxonomy-ontology-accelerator[owl]
    """

    def __init__(self, export_temp_owl: bool = True):
        """
        Initialize validator.

        Args:
            export_temp_owl: Whether to export schema to temporary OWL file for validation
        """
        assert isinstance(export_temp_owl, bool), "export_temp_owl must be boolean"
        assert isinstance(OWLREADY2_AVAILABLE, bool), "OWLREADY2_AVAILABLE must be boolean"

        if not OWLREADY2_AVAILABLE:
            logger.warning(
                "owlready2 not available. OWLConsistencyValidator will be disabled. "
                "Install with: pip install taxonomy-ontology-accelerator[owl]"
            )

        self.export_temp_owl = export_temp_owl

    def validate(self, **kwargs: Any) -> ValidationResult:
        """
        Validate OWL consistency.

        Args:
            **kwargs: Must contain 'schema' OntologySchema

        Returns:
            ValidationResult indicating success or failure
        """
        assert "schema" in kwargs, "schema must be in kwargs"
        assert isinstance(OWLREADY2_AVAILABLE, bool), "OWLREADY2_AVAILABLE must be boolean"

        if not OWLREADY2_AVAILABLE:
            return ValidationResult.ok("OWL validation skipped (owlready2 not installed)")

        schema = kwargs["schema"]
        assert schema is not None, "schema must not be None"
        assert isinstance(schema, OntologySchema), "schema must be OntologySchema"

        try:
            onto = get_ontology(f"http://example.org/ontology/{schema.domain}/")
            return _run_pellet_and_check(onto, schema)
        except Exception as e:
            return ValidationResult.fail(
                f"OWL consistency check failed: {e!s}",
                details={"error": str(e)},
            )
