"""
Processing layer for ontology engine.

Contains validation, conflict resolution, type similarity, embeddings,
text processing, entity processing, schema evolution, and relationship building.
"""

from taxonomy_ontology_accelerator.ontology_engine.processing.conflict_resolution import (
    detect_contradictory_relationships,
    resolve_conflict,
    resolve_relationship_conflicts,
)
from taxonomy_ontology_accelerator.ontology_engine.processing.embeddings import (
    FAISSIndex,
    cosine_similarity,
    find_semantic_duplicates,
    generate_embedding,
    generate_embeddings_batch,
    load_embeddings,
    save_embeddings,
)
from taxonomy_ontology_accelerator.ontology_engine.processing.entity_deduplicator import (
    deduplicate_entities_enhanced,
    deduplicate_entities_enhanced_async,
)
from taxonomy_ontology_accelerator.ontology_engine.processing.entity_processor import (
    normalize_and_deduplicate_entities,
)
from taxonomy_ontology_accelerator.ontology_engine.processing.relationship_builder import (
    build_relationships,
)
from taxonomy_ontology_accelerator.ontology_engine.processing.schema_evolver import evolve_schema
from taxonomy_ontology_accelerator.ontology_engine.processing.text_processor import chunk_texts
from taxonomy_ontology_accelerator.ontology_engine.processing.type_similarity import (
    calculate_type_similarity,
    check_type_similarity_before_creation,
    find_similar_type,
    generate_type_embedding,
)
from taxonomy_ontology_accelerator.ontology_engine.processing.validation import validate_ontology

__all__ = [
    "FAISSIndex",
    "build_relationships",
    "calculate_type_similarity",
    "check_type_similarity_before_creation",
    "chunk_texts",
    "cosine_similarity",
    "deduplicate_entities_enhanced",
    "deduplicate_entities_enhanced_async",
    "detect_contradictory_relationships",
    "evolve_schema",
    "find_semantic_duplicates",
    "find_similar_type",
    "generate_embedding",
    "generate_embeddings_batch",
    "generate_type_embedding",
    "load_embeddings",
    "normalize_and_deduplicate_entities",
    "resolve_conflict",
    "resolve_relationship_conflicts",
    "save_embeddings",
    "validate_ontology",
]
