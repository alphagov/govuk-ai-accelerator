"""
Validation module for ontology schema and graph consistency.
"""

from taxonomy_ontology_accelerator.commons.utils.logger import get_logger
from taxonomy_ontology_accelerator.ontology_engine.core.models import (
    Entity,
    OntologyGraph,
    OntologySchema,
)

logger = get_logger()


# ========================================================================
# Exception Classes
# ========================================================================


class ValidationError(Exception):
    """Raised when validation finds critical errors that must be fixed."""


class ValidationWarning(Exception):
    """Raised when validation finds issues but processing can continue."""


# ========================================================================
# Helper Functions
# ========================================================================


def _entity_extends(entity_type: str, parent_type: str, schema: OntologySchema) -> bool:
    """
    Check if entity_type extends (is a subtype of) parent_type.

    Uses iterative approach to walk the inheritance chain (no recursion).

    Args:
        entity_type: Entity type to check
        parent_type: Parent type to check against
        schema: Ontology schema

    Returns:
        True if entity_type extends parent_type (directly or transitively)
    """
    assert entity_type is not None, "entity_type parameter is required"
    assert schema is not None, "schema parameter is required"

    current_type = entity_type
    visited: set[str] = set()  # Prevent infinite loops on malformed schemas

    while current_type is not None:
        if current_type == parent_type:
            return True

        # Prevent infinite loop if there's a cycle
        if current_type in visited:
            return False
        visited.add(current_type)

        # Get type definition and move to parent
        type_def = schema.entity_types.get(current_type)
        if not type_def:
            return False

        current_type = type_def.parent_type

    return False


def _check_parent_references(entity_types: dict, errors: list[str]) -> None:
    """Check all parent_type references exist."""
    assert entity_types is not None, "entity_types parameter is required"
    assert errors is not None, "errors parameter is required"
    for type_name, type_def in entity_types.items():
        parent = type_def.parent_type
        if parent and parent not in entity_types:
            errors.append(f"Entity type '{type_name}' references unknown parent '{parent}'")


def _check_hierarchy_cycles(entity_types: dict, errors: list[str]) -> None:
    """Check for circular dependencies in type hierarchy using iterative DFS."""
    assert entity_types is not None, "entity_types parameter is required"
    assert errors is not None, "errors parameter is required"

    visited: set[str] = set()

    for start_type in entity_types:
        if start_type in visited:
            continue

        # Iterative DFS with explicit stack: (type_name, path)
        stack: list[tuple[str, list[str]]] = [(start_type, [])]

        while stack:
            type_name, path = stack.pop()

            # Check for cycle
            if type_name in path:
                errors.append(f"Circular dependency: {' -> '.join([*path, type_name])}")
                continue

            # Skip if already fully visited
            if type_name in visited:
                continue

            visited.add(type_name)

            # Get parent and add to stack if exists
            type_def = entity_types.get(type_name)
            if type_def and type_def.parent_type:
                stack.append((type_def.parent_type, [*path, type_name]))


def validate_entity_type_hierarchy(schema: OntologySchema) -> list[str]:
    """Validate entity type hierarchy (Rule 11): parent references and cycles."""
    assert schema is not None, "schema parameter is required"
    assert hasattr(schema, "entity_types"), "schema must have entity_types attribute"

    errors: list[str] = []
    _check_parent_references(schema.entity_types, errors)
    _check_hierarchy_cycles(schema.entity_types, errors)
    return errors


def _validate_restriction_references(schema: OntologySchema) -> list[str]:
    """
    Validate OWL restriction references.

    Check that:
    - Properties in restrictions exist as relationship types
    - Classes in restrictions (on_class, value) exist as entity types
    """
    assert schema is not None, "schema parameter is required"
    assert hasattr(schema, "entity_types"), "schema must have entity_types"

    errors: list[str] = []
    entity_type_names = set(schema.entity_types.keys())
    relationship_type_names = set(schema.relationship_types.keys())

    for type_name, type_def in schema.entity_types.items():
        for restriction in type_def.restrictions:
            if restriction.property not in relationship_type_names:
                errors.append(
                    f"Entity type '{type_name}': restriction references unknown property '{restriction.property}'"
                )

            if restriction.on_class and restriction.on_class not in entity_type_names:
                errors.append(
                    f"Entity type '{type_name}': restriction references unknown class '{restriction.on_class}'"
                )

            if (
                isinstance(restriction.value, str)
                and restriction.value not in entity_type_names
                and restriction.restriction_type.value in ["someValuesFrom", "allValuesFrom"]
            ):
                errors.append(
                    f"Entity type '{type_name}': restriction references unknown class '{restriction.value}'"
                )

    return errors


def _validate_property_characteristics(schema: OntologySchema) -> list[str]:
    """
    Validate OWL property characteristics for contradictions.

    Check for incompatible characteristic combinations:
    - Symmetric + Asymmetric
    - Reflexive + Irreflexive
    - Functional + InverseFunctional (warning, not error)
    """
    assert schema is not None, "schema parameter is required"
    assert hasattr(schema, "relationship_types"), "schema must have relationship_types"

    errors: list[str] = []

    for rel_type_name, rel_type_def in schema.relationship_types.items():
        char_names = {c.value for c in rel_type_def.characteristics}

        if "Symmetric" in char_names and "Asymmetric" in char_names:
            errors.append(
                f"Relationship type '{rel_type_name}': cannot be both Symmetric and Asymmetric"
            )

        if "Reflexive" in char_names and "Irreflexive" in char_names:
            errors.append(
                f"Relationship type '{rel_type_name}': cannot be both Reflexive and Irreflexive"
            )

    return errors


def _validate_inverse_of_references(schema: OntologySchema) -> list[str]:
    """
    Validate that inverse_of references point to existing relationship types.

    For each relationship type with inverse_of set, check that the referenced
    name exists in schema.relationship_types.
    """
    assert schema is not None, "schema parameter is required"
    assert hasattr(schema, "relationship_types"), "schema must have relationship_types"

    errors: list[str] = []
    relationship_type_names = set(schema.relationship_types.keys())

    for rel_type_name, rel_type_def in schema.relationship_types.items():
        if rel_type_def.inverse_of and rel_type_def.inverse_of not in relationship_type_names:
            errors.append(
                f"Relationship type '{rel_type_name}': inverse_of references "
                f"unknown relationship type '{rel_type_def.inverse_of}'"
            )

    return errors


def _validate_confidence_scores(graph: OntologyGraph) -> list[str]:
    """
    Validate confidence scores in entity and relationship metadata.

    Returns warnings for confidence values outside [0.0, 1.0] or non-numeric.

    Args:
        graph: Ontology graph to validate

    Returns:
        List of warning messages for invalid confidence scores
    """
    assert graph is not None, "graph parameter is required"
    assert hasattr(graph, "entities"), "graph must have entities attribute"

    warnings: list[str] = []

    for entity in graph.entities:
        confidence = entity.metadata.get("confidence")
        if confidence is not None:
            if not isinstance(confidence, int | float):
                warnings.append(
                    f"Entity '{entity.id}': confidence is not numeric (got {type(confidence).__name__})"
                )
            elif confidence < 0.0 or confidence > 1.0:
                warnings.append(
                    f"Entity '{entity.id}': confidence {confidence} outside valid range [0.0, 1.0]"
                )

    for rel in graph.relationships:
        confidence = rel.metadata.get("confidence")
        if confidence is not None:
            if not isinstance(confidence, int | float):
                warnings.append(
                    f"Relationship '{rel.id}': confidence is not numeric (got {type(confidence).__name__})"
                )
            elif confidence < 0.0 or confidence > 1.0:
                warnings.append(
                    f"Relationship '{rel.id}': confidence {confidence} outside valid range [0.0, 1.0]"
                )

    return warnings


def _validate_relationship_type_domain_range(schema: OntologySchema) -> list[str]:
    """
    Validate that from_type and to_type in relationship type definitions exist in entity types.

    Returns warnings (not errors) since schema evolution is incremental and types
    may be added later.

    Args:
        schema: Ontology schema to validate

    Returns:
        List of warning messages for invalid domain/range references
    """
    assert schema is not None, "schema parameter is required"
    assert hasattr(schema, "relationship_types"), "schema must have relationship_types"

    warnings: list[str] = []
    entity_type_names = set(schema.entity_types.keys())
    # 'entity' is always valid as a generic base type
    entity_type_names.add("entity")

    for rel_type_name, rel_type_def in schema.relationship_types.items():
        if rel_type_def.from_type and rel_type_def.from_type not in entity_type_names:
            warnings.append(
                f"Relationship type '{rel_type_name}': from_type '{rel_type_def.from_type}' "
                f"not found in entity types"
            )
        if rel_type_def.to_type and rel_type_def.to_type not in entity_type_names:
            warnings.append(
                f"Relationship type '{rel_type_name}': to_type '{rel_type_def.to_type}' "
                f"not found in entity types"
            )

    return warnings


def _validate_sub_property_of_references(schema: OntologySchema) -> list[str]:
    """
    Validate that sub_property_of references point to existing relationship types.

    Args:
        schema: Ontology schema to validate

    Returns:
        List of error messages for invalid sub_property_of references
    """
    assert schema is not None, "schema parameter is required"
    assert hasattr(schema, "relationship_types"), "schema must have relationship_types"

    errors: list[str] = []
    relationship_type_names = set(schema.relationship_types.keys())

    for rel_type_name, rel_type_def in schema.relationship_types.items():
        if (
            rel_type_def.sub_property_of
            and rel_type_def.sub_property_of not in relationship_type_names
        ):
            errors.append(
                f"Relationship type '{rel_type_name}': sub_property_of references "
                f"unknown relationship type '{rel_type_def.sub_property_of}'"
            )

    return errors


def _validate_sub_property_cycles(schema: OntologySchema) -> list[str]:
    """
    Detect cycles in sub_property_of chains.

    Prevents circular sub-property definitions like: A subPropertyOf B, B subPropertyOf A.

    Args:
        schema: Ontology schema to validate

    Returns:
        List of error messages for cycles found
    """
    assert schema is not None, "schema parameter is required"
    assert hasattr(schema, "relationship_types"), "schema must have relationship_types"

    errors: list[str] = []

    for start_type in schema.relationship_types:
        visited: set[str] = set()
        path: list[str] = []
        current = start_type

        while current is not None:
            if current in visited:
                cycle_start = path.index(current) if current in path else 0
                cycle_path = [*path[cycle_start:], current]
                errors.append(f"Circular sub_property_of chain: {' -> '.join(cycle_path)}")
                break

            visited.add(current)
            path.append(current)

            rel_def = schema.relationship_types.get(current)
            current = rel_def.sub_property_of if rel_def else None

    return errors


def _validate_property_chain_references(schema: OntologySchema) -> list[str]:
    """
    Validate that property_chain references point to existing relationship types.

    Args:
        schema: Ontology schema to validate

    Returns:
        List of error messages for invalid property_chain references
    """
    assert schema is not None, "schema parameter is required"
    assert hasattr(schema, "relationship_types"), "schema must have relationship_types"

    errors: list[str] = []
    relationship_type_names = set(schema.relationship_types.keys())

    for rel_type_name, rel_type_def in schema.relationship_types.items():
        if rel_type_def.property_chain:
            for prop_name in rel_type_def.property_chain.properties:
                if prop_name not in relationship_type_names:
                    errors.append(
                        f"Relationship type '{rel_type_name}': property_chain references "
                        f"unknown relationship type '{prop_name}'"
                    )

    return errors


def _validate_equivalent_class_cycles(schema: OntologySchema) -> list[str]:
    """
    Validate OWL equivalent class definitions for cycles.

    Prevent circular equivalence chains like: A ≡ B, B ≡ C, C ≡ A
    """
    assert schema is not None, "schema parameter is required"
    assert hasattr(schema, "entity_types"), "schema must have entity_types"

    errors: list[str] = []
    visited: set[str] = set()

    for start_type in schema.entity_types:
        if start_type in visited:
            continue

        stack: list[tuple[str, list[str]]] = [(start_type, [])]

        while stack:
            type_name, path = stack.pop()

            if type_name in path:
                errors.append(
                    f"Circular equivalent class definition: {' ≡ '.join([*path, type_name])}"
                )
                continue

            if type_name in visited:
                continue

            visited.add(type_name)

            type_def = schema.entity_types.get(type_name)
            if type_def:
                for equiv_class in type_def.equivalent_classes:
                    if equiv_class in schema.entity_types:
                        stack.append((equiv_class, [*path, type_name]))

    return errors


# ========================================================================
# Main Validation Functions
# ========================================================================


def _validate_schema_version(schema: OntologySchema, graph: OntologyGraph) -> list[str]:
    """
    Rule 1: Check schema version consistency between schema and graph.

    Returns a warning (not error) if versions mismatch, as the graph's
    schema_version is used as source of truth during processing.

    Args:
        schema: Ontology schema to validate
        graph: Ontology graph to validate

    Returns:
        List of warning messages (empty if versions match)
    """
    assert schema is not None, "schema parameter is required"
    assert graph is not None, "graph parameter is required"
    if graph.schema_version != schema.version:
        return [
            f"Schema version mismatch: graph has '{graph.schema_version}', "
            f"schema has '{schema.version}'. Using graph's schema_version as source of truth."
        ]
    return []


def _validate_entity_types(schema: OntologySchema, graph: OntologyGraph) -> list[str]:
    """
    Rule 2: Validate all entity types in graph exist in schema.

    Critical error if entities reference types not defined in schema.

    Args:
        schema: Ontology schema with defined entity types
        graph: Ontology graph with entities to validate

    Returns:
        List of error messages for invalid entity types
    """
    assert schema is not None, "schema parameter is required"
    assert graph is not None, "graph parameter is required"
    schema_types = set(schema.entity_types.keys())
    graph_types = {e.type for e in graph.entities}
    invalid = graph_types - schema_types
    if invalid:
        return [f"Entities reference unknown entity types: {sorted(invalid)}"]
    return []


def _validate_relationship_types(schema: OntologySchema, graph: OntologyGraph) -> list[str]:
    """
    Rule 3: Validate all relationship types in graph exist in schema.

    Critical error if relationships reference types not defined in schema.

    Args:
        schema: Ontology schema with defined relationship types
        graph: Ontology graph with relationships to validate

    Returns:
        List of error messages for invalid relationship types
    """
    assert schema is not None, "schema parameter is required"
    assert graph is not None, "graph parameter is required"
    schema_types = set(schema.relationship_types.keys())
    graph_types = {r.type for r in graph.relationships}
    invalid = graph_types - schema_types
    if invalid:
        return [f"Relationships reference unknown relationship types: {sorted(invalid)}"]
    return []


def _validate_relationship_constraints(
    schema: OntologySchema, graph: OntologyGraph, entity_by_id: dict[str, Entity]
) -> list[str]:
    """
    Rule 4: Validate relationship type constraints (from_type, to_type).

    Checks that entity types used in relationships match the constraints
    defined in the relationship type definition. Returns warnings (not errors)
    because constraints can be relaxed during schema evolution.

    Args:
        schema: Ontology schema with relationship type constraints
        graph: Ontology graph with relationships to validate
        entity_by_id: Map of entity_id -> Entity for type lookup

    Returns:
        List of warning messages for constraint violations
    """
    assert schema is not None, "schema parameter is required"
    assert graph is not None, "graph parameter is required"
    warnings = []
    for rel in graph.relationships:
        rel_type_def = schema.relationship_types.get(rel.type)
        if not rel_type_def:
            continue

        from_entity = entity_by_id.get(rel.from_)
        to_entity = entity_by_id.get(rel.to)
        if not from_entity or not to_entity:
            continue

        if (
            rel_type_def.from_type
            and rel_type_def.from_type not in (from_entity.type, "entity")
            and not _entity_extends(from_entity.type, rel_type_def.from_type, schema)
        ):
            warnings.append(
                f"Relationship '{rel.id}': from entity type '{from_entity.type}' "
                f"does not match relationship constraint '{rel_type_def.from_type}'"
            )

        if (
            rel_type_def.to_type
            and rel_type_def.to_type not in (to_entity.type, "entity")
            and not _entity_extends(to_entity.type, rel_type_def.to_type, schema)
        ):
            warnings.append(
                f"Relationship '{rel.id}': to entity type '{to_entity.type}' "
                f"does not match relationship constraint '{rel_type_def.to_type}'"
            )
    return warnings


def _validate_required_fields(schema: OntologySchema, graph: OntologyGraph) -> list[str]:
    """
    Rule 5: Validate required fields are present in entities.

    Checks that each entity has all required fields defined for its type.
    Fields are checked as both direct attributes and in the properties dict.

    Args:
        schema: Ontology schema with required field definitions
        graph: Ontology graph with entities to validate

    Returns:
        List of error messages for missing required fields
    """
    assert schema is not None, "schema parameter is required"
    assert graph is not None, "graph parameter is required"
    errors = []
    for entity in graph.entities:
        entity_type_def = schema.entity_types.get(entity.type)
        if not entity_type_def:
            continue

        # Convert entity to dict for safe field access without getattr
        entity_dict = entity.model_dump()

        for field in entity_type_def.required_fields:
            field_value = entity_dict.get(field)
            if field_value is None and field in entity.properties:
                field_value = entity.properties[field]

            if field_value is None:
                errors.append(
                    f"Entity '{entity.id}': missing required field '{field}' for type '{entity.type}'"
                )
    return errors


def _validate_relationship_references(graph: OntologyGraph, entity_ids: set[str]) -> list[str]:
    """
    Rule 6: Validate relationship endpoint references exist.

    Critical error if from_ or to_ reference non-existent entity IDs.
    This prevents orphaned relationships in the graph.

    Args:
        graph: Ontology graph with relationships to validate
        entity_ids: Set of all valid entity IDs in the graph

    Returns:
        List of error messages for invalid relationship references
    """
    assert graph is not None, "graph parameter is required"
    assert entity_ids is not None, "entity_ids parameter is required"
    errors = []
    for rel in graph.relationships:
        if rel.from_ not in entity_ids:
            errors.append(f"Relationship '{rel.id}': from entity '{rel.from_}' does not exist")
        if rel.to not in entity_ids:
            errors.append(f"Relationship '{rel.id}': to entity '{rel.to}' does not exist")
    return errors


def _find_duplicates(items: list[str]) -> set[str]:
    """
    Find duplicate values in a list.

    Used for Rules 7-9 to check uniqueness of canonical_key, entity ID,
    and relationship ID.

    Args:
        items: List of string values to check for duplicates

    Returns:
        Set of values that appear more than once
    """
    assert items is not None, "items parameter is required"
    assert isinstance(items, list), "items must be a list"
    seen: set[str] = set()
    duplicates: set[str] = set()
    for item in items:
        if item in seen:
            duplicates.add(item)
        else:
            seen.add(item)
    return duplicates


def _check_uniqueness_constraints(graph: OntologyGraph, errors: list[str]) -> None:
    """Check uniqueness constraints (Rules 7-9)."""
    assert graph is not None, "graph parameter is required"
    assert errors is not None, "errors parameter is required"

    dup_keys = _find_duplicates([e.canonical_key for e in graph.entities])
    if dup_keys:
        errors.append(f"Duplicate canonical_key values: {sorted(dup_keys)}")

    dup_entity_ids = _find_duplicates([e.id for e in graph.entities])
    if dup_entity_ids:
        errors.append(f"Duplicate entity IDs: {sorted(dup_entity_ids)}")

    dup_rel_ids = _find_duplicates([r.id for r in graph.relationships])
    if dup_rel_ids:
        errors.append(f"Duplicate relationship IDs: {sorted(dup_rel_ids)}")


def validate_ontology(
    schema: OntologySchema,
    graph: OntologyGraph,
) -> tuple[list[str], list[str]]:
    """Validate schema and graph consistency (all 11 rules + OWL features)."""
    assert schema is not None, "schema parameter is required"
    assert graph is not None, "graph parameter is required"

    errors: list[str] = []
    warnings: list[str] = []
    entity_by_id = {e.id: e for e in graph.entities}
    entity_ids = set(entity_by_id.keys())

    warnings.extend(_validate_schema_version(schema, graph))
    errors.extend(_validate_entity_types(schema, graph))
    errors.extend(_validate_relationship_types(schema, graph))
    warnings.extend(_validate_relationship_constraints(schema, graph, entity_by_id))
    errors.extend(_validate_required_fields(schema, graph))
    errors.extend(_validate_relationship_references(graph, entity_ids))
    _check_uniqueness_constraints(graph, errors)

    if schema.domain != graph.domain:
        errors.append(f"Domain mismatch: schema='{schema.domain}', graph='{graph.domain}'")

    errors.extend(validate_entity_type_hierarchy(schema))
    errors.extend(_validate_restriction_references(schema))
    errors.extend(_validate_property_characteristics(schema))
    errors.extend(_validate_inverse_of_references(schema))
    errors.extend(_validate_equivalent_class_cycles(schema))

    # Issue 4a: Validate relationship type domain/range (warnings)
    warnings.extend(_validate_relationship_type_domain_range(schema))

    # Issue 4c: Validate sub_property_of references and cycles
    errors.extend(_validate_sub_property_of_references(schema))
    errors.extend(_validate_sub_property_cycles(schema))

    # Issue 4d: Validate property_chain references
    errors.extend(_validate_property_chain_references(schema))

    # Issue 3b: Confidence score validation (warnings, not errors)
    warnings.extend(_validate_confidence_scores(graph))

    return errors, warnings
