"""
Post-merge validation to ensure no data loss.

Validates that merged entities and relationships preserve all original information.
"""

from taxonomy_ontology_accelerator.commons.utils.logger import get_logger
from taxonomy_ontology_accelerator.ontology_engine.core.models import (
    Entity,
    OntologyGraph,
    Relationship,
)

logger = get_logger()

def validate_entity_merge(
    merged_entity: Entity,
    original_entities: list[Entity],
) -> list[str]:
    """
    Validate that merged entity preserves all information from original entities.

    Args:
        merged_entity: Merged entity
        original_entities: Original entities that were merged

    Returns:
        List of validation warnings (empty if all valid)
    """
    assert merged_entity is not None, "Merged entity must not be None"
    assert isinstance(original_entities, list), "Original entities must be a list"
    assert len(original_entities) > 0, "Must have at least one original entity"

    warnings: list[str] = []

    # Check that all original labels are preserved (as label or alias)
    all_original_labels = {e.label for e in original_entities}
    merged_labels = {merged_entity.label} | set(merged_entity.alias_names or [])

    missing_labels = all_original_labels - merged_labels
    if missing_labels:
        warnings.append(
            f"Entity '{merged_entity.id}': Missing original labels as aliases: {missing_labels}"
        )

    # Check that all original aliases are preserved
    all_original_aliases: set[str] = set()
    for e in original_entities:
        if e.aliases:
            all_original_aliases.update(e.alias_names)

    missing_aliases = all_original_aliases - set(merged_entity.alias_names or [])
    if missing_aliases:
        warnings.append(f"Entity '{merged_entity.id}': Missing original aliases: {missing_aliases}")

    # Merged props might be fewer due to deduplication, but should have at least
    # the unique keys from all originals
    # Merged props might be fewer due to deduplication, but should have at least
    # the unique keys from all originals
    all_original_prop_keys: set[str] = set()
    for e in original_entities:
        if e.properties:
            all_original_prop_keys.update(e.properties.keys())

    missing_prop_keys: set[str] = all_original_prop_keys - set(merged_entity.properties or {})
    if missing_prop_keys:
        warnings.append(f"Entity '{merged_entity.id}': Missing property keys: {missing_prop_keys}")

    return warnings

def validate_relationship_updates(
    relationships: list[Relationship],
    entity_ids: set[str],
) -> list[str]:
    """
    Validate that all relationship entity IDs exist.

    Args:
        relationships: List of relationships
        entity_ids: Set of valid entity IDs

    Returns:
        List of validation errors (empty if all valid)
    """
    assert isinstance(relationships, list), "Relationships must be a list"
    assert isinstance(entity_ids, set), "Entity IDs must be a set"

    errors: list[str] = []

    for rel in relationships:
        if rel.from_ not in entity_ids:
            errors.append(f"Relationship '{rel.id}': Source entity '{rel.from_}' not found")
        if rel.to not in entity_ids:
            errors.append(f"Relationship '{rel.id}': Target entity '{rel.to}' not found")

    return errors

def validate_merged_graph(
    graph: OntologyGraph,
    original_entities: list[Entity] | None = None,
) -> tuple[bool, list[str]]:
    """
    Validate merged graph for data integrity.

    Args:
        graph: Merged graph
        original_entities: Original entities before merge (optional, for validation)

    Returns:
        Tuple of (is_valid, warnings)
    """
    assert graph is not None, "Graph must not be None"
    assert graph.entities is not None, "Graph entities must not be None"

    warnings: list[str] = []

    # Validate entity IDs are unique
    # Validate entity IDs are unique
    entity_ids = {e.id for e in graph.entities}
    if len(entity_ids) != len(graph.entities):
        warnings.append("Duplicate entity IDs detected")

                                        
    # Validate canonical keys are unique
    canonical_keys = {e.canonical_key for e in graph.entities}
    if len(canonical_keys) != len(graph.entities):
        warnings.append("Duplicate canonical keys detected")

    # Validate relationships reference valid entities
    # Validate relationships reference valid entities
    rel_errors = validate_relationship_updates(graph.relationships, entity_ids)
    warnings.extend(rel_errors)

    # Validate entity merges if original entities provided
    # Validate entity merges if original entities provided
    if original_entities:
                                                                         
        # This is complex without merge history tracking, so skip for now
        pass

    is_valid = len([w for w in warnings if "error" in w.lower() or "not found" in w.lower()]) == 0

    if warnings:
        logger.warning(f"Graph validation found {len(warnings)} issues")
        for warning in warnings:
            logger.warning(f"  - {warning}")

    return is_valid, warnings
