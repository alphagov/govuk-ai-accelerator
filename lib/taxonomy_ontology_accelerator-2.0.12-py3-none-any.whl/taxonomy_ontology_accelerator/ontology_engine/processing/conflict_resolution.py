"""
Conflict resolution module for ontology relationships.
"""

from collections import defaultdict
from typing import TYPE_CHECKING, cast

if TYPE_CHECKING:
    from taxonomy_ontology_accelerator.ontology_engine.config.config import OntologyConfig
    from taxonomy_ontology_accelerator.ontology_engine.core.models import Relationship

from taxonomy_ontology_accelerator.commons.utils.logger import get_logger

logger = get_logger()


# ========================================================================
# Constants
# ========================================================================

# Contradictory relationship type pairs
# Each pair represents mutually exclusive relationship types
CONTRADICTORY_PAIRS: set[tuple[str, str]] = {
    ("requires", "conflicts_with"),
    ("conflicts_with", "requires"),
    ("enables", "prevents"),
    ("prevents", "enables"),
    ("supports", "opposes"),
    ("opposes", "supports"),
    ("allows", "forbids"),
    ("forbids", "allows"),
}


# ========================================================================
# Conflict Detection
# ========================================================================


def _check_same_direction_conflicts(
    rel: "Relationship",
    rel_index: dict[tuple[str, str], list["Relationship"]],
    conflicts: list[tuple["Relationship", "Relationship", str]],
) -> None:
    """Check for contradictory relationships in the same direction."""
    assert rel is not None, "Relationship must not be None"
    assert isinstance(rel_index, dict), "Relationship index must be a dict"

    for existing_rel in rel_index.get((rel.from_, rel.to), []):
        if existing_rel.id == rel.id:
            continue

        if (rel.type, existing_rel.type) in CONTRADICTORY_PAIRS:
            conflicts.append((rel, existing_rel, "contradictory"))
            msg = (
                f"Contradictory relationship detected: {rel.from_} {rel.type} {rel.to} "
                f"vs {existing_rel.from_} {existing_rel.type} {existing_rel.to}"
            )
            logger.debug(msg)


def _check_reversed_direction_conflicts(
    rel: "Relationship",
    rel_index: dict[tuple[str, str], list["Relationship"]],
    conflicts: list[tuple["Relationship", "Relationship", str]],
) -> None:
    """Check for conflicts in reversed direction with same type."""
    assert rel is not None, "Relationship must not be None"
    assert isinstance(rel_index, dict), "Relationship index must be a dict"

    reversed_rels = rel_index.get((rel.to, rel.from_), [])
    for reversed_rel in reversed_rels:
        if reversed_rel.id == rel.id:
            continue

        if reversed_rel.type == rel.type:
            conflicts.append((rel, reversed_rel, "reversed"))
            msg = (
                f"Reversed relationship detected: {rel.from_} {rel.type} {rel.to} "
                f"vs {reversed_rel.from_} {reversed_rel.type} {reversed_rel.to}"
            )
            logger.debug(msg)


def detect_contradictory_relationships(
    relationships: list["Relationship"],
    existing_relationships: list["Relationship"] | None = None,
) -> list[tuple["Relationship", "Relationship", str]]:
    """
    Detect contradictory relationships.

    Args:
        relationships: New relationships to check
        existing_relationships: Existing relationships to check against

    Returns:
        List of tuples: (new_rel, conflicting_rel, conflict_type)
        conflict_type: "contradictory" or "reversed"
    """
    assert isinstance(relationships, list), "Relationships must be a list"
    assert existing_relationships is None or isinstance(existing_relationships, list), (
        "Existing relationships must be None or a list"
    )

    conflicts: list[tuple[Relationship, Relationship, str]] = []

    # Combine new and existing relationships for comprehensive checking
    all_relationships = list(relationships)
    if existing_relationships:
        all_relationships.extend(existing_relationships)

    # Build index: (from_id, to_id) -> list of relationships
    rel_index: dict[tuple[str, str], list[Relationship]] = defaultdict(list)
    for rel in all_relationships:
        rel_index[(rel.from_, rel.to)].append(rel)

    # Check for contradictory relationships
    for rel in relationships:
        _check_same_direction_conflicts(rel, rel_index, conflicts)
        _check_reversed_direction_conflicts(rel, rel_index, conflicts)

    return conflicts


# ========================================================================
# Conflict Resolution
# ========================================================================


def resolve_conflict(
    rel1: "Relationship",
    rel2: "Relationship",
    strategy: str,
    _config: "OntologyConfig",  # Reserved for future strategy options
) -> "Relationship":
    """
    Resolve conflict between two relationships using specified strategy.

    Args:
        rel1: First relationship
        rel2: Second relationship
        strategy: Resolution strategy ("higher_confidence", "most_recent", "more_sources")
        config: Ontology configuration

    Returns:
        The relationship to keep (resolved)
    """
    assert rel1 is not None, "First relationship must not be None"
    assert rel2 is not None, "Second relationship must not be None"

    result: Relationship | None = None

    if strategy == "higher_confidence":  # Use confidence-based resolution
        conf1 = cast("float", rel1.metadata.get("confidence", 0.0))
        conf2 = cast("float", rel2.metadata.get("confidence", 0.0))
        if conf1 > conf2:  # rel1 has higher confidence
            result = rel1  # Keep rel1
        elif conf2 > conf1:  # rel2 has higher confidence
            result = rel2  # Keep rel2
        else:
            # If equal, fall back to most_recent
            strategy = "most_recent"  # Use next strategy

    if result is None and strategy == "most_recent":  # Use timestamp-based resolution
        timestamp1 = cast("str", rel1.metadata.get("timestamp", ""))
        timestamp2 = cast("str", rel2.metadata.get("timestamp", ""))
        # String comparison works for ISO format timestamps
        if timestamp1 > timestamp2:  # rel1 is more recent
            result = rel1  # Keep rel1
        elif timestamp2 > timestamp1:  # rel2 is more recent
            result = rel2  # Keep rel2
        else:
            # If equal, fall back to more_sources
            strategy = "more_sources"  # Use next strategy

    if result is None and strategy == "more_sources":  # Use source count-based resolution
        sources1 = len(cast("list[object]", rel1.properties.get("sources", [])))
        sources2 = len(cast("list[object]", rel2.properties.get("sources", [])))
        if sources1 > sources2:  # rel1 has more sources
            result = rel1  # Keep rel1
        elif sources2 > sources1:  # rel2 has more sources
            result = rel2  # Keep rel2

    # Default: prefer first relationship
    return result if result is not None else rel1


# ========================================================================
# Main Conflict Resolution Pipeline
# ========================================================================


def _process_conflict(
    rel1: "Relationship",
    rel2: "Relationship",
    conflict_type: str,
    relationship_ids: set[str],
    context: tuple[set[str], list[tuple["Relationship", "Relationship", str]]],
    config: "OntologyConfig",
) -> None:
    """Process a single conflict between two relationships.

    Args:
        rel1: First relationship in conflict
        rel2: Second relationship in conflict
        conflict_type: Type of conflict
        relationship_ids: Set of IDs from new relationships
        context: Tuple of (relationships_to_remove, resolved_conflicts)
        config: Ontology configuration
    """
    assert rel1 is not None, "First relationship must not be None"
    assert rel2 is not None, "Second relationship must not be None"

    relationships_to_remove, resolved_conflicts = context

    if rel1.id in relationships_to_remove or rel2.id in relationships_to_remove:
        return

    resolved = resolve_conflict(rel1, rel2, config.conflict_resolution.strategy, config)

    if rel1.id in relationship_ids:
        if resolved.id == rel2.id:
            relationships_to_remove.add(rel1.id)
            resolved_conflicts.append((rel1, rel2, conflict_type))
            logger.debug(f"Resolved conflict: keeping {rel2.id}, removing {rel1.id}")
        else:
            resolved_conflicts.append((rel1, rel2, conflict_type))
            logger.debug(f"Resolved conflict: keeping {rel1.id} over {rel2.id}")
    else:
        if resolved.id == rel2.id:
            relationships_to_remove.add(rel1.id)
        else:
            relationships_to_remove.add(rel2.id)
        resolved_conflicts.append((rel1, rel2, conflict_type))
        logger.debug(f"Resolved conflict: keeping {resolved.id}")


def _log_resolution_summary(
    relationships_to_remove: set[str],
    resolved_conflicts: list[tuple["Relationship", "Relationship", str]],
    resolved_relationships: list["Relationship"],
    relationships: list["Relationship"],
) -> None:
    """Log summary of conflict resolution results."""
    assert isinstance(relationships_to_remove, set), "Relationships to remove must be a set"
    assert isinstance(resolved_conflicts, list), "Resolved conflicts must be a list"

    if not relationships_to_remove:
        return

    removed_count = len(relationships_to_remove)
    kept_count = len(resolved_relationships)
    msg = (
        f"Conflict resolution complete: resolved {len(resolved_conflicts)} conflict(s), "
        f"removed {removed_count} relationship(s), kept {kept_count} relationship(s)"
    )
    logger.info(msg)

    if removed_count > len(resolved_relationships) * 0.1:
        removal_pct = removed_count / len(relationships)
        warning_msg = (
            f"High relationship removal rate during conflict resolution: "
            f"{removed_count}/{len(relationships)} ({removal_pct:.1%}) removed. "
            f"Review conflict resolution strategy if this seems excessive."
        )
        logger.warning(warning_msg)


def resolve_relationship_conflicts(
    relationships: list["Relationship"],
    config: "OntologyConfig",
    existing_relationships: list["Relationship"] | None = None,
) -> tuple[list["Relationship"], list[tuple["Relationship", "Relationship", str]]]:
    """
    Detect and resolve all relationship conflicts.

    Args:
        relationships: New relationships to check
        existing_relationships: Existing relationships to check against
        config: Ontology configuration

    Returns:
        Tuple of (resolved_relationships, detected_conflicts)
        resolved_relationships: Relationships after conflict resolution
        detected_conflicts: List of conflicts that were detected and resolved
    """
    assert isinstance(relationships, list), "Relationships must be a list"
    assert hasattr(config, "conflict_resolution"), "Config must have conflict_resolution"

    if not config.conflict_resolution.enabled:
        return relationships, []

    # Detect conflicts
    conflicts = detect_contradictory_relationships(relationships, existing_relationships)

    if not conflicts:
        return relationships, []

    logger.info(f"ℹ️  Detected {len(conflicts)} relationship conflicts")  # noqa: RUF001

    # Track which relationships to remove
    relationships_to_remove: set[str] = set()
    resolved_conflicts: list[tuple[Relationship, Relationship, str]] = []
    relationship_ids: set[str] = {rel.id for rel in relationships}
    context = (relationships_to_remove, resolved_conflicts)

    # Resolve each conflict
    for rel1, rel2, conflict_type in conflicts:
        _process_conflict(rel1, rel2, conflict_type, relationship_ids, context, config)

    # Filter out removed relationships
    resolved_relationships = [rel for rel in relationships if rel.id not in relationships_to_remove]

    # Log summary
    _log_resolution_summary(
        relationships_to_remove, resolved_conflicts, resolved_relationships, relationships
    )

    return resolved_relationships, resolved_conflicts
