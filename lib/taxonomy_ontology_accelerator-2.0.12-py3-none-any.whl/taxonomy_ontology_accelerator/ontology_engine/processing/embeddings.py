"""
Embedding generation and semantic similarity for ontology entities.

Introduction:
- Uses PydanticAI Embedder exclusively for all embedding generation
- Supports any PydanticAI-compatible embedding model (selected via config)
- Examples: google-gla:*, openai:*, cohere:*, bedrock:*, voyageai:*
- No automatic fallbacks - fails gracefully if configured model is unavailable
- Uses FAISS for datasets exceeding configured threshold
- Falls back to linear search for smaller datasets
- Caches embeddings to reduce computation
- Handles errors gracefully (doesn't fail entire extraction)

API Key Management:
- PydanticAI automatically reads API keys from environment variables:
  * OPENAI_API_KEY for OpenAI models
  * GOOGLE_API_KEY for Google Gemini models
  * CO_API_KEY for Cohere models
  * AWS credentials (AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY) for Bedrock
  * VOYAGE_API_KEY for VoyageAI models
- Set keys before running: export OPENAI_API_KEY='your-key-here'

"""

import asyncio
import contextlib
import hashlib
import json
import logging
import os
import time
import warnings
from collections.abc import Callable, Iterator
from contextvars import ContextVar
from pathlib import Path
from typing import TYPE_CHECKING, Any, cast

import numpy as np
from pydantic_ai import Embedder
from pydantic_ai.embeddings import EmbeddingSettings
from pydantic_ai.usage import RequestUsage

if TYPE_CHECKING:
    from pydantic_ai.embeddings.cohere import CohereEmbeddingSettings

from taxonomy_ontology_accelerator.commons.errors import ErrorCollector
from taxonomy_ontology_accelerator.commons.io.file_utils import (
    join_path,
    safe_read_file,
    safe_write_json,
)
from taxonomy_ontology_accelerator.commons.io.fsspec_utils import (
    get_default_filesystem,
    get_filesystem_from_config,
)
from taxonomy_ontology_accelerator.commons.utils.logger import get_logger
from taxonomy_ontology_accelerator.ontology_engine.config.config import OntologyConfig
from taxonomy_ontology_accelerator.ontology_engine.utils.runtime_context import (
    format_runtime_prefix,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.memory_utils import (
    check_memory_available,
    estimate_embeddings_memory,
)

logger = get_logger()
_CLOUD_PROTOCOLS = ("s3", "gs", "gcs", "az", "hdfs")
_embedding_usage_callbacks: ContextVar[tuple[Callable[[RequestUsage], None], ...]] = ContextVar(
    "_embedding_usage_callbacks",
    default=(),
)


def _format_embedding_exception(error: Exception) -> str:
    if isinstance(error, BaseExceptionGroup) and error.exceptions:
        first = error.exceptions[0]
        return f"{type(first).__name__}: {first}"
    return f"{type(error).__name__}: {error}"


def _extract_protocol(path_str: str) -> str | None:
    """Return the protocol prefix for cloud-style URIs."""
    assert path_str is not None, "path_str must not be None"
    for protocol in _CLOUD_PROTOCOLS:
        if path_str.startswith(f"{protocol}://") or path_str.startswith(f"{protocol}::"):
            return protocol
    return None


@contextlib.contextmanager
def capture_embedding_usage(callback: Callable[[RequestUsage], None]) -> Iterator[None]:
    """Capture embedding API usage emitted during the active context."""
    assert callback is not None, "callback must not be None"

    callbacks = _embedding_usage_callbacks.get()
    token = _embedding_usage_callbacks.set((*callbacks, callback))
    try:
        yield
    finally:
        _embedding_usage_callbacks.reset(token)


def _emit_embedding_usage(usage: RequestUsage | None) -> None:
    """Forward embedding usage to any active capture callbacks."""
    if usage is None:
        return

    input_tokens = getattr(usage, "input_tokens", 0)
    output_tokens = getattr(usage, "output_tokens", 0)
    cache_read_tokens = getattr(usage, "cache_read_tokens", 0)
    cache_write_tokens = getattr(usage, "cache_write_tokens", 0)

    if not isinstance(input_tokens, int):
        input_tokens = 0
    if not isinstance(output_tokens, int):
        output_tokens = 0
    if not isinstance(cache_read_tokens, int):
        cache_read_tokens = 0
    if not isinstance(cache_write_tokens, int):
        cache_write_tokens = 0

    total_tokens = (
        input_tokens
        + output_tokens
        + cache_read_tokens
        + cache_write_tokens
    )
    if total_tokens <= 0:
        return

    normalized_usage = RequestUsage(
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        cache_read_tokens=cache_read_tokens,
        cache_write_tokens=cache_write_tokens,
    )
    for callback in _embedding_usage_callbacks.get():
        callback(normalized_usage)


def _default_embeddings_storage_path(config: OntologyConfig) -> str:
    """Resolve the default embeddings storage path for the active filesystem."""
    assert config is not None, "config parameter is required"

    runtime_output_dir = getattr(config, "_runtime_output_dir", None)
    if runtime_output_dir:
        return str(
            join_path(
                runtime_output_dir,
                config.output.embeddings_directory,
                config.output.embeddings_filename,
            )
        )

    protocol = getattr(config.filesystem, "protocol", "local")
    if protocol == "local":
        cache_dir = config.embeddings.cache.directory
        return f"{cache_dir}/{config.embeddings.cache.file}"

    output_dir = str(config.output.base_directory).rstrip("/")
    domain_name = getattr(config, "domain_name", None)
    if config.output.append_domain_name and domain_name:
        output_dir = f"{output_dir}/{domain_name}/output"

    return str(
        join_path(
            output_dir,
            config.output.embeddings_directory,
            config.output.embeddings_filename,
        )
    )


def _resolve_embeddings_storage(
    config: OntologyConfig,
    embeddings_path: str | Path | None = None,
    fs=None,
) -> tuple[str, Any]:
    """Resolve the embeddings file path and filesystem for cache I/O."""
    assert config is not None, "config parameter is required"

    cache_file = (
        str(embeddings_path)
        if embeddings_path is not None
        else _default_embeddings_storage_path(config)
    )

    if fs is not None:
        return cache_file, fs

    cache_protocol = _extract_protocol(cache_file)
    if cache_protocol is None:
        return cache_file, get_default_filesystem()

    config_protocol = getattr(config.filesystem, "protocol", "local")
    config_options = getattr(config.filesystem, "options", None) or {}
    if cache_protocol == config_protocol:
        return cache_file, get_filesystem_from_config(cache_protocol, config_options)

    return cache_file, get_filesystem_from_config(cache_protocol, {})


# Constants
EMBEDDING_DIMENSION = 3072  # Default embedding dimension for gemini-embedding-001
LARGE_DATASET_FAISS_THRESHOLD = 10000  # Use IVF index for datasets larger than this
LINEAR_SEARCH_MAX_SIMILARITY_MATRIX_MB = 256.0
COHERE_TASK_TYPE_MAP = {
    "RETRIEVAL_DOCUMENT": "search_document",
    "RETRIEVAL_QUERY": "search_query",
    "SEMANTIC_SIMILARITY": "clustering",
    "CLASSIFICATION": "classification",
}


# Suppress httpx INFO logs for embedding API calls (too verbose)
# Only show WARNING/ERROR level logs from httpx during embedding operations
logging.getLogger("httpx").setLevel(logging.WARNING)

os.environ["TQDM_DISABLE"] = "1"  # Force disable (don't use setdefault - override if already set)
# Suppress tqdm progress bars (don't monkey-patch __init__ to avoid recursion)
# Instead, rely on TQDM_DISABLE environment variable and show_progress_bar=False

# ========================================================================
# Optional Dependencies
# ========================================================================
# Try to import FAISS (optional for large datasets)
# Suppress FAISS GPU warning BEFORE import (warning occurs during import)
# Set logging level for faiss.loader to suppress GPU-related warnings
logging.getLogger("faiss.loader").setLevel(logging.ERROR)
logging.getLogger("faiss").setLevel(logging.ERROR)


# Also suppress Python warnings about GPU (if any)
warnings.filterwarnings("ignore", message=".*GPU.*", category=UserWarning)
warnings.filterwarnings("ignore", message=".*GpuIndex.*", category=UserWarning)

try:
    import faiss  # type: ignore[reportMissingImports]

    FAISS_AVAILABLE = True
except ImportError:
    FAISS_AVAILABLE = False
    logger.warning(
        "FAISS not available - using linear search for semantic deduplication (slower for large datasets). "
        "Install with: pip install taxonomy-ontology-accelerator[embeddings]"
    )


def get_event_loop() -> asyncio.AbstractEventLoop:
    """Get or create event loop for current thread.

    Uses Python 3.12+ compatible pattern that avoids DeprecationWarning.
    This should only be called from sync context after verifying no loop is running.
    """
    # 1. Check if a loop is already running (e.g. inside an async context)
    # 1. Check if a loop is already running (e.g. inside an async context)
    try:
        return asyncio.get_running_loop()
    except RuntimeError:
        pass  # No running loop — expected in sync context

    # 2. Reuse existing loop or create new one via the policy (avoids top-level deprecation)
    policy = asyncio.get_event_loop_policy()
    assert policy is not None, "asyncio event loop policy must be available"
    try:
        loop = policy.get_event_loop()  # type: ignore[deprecated]  # safe: we handle RuntimeError
        if not loop.is_closed():
            return loop
    except RuntimeError:
        pass

    # 3. Create a fresh loop for this thread
    # 3. Create a fresh loop for this thread
    loop = policy.new_event_loop()
    assert not loop.is_closed(), "newly created event loop must not be closed"
    policy.set_event_loop(loop)
    return loop


def _text_hash(text: str) -> str:
    """Generate SHA256 hash for text (used as cache key)."""
    assert text is not None, "text parameter is required"
    assert isinstance(text, str), "text must be a string"
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _convert_embedding_to_list(embedding: Any) -> list[float] | None:
    """
    Convert embedding to list of floats (handles various input types).

    Args:
        embedding: Embedding in various formats (list, tuple, numpy array, etc.)

    Returns:
        List of floats, or None if conversion fails or embedding is empty
    """
    assert np is not None, "numpy must be available"
    assert logger is not None, "logger must be available"
    if embedding is None:
        return None

    result: list[float] | None = None

    # Handle list/tuple
    # Handle list/tuple
    if isinstance(embedding, list | tuple):
        result = [float(x) for x in embedding] if len(embedding) > 0 else None

    # Handle numpy array
    elif isinstance(embedding, np.ndarray):
        result = embedding.tolist()
    # Handle PyTorch tensors
    # Handle PyTorch tensors
    elif hasattr(embedding, "numpy"):
        result = embedding.detach().cpu().numpy().tolist()
    else:
        # Handle other iterables
        try:
            converted = [float(x) for x in iter(embedding)]
            result = converted if len(converted) > 0 else None
        except (TypeError, ValueError) as e:
            logger.warning(
                f"Failed to convert embedding to list of floats: {type(embedding)}, error: {e}"
            )

    return result


def _validate_embedding_dimension(
    embedding: list[float],
    expected_dimension: int,
    context: str = "",
) -> bool:
    """
    Validate embedding dimension and log warning if mismatch.

    Args:
        embedding: Embedding vector
        expected_dimension: Expected dimension
        context: Optional context string for logging

    Returns:
        True if dimension matches or is acceptable, False otherwise
    """
    assert embedding is not None, "embedding parameter is required"
    assert isinstance(expected_dimension, int), "expected_dimension must be an integer"
    if len(embedding) != expected_dimension:
        context_str = f" for {context}" if context else ""
        logger.warning(
            f"Embedding dimension mismatch{context_str}: "
            f"got {len(embedding)}, expected {expected_dimension}"
        )
        return False
    return True


def cosine_similarity(embedding1: list[float], embedding2: list[float]) -> float:
    """
    Calculate cosine similarity between two embeddings.

    Args:
        embedding1: First embedding vector
        embedding2: Second embedding vector

    Returns:
        Cosine similarity score (0.0-1.0)

    Raises:
        ValueError: If embeddings have different dimensions or are empty
    """
    assert embedding1 is not None, "embedding1 parameter is required"
    assert embedding2 is not None, "embedding2 parameter is required"
    if not embedding1 or not embedding2:
        raise ValueError("Embeddings cannot be empty")

    if len(embedding1) != len(embedding2):
        raise ValueError(f"Embedding dimensions must match: {len(embedding1)} != {len(embedding2)}")

    a_arr = np.array(embedding1, dtype=np.float32)
    b_arr = np.array(embedding2, dtype=np.float32)

    # Calculate cosine similarity: dot product / (norm1 * norm2)
    # Calculate cosine similarity: dot product / (norm1 * norm2)
    dot_product = np.dot(a_arr, b_arr)
    norm1 = np.linalg.norm(a_arr)
    norm2 = np.linalg.norm(b_arr)

    if norm1 == 0.0 or norm2 == 0.0:
        return 0.0

    similarity = float(dot_product / (norm1 * norm2))
    # Clamp to [0, 1] range (should already be in range, but ensure for numerical stability)
    # Clamp to [0, 1] range (should already be in range, but ensure for numerical stability)
    return max(0.0, min(1.0, similarity))


def _map_model_name_to_pydantic_format(model_name: str) -> str:
    """
    Map user-friendly model names to PydanticAI provider:model format.

    Args:
        model_name: Model name in any format

    Returns:
        Model name in provider:model format
    """
    assert model_name is not None, "model_name is required"
    assert isinstance(model_name, str), "model_name must be a string"

    # If already has provider prefix, return as-is
    # If already has provider prefix, return as-is
    if ":" in model_name:
        return model_name

    # Convert Google model names to google-gla: prefix
    # Google models: embedding-001, gemini-embedding-001, etc.
    if model_name.startswith(("embedding-", "text-embedding")) or model_name in [
        "embedding-001",
        "gemini-embedding-001",
    ]:
        return f"google-gla:{model_name}"

    # Otherwise, assume it's a Google model and add prefix
    # Otherwise, assume it's a Google model and add prefix
    return f"google-gla:{model_name}"


def _is_cohere_model(model_name: str) -> bool:
    assert model_name is not None, "model_name is required"
    assert isinstance(model_name, str), "model_name must be a string"
    return "cohere" in model_name.lower()


def _apply_provider_embedding_settings(settings: EmbeddingSettings, config: OntologyConfig) -> None:
    assert settings is not None, "settings is required"
    assert config is not None, "config parameter is required"
    model_name = config.embeddings.model
    # ========================================================================
    if _is_cohere_model(model_name):
        mapped = COHERE_TASK_TYPE_MAP.get(config.embeddings.task_type)
        if mapped:
            cohere_settings = cast("CohereEmbeddingSettings", settings)
            cohere_settings["cohere_input_type"] = mapped


def _validate_embedding_input(text: str) -> bool:
    """
    Validate input text for embedding generation.

    Args:
        text: Text to validate

    Returns:
        True if valid, False if empty
    """
    assert text is not None, "text parameter is required"
    assert isinstance(text, str), "text must be a string"
    if not text or not text.strip():
        logger.warning("Empty text provided for embedding generation")
        return False
    return True


def _warn_dimension_mismatch(config: OntologyConfig) -> None:
    """
    Log warning if config dimension doesn't match model dimension.

    Args:
        config: Ontology configuration
    """
    assert config is not None, "config parameter is required"
    assert hasattr(config, "embeddings"), "config must have embeddings attribute"
    if config.embeddings.dimension != EMBEDDING_DIMENSION:
        logger.warning(
            f"Config dimension is {config.embeddings.dimension}, "
            f"but both supported models use {EMBEDDING_DIMENSION} dimensions. Using {EMBEDDING_DIMENSION} dimensions."
        )


async def generate_embedding_async(text: str, config: OntologyConfig) -> list[float] | None:
    """Generate embedding for text (async, primary implementation).
    Returns embedding vector or None if generation fails."""
    assert text is not None, "text parameter is required"
    assert config is not None, "config parameter is required"
    if not _validate_embedding_input(text):
        return None

    try:
        model_name = config.embeddings.model
        pydantic_model = _map_model_name_to_pydantic_format(model_name)
        settings = EmbeddingSettings()
        if config.embeddings.dimension != EMBEDDING_DIMENSION:
            settings["dimensions"] = config.embeddings.dimension
        _apply_provider_embedding_settings(settings, config)

        embedder = Embedder(pydantic_model, settings=settings)
        result = await embedder.embed_documents([text])

        if not result or not result.embeddings:
            return None

        _emit_embedding_usage(getattr(result, "usage", None))

        embedding = _convert_embedding_to_list(result.embeddings[0])
        if embedding:
            _validate_embedding_dimension(embedding, config.embeddings.dimension)
        return embedding
    except Exception as e:
        logger.error(
            f"{format_runtime_prefix()}Failed to generate embedding: {_format_embedding_exception(e)}"
        )
        return None


def generate_embedding(text: str, config: OntologyConfig) -> list[float] | None:
    """Generate embedding (sync wrapper, use async version for better performance).
    Returns embedding vector or None if generation fails.

    Raises:
        RuntimeError: If called from an async context. Use generate_embedding_async() instead.
    """
    assert text is not None, "text parameter is required"
    assert config is not None, "config parameter is required"

    # Check if there's already a running event loop
    # Check if there's already a running event loop
    try:
        asyncio.get_running_loop()
        raise RuntimeError(
            "generate_embedding() cannot be called from async context. "
            "Use 'await generate_embedding_async()' instead."
        )
    except RuntimeError as e:
        if "cannot be called from async context" in str(e):
            raise
        # No running loop - safe to proceed with sync wrapper
        # No running loop - safe to proceed with sync wrapper
        loop = get_event_loop()
        return loop.run_until_complete(generate_embedding_async(text, config))


def _collect_texts_for_embedding(
    texts: list[str], existing_embeddings: dict[str, list[float]]
) -> tuple[dict[str, list[float]], list[tuple[str, str]]]:
    """Collect texts that need embedding generation, checking cache."""
    assert texts is not None, "texts parameter is required"
    assert existing_embeddings is not None, "existing_embeddings must not be None"

    embeddings: dict[str, list[float]] = {}
    to_generate: list[tuple[str, str]] = []
    seen_hashes: set[str] = set()

    for text in texts:
        if not text or not text.strip():
            continue
        text_hash = _text_hash(text)
        if text_hash in seen_hashes:
            continue
        seen_hashes.add(text_hash)
        if text_hash in existing_embeddings:
            embeddings[text_hash] = existing_embeddings[text_hash]
        else:
            to_generate.append((text, text_hash))

    return embeddings, to_generate


async def generate_embeddings_batch_async(
    texts: list[str],
    config: OntologyConfig,
    error_collector: ErrorCollector | None = None,
    embeddings_path: Path | str | None = None,
    concurrency: int | None = None,
    fs=None,
) -> tuple[dict[str, list[float]], int]:
    """Generate embeddings with concurrency (async, primary implementation).
    Returns (embeddings_dict, count_generated) with semaphore-controlled parallelism."""
    assert texts is not None, "texts is required"
    assert config is not None, "config is required"
    if not texts:
        return {}, 0

    effective_concurrency = concurrency or config.embeddings.concurrency
    if effective_concurrency < 1:
        effective_concurrency = 1

    existing_embeddings = load_embeddings(config, embeddings_path, fs=fs)
    embeddings, to_generate = _collect_texts_for_embedding(texts, existing_embeddings)

    if not to_generate:
        return embeddings, 0

    embedding_stage_start = time.perf_counter()
    logger.info(
        f"{format_runtime_prefix()}Generating {len(to_generate)} embeddings (concurrency: {effective_concurrency})..."
    )
    semaphore = asyncio.Semaphore(effective_concurrency)

    async def embed_one(text: str, text_hash: str) -> bool:
        assert text is not None, "text must not be None"
        assert text_hash is not None, "text_hash must not be None"
        async with semaphore:
            try:
                embedding = await generate_embedding_async(text, config)
                if embedding:
                    embeddings[text_hash] = embedding
                    existing_embeddings[text_hash] = embedding
                    return True
            except Exception as e:
                logger.error(
                    f"{format_runtime_prefix()}Failed to generate embedding: {_format_embedding_exception(e)}"
                )
                if error_collector:
                    error_collector.add_error("embedding_generation", str(e))
        return False

    tasks = [embed_one(text, hash_) for text, hash_ in to_generate]
    results = await asyncio.gather(*tasks, return_exceptions=True)
    generated_count = sum(1 for r in results if r is True)

    if generated_count > 0:
        logger.info(f"{format_runtime_prefix()}Generated {generated_count} embeddings successfully")
        save_embeddings(existing_embeddings, config, embeddings_path, fs=fs)
    else:
        logger.warning(
            f"{format_runtime_prefix()}Failed to generate any embeddings from {len(to_generate)} attempts"
        )

    embedding_elapsed = time.perf_counter() - embedding_stage_start
    logger.debug(
        f"Stage 'embedding_generation' took {embedding_elapsed:.3f}s "
        f"({generated_count}/{len(to_generate)} generated)"
    )

    return embeddings, generated_count


def generate_embeddings_batch(
    texts: list[str],
    config: OntologyConfig,
    error_collector: ErrorCollector | None = None,
    embeddings_path: Path | str | None = None,
) -> tuple[dict[str, list[float]], int]:
    """Generate embeddings batch (sync wrapper, use async version for better performance).
    Returns (embeddings_dict, count_generated) with cached results.

    Raises:
        RuntimeError: If called from an async context. Use generate_embeddings_batch_async() instead.
    """
    assert texts is not None, "texts is required"
    assert config is not None, "config is required"
    concurrency = config.embeddings.concurrency

    # Check if there's already a running event loop
    # Check if there's already a running event loop
    try:
        asyncio.get_running_loop()
        raise RuntimeError(
            "generate_embeddings_batch() cannot be called from async context. "
            "Use 'await generate_embeddings_batch_async()' instead."
        )
    except RuntimeError as e:
        if "cannot be called from async context" in str(e):
            raise
        # No running loop - safe to proceed with sync wrapper
        # No running loop - safe to proceed with sync wrapper
        loop = get_event_loop()
        return loop.run_until_complete(
            generate_embeddings_batch_async(
                texts, config, error_collector, embeddings_path, concurrency,
            )
        )


def _check_embeddings_memory(cache_file: str, config: OntologyConfig, fs=None) -> None:
    """Check memory availability before loading embeddings file."""
    assert cache_file is not None, "cache_file parameter is required"
    assert config is not None, "config parameter is required"

    from taxonomy_ontology_accelerator.commons.io.fsspec_utils import get_default_filesystem

    if fs is None:
        fs = get_default_filesystem()

    if not config.memory.check_available:
        return
    try:
        info = fs.info(cache_file)
        file_size_mb = info.get("size", 0) / (1024 * 1024)
        estimated_entity_count = int((file_size_mb * 1024) / 3)
        if estimated_entity_count > 0:
            estimated_memory = estimate_embeddings_memory(
                estimated_entity_count, config.embeddings.dimension
            )
            check_memory_available(estimated_memory, config, "embeddings")
    except OSError:
        pass  # Ignore stat errors, proceed with loading


def _validate_embeddings_data(embeddings_data: Any) -> dict[str, list[float]]:
    """Validate and convert embeddings data to proper format."""
    assert embeddings_data is not None, "embeddings_data parameter is required"
    assert logger is not None, "logger must be available"
    if not isinstance(embeddings_data, dict):
        logger.warning(
            f"Invalid embeddings cache structure: expected dict, got {type(embeddings_data)}"
        )
        return {}

    valid_embeddings: dict[str, list[float]] = {}
    for key, value in embeddings_data.items():
        if isinstance(value, list) and all(isinstance(x, int | float) for x in value):
            valid_embeddings[key] = [float(x) for x in value]
        else:
            logger.warning(f"Invalid embedding format for key {key}: expected list of numbers")
    return valid_embeddings


def load_embeddings(
    config: OntologyConfig, embeddings_path: str | Path | None = None, fs=None
) -> dict[str, list[float]]:
    """
    Load embeddings from embeddings.json file.

    Args:
        config: Ontology configuration
        embeddings_path: Optional path to embeddings file (str or Path). If None, uses config path.
        fs: Optional filesystem instance (defaults to local filesystem)

    Returns:
        Dictionary mapping text hash to embedding vector

    Note:
        Returns empty dict if file doesn't exist or is corrupted.
        Errors are logged but don't raise exceptions.
    """
    assert config is not None, "config parameter is required"
    assert hasattr(config, "embeddings"), "config must have embeddings attribute"

    if not config.embeddings.cache.enabled:
        return {}

    cache_file, fs = _resolve_embeddings_storage(config, embeddings_path, fs)

    if not fs.exists(cache_file):
        logger.debug(f"Embeddings cache file not found: {cache_file}")
        return {}

    _check_embeddings_memory(cache_file, config, fs=fs)

    try:
        embeddings_data = json.loads(safe_read_file(cache_file, fs=fs))
        valid_embeddings = _validate_embeddings_data(embeddings_data)
        logger.debug(f"Loaded {len(valid_embeddings)} embeddings from cache")
        return valid_embeddings
    except (json.JSONDecodeError, OSError) as e:
        logger.warning(f"Failed to load embeddings cache: {e}")
        return {}
    except Exception as e:
        logger.error(f"Unexpected error loading embeddings cache: {e}")
        return {}


def save_embeddings(
    embeddings: dict[str, list[float]],
    config: OntologyConfig,
    embeddings_path: str | Path | None = None,
    fs=None,
) -> None:
    """
    Save embeddings to embeddings.json file.

    Args:
        embeddings: Dictionary mapping text hash to embedding vector
        config: Ontology configuration
        embeddings_path: Optional path to embeddings file (str or Path). If None, uses config path.
        fs: Optional filesystem instance (defaults to local filesystem)

    Note:
        Creates cache directory if it doesn't exist.
        Errors are logged but don't raise exceptions.
    """
    assert embeddings is not None, "embeddings parameter is required"
    assert config is not None, "config parameter is required"

    if not config.embeddings.cache.enabled:
        logger.debug("Embeddings caching is disabled")
        return

    if not embeddings:
        logger.debug("No embeddings to save")
        return

    cache_file, fs = _resolve_embeddings_storage(config, embeddings_path, fs)

    try:
        parent_dir = cache_file.rsplit("/", 1)[0] if "/" in cache_file else "."
        fs.makedirs(parent_dir, exist_ok=True)

        # Save embeddings as JSON
        safe_write_json(cache_file, embeddings, fs=fs)
        logger.debug(f"Saved {len(embeddings)} embeddings to cache: {cache_file}")

    except OSError as e:
        logger.error(f"Failed to save embeddings cache: {e}")
    except Exception as e:
        logger.error(f"Unexpected error saving embeddings cache: {e}")


class FAISSIndex:
    """
    FAISS index wrapper for efficient similarity search.

    Uses FAISS for approximate nearest neighbor search when entity count
    exceeds config.faiss.threshold. Falls back to linear search for smaller datasets.
    """

    def __init__(
        self, dimension: int, index_type: str = "auto", config: OntologyConfig | None = None
    ):
        """
        Initialize FAISS index.

        Args:
            dimension: Embedding dimension
            index_type: FAISS index type ("auto", "IndexFlatL2", "IndexIVFFlat", "IndexHNSW")
                       "auto" selects based on dimension and expected size
            config: Optional OntologyConfig for memory checking
        """
        assert isinstance(dimension, int), "dimension must be an integer"
        assert isinstance(index_type, str), "index_type must be a string"
        self.dimension = dimension
        self.index_type = index_type
        self.index: Any = None
        self.id_to_index: dict[str, int] = {}  # Map entity ID to FAISS index position
        self.index_to_id: dict[int, str] = {}  # Reverse mapping
        self._built = False
        self._config = config  # Store config for memory checking

    def _convert_embeddings_to_list(self, embeddings: dict[str, list[float]]) -> list[list[float]]:
        """
        Convert embeddings dict to list, filtering invalid dimensions.

        Args:
            embeddings: Dictionary mapping entity ID to embedding vector

        Returns:
            List of valid embeddings
        """
        assert embeddings is not None, "embeddings parameter is required"
        assert isinstance(embeddings, dict), "embeddings must be a dictionary"
        embedding_list = []
        for entity_id, embedding in embeddings.items():
            if len(embedding) != self.dimension:
                logger.warning(
                    f"Skipping embedding with wrong dimension: "
                    f"got {len(embedding)}, expected {self.dimension}"
                )
                continue

            index_pos = len(embedding_list)
            embedding_list.append(embedding)
            self.id_to_index[entity_id] = index_pos
            self.index_to_id[index_pos] = entity_id

        return embedding_list

    def _check_build_memory(self, num_embeddings: int) -> None:
        """
        Check memory availability before building index.

        Args:
            num_embeddings: Number of embeddings

        Raises:
            MemoryError: If insufficient memory
        """
        assert isinstance(num_embeddings, int), "num_embeddings must be an integer"
        assert num_embeddings >= 0, "num_embeddings must be non-negative"
        if not self._config:
            return

        embeddings_array_mb = (num_embeddings * self.dimension * 4) / (1024 * 1024)
        index_overhead_mb = embeddings_array_mb * 0.3
        total_estimated_mb = int(embeddings_array_mb + index_overhead_mb)

        from taxonomy_ontology_accelerator.ontology_engine.utils.memory_utils import (
            check_memory_available,
        )

        try:
            check_memory_available(total_estimated_mb, self._config, "faiss_index")
        except MemoryError as e:
            error_msg = (
                f"Insufficient memory to build FAISS index: {e}. "
                f"Estimated need: {total_estimated_mb}MB for {num_embeddings} embeddings. "
                f"Consider using linear search instead or reducing embedding count."
            )
            logger.error(error_msg)
            raise MemoryError(error_msg) from e

    def _normalize_embeddings(self, embedding_list: list[list[float]]):
        """
        Normalize embeddings for cosine similarity.

        Args:
            embedding_list: List of embedding vectors

        Returns:
            Normalized numpy array
        """
        assert embedding_list is not None, "embedding_list parameter is required"
        assert isinstance(embedding_list, list), "embedding_list must be a list"
        embeddings_array = np.array(embedding_list, dtype=np.float32)
        norms = np.linalg.norm(embeddings_array, axis=1, keepdims=True)
        norms[norms == 0] = 1.0
        return embeddings_array / norms

    def _check_index_flat_ip_available(self) -> bool:
        """Check if IndexFlatIP is available in FAISS."""
        assert self is not None, "self must be available"
        assert FAISS_AVAILABLE is not None, "FAISS_AVAILABLE must be defined"
        try:
            return hasattr(faiss, "IndexFlatIP")
        except Exception:
            return False

    def _create_ivf_index_factory(self, num_embeddings: int, has_flat_ip: bool):
        """
        Create an IndexIVFFlat factory function.

        Args:
            num_embeddings: Number of embeddings for nlist calculation
            has_flat_ip: Whether IndexFlatIP is available

        Returns:
            Factory function that creates the index
        """
        assert isinstance(num_embeddings, int), "num_embeddings must be an integer"
        assert isinstance(has_flat_ip, bool), "has_flat_ip must be a boolean"
        nlist = min(100, num_embeddings // 10)
        if has_flat_ip:
            quantizer = faiss.IndexFlatIP(self.dimension)
        else:
            logger.warning("IndexFlatIP not available, using IndexFlatL2 quantizer")
            quantizer = faiss.IndexFlatL2(self.dimension)

        def factory():
            assert quantizer is not None, "quantizer must be available in closure"
            assert nlist > 0, "nlist must be positive"
            return faiss.IndexIVFFlat(quantizer, self.dimension, nlist)

        return factory

    def _select_index_type(self, num_embeddings: int, has_flat_ip: bool):
        """
        Select appropriate FAISS index type based on configuration.

        Args:
            num_embeddings: Number of embeddings
            has_flat_ip: Whether IndexFlatIP is available

        Returns:
            Index type or factory function
        """
        assert isinstance(num_embeddings, int), "num_embeddings must be an integer"
        assert isinstance(has_flat_ip, bool), "has_flat_ip must be a boolean"
        # Handle "auto" mode
        # Handle "auto" mode
        if self.index_type == "auto":
            return self._select_auto_index(num_embeddings, has_flat_ip)

        # Handle known index types — all return factory functions (callable, no args)
        dim = self.dimension
        known_types = {
            "IndexFlatL2": lambda: lambda: faiss.IndexFlatL2(dim),
            "IndexIVFFlat": lambda: self._create_ivf_index_factory(num_embeddings, has_flat_ip),
            "IndexHNSW": lambda: lambda: faiss.IndexHNSWFlat(dim, 32),
        }

        if self.index_type in known_types:
            return known_types[self.index_type]()

        # Fallback for unknown types
        logger.warning(f"Unknown index type: {self.index_type}, using default")
        if has_flat_ip:
            return lambda: faiss.IndexFlatIP(dim)
        return lambda: faiss.IndexFlatL2(dim)

    def _select_auto_index(self, num_embeddings: int, has_flat_ip: bool):
        """
        Select index type automatically based on embedding count.

        Args:
            num_embeddings: Number of embeddings
            has_flat_ip: Whether IndexFlatIP is available

        Returns:
            Factory function that creates the index (always callable with no args)
        """
        assert isinstance(num_embeddings, int), "num_embeddings must be an integer"
        assert isinstance(has_flat_ip, bool), "has_flat_ip must be a boolean"
        if num_embeddings >= LARGE_DATASET_FAISS_THRESHOLD:
            return self._create_ivf_index_factory(num_embeddings, has_flat_ip)

        dim = self.dimension
        if has_flat_ip:
            return lambda: faiss.IndexFlatIP(dim)

        logger.warning("IndexFlatIP not available, using IndexFlatL2")
        return lambda: faiss.IndexFlatL2(dim)

    def _create_and_train_index(self, index_type_actual, embeddings_array_normalized) -> None:
        """
        Create and optionally train the FAISS index.

        Args:
            index_type_actual: Index type class or factory function
            embeddings_array_normalized: Normalized embeddings array
        """
        assert index_type_actual is not None, "index_type_actual parameter is required"
        assert embeddings_array_normalized is not None, (
            "embeddings_array_normalized parameter is required"
        )
        if callable(index_type_actual):
            self.index = index_type_actual()
            if hasattr(self.index, "train"):
                self.index.train(embeddings_array_normalized)
        else:
            self.index = index_type_actual(self.dimension)

        self.index.add(embeddings_array_normalized)

    def build(self, embeddings: dict[str, list[float]]) -> None:
        """
        Build FAISS index from embeddings.

        Args:
            embeddings: Dictionary mapping entity ID (or text hash) to embedding vector
        """
        assert embeddings is not None, "embeddings parameter is required"
        assert isinstance(embeddings, dict), "embeddings must be a dictionary"
        if not FAISS_AVAILABLE:
            logger.warning("FAISS not available - cannot build index")
            return

        if not embeddings:
            logger.warning("No embeddings provided for FAISS index")
            return

        try:
            embedding_list = self._convert_embeddings_to_list(embeddings)

            if not embedding_list:
                logger.warning("No valid embeddings for FAISS index")
                return

            num_embeddings = len(embedding_list)
            self._check_build_memory(num_embeddings)

            embeddings_array_normalized = self._normalize_embeddings(embedding_list)

            has_flat_ip = self._check_index_flat_ip_available()
            index_type_actual = self._select_index_type(num_embeddings, has_flat_ip)

            self._create_and_train_index(index_type_actual, embeddings_array_normalized)
            self._built = True

            logger.semantic(
                f"Built FAISS index | Type: {self.index_type} | Embeddings: {num_embeddings:,} | Dimension: {self.dimension}"
            )

        except MemoryError:
            self.index = None
            self._built = False
            raise
        except Exception as e:
            error_msg = (
                f"Failed to build FAISS index: {type(e).__name__}: {e}. "
                f"This may indicate invalid embeddings, dimension mismatch, "
                f"or FAISS installation issues. "
                f"Check embedding dimensions ({self.dimension}) and ensure FAISS is properly installed."
            )
            logger.error(error_msg)
            self.index = None
            self._built = False

    def search(
        self, query_embedding: list[float], top_k: int, similarity_threshold: float = 0.0
    ) -> list[tuple[str, float]]:
        """
        Search for similar embeddings (single query).

        Args:
            query_embedding: Query embedding vector
            top_k: Number of results to return
            similarity_threshold: Minimum similarity score (0.0-1.0)

        Returns:
            List of (entity_id, similarity_score) tuples, sorted by similarity (descending)
        """
        assert query_embedding is not None, "query_embedding parameter is required"
        assert isinstance(top_k, int), "top_k must be an integer"
        results = self.search_batch([query_embedding], top_k, similarity_threshold)
        return results[0] if results else []

    def _validate_query_dimensions(self, query_embeddings: list[list[float]]) -> bool:
        """
        Validate that all query embeddings have the expected dimension.

        Returns:
            True if all dimensions are valid, False otherwise
        """
        assert query_embeddings is not None, "query_embeddings parameter is required"
        assert isinstance(query_embeddings, list), "query_embeddings must be a list"
        for i, query_emb in enumerate(query_embeddings):
            if len(query_emb) != self.dimension:
                logger.warning(
                    f"Query embedding {i} dimension mismatch: got {len(query_emb)}, "
                    f"expected {self.dimension}"
                )
                return False
        return True

    def _check_search_memory(self, num_queries: int, expected_dim: int, top_k: int) -> None:
        """
        Check if there's enough memory for FAISS search.

        Raises:
            MemoryError: If insufficient memory
        """
        assert isinstance(num_queries, int), "num_queries must be an integer"
        assert isinstance(expected_dim, int), "expected_dim must be an integer"
        # Estimate memory: query_matrix + normalized + search results
        # Estimate memory: query_matrix + normalized + search results
        query_matrix_mb = (num_queries * expected_dim * 4) / (1024 * 1024)
        results_mb = (num_queries * top_k * 8) / (1024 * 1024)
        total_estimated_mb = query_matrix_mb + results_mb

        if hasattr(self, "_config") and self._config:
            from taxonomy_ontology_accelerator.ontology_engine.utils.memory_utils import (
                check_memory_available,
            )

            try:
                check_memory_available(int(total_estimated_mb), self._config, "faiss_search")
            except MemoryError as e:
                error_msg = (
                    f"Insufficient memory for FAISS search: {e}. "
                    f"Estimated need: {total_estimated_mb:.1f}MB for {num_queries} "
                    f"queries with top_k={top_k}."
                )
                logger.error(error_msg)
                raise

    def _normalize_query_matrix(self, query_embeddings: list[list[float]]) -> "np.ndarray":
        """
        Convert and normalize query embeddings for cosine similarity.

        Returns:
            Normalized numpy array of query embeddings
        """
        assert query_embeddings is not None, "query_embeddings parameter is required"
        assert isinstance(query_embeddings, list), "query_embeddings must be a list"
        query_matrix = np.array(query_embeddings, dtype=np.float32)
        query_norms = np.linalg.norm(query_matrix, axis=1, keepdims=True)
        query_matrix_normalized = query_matrix / (query_norms + 1e-8)

        if np.any(query_norms == 0):
            logger.warning("Some query embeddings have zero norm")

        return query_matrix_normalized

    def _convert_score_to_similarity(self, score: float, is_ip_index: bool) -> float:
        """
        Convert FAISS score to cosine similarity.

        Args:
            score: Raw FAISS score
            is_ip_index: Whether index is inner product type

        Returns:
            Cosine similarity score in [0, 1]
        """
        assert isinstance(is_ip_index, bool), "is_ip_index must be a boolean"
        assert score is not None, "score must not be None"
        if is_ip_index:
            return float(score)

        # L2 distance on normalized vectors: cosine_sim = 1 - (L2_distance^2 / 2)
        return max(0.0, min(1.0, 1.0 - (float(score) ** 2 / 2.0)))

    def _process_search_results(
        self,
        distances: "np.ndarray",
        indices: "np.ndarray",
        num_queries: int,
        similarity_threshold: float,
    ) -> list[list[tuple[str, float]]]:
        """
        Process FAISS search results into entity ID -> similarity mappings.

        Args:
            distances: FAISS distance/similarity array
            indices: FAISS index array
            num_queries: Number of queries
            similarity_threshold: Minimum similarity threshold

        Returns:
            List of result lists for each query
        """
        assert distances is not None, "distances parameter is required"
        assert indices is not None, "indices parameter is required"
        try:
            is_ip_index = isinstance(self.index, faiss.IndexFlatIP)
        except Exception:
            is_ip_index = False

        batch_results: list[list[tuple[str, float]]] = []
        for query_idx in range(num_queries):
            query_results: list[tuple[str, float]] = []

            for score, idx in zip(distances[query_idx], indices[query_idx], strict=False):
                if idx < 0:
                    continue

                entity_id = self.index_to_id.get(int(idx))
                if not entity_id:
                    continue

                similarity = self._convert_score_to_similarity(score, is_ip_index)
                if similarity >= similarity_threshold:
                    query_results.append((entity_id, similarity))

            batch_results.append(query_results)

        return batch_results

    def _can_perform_search(
        self, query_embeddings: list[list[float]], top_k: int
    ) -> tuple[bool, str]:
        """
        Check if search can be performed with given inputs.

        Returns:
            Tuple of (can_search, reason) where reason explains failure
        """
        assert isinstance(top_k, int), "top_k must be an integer"
        assert query_embeddings is None or isinstance(query_embeddings, list), (
            "query_embeddings must be a list or None"
        )
        if not self._built or not self.index:
            return False, "index_not_built"
        if not query_embeddings:
            return False, "empty_queries"
        if not self._validate_query_dimensions(query_embeddings):
            return False, "dimension_mismatch"
        if top_k <= 0:
            return False, "invalid_top_k"
        return True, ""

    def search_batch(
        self, query_embeddings: list[list[float]], top_k: int, similarity_threshold: float = 0.0
    ) -> list[list[tuple[str, float]]]:
        """
        Search for similar embeddings (batch queries).

        Args:
            query_embeddings: List of query embedding vectors
            top_k: Number of results to return per query
            similarity_threshold: Minimum similarity score (0.0-1.0)

        Returns:
            List of result lists, one per query. Each result list contains
            (entity_id, similarity_score) tuples, sorted by similarity (descending)
        """
        assert query_embeddings is not None, "query_embeddings parameter is required"
        assert isinstance(top_k, int), "top_k must be an integer"
        can_search, reason = self._can_perform_search(query_embeddings, top_k)
        if not can_search:
            return [] if reason == "empty_queries" else [[] for _ in query_embeddings]

        empty_results = [[] for _ in query_embeddings]

        try:
            num_queries = len(query_embeddings)
            if num_queries > 0:
                self._check_search_memory(num_queries, len(query_embeddings[0]), top_k)

            query_matrix_normalized = self._normalize_query_matrix(query_embeddings)
            distances, indices = self.index.search(query_matrix_normalized, top_k)

            if distances.size == 0 or indices.size == 0:
                return empty_results

            return self._process_search_results(
                distances, indices, num_queries, similarity_threshold
            )

        except MemoryError:
            logger.error(
                "Insufficient memory for FAISS batch search. "
                "Consider reducing query batch size or using linear search."
            )
        except Exception as e:
            logger.error(
                f"FAISS batch search failed: {type(e).__name__}: {e}. "
                f"Check embedding dimensions and FAISS index integrity."
            )

        return empty_results


def _process_faiss_batch_results(
    batch_query_ids: list[str],
    batch_results: list,
    duplicates: dict[str, tuple[str, float]],
) -> None:
    """Process FAISS batch search results and update duplicates dict."""
    assert batch_query_ids is not None, "batch_query_ids parameter is required"
    assert duplicates is not None, "duplicates parameter is required"

    for query_idx, query_id in enumerate(batch_query_ids):
        results = batch_results[query_idx] if query_idx < len(batch_results) else []
        if results:
            best_match_id, best_similarity = results[0]
            duplicates[query_id] = (best_match_id, best_similarity)


def _find_duplicates_with_faiss(
    query_embeddings: dict[str, list[float]],
    existing_embeddings: dict[str, list[float]],
    config: OntologyConfig,
) -> dict[str, tuple[str, float]]:
    """Find semantic duplicates using FAISS index."""
    assert query_embeddings is not None, "query_embeddings parameter is required"
    assert config is not None, "config parameter is required"

    logger.info(
        f"Using FAISS ({len(existing_embeddings)} existing, {len(query_embeddings)} queries)"
    )

    faiss_index = FAISSIndex(
        dimension=config.embeddings.dimension,
        index_type=config.deduplication.faiss.index_type,
        config=config,
    )
    faiss_index.build(existing_embeddings)

    if not faiss_index._built:
        return {}

    duplicates: dict[str, tuple[str, float]] = {}
    batch_size = config.deduplication.faiss.batch_size
    top_k = config.deduplication.faiss.top_k
    threshold = config.deduplication.semantic_threshold
    query_items = list(query_embeddings.items())

    for i in range(0, len(query_items), batch_size):
        batch = query_items[i : i + batch_size]
        ids = [qid for qid, _ in batch]
        embs = [emb for _, emb in batch]
        results = faiss_index.search_batch(embs, top_k, threshold)
        _process_faiss_batch_results(ids, results, duplicates)

    return duplicates


def _check_linear_search_memory(
    num_existing: int,
    num_queries: int,
    expected_dim: int,
    batch_size: int,
    config: OntologyConfig,
) -> None:
    """
    Check memory availability for linear search.

    Args:
        num_existing: Number of existing embeddings
        num_queries: Number of query embeddings
        expected_dim: Embedding dimension
        batch_size: Batch size for processing
        config: Ontology configuration

    Raises:
        MemoryError: If insufficient memory
    """
    assert isinstance(num_existing, int), "num_existing must be an integer"
    assert config is not None, "config parameter is required"
    existing_matrix_mb = (num_existing * expected_dim * 4) / (1024 * 1024)
    query_matrix_mb = (batch_size * expected_dim * 4) / (1024 * 1024)
    similarity_matrix_mb = (batch_size * num_existing * 4) / (1024 * 1024)
    total_estimated_mb = existing_matrix_mb + query_matrix_mb + similarity_matrix_mb

    from taxonomy_ontology_accelerator.ontology_engine.utils.memory_utils import (
        check_memory_available,
    )

    try:
        check_memory_available(int(total_estimated_mb), config, "semantic_deduplication")
    except MemoryError as e:
        error_msg = (
            f"Insufficient memory for semantic deduplication: {e}. "
            f"Estimated need: {total_estimated_mb:.1f}MB for {num_existing} existing "
            f"and {num_queries} query embeddings. "
            f"Consider reducing batch size (current: {batch_size}) or using FAISS."
        )
        logger.error(error_msg)
        logger.info("Falling back to individual embedding comparisons (lower memory usage)")
        raise


def _process_linear_batch(
    batch_queries: list[tuple[str, list[float]]],
    existing_matrix_normalized,
    existing_ids,
    expected_dim: int,
    semantic_threshold: float,
) -> dict[str, tuple[str, float]]:
    """
    Process a single batch of queries using linear search.

    Args:
        batch_queries: List of (query_id, embedding) tuples
        existing_matrix_normalized: Normalized existing embeddings matrix
        existing_ids: Array of existing entity IDs
        expected_dim: Expected embedding dimension
        semantic_threshold: Minimum similarity threshold

    Returns:
        Dictionary of matches for this batch
    """
    assert batch_queries is not None, "batch_queries parameter is required"
    assert existing_matrix_normalized is not None, (
        "existing_matrix_normalized parameter is required"
    )
    duplicates: dict[str, tuple[str, float]] = {}

    query_ids = [qid for qid, _ in batch_queries]
    query_matrix = np.array([emb for _, emb in batch_queries], dtype=np.float32)

    if query_matrix.size == 0:
        return duplicates

    if len(query_matrix.shape) > 1 and query_matrix.shape[1] != expected_dim:
        logger.warning(
            f"Dimension mismatch: query embeddings have {query_matrix.shape[1]} dims, "
            f"expected {expected_dim}. Skipping batch."
        )
        return duplicates

    query_norms = np.linalg.norm(query_matrix, axis=1, keepdims=True)
    query_matrix_normalized = query_matrix / (query_norms + 1e-8)

    num_queries = len(query_ids)
    num_existing = int(existing_matrix_normalized.shape[0])
    similarity_matrix_mb = (num_queries * num_existing * 4) / (1024 * 1024)

    if similarity_matrix_mb <= LINEAR_SEARCH_MAX_SIMILARITY_MATRIX_MB:
        similarity_matrix = np.dot(query_matrix_normalized, existing_matrix_normalized.T)
        best_indices = np.argmax(similarity_matrix, axis=1)
        best_similarities = similarity_matrix[np.arange(num_queries), best_indices]
    else:
        max_elements = max(1, int((LINEAR_SEARCH_MAX_SIMILARITY_MATRIX_MB * 1024 * 1024) / 4))
        existing_chunk_size = max(1, min(num_existing, max_elements // max(1, num_queries)))

        best_similarities = np.full(num_queries, -np.inf, dtype=np.float32)
        best_indices = np.zeros(num_queries, dtype=np.int64)

        for start in range(0, num_existing, existing_chunk_size):
            end = min(start + existing_chunk_size, num_existing)
            block = existing_matrix_normalized[start:end]
            block_similarity = np.dot(query_matrix_normalized, block.T)
            block_best_local_idx = np.argmax(block_similarity, axis=1)
            block_best_scores = block_similarity[np.arange(num_queries), block_best_local_idx]

            improved = block_best_scores > best_similarities
            if np.any(improved):
                best_similarities[improved] = block_best_scores[improved]
                best_indices[improved] = start + block_best_local_idx[improved]

    mask = best_similarities >= semantic_threshold
    for i, query_id in enumerate(query_ids):
        if mask[i]:
            best_match_id = existing_ids[best_indices[i]]
            best_similarity = float(best_similarities[i])
            duplicates[query_id] = (best_match_id, best_similarity)

    return duplicates


def _find_duplicates_linear_vectorized(
    query_items: list[tuple[str, list[float]]],
    existing_items: list[tuple[str, list[float]]],
    config: OntologyConfig,
) -> dict[str, tuple[str, float]]:
    """
    Find semantic duplicates using vectorized linear search.

    Args:
        query_items: List of (query_id, embedding) tuples
        existing_items: List of (existing_id, embedding) tuples
        config: Ontology configuration

    Returns:
        Dictionary of matches
    """
    assert query_items is not None, "query_items parameter is required"
    assert config is not None, "config parameter is required"
    num_existing = len(existing_items)
    num_queries = len(query_items)
    expected_dim = len(existing_items[0][1]) if existing_items else config.embeddings.dimension
    batch_size = config.deduplication.faiss.batch_size
    semantic_threshold = config.deduplication.semantic_threshold

    _check_linear_search_memory(num_existing, num_queries, expected_dim, batch_size, config)

    existing_ids = np.array([eid for eid, _ in existing_items])
    existing_matrix = np.array([emb for _, emb in existing_items], dtype=np.float32)

    if existing_matrix.size == 0:
        return {}

    expected_dim = (
        existing_matrix.shape[1] if len(existing_matrix.shape) > 1 else len(existing_items[0][1])
    )

    existing_norms = np.linalg.norm(existing_matrix, axis=1, keepdims=True)
    existing_matrix_normalized = existing_matrix / (existing_norms + 1e-8)

    duplicates: dict[str, tuple[str, float]] = {}
    for batch_start in range(0, len(query_items), batch_size):
        batch_end = min(batch_start + batch_size, len(query_items))
        batch_queries = query_items[batch_start:batch_end]

        batch_duplicates = _process_linear_batch(
            batch_queries,
            existing_matrix_normalized,
            existing_ids,
            expected_dim,
            semantic_threshold,
        )
        duplicates.update(batch_duplicates)

    return duplicates


def _find_duplicates_fallback(
    query_items: list[tuple[str, list[float]]],
    existing_items: list[tuple[str, list[float]]],
    semantic_threshold: float,
) -> dict[str, tuple[str, float]]:
    """
    Fallback: find duplicates using individual comparisons (memory efficient).

    Args:
        query_items: List of (query_id, embedding) tuples
        existing_items: List of (existing_id, embedding) tuples
        semantic_threshold: Minimum similarity threshold

    Returns:
        Dictionary of matches
    """
    assert query_items is not None, "query_items parameter is required"
    assert existing_items is not None, "existing_items parameter is required"
    duplicates: dict[str, tuple[str, float]] = {}

    for query_id, query_embedding in query_items:
        best_match_id: str | None = None
        best_similarity = 0.0

        for existing_id, existing_embedding in existing_items:
            try:
                similarity = cosine_similarity(query_embedding, existing_embedding)
                if similarity > best_similarity and similarity >= semantic_threshold:
                    best_similarity = similarity
                    best_match_id = existing_id
                    if best_similarity >= 1.0:
                        break
            except Exception:
                continue

        if best_match_id:
            duplicates[query_id] = (best_match_id, best_similarity)

    return duplicates


def _find_duplicates_linear(
    query_embeddings: dict[str, list[float]],
    existing_embeddings: dict[str, list[float]],
    config: OntologyConfig,
) -> dict[str, tuple[str, float]]:
    """
    Find semantic duplicates using linear search.

    Args:
        query_embeddings: Query embedding dict
        existing_embeddings: Existing embedding dict
        config: Ontology configuration

    Returns:
        Dictionary of matches
    """
    assert query_embeddings is not None, "query_embeddings parameter is required"
    assert config is not None, "config parameter is required"
    if len(existing_embeddings) >= config.deduplication.faiss.threshold:
        logger.warning(
            f"Large dataset ({len(existing_embeddings)} embeddings) but FAISS not available. "
            f"Linear search will be slow. Consider enabling FAISS."
        )

    query_items = list(query_embeddings.items())
    existing_items = list(existing_embeddings.items())

    if not existing_items or not query_items:
        return {}

    try:
        return _find_duplicates_linear_vectorized(query_items, existing_items, config)
    except MemoryError:
        raise
    except Exception as e:
        logger.error(
            f"Vectorized batch comparison failed: {type(e).__name__}: {e}. "
            f"Falling back to individual comparisons (slower but more memory-efficient)."
        )
        return _find_duplicates_fallback(
            query_items, existing_items, config.deduplication.semantic_threshold
        )


async def find_semantic_duplicates_async(
    query_embeddings: dict[str, list[float]],
    existing_embeddings: dict[str, list[float]],
    config: OntologyConfig,
    use_faiss: bool = False,
) -> dict[str, tuple[str, float]]:
    """Find semantic duplicates (async, delegates to sync for CPU-bound ops).
    Returns mapping of query_id -> (match_id, similarity_score)."""
    assert config is not None, "config parameter is required"
    assert isinstance(use_faiss, bool), "use_faiss must be a boolean"
    loop = asyncio.get_running_loop()
    try:
        return await loop.run_in_executor(
            None,
            find_semantic_duplicates,
            query_embeddings,
            existing_embeddings,
            config,
            use_faiss,
        )
    except RuntimeError as e:
        err = str(e).lower()
        if "cannot schedule new futures" in err or "interpreter shutdown" in err:
            logger.warning(
                "Executor unavailable during shutdown; falling back to synchronous semantic duplicate search"
            )
            return find_semantic_duplicates(
                query_embeddings,
                existing_embeddings,
                config,
                use_faiss,
            )
        raise


def find_semantic_duplicates(
    query_embeddings: dict[str, list[float]],
    existing_embeddings: dict[str, list[float]],
    config: OntologyConfig,
    use_faiss: bool = False,
) -> dict[str, tuple[str, float]]:
    """
    Find semantically similar entities using cosine similarity.

    Args:
        query_embeddings: Dictionary mapping entity ID to embedding (new entities)
        existing_embeddings: Dictionary mapping entity ID to embedding (existing entities)
        config: Ontology configuration
        use_faiss: Whether to use FAISS for search (if available and dataset is large)

    Returns:
        Dictionary mapping query entity ID to (existing entity ID, similarity_score) tuple
        Only includes matches above semantic_threshold
    """
    assert config is not None, "config parameter is required"
    assert isinstance(use_faiss, bool), "use_faiss must be a boolean"
    if not query_embeddings or not existing_embeddings:
        return {}

    # Use FAISS for large datasets
    # Use FAISS for large datasets
    use_faiss_actual = (
        use_faiss
        and FAISS_AVAILABLE
        and len(existing_embeddings) >= config.deduplication.faiss.threshold
    )

    if use_faiss_actual:
        duplicates = _find_duplicates_with_faiss(query_embeddings, existing_embeddings, config)
    else:
        duplicates = _find_duplicates_linear(query_embeddings, existing_embeddings, config)

    if duplicates:
        logger.debug(
            f"Found {len(duplicates)} semantic duplicates "
            f"(threshold: {config.deduplication.semantic_threshold})"
        )

    return duplicates
