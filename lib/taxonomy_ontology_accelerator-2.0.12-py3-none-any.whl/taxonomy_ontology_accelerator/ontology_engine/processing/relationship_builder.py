"""
Relationship building functions for ontology extraction.
"""

import re
from typing import Any

import inflect
from pydantic import BaseModel, Field

from taxonomy_ontology_accelerator.commons.errors import ErrorCollector
from taxonomy_ontology_accelerator.commons.utils.logger import get_logger
from taxonomy_ontology_accelerator.ontology_engine.config.config import OntologyConfig
from taxonomy_ontology_accelerator.ontology_engine.core.models import (
    Entity,
    ExtractedRelationship,
    OntologyGraph,
    OntologySchema,
    Relationship,
)
from taxonomy_ontology_accelerator.ontology_engine.processing.embeddings import (
    _text_hash,
    cosine_similarity,
    find_semantic_duplicates,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.error_helpers import (
    collect_error_if_enabled,
    merge_metadata_confidence,
    should_collect_error,
    validate_confidence,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.id_generation import (
    generate_relationship_id,
    get_current_timestamp,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.property_merger import merge_properties
from taxonomy_ontology_accelerator.ontology_engine.utils.text_normalization import (
    get_entity_text_for_embedding,
    normalize_text,
    validate_normalized_string,
)

logger = get_logger()

# Threshold for warning about high relationship drop rate (10%)
HIGH_DROP_RATE_THRESHOLD = 0.1

# Inflect engine for plural/singular matching (module-level, matches entity_deduplicator.py pattern)
_inflect_engine = inflect.engine()


# ========================================================================
# Relationship Building
# ========================================================================


class RelationshipBuildInput(BaseModel):
    """Input parameters for relationship building."""

    model_config = {"arbitrary_types_allowed": True}

    all_relationships: list[ExtractedRelationship]
    entity_label_to_id: dict[str, str]
    existing_entity_map: dict[str, str]
    existing_graph: OntologyGraph | None
    config: OntologyConfig
    error_collector: ErrorCollector
    entities: list[Entity] | None = None
    all_embeddings: dict[str, list[float]] | None = None
    auto_created_entities: list[Entity] = Field(default_factory=list)


async def build_relationships(build_input: RelationshipBuildInput) -> list[Relationship]:
    """Build relationship objects from extracted relationships."""
    assert build_input is not None, "build_input parameter is required"
    assert hasattr(build_input, "all_relationships"), "build_input must have all_relationships"

    config = build_input.config
    ctx = _initialize_build_context(
        build_input.entity_label_to_id,
        build_input.existing_entity_map,
        build_input.existing_graph,
        config,
    )
    _build_alias_lookup(build_input.entities, build_input.existing_graph, ctx, config)
    _build_entity_lookup_cache(build_input.entities, build_input.existing_graph, ctx)

    logger.info(
        f"Building relationships from {len(build_input.all_relationships)} extracted triples..."
    )
    entity_id_to_embedding = await _build_entity_embeddings_map(
        build_input.entities,
        build_input.existing_graph,
        build_input.all_embeddings,
        config,
        build_input.error_collector,
    )
    rels_data, missing = _collect_relationships_first_pass(
        build_input.all_relationships, ctx, config, build_input.error_collector
    )
    logger.info(
        f"First pass: {len(rels_data)} relationships resolved, {len(missing)} need semantic matching"
    )

    sem_ctx = SemanticMatchContext(
        entity_id_to_embedding=entity_id_to_embedding,
        entities=build_input.entities,
        existing_graph=build_input.existing_graph,
        normalization_cache=ctx["normalization_cache"],
        entity_lookup_cache=ctx["entity_lookup_cache"],
    )
    sem_map = await _perform_semantic_matching(
        missing, sem_ctx, config, build_input.error_collector
    )
    relationships = _create_relationship_objects(
        rels_data, sem_map, ctx, config, build_input.error_collector
    )
    _log_relationship_stats(
        len(build_input.all_relationships),
        len(relationships),
        ctx["dropped_stats"],
        len(ctx.get("auto_created_entities", [])),
    )
    # Copy auto-created entities to build_input so caller can access them
    build_input.auto_created_entities = ctx.get("auto_created_entities", [])
    del ctx["entity_lookup_cache"]
    return relationships


class _BuildContext:
    """Type hint for build context dictionary."""


def _build_reference_match_key(
    text: str,
    config: OntologyConfig,
    cache: dict[str, str] | None,
) -> str:
    """Build a comparison key that tolerates case and separator drift."""
    assert text is not None, "text parameter is required"
    assert config is not None, "config parameter is required"

    normalized = normalize_text(text, config, cache=cache)
    return re.sub(r"[^a-z0-9]+", "", normalized.lower())


def _compute_auto_entity_counter(
    entity_label_to_id: dict[str, str],
    existing_graph: OntologyGraph | None,
    config: OntologyConfig,
) -> int:
    """Compute a collision-safe ID counter for auto-created entities."""
    assert entity_label_to_id is not None, "entity_label_to_id parameter is required"
    assert config is not None, "config parameter is required"
    from taxonomy_ontology_accelerator.ontology_engine.utils.id_generation import (
        find_max_id_counter,
        initialize_id_counter,
    )

    existing_counter = initialize_id_counter(
        existing_graph.entities if existing_graph else None,
        "id",
        config.output.entity_id_prefix,
    )
    new_entity_ids = list(entity_label_to_id.values())
    new_max = find_max_id_counter(new_entity_ids, config.output.entity_id_prefix)
    return max(existing_counter, new_max + 1) if new_max >= 0 else existing_counter


def _initialize_build_context(
    entity_label_to_id: dict[str, str],
    existing_entity_map: dict[str, str],
    existing_graph: OntologyGraph | None,
    config: OntologyConfig,
) -> dict[str, Any]:
    """
    Initialize the context dictionary for relationship building.

    Contains all shared state: counters, caches, lookup maps, and statistics.

    Args:
        entity_label_to_id: Map of normalized labels to entity IDs
        existing_entity_map: Map of normalized labels to existing entity IDs
        existing_graph: Existing graph for incremental mode
        config: Ontology configuration

    Returns:
        Context dictionary with initialized state
    """
    assert entity_label_to_id is not None, "entity_label_to_id parameter is required"
    assert config is not None, "config parameter is required"
    from taxonomy_ontology_accelerator.ontology_engine.utils.id_generation import (
        initialize_id_counter,
    )

    # Build unified entity map: existing first, then new entities override
    # New entities take precedence because they may have updated IDs from deduplication
    normalization_cache: dict[str, str] = {}
    unified_entity_map: dict[str, str] = {}
    unified_entity_map.update(existing_entity_map)
    unified_entity_map.update(entity_label_to_id)
    reference_match_entity_map = {
        _build_reference_match_key(label, config, normalization_cache): entity_id
        for label, entity_id in unified_entity_map.items()
    }

    return {
        "relationship_id_counter": initialize_id_counter(
            existing_graph.relationships if existing_graph else None,
            "id",
            config.output.relationship_id_prefix,
        ),
        "timestamp": get_current_timestamp(config),
        "normalization_cache": normalization_cache,
        "seen_in_batch": set(),
        "unified_entity_map": unified_entity_map,
        "alias_to_entity_id": {},
        "reference_match_entity_map": reference_match_entity_map,
        "reference_match_alias_to_entity_id": {},
        "entity_lookup_cache": {},
        "dropped_stats": {"missing_entity": 0, "duplicate_batch": 0},
        "auto_created_entity_counter": _compute_auto_entity_counter(
            entity_label_to_id, existing_graph, config
        ),
        "auto_created_entities": [],
    }


def _find_morphological_match(normalized_label: str, ctx: dict[str, Any]) -> str | None:
    """Check plural/singular variants against unified_entity_map. Returns entity_id if found."""
    assert normalized_label is not None, "normalized_label parameter is required"
    assert ctx is not None, "ctx parameter is required"
    singular = _inflect_engine.singular_noun(normalized_label)
    plural = _inflect_engine.plural_noun(normalized_label)
    variants = [
        normalized_label,
        singular if singular else normalized_label,
        plural if plural else normalized_label,
    ]
    for variant in variants:
        if variant in ctx["unified_entity_map"]:
            existing_id = ctx["unified_entity_map"][variant]
            ctx["unified_entity_map"][normalized_label] = existing_id
            logger.debug(
                f"Fuzzy match: '{normalized_label}' matched variant '{variant}' "
                f"(reusing entity {existing_id})"
            )
            return existing_id
    return None


def _create_new_auto_entity(
    label: str,
    normalized_label: str,
    relationship_type: str,
    config: OntologyConfig,
    ctx: dict[str, Any],
) -> str:
    """Create a new auto-entity and register it in ctx. Returns entity_id."""
    assert label is not None, "label parameter is required"
    assert config is not None, "config parameter is required"
    from taxonomy_ontology_accelerator.ontology_engine.utils.id_generation import generate_entity_id
    from taxonomy_ontology_accelerator.ontology_engine.utils.text_normalization import (
        generate_canonical_key,
    )

    entity_id_counter = ctx["auto_created_entity_counter"]
    entity_id = generate_entity_id(entity_id_counter, config)
    ctx["auto_created_entity_counter"] = entity_id_counter + 1

    entity_type = config.relationship_processing.auto_created_entity_default_type
    # Use type-aware canonical key if configured (consistent with entity_processor.py)
    canonical_key = generate_canonical_key(
        normalized_label,
        entity_type if config.output.type_aware_canonical_keys else None,
    )
    entity = Entity(
        id=entity_id,
        canonical_key=canonical_key,
        label=label,
        aliases=[],
        type=entity_type,
        description=None,
        properties={},
        metadata={
            "confidence": config.relationship_processing.auto_created_entity_confidence,
            "auto_created": True,
            "created_from": "relationship_reference",
            "source_relationship_type": relationship_type,
            "timestamp": ctx["timestamp"],
        },
    )
    ctx["auto_created_entities"].append(entity)
    ctx["unified_entity_map"][normalized_label] = entity_id
    ctx["reference_match_entity_map"][
        _build_reference_match_key(normalized_label, config, ctx["normalization_cache"])
    ] = entity_id
    logger.info(f"Auto-created entity: '{label}' (type: {entity_type}, id: {entity_id})")
    return entity_id


def _auto_create_missing_entity(
    label: str,
    normalized_label: str,
    relationship_type: str,
    config: OntologyConfig,
    ctx: dict[str, Any],
) -> str:
    """
    Auto-create an entity when referenced by a relationship but not extracted.

    Checks for existing entities with similar labels (plural/singular variants)
    before creating. Only creates a new entity if no match is found.

    Returns:
        Entity ID of the found or newly created entity.
    """
    assert label is not None, "label parameter is required"
    assert config is not None, "config parameter is required"

    existing_id = _find_morphological_match(normalized_label, ctx)
    if existing_id is not None:
        return existing_id
    return _create_new_auto_entity(label, normalized_label, relationship_type, config, ctx)


def _process_entity_aliases(
    entity: Entity,
    alias_to_entity_id: dict[str, str],
    reference_match_alias_to_entity_id: dict[str, str],
    unified_entity_map: dict[str, str],
    normalization_cache: dict[str, str],
    config: OntologyConfig,
    check_existing_alias: bool = False,
) -> None:
    """
    Process aliases for a single entity and add to lookup.

    Args:
        entity: Entity to process aliases for
        alias_to_entity_id: Alias lookup dict to update
        unified_entity_map: Unified entity map for exclusion check
        normalization_cache: Cache for normalized text
        config: Ontology configuration
        check_existing_alias: If True, also check alias_to_entity_id for duplicates
    """
    assert entity is not None, "entity parameter is required"
    assert config is not None, "config parameter is required"
    if not entity.aliases:
        return

    for alias in entity.alias_names:
        normalized_alias = normalize_text(alias, config, cache=normalization_cache)
        if not normalized_alias or not normalized_alias.strip():
            continue
        if normalized_alias in unified_entity_map:
            continue
        if check_existing_alias and normalized_alias in alias_to_entity_id:
            continue
        alias_to_entity_id[normalized_alias] = entity.id
        reference_match_alias_to_entity_id[
            _build_reference_match_key(alias, config, normalization_cache)
        ] = entity.id


def _build_alias_lookup(
    entities: list[Entity] | None,
    existing_graph: OntologyGraph | None,
    ctx: dict[str, Any],
    config: OntologyConfig,
) -> None:
    """
    Build entity alias lookup index for relationship matching.

    Normalizes aliases and maps them to entity IDs. Relationships may
    use aliases (e.g., "FCDO" instead of full name).

    Args:
        entities: Current entities
        existing_graph: Existing graph with entities
        ctx: Build context to update with alias_to_entity_id
        config: Ontology configuration
    """
    assert ctx is not None, "ctx parameter is required"
    assert config is not None, "config parameter is required"
    normalization_cache = ctx["normalization_cache"]
    unified_entity_map = ctx["unified_entity_map"]
    alias_to_entity_id = ctx["alias_to_entity_id"]
    reference_match_alias_to_entity_id = ctx["reference_match_alias_to_entity_id"]

    # Process current entities (don't check existing aliases)
    if entities:
        for entity in entities:
            _process_entity_aliases(
                entity,
                alias_to_entity_id,
                reference_match_alias_to_entity_id,
                unified_entity_map,
                normalization_cache,
                config,
                check_existing_alias=False,
            )

    # Process existing graph entities (check existing aliases to avoid overwriting)
    if existing_graph and existing_graph.entities:
        for existing_entity in existing_graph.entities:
            _process_entity_aliases(
                existing_entity,
                alias_to_entity_id,
                reference_match_alias_to_entity_id,
                unified_entity_map,
                normalization_cache,
                config,
                check_existing_alias=True,
            )


def _build_entity_lookup_cache(
    entities: list[Entity] | None,
    existing_graph: OntologyGraph | None,
    ctx: dict[str, Any],
) -> None:
    """
    Build entity lookup cache for O(1) entity retrieval by ID.

    Args:
        entities: Current entities
        existing_graph: Existing graph with entities
        ctx: Build context to update with entity_lookup_cache
    """
    assert ctx is not None, "ctx parameter is required"
    assert "entity_lookup_cache" in ctx, "ctx must have entity_lookup_cache key"
    entity_lookup_cache = ctx["entity_lookup_cache"]
    if entities:
        entity_lookup_cache.update({e.id: e for e in entities})
    if existing_graph and existing_graph.entities:
        entity_lookup_cache.update({e.id: e for e in existing_graph.entities})


def _process_entity_for_embedding(
    entity_id: str,
    entity_text: str,
    all_embeddings: dict[str, list[float]],
    text_hash_cache: dict[str, str],
    entity_id_to_embedding: dict[str, list[float]],
    entities_needing_embeddings: list[tuple[str, str]],
) -> None:
    """
    Process a single entity for embedding lookup or generation.

    Args:
        entity_id: Entity ID
        entity_text: Text to embed (label + aliases)
        all_embeddings: All available embeddings
        text_hash_cache: Cache for text hashes
        entity_id_to_embedding: Output map to update
        entities_needing_embeddings: List to append if embedding not found
    """
    assert entity_id is not None, "entity_id parameter is required"
    assert all_embeddings is not None, "all_embeddings parameter is required"
    if entity_text not in text_hash_cache:
        text_hash_cache[entity_text] = _text_hash(entity_text)
    text_hash = text_hash_cache[entity_text]

    if text_hash in all_embeddings:
        entity_id_to_embedding[entity_id] = all_embeddings[text_hash]
    else:
        entities_needing_embeddings.append((entity_id, entity_text))


async def _build_entity_embeddings_map(
    entities: list[Entity] | None,
    existing_graph: OntologyGraph | None,
    all_embeddings: dict[str, list[float]] | None,
    config: OntologyConfig,
    error_collector: ErrorCollector,
) -> dict[str, list[float]] | None:
    """Build entity_id -> embedding mapping for semantic matching."""
    assert config is not None, "config parameter is required"
    assert error_collector is not None, "error_collector parameter is required"

    if not (config.features.cross_session_deduplication and all_embeddings and entities):
        return None

    id_to_emb: dict[str, list[float]] = {}
    hash_cache: dict[str, str] = {}
    needing: list[tuple[str, str]] = []

    for entity in entities:
        _process_entity_for_embedding(
            entity.id,
            get_entity_text_for_embedding(entity),
            all_embeddings,
            hash_cache,
            id_to_emb,
            needing,
        )

    if existing_graph:
        for e in existing_graph.entities:
            txt = f"{e.label} {' '.join(e.alias_names)}" if e.aliases else e.label
            _process_entity_for_embedding(e.id, txt, all_embeddings, hash_cache, id_to_emb, needing)

    if needing:
        await _generate_missing_embeddings(needing, hash_cache, id_to_emb, config, error_collector)

    return id_to_emb


async def _generate_missing_embeddings(
    entities_needing_embeddings: list[tuple[str, str]],
    text_hash_cache: dict[str, str],
    entity_id_to_embedding: dict[str, list[float]],
    config: OntologyConfig,
    error_collector: ErrorCollector,
) -> None:
    """
    Generate embeddings for entities missing from cache.

    Args:
        entities_needing_embeddings: List of (entity_id, entity_text) tuples
        text_hash_cache: Cache of text -> hash
        entity_id_to_embedding: Map to update with generated embeddings
        config: Ontology configuration
        error_collector: Error collector
    """
    assert entities_needing_embeddings is not None, (
        "entities_needing_embeddings parameter is required"
    )
    assert config is not None, "config parameter is required"
    entity_texts = [text for _, text in entities_needing_embeddings]
    from taxonomy_ontology_accelerator.ontology_engine.processing.embeddings import (
        generate_embeddings_batch_async,
    )

    missing_entity_embeddings, _ = await generate_embeddings_batch_async(
        entity_texts, config, error_collector, None
    )

    for entity_id, entity_text in entities_needing_embeddings:
        text_hash = text_hash_cache.get(entity_text, _text_hash(entity_text))
        if text_hash in missing_entity_embeddings:
            entity_id_to_embedding[entity_id] = missing_entity_embeddings[text_hash]
        else:
            logger.warning(
                f"Failed to generate embedding for entity {entity_id} "
                f"(text: '{entity_text[:50]}...') - semantic matching may fail"
            )


def _validate_rel_label(
    normalized: str,
    original: str,
    field: str,
    config: OntologyConfig,
    error_collector: ErrorCollector,
    dropped_stats: dict,
) -> bool:
    """Validate a relationship label. Returns True if valid."""
    assert config is not None, "config parameter is required"
    assert error_collector is not None, "error_collector parameter is required"
    is_valid, _ = validate_normalized_string(normalized, original, field)
    if not is_valid:
        dropped_stats["missing_entity"] += 1
        err = f"Relationship {field} '{original}' normalizes to empty"
        # Use add_validation_error only — always records regardless of config severity filter.
        # Validation errors about invalid relationship labels must always be tracked so
        # error_collector.has_errors() is reliable even when collect_severities=["error"].
        # collect_error_if_enabled was removed: it's severity-gated and added a duplicate
        # entry to _errors when warning severity is permitted by config.
        error_collector.add_validation_error(err, field=field.split()[0], severity="warning")
    return is_valid


def _collect_relationships_first_pass(
    all_relationships: list[ExtractedRelationship],
    ctx: dict[str, Any],
    config: OntologyConfig,
    error_collector: ErrorCollector,
) -> tuple[list[tuple[ExtractedRelationship, str, str, str | None, str | None]], set[str]]:
    """First pass: collect relationships and identify missing entities."""
    assert all_relationships is not None, "all_relationships parameter is required"
    assert config is not None, "config parameter is required"

    rels_data: list[tuple[ExtractedRelationship, str, str, str | None, str | None]] = []
    missing: set[str] = set()
    norm_cache, entity_map, alias_map, reference_entity_map, reference_alias_map, dropped = (
        ctx["normalization_cache"],
        ctx["unified_entity_map"],
        ctx["alias_to_entity_id"],
        ctx["reference_match_entity_map"],
        ctx["reference_match_alias_to_entity_id"],
        ctx["dropped_stats"],
    )

    for rel in all_relationships:
        src_norm = normalize_text(rel.source_label, config, cache=norm_cache)
        tgt_norm = normalize_text(rel.target_label, config, cache=norm_cache)
        src_reference_key = _build_reference_match_key(rel.source_label, config, norm_cache)
        tgt_reference_key = _build_reference_match_key(rel.target_label, config, norm_cache)

        if not _validate_rel_label(
            src_norm, rel.source_label, "source label", config, error_collector, dropped
        ):
            continue
        if not _validate_rel_label(
            tgt_norm, rel.target_label, "target label", config, error_collector, dropped
        ):
            continue

        src_id = (
            entity_map.get(src_norm)
            or alias_map.get(src_norm)
            or reference_entity_map.get(src_reference_key)
            or reference_alias_map.get(src_reference_key)
        )
        tgt_id = (
            entity_map.get(tgt_norm)
            or alias_map.get(tgt_norm)
            or reference_entity_map.get(tgt_reference_key)
            or reference_alias_map.get(tgt_reference_key)
        )

        if src_id is None:
            missing.add(src_norm)
        if tgt_id is None:
            missing.add(tgt_norm)

        rels_data.append((rel, src_norm, tgt_norm, src_id, tgt_id))

    return rels_data, missing


class SemanticMatchContext(BaseModel):
    """Context for semantic matching of missing entities."""

    model_config = {"arbitrary_types_allowed": True}

    entity_id_to_embedding: dict[str, list[float]] | None
    entities: list[Entity] | None
    existing_graph: OntologyGraph | None
    normalization_cache: dict[str, str]
    entity_lookup_cache: dict[str, Entity | None]


async def _perform_semantic_matching(
    missing_entities_set: set[str],
    ctx: SemanticMatchContext,
    config: OntologyConfig,
    error_collector: ErrorCollector,
) -> dict[str, str]:
    """Perform batch semantic matching for missing entities."""
    assert missing_entities_set is not None, "missing_entities_set parameter is required"
    assert config is not None, "config parameter is required"

    if not (
        missing_entities_set
        and ctx.entity_id_to_embedding
        and config.features.cross_session_deduplication
    ):
        return {}

    label_to_entity = _build_normalized_label_to_entity_map(
        ctx.entities, ctx.existing_graph, config, ctx.normalization_cache
    )
    missing_list = list(missing_entities_set)
    texts, label_to_text = _prepare_missing_entity_texts(
        missing_list, label_to_entity, ctx.entity_lookup_cache, config, ctx.normalization_cache
    )
    from taxonomy_ontology_accelerator.ontology_engine.processing.embeddings import (
        generate_embeddings_batch_async,
    )

    embeddings, _ = await generate_embeddings_batch_async(texts, config, error_collector, None)
    if not embeddings:
        return {}

    use_faiss = len(ctx.entity_id_to_embedding) >= config.deduplication.faiss.threshold
    matches = find_semantic_duplicates(
        embeddings, ctx.entity_id_to_embedding, config, use_faiss=use_faiss
    )

    result: dict[str, str] = {}
    for label in missing_list:
        text_hash = _text_hash(label_to_text[label])
        if text_hash in matches and ctx.entity_lookup_cache.get(matches[text_hash][0]):
            result[label] = matches[text_hash][0]
    return result


def _build_normalized_label_to_entity_map(
    entities: list[Entity] | None,
    existing_graph: OntologyGraph | None,
    config: OntologyConfig,
    normalization_cache: dict[str, str],
) -> dict[str, Entity]:
    """Build map of normalized_label -> entity for alias lookup."""
    assert config is not None, "config parameter is required"
    assert normalization_cache is not None, "normalization_cache parameter is required"
    normalized_label_to_entity: dict[str, Entity] = {}

    if entities:
        for entity in entities:
            normalized = normalize_text(entity.label, config, cache=normalization_cache)
            normalized_label_to_entity[normalized] = entity

    if existing_graph:
        for existing_entity in existing_graph.entities:
            normalized = normalize_text(existing_entity.label, config, cache=normalization_cache)
            if normalized not in normalized_label_to_entity:
                normalized_label_to_entity[normalized] = existing_entity

    return normalized_label_to_entity


def _prepare_missing_entity_texts(
    missing_entities_list: list[str],
    normalized_label_to_entity: dict[str, Entity],
    entity_lookup_cache: dict[str, Entity | None],
    config: OntologyConfig,
    normalization_cache: dict[str, str],
) -> tuple[list[str], dict[str, str]]:
    """
    Prepare texts for embedding generation from missing entity labels.

    Args:
        missing_entities_list: List of normalized labels needing semantic matching
        normalized_label_to_entity: Map of normalized_label -> entity
        entity_lookup_cache: Cache of entity_id -> entity
        config: Ontology configuration
        normalization_cache: Cache for text normalization

    Returns:
        Tuple of (missing_entity_texts, normalized_label_to_text)
    """
    assert missing_entities_list is not None, "missing_entities_list parameter is required"
    assert config is not None, "config parameter is required"
    missing_entity_texts: list[str] = []
    normalized_label_to_text: dict[str, str] = {}

    for normalized_label in missing_entities_list:
        entity = normalized_label_to_entity.get(normalized_label)
        if entity:
            entity_text = get_entity_text_for_embedding(entity)
            missing_entity_texts.append(entity_text)
            normalized_label_to_text[normalized_label] = entity_text
        else:
            # Try to find via aliases
            entity_text = _find_entity_via_alias(
                normalized_label, entity_lookup_cache, config, normalization_cache
            )
            missing_entity_texts.append(entity_text)
            normalized_label_to_text[normalized_label] = entity_text

    return missing_entity_texts, normalized_label_to_text


def _find_entity_via_alias(
    normalized_label: str,
    entity_lookup_cache: dict[str, Entity | None],
    config: OntologyConfig,
    normalization_cache: dict[str, str],
) -> str:
    """Find entity text via alias matching, or return normalized_label as fallback."""
    assert normalized_label is not None, "normalized_label parameter is required"
    assert config is not None, "config parameter is required"
    for existing_entity in entity_lookup_cache.values():
        if existing_entity is None:
            continue
        if existing_entity.aliases:
            for alias in existing_entity.alias_names:
                normalized_alias = normalize_text(alias, config, cache=normalization_cache)
                if normalized_alias == normalized_label:
                    entity_text = existing_entity.label
                    if existing_entity.aliases:
                        entity_text = f"{entity_text} {' '.join(existing_entity.alias_names)}"
                    logger.debug(
                        f"Found entity via alias: '{normalized_label}' → '{existing_entity.label}'"
                    )
                    return entity_text
    return normalized_label


def _resolve_entity_ids(
    source_id: str | None,
    target_id: str | None,
    source_norm: str,
    target_norm: str,
    sem_map: dict[str, str],
) -> tuple[str | None, str | None]:
    """Resolve entity IDs using semantic match map."""
    assert sem_map is not None, "sem_map parameter is required"
    assert source_norm is not None, "source_norm parameter is required"
    src = source_id if source_id else sem_map.get(source_norm)
    tgt = target_id if target_id else sem_map.get(target_norm)
    return src, tgt


def _handle_missing_ids(  # noqa: PLR0913
    rel: ExtractedRelationship,
    src_norm: str,
    tgt_norm: str,
    src_id: str | None,
    tgt_id: str | None,
    config: OntologyConfig,
    ctx: dict[str, Any],
    error_collector: ErrorCollector,
    dropped: dict[str, int],
) -> tuple[str | None, str | None, bool]:
    """Handle missing entity IDs. Returns (src_id, tgt_id, should_skip)."""
    assert rel is not None, "rel parameter is required"
    assert config is not None, "config parameter is required"
    if config.relationship_processing.auto_create_missing_entities:
        if src_id is None:
            src_id = _auto_create_missing_entity(
                label=rel.source_label,
                normalized_label=src_norm,
                relationship_type=rel.type,
                config=config,
                ctx=ctx,
            )
        if tgt_id is None:
            tgt_id = _auto_create_missing_entity(
                label=rel.target_label,
                normalized_label=tgt_norm,
                relationship_type=rel.type,
                config=config,
                ctx=ctx,
            )
        return src_id, tgt_id, False
    _log_missing_entity(
        rel,
        MissingEntityInfo(
            source_id=src_id,
            target_id=tgt_id,
            source_normalized=src_norm,
            target_normalized=tgt_norm,
        ),
        config,
        error_collector,
        dropped,
    )
    return src_id, tgt_id, True


def _create_relationship_objects(
    relationships_data: list[tuple[ExtractedRelationship, str, str, str | None, str | None]],
    semantic_match_map: dict[str, str],
    ctx: dict[str, Any],
    config: OntologyConfig,
    error_collector: ErrorCollector,
) -> list[Relationship]:
    """Create Relationship objects from relationship data."""
    assert relationships_data is not None, "relationships_data parameter is required"
    assert config is not None, "config parameter is required"

    relationships: list[Relationship] = []
    norm_cache, seen, dropped, ts = (
        ctx["normalization_cache"],
        ctx["seen_in_batch"],
        ctx["dropped_stats"],
        ctx["timestamp"],
    )
    counter = ctx["relationship_id_counter"]

    for rel, src_norm, tgt_norm, src_id, tgt_id in relationships_data:
        src_id, tgt_id = _resolve_entity_ids(src_id, tgt_id, src_norm, tgt_norm, semantic_match_map)

        if src_id is None or tgt_id is None:
            src_id, tgt_id, skip = _handle_missing_ids(
                rel, src_norm, tgt_norm, src_id, tgt_id, config, ctx, error_collector, dropped
            )
            if skip:
                continue

        rel_type_norm = normalize_relationship_type(rel.type, config, norm_cache)
        rel_key = (src_id, tgt_id, rel_type_norm)
        if rel_key in seen:
            dropped["duplicate_batch"] += 1
            continue
        seen.add(rel_key)

        relationships.append(
            _make_relationship(rel, src_id, tgt_id, rel_type_norm, counter, ts, config)
        )
        counter += 1

    ctx["relationship_id_counter"] = counter
    return relationships


def _make_relationship(  # noqa: PLR0913
    rel: ExtractedRelationship,
    src_id: str,
    tgt_id: str,
    norm_type: str,
    counter: int,
    ts: str,
    config: OntologyConfig,
) -> Relationship:
    """Create a single Relationship object."""
    assert rel is not None, "rel parameter is required"
    assert config is not None, "config parameter is required"
    return Relationship.model_validate(
        {
            "id": generate_relationship_id(counter, config),
            "type": norm_type,
            "from": src_id,
            "to": tgt_id,
            "properties": _build_relationship_properties(rel),
            "metadata": {"confidence": rel.confidence, "timestamp": ts},
        }
    )


class MissingEntityInfo(BaseModel):
    """Information about a relationship with missing entities."""

    source_id: str | None
    target_id: str | None
    source_normalized: str
    target_normalized: str


def _log_missing_entity(
    rel: ExtractedRelationship,
    info: MissingEntityInfo,
    config: OntologyConfig,
    error_collector: ErrorCollector,
    dropped_stats: dict[str, int],
) -> None:
    """Log details about dropped relationship due to missing entity."""
    assert rel is not None, "rel parameter is required"
    assert config is not None, "config parameter is required"
    dropped_stats["missing_entity"] += 1

    missing_parts = []
    if info.source_id is None:
        missing_parts.append(
            f"source: '{rel.source_label}' (normalized: '{info.source_normalized}')"
        )
    if info.target_id is None:
        missing_parts.append(
            f"target: '{rel.target_label}' (normalized: '{info.target_normalized}')"
        )

    logger.warning(
        f"Relationship dropped [{rel.type}]: missing entity - {', '.join(missing_parts)}"
    )

    if should_collect_error("warning", config):
        collect_error_if_enabled(
            error_collector,
            config,
            "warning",
            "validation_error",
            f"Relationship references unknown entity: '{rel.source_label}' -> '{rel.target_label}'",
        )
        error_collector.add_validation_error(
            f"Relationship references unknown entity: '{rel.source_label}' -> '{rel.target_label}' "
            f"(normalized: '{info.source_normalized}' -> '{info.target_normalized}')",
            field="source_label/target_label",
            severity="warning",
        )


def _build_relationship_properties(rel: ExtractedRelationship) -> dict[str, Any]:
    """Build properties dict from ExtractedRelationship."""
    assert rel is not None, "rel parameter is required"
    assert hasattr(rel, "properties"), "rel must have properties attribute"
    properties: dict[str, Any] = {}
    if rel.properties:
        properties.update(rel.properties)
        logger.debug(f"Preserved {len(rel.properties)} properties for {rel.type}")
    if rel.description:
        properties["description"] = rel.description
    return properties


def _log_relationship_stats(
    total_input: int,
    total_created: int,
    dropped_stats: dict[str, int],
    auto_created_count: int = 0,
) -> None:
    """
    Log comprehensive statistics about relationship building.

    Args:
        total_input: Total number of input relationships
        total_created: Number of relationships created
        dropped_stats: Dict with 'missing_entity' and 'duplicate_batch' counts
        auto_created_count: Number of entities auto-created to save relationship drops
    """
    assert isinstance(total_input, int), "total_input must be an integer"
    assert dropped_stats is not None, "dropped_stats parameter is required"
    total_dropped = sum(dropped_stats.values())
    if total_dropped > 0 or auto_created_count > 0:
        missing_count = dropped_stats["missing_entity"]
        duplicate_count = dropped_stats["duplicate_batch"]
        parts = [f"Created: {total_created}"]
        if total_dropped > 0:
            parts.append(
                f"Dropped: {total_dropped} (missing entity: {missing_count}, duplicate: {duplicate_count})"
            )
        if auto_created_count > 0:
            parts.append(f"Auto-created entities: {auto_created_count} (saved from drop)")
        logger.processing(f"Relationship building | {' | '.join(parts)}")

    if total_input > 0:
        drop_rate = total_dropped / total_input
        if drop_rate > HIGH_DROP_RATE_THRESHOLD:
            logger.warning(
                f"🔗 Relationship quality control: {drop_rate:.1%} filtered ({total_dropped}/{total_input}) "
                f"- duplicates or invalid references removed during deduplication"
            )

        # Validate accounting
        accounted_for = total_created + total_dropped
        if accounted_for != total_input:
            discrepancy = total_input - accounted_for
            logger.warning(
                f"📊 Relationship tracking mismatch: {total_input} extracted, "
                f"{accounted_for} processed (delta: {discrepancy}) - this is uncommon but non-critical"
            )
        else:
            logger.debug(
                f"Relationship accounting validated: {total_input} extracted = "
                f"{total_created} created + {total_dropped} dropped"
            )


# ========================================================================
# Relationship Merging Functions
# ========================================================================


def _merge_relationship_properties_safe(
    existing_props: dict[str, Any],
    new_props: dict[str, Any],
) -> dict[str, Any]:
    """
    Safely merge relationship properties when semantic merge fails.
    Preserves both property sets without overwriting.
    """
    assert existing_props is not None or new_props is not None, (
        "at least one props dict must be provided"
    )
    assert True, "safe merge function called"
    if not existing_props:
        return new_props.copy() if new_props else {}
    if not new_props:
        return existing_props.copy()
    return {**existing_props, **new_props}


def _merge_relationship_metadata(
    target_rel: Relationship,
    source_rel: Relationship,
    target_confidence: float,
    source_confidence: float,
) -> None:
    """
    Merge metadata from source relationship into target relationship.

    Args:
        target_rel: Relationship to update (modified in-place)
        source_rel: Relationship to merge from
        target_confidence: Confidence of target relationship
        source_confidence: Confidence of source relationship
    """
    assert target_rel is not None, "target_rel parameter is required"
    assert source_rel is not None, "source_rel parameter is required"
    # Merge confidence (common pattern for entities and relationships)
    merge_metadata_confidence(
        target_rel.metadata,
        source_rel.metadata,
        target_confidence,
        source_confidence,
    )

    # Merge timestamp (latest)
    if "timestamp" in source_rel.metadata:
        if "timestamp" not in target_rel.metadata:
            target_rel.metadata["timestamp"] = source_rel.metadata["timestamp"]
        else:
            target_rel.metadata["timestamp"] = max(
                target_rel.metadata["timestamp"], source_rel.metadata["timestamp"]
            )


def _merge_duplicate_relationship(
    existing_rel: Relationship,
    new_rel: Relationship,
    config: OntologyConfig,
    merge_reason: str,
    merge_timestamp: str,
) -> None:
    """Merge a duplicate relationship into an existing one."""
    assert existing_rel is not None, "existing_rel parameter is required"
    assert config is not None, "config parameter is required"

    exist_conf = validate_confidence(existing_rel.metadata.get("confidence"), 1.0)
    new_conf = validate_confidence(new_rel.metadata.get("confidence"), 1.0)

    try:
        existing_rel.properties = merge_properties(
            existing_rel.properties or {},
            new_rel.properties or {},
            exist_conf,
            new_conf,
            config=config,
        )
    except Exception as e:
        logger.warning(f"Failed to merge relationship properties: {e}")
        existing_rel.properties = _merge_relationship_properties_safe(
            existing_rel.properties or {}, new_rel.properties or {}
        )

    _merge_relationship_metadata(existing_rel, new_rel, exist_conf, new_conf)

    if "merged_from" not in existing_rel.metadata:
        existing_rel.metadata["merged_from"] = []
    existing_rel.metadata["merged_from"].append(
        {
            "relationship_id": new_rel.id,
            "type": new_rel.type,
            "merge_reason": merge_reason,
            "timestamp": merge_timestamp,
        }
    )


def resolve_chain_mappings(mapping: dict[str, str]) -> dict[str, str]:
    """
    Resolve chain mappings to ensure all IDs map to final canonical IDs.

    Example: If A→B and B→C, then A→C (final mapping).
    """
    assert mapping is not None, "mapping parameter is required"
    assert isinstance(mapping, dict), "mapping must be a dictionary"
    resolved = {}  # Final resolved mappings
    for old_id, new_id in mapping.items():
        current = new_id  # Start with immediate mapping
        visited = {old_id}  # Track visited IDs to detect cycles
        while current in mapping and current not in visited:  # Follow chain until final ID
            visited.add(current)  # Mark as visited
            current = mapping[current]  # Follow to next mapping
        resolved[old_id] = current  # Store final canonical ID
    return resolved


def normalize_relationship_type(
    rel_type: str,
    config: OntologyConfig,
    normalization_cache: dict[str, str],
) -> str:
    """Normalize relationship type using naming_conventions.relationship_type_casing.

    Applies the configured casing style (lowerCamelCase, UpperCamelCase, snake_case)
    instead of generic text normalization, which would destroy casing information.
    """
    assert rel_type is not None, "rel_type parameter is required"
    assert config is not None, "config parameter is required"

    from taxonomy_ontology_accelerator.ontology_engine.core.models import apply_type_casing

    cache_key = rel_type
    if cache_key in normalization_cache:
        return normalization_cache[cache_key]

    casing = config.naming_conventions.relationship_type_casing
    normalized = apply_type_casing(rel_type, casing)
    _, final_value = validate_normalized_string(normalized, rel_type, "relationship type")

    normalization_cache[cache_key] = final_value
    return final_value


async def _generate_type_embeddings(
    types: list[str], config: OntologyConfig
) -> dict[str, list[float]]:
    """Generate embeddings for a list of relationship types."""
    assert types is not None, "types parameter is required"
    assert config is not None, "config parameter is required"
    from taxonomy_ontology_accelerator.ontology_engine.processing.embeddings import (
        generate_embedding_async,
    )

    embeddings: dict[str, list[float]] = {}
    for rel_type in types:
        embedding = await generate_embedding_async(rel_type, config)
        if embedding:
            embeddings[rel_type] = embedding
    return embeddings


def _find_best_match(
    new_emb: list[float], existing_embeddings: dict[str, list[float]], threshold: float
) -> str | None:
    """Find the best matching existing type for a new embedding."""
    assert new_emb is not None, "new_emb parameter is required"
    assert existing_embeddings is not None, "existing_embeddings parameter is required"
    best_match, best_similarity = None, 0.0
    for existing_type, existing_emb in existing_embeddings.items():
        try:
            similarity = cosine_similarity(new_emb, existing_emb)
            if similarity >= threshold and similarity > best_similarity:
                best_match, best_similarity = existing_type, similarity
        except Exception:
            continue
    return best_match


async def find_semantic_relationship_type_matches(
    new_types: list[str],
    existing_types: list[str],
    config: OntologyConfig,
) -> dict[str, str]:
    """Find semantic matches for relationship types using 0.75 threshold."""
    assert new_types is not None, "new_types parameter is required"
    assert config is not None, "config parameter is required"
    if not new_types or not existing_types:
        return {}

    try:
        new_embeddings = await _generate_type_embeddings(new_types, config)
        existing_embeddings = await _generate_type_embeddings(existing_types, config)

        if not new_embeddings or not existing_embeddings:
            return {}

        threshold = config.deduplication.semantic_threshold
        matches: dict[str, str] = {}
        for new_type, new_emb in new_embeddings.items():
            best_match = _find_best_match(new_emb, existing_embeddings, threshold)
            if best_match:
                matches[new_type] = best_match
        return matches
    except Exception as e:
        logger.warning(f"Semantic relationship type matching failed: {e}")
        return {}


def _update_entity_ids(relationships: list[Relationship], mapping: dict[str, str]) -> None:
    """
    Update entity IDs in relationships using resolved ID mapping.

    When entities are merged, their IDs change. This updates all relationship
    endpoints (from_, to) to use the canonical entity ID after merging.

    Args:
        relationships: List of relationships to update in place
        mapping: Dict of old_entity_id -> new_entity_id (canonical)
    """
    assert relationships is not None, "relationships parameter is required"
    assert mapping is not None, "mapping parameter is required"
    for rel in relationships:
        rel.from_ = mapping.get(rel.from_, rel.from_)
        rel.to = mapping.get(rel.to, rel.to)


def _normalize_relationship_types(
    relationships: list[Relationship],
    config: OntologyConfig,
    cache: dict[str, str],
) -> set[str]:
    """
    Normalize relationship type names for consistent matching.

    Applies text normalization (lowercase, whitespace normalization, etc.)
    to relationship types for deduplication and semantic matching.

    Args:
        relationships: List of relationships to normalize in place
        config: Ontology configuration with normalization settings
        cache: Shared normalization cache for efficiency

    Returns:
        Set of all unique normalized type names
    """
    assert relationships is not None, "relationships parameter is required"
    assert config is not None, "config parameter is required"
    types = set()
    for rel in relationships:
        normalized = normalize_relationship_type(rel.type, config, cache)
        rel.type = normalized
        types.add(normalized)
    return types


def _apply_type_matches(relationships: list[Relationship], type_matches: dict[str, str]) -> None:
    """
    Apply semantic type matches to relationship types.

    When semantic similarity finds that two type names are equivalent
    (e.g., "belongs_to" and "is_member_of"), updates relationships
    to use the canonical type name.

    Args:
        relationships: List of relationships to update in place
        type_matches: Dict of original_type -> canonical_type from semantic matching
    """
    assert relationships is not None, "relationships parameter is required"
    assert type_matches is not None, "type_matches parameter is required"
    for rel in relationships:
        if rel.type in type_matches:
            logger.debug(
                f"Applying semantic type match: '{rel.type}' -> '{type_matches[rel.type]}'"
            )
            rel.type = type_matches[rel.type]


def _build_relationship_map(
    existing_relationships: list[Relationship] | None,
    resolved_mapping: dict[str, str],
    config: OntologyConfig,
) -> tuple[dict[tuple[str, str, str], Relationship], set[tuple[str, str, str]]]:
    """
    Build relationship map from existing relationships for deduplication.

    Creates a map keyed by (from_id, to_id, type) for efficient duplicate
    detection and merges any duplicates within existing relationships.

    Args:
        existing_relationships: List of existing relationships (or None)
        resolved_mapping: Dict of old_entity_id -> canonical_entity_id
        config: Ontology configuration

    Returns:
        Tuple of:
        - relationship_map: Dict of (from, to, type) -> Relationship
        - normalized_set: Set of all (from, to, type) tuples for lookup
    """
    assert resolved_mapping is not None, "resolved_mapping parameter is required"
    assert config is not None, "config parameter is required"
    relationship_map: dict[tuple[str, str, str], Relationship] = {}
    normalized_set: set[tuple[str, str, str]] = set()

    if not existing_relationships:
        return relationship_map, normalized_set

    merge_timestamp = get_current_timestamp(config)

    # Apply resolved mapping to existing relationship endpoints
    _update_entity_ids(existing_relationships, resolved_mapping)

    for rel in existing_relationships:
        key = (rel.from_, rel.to, rel.type)

        normalized_set.add(key)

        if key in relationship_map:
            _merge_duplicate_relationship(
                relationship_map[key],
                rel,
                config,
                merge_reason="duplicate_in_existing",
                merge_timestamp=merge_timestamp,
            )
        else:
            relationship_map[key] = rel

    return relationship_map, normalized_set


def _merge_new_into_map(
    new_relationships: list[Relationship],
    relationship_map: dict[tuple[str, str, str], Relationship],
    normalized_existing: set[tuple[str, str, str]],
    config: OntologyConfig,
) -> int:
    """
    Merge new relationships into the existing relationship map.

    For each new relationship:
    - If key exists in map: merge properties/metadata into existing
    - If key in normalized_existing but not map (edge case): add to map
    - Otherwise: add as new relationship

    Args:
        new_relationships: List of new relationships to merge
        relationship_map: Map to merge into (modified in place)
        normalized_existing: Set of all existing relationship keys
        config: Ontology configuration

    Returns:
        Count of relationships merged (duplicates combined)
    """
    assert new_relationships is not None, "new_relationships parameter is required"
    assert config is not None, "config parameter is required"
    merge_timestamp = get_current_timestamp(config)
    merged_count = 0

    for rel in new_relationships:
        key = (rel.from_, rel.to, rel.type)

        if key in relationship_map:
            _merge_duplicate_relationship(
                relationship_map[key],
                rel,
                config,
                merge_reason="duplicate",
                merge_timestamp=merge_timestamp,
            )
            merged_count += 1
        elif key in normalized_existing:
            logger.debug(f"Relationship {key} in normalized set but not map - preserving")
            relationship_map[key] = rel
        else:
            relationship_map[key] = rel

    return merged_count


def _relationship_type_specificity(rel_type: str, schema: "OntologySchema | None" = None) -> int:
    """
    Calculate specificity of a relationship type using sub_property_of chain depth.

    Falls back to name length if schema is not available.

    Args:
        rel_type: Relationship type name
        schema: Optional ontology schema for sub_property_of chain lookup

    Returns:
        Specificity score (higher = more specific)
    """
    assert rel_type is not None, "rel_type parameter is required"
    assert isinstance(rel_type, str), "rel_type must be a string"

    if schema is None:
        return len(rel_type)

    depth = 0
    current_type = rel_type
    visited: set[str] = set()

    while current_type and current_type not in visited:
        visited.add(current_type)
        rel_type_def = schema.relationship_types.get(current_type)
        if rel_type_def and rel_type_def.sub_property_of:
            depth += 1
            current_type = rel_type_def.sub_property_of
        else:
            break

    return depth if depth > 0 else len(rel_type)


def _deduplicate_entity_pair_relationships(
    relationships: list[Relationship],
    config: OntologyConfig,
    schema: "OntologySchema | None" = None,
) -> list[Relationship]:
    """Ensure one relationship per entity pair, selecting best by type specificity then confidence."""
    assert relationships is not None, "relationships parameter is required"
    assert config is not None, "config parameter is required"

    from collections import defaultdict

    pair_to_rels: dict[tuple[str, str], list[Relationship]] = defaultdict(list)
    for rel in relationships:
        pair_to_rels[(rel.from_, rel.to)].append(rel)

    result: list[Relationship] = []
    dedup_count = 0
    merge_timestamp = get_current_timestamp(config)

    for (_from_id, _to_id), rels in pair_to_rels.items():
        if len(rels) == 1:
            result.append(rels[0])
        else:
            rels.sort(
                key=lambda r: (
                    -_relationship_type_specificity(r.type, schema),
                    -validate_confidence(r.metadata.get("confidence"), 1.0),
                    r.type,
                )
            )
            primary = rels[0]
            for other in rels[1:]:
                _merge_duplicate_relationship(
                    primary,
                    other,
                    config,
                    merge_reason="duplicate_entity_pair",
                    merge_timestamp=merge_timestamp,
                )
                dedup_count += 1
            result.append(primary)

    if dedup_count > 0:
        logger.debug(
            f"Deduplicated {dedup_count} entity pair relationship(s): "
            f"{len(relationships)} -> {len(result)}"
        )
    return result


def _remove_orphaned_relationships(
    relationships: list[Relationship], entity_ids: set[str]
) -> tuple[list[Relationship], int]:
    """
    Remove orphaned relationships that reference non-existent entities.

    A relationship is orphaned if its from_ or to_ endpoint references
    an entity ID that doesn't exist in the final entity set. This can
    happen when entities are filtered out during processing.

    Args:
        relationships: List of relationships to filter
        entity_ids: Set of valid entity IDs in the final graph

    Returns:
        Tuple of (filtered_relationships, count_of_removed_orphans)
    """
    assert relationships is not None, "relationships parameter is required"
    assert entity_ids is not None, "entity_ids parameter is required"
    orphaned = [r for r in relationships if r.from_ not in entity_ids or r.to not in entity_ids]
    orphan_count = len(orphaned)

    if orphaned:
        logger.warning(f"Removing {orphan_count} orphaned relationship(s) (entities not found)")
        relationships = [r for r in relationships if r.from_ in entity_ids and r.to in entity_ids]

    return relationships, orphan_count


def _validate_merge_accounting(
    input_count: int,
    output_count: int,
    removed_count: int,
    deduped_count: int,
) -> None:
    """
    Validate that all relationships are accounted for after merging.

    Ensures: input = output + removed + deduped
    Logs a warning only if relationships are unaccounted for after all known
    operations, which indicates a genuine processing bug.

    Args:
        input_count: Total relationships entering the merge (new + existing)
        output_count: Relationships in the final output
        removed_count: Relationships removed (orphaned endpoints, self-loops)
        deduped_count: Relationships collapsed by merging (same key or same entity pair)
    """
    assert isinstance(input_count, int), "input_count must be an integer"
    assert isinstance(output_count, int), "output_count must be an integer"
    accounted = output_count + removed_count + deduped_count

    if accounted != input_count:
        delta = input_count - accounted
        logger.warning(
            f"Relationship accounting mismatch: {delta} relationship(s) unaccounted for. "
            f"input={input_count}, active={output_count}, removed={removed_count}, "
            f"deduped={deduped_count}. This may indicate a processing bug."
        )
    else:
        logger.debug("Relationship accounting balanced.")


def _validate_and_finalize_relationships(  # noqa: PLR0913
    merged_rels: list[Relationship],
    entity_ids: set[str] | None,
    new_count: int,
    existing_count: int,
    merged_count: int,
    norm_existing_count: int,
    config: OntologyConfig | None = None,
) -> list[Relationship]:
    """Validate and finalize merged relationships."""
    assert merged_rels is not None, "merged_rels parameter is required"
    assert new_count >= 0, "new_count must be non-negative"

    # Deduplicate entity pair relationships (keep best relationship per entity pair)
    entity_pair_dedup_count = 0
    if config is not None:
        before_dedup = len(merged_rels)
        merged_rels = _deduplicate_entity_pair_relationships(merged_rels, config)
        entity_pair_dedup_count = before_dedup - len(merged_rels)

    # Remove self-referential relationships (can arise when two related entities merge)
    self_loop_count = sum(1 for r in merged_rels if r.from_ == r.to)
    if self_loop_count > 0:
        merged_rels = [r for r in merged_rels if r.from_ != r.to]

    orphaned_count = 0
    if entity_ids is not None:
        merged_rels, orphaned_count = _remove_orphaned_relationships(merged_rels, entity_ids)
        from taxonomy_ontology_accelerator.ontology_engine.processing.merge_validator import (
            validate_relationship_updates,
        )

        errors = validate_relationship_updates(merged_rels, entity_ids)
        if errors:
            logger.warning(f"Merge validation found {len(errors)} issues: {'; '.join(errors[:3])}")

    existing_dup_count = existing_count - norm_existing_count
    logger.debug(
        f"Relationship merge: {new_count + existing_count} in → {len(merged_rels)} active"
        f" | key-merged {merged_count} (new rel matched existing from/to/type, metadata combined)"
        f" | existing-dups {existing_dup_count} (duplicate entries already in graph, collapsed)"
        f" | pair-deduped {entity_pair_dedup_count}"
        f" (multiple rel types between same entity pair — best kept, others merged in)"
        f" | orphaned {orphaned_count} (endpoints no longer in entity set)"
        f" | self-loops {self_loop_count} (entity merged into itself, rel removed)"
    )
    _validate_merge_accounting(
        input_count=new_count + existing_count,
        output_count=len(merged_rels),
        removed_count=orphaned_count + self_loop_count,
        deduped_count=merged_count + existing_dup_count + entity_pair_dedup_count,
    )
    return merged_rels


async def merge_relationships(
    new_relationships: list[Relationship],
    existing_relationships: list[Relationship] | None,
    entity_id_mapping: dict[str, str],
    config: OntologyConfig,
    entity_ids: set[str] | None = None,
) -> list[Relationship]:
    """Merge new relationships with existing relationships."""
    assert new_relationships is not None, "new_relationships parameter is required"
    assert config is not None, "config parameter is required"

    resolved_mapping = resolve_chain_mappings(entity_id_mapping)
    norm_cache: dict[str, str] = {}
    _update_entity_ids(new_relationships, resolved_mapping)

    new_types = _normalize_relationship_types(new_relationships, config, norm_cache)
    existing_types = (
        _normalize_relationship_types(existing_relationships, config, norm_cache)
        if existing_relationships
        else set()
    )

    type_matches = await find_semantic_relationship_type_matches(
        list(new_types), list(existing_types), config
    )
    _apply_type_matches(new_relationships, type_matches)
    if existing_relationships:
        _apply_type_matches(existing_relationships, type_matches)

    rel_map, norm_existing = _build_relationship_map(
        existing_relationships, resolved_mapping, config
    )
    merged_count = _merge_new_into_map(new_relationships, rel_map, norm_existing, config)

    return _validate_and_finalize_relationships(
        list(rel_map.values()),
        entity_ids,
        len(new_relationships),
        len(existing_relationships) if existing_relationships else 0,
        merged_count,
        len(norm_existing),
        config,
    )
