"""
Text processing functions for ontology extraction.
"""

from collections.abc import Callable
import re

from taxonomy_ontology_accelerator.commons.utils.logger import get_logger
from taxonomy_ontology_accelerator.ontology_engine.config.config import (
    ChunkingConfig,
    OntologyConfig,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.validation import validate_and_merge_chunks

logger = get_logger()


# ========================================================================
# Text Chunking
# ========================================================================


def _ensure_source_ids(
    texts: list[str], source_ids: list[str] | None, fallback_prefix: str
) -> list[str]:
    """Ensure source IDs exist and match texts length."""
    assert texts is not None, "texts must not be None"
    assert fallback_prefix is not None, "fallback_prefix must not be None"
    assert len(fallback_prefix) > 0, "fallback_prefix must be non-empty"

    if source_ids is None or len(source_ids) != len(texts):
        if source_ids is not None:
            logger.warning(
                f"Source IDs length ({len(source_ids)}) doesn't match texts ({len(texts)}). "
                "Generating synthetic source IDs."
            )
        return [f"{fallback_prefix}_{i}" for i in range(len(texts))]
    return source_ids


def _get_chars_per_token(chunking_config: ChunkingConfig) -> float:
    """Get chars per token ratio with validation."""
    assert chunking_config is not None, "chunking_config must not be None"
    assert isinstance(chunking_config, ChunkingConfig), "chunking_config must be ChunkingConfig"

    ratio = chunking_config.chars_per_token_estimate
    if ratio <= 0:
        logger.warning("chars_per_token_estimate is zero or negative, using default 4.0")
        return 4.0
    return float(ratio)


def _load_custom_chunker(chunking_config: ChunkingConfig) -> Callable | None:
    """
    Load custom chunking function if configured.

    Args:
        chunking_config: Chunking configuration

    Returns:
        Custom chunking function or None if not configured/failed to load
    """
    assert chunking_config is not None, "chunking_config must not be None"
    assert isinstance(chunking_config, ChunkingConfig), "chunking_config must be ChunkingConfig"

    if not chunking_config.custom_chunking_function_file:
        return None

    from taxonomy_ontology_accelerator.ontology_engine.utils.function_loader import (
        load_custom_function,
        validate_chunking_function_signature,
    )

    try:
        custom_func = load_custom_function(
            chunking_config.custom_chunking_function_file,
            chunking_config.custom_chunking_function_name,
        )

        if custom_func is None:
            logger.warning("Custom chunking function could not be loaded. Using default.")
            return None

        # Validate signature
        if not validate_chunking_function_signature(custom_func):
            logger.warning(
                "Custom chunking function has invalid signature. "
                "Expected: (text: str, chunk_size: int, chunk_overlap: int, "
                "separators: list[str], chars_per_token: float) -> list[str]. "
                "Using default chunking."
            )
            return None

        logger.info(
            f"Successfully loaded custom chunking function '{chunking_config.custom_chunking_function_name}' "
            f"from: {chunking_config.custom_chunking_function_file}"
        )
        return custom_func

    except Exception as e:
        logger.warning(
            f"Error loading custom chunking function: {e}. "
            "Falling back to default recursive chunking."
        )
        return None


def _validate_custom_chunks(chunks: list) -> None:
    """Validate chunks returned from custom chunker."""
    assert chunks is not None, "chunks must not be None"
    assert isinstance(chunks, list) or not chunks, "chunks must be a list"

    if not isinstance(chunks, list):
        logger.warning(
            f"Custom chunker returned {type(chunks)}, expected list[str]. Falling back to default."
        )
        raise TypeError("Custom chunker must return list")

    if not all(isinstance(c, str) for c in chunks):
        logger.warning("Custom chunker returned non-string chunks. Falling back to default.")
        raise TypeError("Custom chunker must return list of strings")

    if not chunks:
        logger.warning("Custom chunker returned empty list. Falling back to default.")
        raise ValueError("Custom chunker returned no chunks")


def _apply_safety_limits(chunks: list[str], hard_max_chars: int, overlap_chars: int) -> list[str]:
    """Apply safety limits to chunks by force-splitting oversized ones."""
    assert chunks is not None
    assert hard_max_chars > 0

    safe_chunks = []
    for chunk in chunks:
        if len(chunk) > hard_max_chars:
            safe_chunks.extend(_force_split_large_text(chunk, hard_max_chars, overlap_chars))
        else:
            safe_chunks.append(chunk)
    return safe_chunks


def _apply_custom_chunker(
    text: str,
    chunking_config: ChunkingConfig,
    token_threshold: float,
    custom_chunker: Callable,
) -> list[str]:
    """
    Apply custom chunking function with safety wrapper.

    Args:
        text: Text to chunk
        chunking_config: Chunking configuration
        token_threshold: Maximum chunk size in characters
        custom_chunker: Custom chunking function

    Returns:
        List of chunks

    Note: Falls back to default chunking if custom function fails
    """
    assert custom_chunker is not None
    assert text is not None

    try:
        chars_per_token = _get_chars_per_token(chunking_config)

        # Call custom chunker
        chunks = custom_chunker(
            text=text,
            chunk_size=chunking_config.chunk_size,
            chunk_overlap=chunking_config.chunk_overlap,
            separators=chunking_config.separators,
            chars_per_token=chars_per_token,
        )

        # Validate and apply safety limits
        _validate_custom_chunks(chunks)
        hard_max_chars = min(int(token_threshold * 0.8), 200000)
        overlap_chars = int(chunking_config.chunk_overlap * chars_per_token)
        return _apply_safety_limits(chunks, hard_max_chars, overlap_chars)

    except Exception as e:
        logger.warning(
            f"Custom chunker failed with error: {e}. Falling back to default recursive chunking."
        )
        return _chunk_recursive(
            text=text,
            max_chunk_chars=int(token_threshold),
            overlap_chars=int(
                chunking_config.chunk_overlap * _get_chars_per_token(chunking_config)
            ),
            separators=chunking_config.separators,
            current_sep_idx=0,
        )


def _force_split_large_text(text: str, max_chars: int, overlap: int = 200) -> list[str]:
    """Force split text that exceeds max_chars into smaller pieces.

    This is a safety mechanism to ensure no chunk exceeds the hard limit,
    regardless of content structure.
    """
    assert text is not None, "text parameter is required"
    assert max_chars > 0, "max_chars must be positive"

    if len(text) <= max_chars:
        return [text]

    chunks = []
    start = 0
    while start < len(text):
        end = start + max_chars

        # Try to find a good break point (newline, sentence end, space)
        if end < len(text):
            # Look for break points within last 20% of chunk
            search_start = max(start, end - int(max_chars * 0.2))

            # Priority: paragraph break > sentence end > space
            best_break = -1
            for break_char in ["\n\n", "\n", ". ", "? ", "! ", " "]:
                pos = text.rfind(break_char, search_start, end)
                if pos > start:
                    best_break = pos + len(break_char)
                    break

            if best_break > start:
                end = best_break

        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)

        # Move start with overlap for context continuity
        start = end - overlap if end < len(text) else end

    return chunks


def _split_and_preserve_separators(text: str, separator: str) -> list[str]:
    """Split text and preserve separators in segments."""
    assert text is not None
    assert separator is not None

    splits = text.split(separator) if separator else list(text)
    segments = []
    for i, split in enumerate(splits):
        if i < len(splits) - 1:  # Add separator back except for last segment
            segments.append(split + separator)
        else:
            segments.append(split)
    return segments


def _extract_markdown_sections(text: str) -> list[str]:
    """Extract markdown sections, preferring level-2+ headings as boundaries."""
    assert text is not None

    heading_matches = list(re.finditer(r"(?m)^#{2,6}\s+.+$", text))
    if not heading_matches:
        heading_matches = list(re.finditer(r"(?m)^#\s+.+$", text))
    if len(heading_matches) <= 1:
        return []

    sections: list[str] = []
    preamble = text[: heading_matches[0].start()].strip()
    for idx, match in enumerate(heading_matches):
        start = match.start()
        end = heading_matches[idx + 1].start() if idx + 1 < len(heading_matches) else len(text)
        section = text[start:end].strip()
        if idx == 0 and preamble:
            section = f"{preamble}\n\n{section}".strip()
        sections.append(section)
    return sections


def _split_large_markdown_section(
    section: str,
    max_chunk_chars: int,
    overlap_chars: int,
    separators: list[str],
) -> list[str]:
    """Split an oversized markdown section without crossing into later sections."""
    assert section is not None

    first_line, sep, remainder = section.partition("\n")
    if sep and first_line.lstrip().startswith("#"):
        available_chars = max(max_chunk_chars - len(first_line) - len(sep), 1)
        remainder = remainder.lstrip()
        if remainder:
            body_chunks = _chunk_recursive(
                text=remainder,
                max_chunk_chars=available_chars,
                overlap_chars=overlap_chars,
                separators=separators,
                current_sep_idx=0,
            )
            if body_chunks:
                return [f"{first_line}{sep}{body_chunks[0]}".strip(), *body_chunks[1:]]
    return _chunk_recursive(
        text=section,
        max_chunk_chars=max_chunk_chars,
        overlap_chars=overlap_chars,
        separators=separators,
        current_sep_idx=0,
    )


def _chunk_markdown_sections(
    text: str,
    max_chunk_chars: int,
    overlap_chars: int,
    separators: list[str],
) -> list[str] | None:
    """Chunk markdown by section boundaries when headings provide stable structure."""
    assert text is not None

    sections = _extract_markdown_sections(text)
    if not sections:
        return None

    chunked_sections: list[str] = []
    current = ""
    for section in sections:
        if len(section) > max_chunk_chars:
            if current:
                chunked_sections.append(current)
                current = ""
            chunked_sections.extend(
                _split_large_markdown_section(
                    section=section,
                    max_chunk_chars=max_chunk_chars,
                    overlap_chars=overlap_chars,
                    separators=separators,
                )
            )
            continue

        if current and len(current) + 2 + len(section) <= max_chunk_chars:
            current = f"{current}\n\n{section}"
        else:
            if current:
                chunked_sections.append(current)
            current = section

    if current:
        chunked_sections.append(current)
    return chunked_sections


def _process_segments_recursive(
    segments: list[str],
    max_chunk_chars: int,
    overlap_chars: int,
    separators: list[str],
    current_sep_idx: int,
) -> list[str]:
    """Process segments recursively, splitting large ones."""
    assert segments is not None
    assert max_chunk_chars > 0

    chunks = []
    for segment in segments:
        stripped = segment.strip()
        if not stripped:
            continue

        if len(stripped) > max_chunk_chars:
            # Segment too large - recurse with next separator
            sub_chunks = _chunk_recursive(
                stripped, max_chunk_chars, overlap_chars, separators, current_sep_idx + 1
            )
            chunks.extend(sub_chunks)
        else:
            chunks.append(stripped)
    return chunks


def _chunk_recursive(
    text: str,
    max_chunk_chars: int,
    overlap_chars: int,
    separators: list[str],
    current_sep_idx: int = 0,
) -> list[str]:
    """
    Recursively chunk text using hierarchical separators.

    Algorithm matches LangChain's RecursiveCharacterTextSplitter.
    See implementation plan for details.

    Args:
        text: Text to chunk
        max_chunk_chars: Maximum chunk size in characters
        overlap_chars: Overlap between chunks in characters
        separators: List of separators in priority order
        current_sep_idx: Current separator index (for recursion)

    Returns:
        List of text chunks with overlap
    """
    assert text is not None
    assert max_chunk_chars > 0
    assert overlap_chars >= 0
    assert separators is not None

    # Base case: text fits in chunk
    if len(text) <= max_chunk_chars:
        return [text] if text.strip() else []

    # No more separators - force split
    if current_sep_idx >= len(separators):
        return _force_split_large_text(text, max_chunk_chars, overlap_chars)

    # Split and process segments
    separator = separators[current_sep_idx]
    segments = _split_and_preserve_separators(text, separator)
    chunks = _process_segments_recursive(
        segments, max_chunk_chars, overlap_chars, separators, current_sep_idx
    )

    # Merge small chunks and add overlap
    return _merge_with_overlap(chunks, max_chunk_chars, overlap_chars)


def _merge_with_overlap(chunks: list[str], max_size: int, overlap: int) -> list[str]:
    """
    Merge small adjacent chunks and add overlap between chunks.

    Args:
        chunks: List of chunks to process
        max_size: Maximum chunk size (won't exceed this when merging)
        overlap: Number of characters to overlap between chunks

    Returns:
        Merged chunks with overlap
    """
    assert chunks is not None
    assert max_size > 0
    assert overlap >= 0

    if not chunks:
        return []

    # Validate overlap isn't too large
    if overlap >= max_size:
        logger.warning(
            f"Overlap ({overlap}) >= max_size ({max_size}). Setting overlap to max_size // 2."
        )
        overlap = max_size // 2

    merged = []
    current = ""

    for chunk in chunks:
        if not current:
            current = chunk
            continue

        # Try to merge if combined size doesn't exceed max
        # Don't add separator - chunks from recursive split already have separators preserved
        combined = current + chunk
        if len(combined) <= max_size:
            current = combined
        else:
            # Can't merge - save current and start new
            merged.append(current)

            # Add overlap from end of previous chunk if possible
            if overlap > 0 and len(current) >= overlap:
                overlap_text = current[-overlap:]
                current = overlap_text + chunk
            else:
                current = chunk

    if current:
        merged.append(current)

    return merged


def _align_sources_to_chunks(
    chunks: list[str], chunk_sources: list[str], fallback_prefix: str
) -> list[str]:
    """Align source tracking list to match chunks after validation/merging."""
    assert chunks is not None, "chunks must not be None"
    assert chunk_sources is not None, "chunk_sources must not be None"
    assert fallback_prefix is not None, "fallback_prefix must not be None"

    if len(chunk_sources) > len(chunks):
        return chunk_sources[: len(chunks)]
    if len(chunk_sources) < len(chunks):
        last_source = chunk_sources[-1] if chunk_sources else f"{fallback_prefix}_0"
        return chunk_sources + [last_source] * (len(chunks) - len(chunk_sources))
    return chunk_sources


def _log_input_stats(
    texts: list[str],
    chunking_config: ChunkingConfig,
    token_threshold: float,
    source_ids: list[str] | None = None,
) -> None:
    """Log input statistics for chunking."""
    assert texts is not None, "texts must not be None"
    assert chunking_config is not None, "chunking_config must not be None"

    total_input_chars = sum(len(text) for text in texts)

    # Calculate tokens from chars (approximate)
    chars_per_token = _get_chars_per_token(chunking_config)
    total_tokens = int(total_input_chars / chars_per_token)

    # Calculate file count from unique source IDs
    if source_ids:
        file_count = len(set(source_ids))
        logger.data(f"Input: {file_count} file(s), ~{total_tokens:,} tokens")
    else:
        logger.data(f"Input: ~{total_tokens:,} tokens")

    logger.debug(
        f"Chunking strategy: {chunking_config.chunk_size} tokens/chunk (~{token_threshold:,.0f} chars)"
    )


def _process_single_text(
    text: str,
    source_id: str,
    token_threshold: float,
    chunking_config: ChunkingConfig,
    custom_chunker: Callable | None = None,
) -> tuple[list[str], list[str]]:
    """Process a single text into chunks with source tracking."""
    assert text is not None, "text must not be None"
    assert source_id is not None, "source_id must not be None"
    assert token_threshold > 0, "token_threshold must be positive"

    if len(text) > token_threshold:
        # Use custom chunker if provided, otherwise use default recursive
        if custom_chunker:
            text_chunks = _apply_custom_chunker(
                text, chunking_config, token_threshold, custom_chunker
            )
        else:
            max_chunk_chars = int(token_threshold)
            overlap_chars = int(
                chunking_config.chunk_overlap * _get_chars_per_token(chunking_config)
            )
            text_chunks = _chunk_markdown_sections(
                text=text,
                max_chunk_chars=max_chunk_chars,
                overlap_chars=overlap_chars,
                separators=chunking_config.separators,
            )
            if text_chunks is None:
                # Default recursive chunking (matches LangChain RecursiveCharacterTextSplitter)
                text_chunks = _chunk_recursive(
                    text=text,
                    max_chunk_chars=max_chunk_chars,
                    overlap_chars=overlap_chars,
                    separators=chunking_config.separators,
                    current_sep_idx=0,
                )
        return text_chunks, [source_id] * len(text_chunks)
    return [text], [source_id]


def _log_chunking_summary(chunks: list[str]) -> None:
    """Log chunking summary statistics."""
    assert chunks is not None, "chunks must not be None"
    assert len(chunks) > 0, "chunks must not be empty"

    avg_chunk_size = sum(len(c) for c in chunks) // len(chunks)
    logger.debug(f"Created {len(chunks)} chunks, avg size: {avg_chunk_size:,} chars")
    logger.debug(
        f"Chunk size range: {min(len(c) for c in chunks):,} - {max(len(c) for c in chunks):,} chars"
    )


def chunk_texts(
    texts: list[str], config: OntologyConfig, source_ids: list[str] | None = None
) -> tuple[list[str], list[str]]:
    """Chunk input texts according to configuration with source tracking."""
    assert texts is not None, "texts must not be None"
    assert config is not None, "config must not be None"
    assert isinstance(texts, list), "texts must be a list"

    if len(texts) == 0:
        raise ValueError("No text chunks created after processing input.")

    chunks: list[str] = []
    chunk_sources: list[str] = []
    chunking_config = config.text_processing.chunking
    fallback_prefix = config.source_grounding.fallback_source_prefix

    # Load custom chunker if configured
    custom_chunker = _load_custom_chunker(chunking_config)

    # Log which chunking strategy is being used
    if custom_chunker is not None:
        logger.info(
            f"Chunking strategy: CUSTOM (function: {chunking_config.custom_chunking_function_name})"
        )
    else:
        logger.info("Chunking strategy: DEFAULT (recursive hierarchical splitting)")

    source_ids = _ensure_source_ids(texts, source_ids, fallback_prefix)
    chars_per_token = _get_chars_per_token(chunking_config)
    token_threshold = chunking_config.chunk_size * chars_per_token

    _log_input_stats(texts, chunking_config, token_threshold, source_ids)

    for text_idx, text in enumerate(texts):
        source_id = (
            source_ids[text_idx] if text_idx < len(source_ids) else f"{fallback_prefix}_{text_idx}"
        )
        text_chunks, text_sources = _process_single_text(
            text, source_id, token_threshold, chunking_config, custom_chunker=custom_chunker
        )
        chunks.extend(text_chunks)
        chunk_sources.extend(text_sources)

    chunks = validate_and_merge_chunks(chunks, config)
    chunk_sources = _align_sources_to_chunks(chunks, chunk_sources, fallback_prefix)

    if chunking_config.max_chunks and len(chunks) > chunking_config.max_chunks:
        logger.info(f"Truncating {len(chunks)} chunks to limit {chunking_config.max_chunks}")
        chunks = chunks[: chunking_config.max_chunks]
        chunk_sources = chunk_sources[: chunking_config.max_chunks]

    if not chunks:
        raise ValueError("No text chunks created after processing input.")

    _log_chunking_summary(chunks)

    return chunks, chunk_sources
