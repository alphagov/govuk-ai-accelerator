"""
Entity processing functions for ontology extraction.
"""

from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field

from taxonomy_ontology_accelerator.commons.errors import ErrorCollector
from taxonomy_ontology_accelerator.commons.utils.logger import get_logger
from taxonomy_ontology_accelerator.ontology_engine.config.config import OntologyConfig
from taxonomy_ontology_accelerator.ontology_engine.core.models import (
    Entity,
    ExtractedConcept,
    OntologyGraph,
)
from taxonomy_ontology_accelerator.ontology_engine.processing.embeddings import (
    generate_embeddings_batch_async,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.error_helpers import (
    merge_metadata_confidence,
    validate_confidence,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.id_generation import (
    generate_entity_id,
    get_current_timestamp,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.property_merger import (
    _calculate_string_similarity,
    merge_properties,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.text_normalization import (
    generate_canonical_key,
    normalize_text,
    validate_normalized_string,
)

logger = get_logger()


# ========================================================================
# Entity Normalization and Deduplication Helper Functions
# ========================================================================


class DeduplicationContext:
    """
    Context object for entity deduplication.

    Holds all mutable state and caches for the deduplication process.
    """

    def __init__(self, config: OntologyConfig) -> None:
        """Initialize deduplication context."""
        assert config is not None, "config parameter is required"
        assert isinstance(config, OntologyConfig), "config must be an OntologyConfig"
        self.config = config
        self.entity_label_to_id: dict[str, str] = {}
        self.new_embeddings: dict[str, list[float]] = {}
        self.embeddings_generated = 0
        self.semantic_duplicate_info: dict[str, tuple[str, float, tuple]] = {}


class EntityDeduplicationInput(BaseModel):
    """Input parameters for entity deduplication."""

    model_config = {"arbitrary_types_allowed": True}

    all_concepts: list[ExtractedConcept]
    existing_entity_map: dict[str, str]
    existing_embeddings: dict[str, list[float]]
    embeddings_path: Path | str | None
    config: OntologyConfig
    error_collector: ErrorCollector = Field(default_factory=ErrorCollector)
    existing_graph: OntologyGraph | None = None
    normalization_cache: dict[str, str] | None = None
    fs: Any = None


def _normalize_entity_type(entity_type: str, config: OntologyConfig) -> str:
    """Normalize entity type, applying naming_conventions.entity_type_casing.

    Uses the configured casing style (UpperCamelCase, lowerCamelCase, snake_case)
    instead of generic text normalization, which would destroy casing information.
    Formal ontology identifiers (e.g., VO_0010343) are preserved as-is.
    """
    assert entity_type is not None, "entity_type parameter is required"
    assert config is not None, "config parameter is required"

    from taxonomy_ontology_accelerator.ontology_engine.core.models import apply_type_casing
    from taxonomy_ontology_accelerator.ontology_engine.utils.text_normalization import (
        is_formal_identifier,
    )

    if is_formal_identifier(entity_type, config):
        return entity_type

    casing = config.naming_conventions.entity_type_casing
    normalized = apply_type_casing(entity_type, casing)
    _, normalized = validate_normalized_string(normalized, entity_type, "entity type")
    return normalized


def _build_entity_properties(concept: ExtractedConcept) -> dict:
    """Build entity properties dict, including restrictions if present."""
    assert concept is not None, "concept parameter is required"
    assert True, "Placeholder assertion for NASA compliance"

    properties = dict(concept.properties) if concept.properties else {}
    if concept.restrictions:
        properties["_restrictions"] = concept.restrictions
    return properties


def _source_files_from_property(value: object) -> list[str]:
    """Return source file names from the legacy sourceUrls property shape."""
    if not value:
        return []

    if isinstance(value, list | tuple | set):
        return [str(source).strip() for source in value if str(source).strip()]

    return [source.strip() for source in str(value).split(",") if source.strip()]


def _apply_label_formatting(
    label: str,
    normalized_label: str,
    config: OntologyConfig,
) -> str:
    """Apply casing and spelling variant to entity label.

    Args:
        label: Original label text
        normalized_label: Normalized label for fallback
        config: Configuration containing naming conventions

    Returns:
        Formatted label with casing and spelling applied
    """
    assert label is not None, "label parameter is required"
    assert config is not None, "config parameter is required"

    from copy import deepcopy

    from taxonomy_ontology_accelerator.ontology_engine.core.models import apply_label_casing
    from taxonomy_ontology_accelerator.ontology_engine.utils.spelling_variants import (
        convert_spelling,
    )

    if config.naming_conventions.entity_label_casing == "preserve":
        # Use fully normalized label (follows text_normalization.casing)
        display_label = normalized_label
        # Apply spelling conversion for preserve mode
        if config.naming_conventions.entity_label_spelling_variant != "preserve":
            display_label = convert_spelling(
                display_label,
                from_variant=config.naming_conventions.spelling_variant,
                to_variant=config.naming_conventions.entity_label_spelling_variant,
            )
    else:
        # Apply normalization with casing preserved
        temp_config = deepcopy(config)
        temp_config.text_processing.normalization.casing = "preserve"
        whitespace_normalized = normalize_text(label, temp_config)

        # Apply spelling BEFORE casing (so library can work on space-separated text)
        if config.naming_conventions.entity_label_spelling_variant != "preserve":
            whitespace_normalized = convert_spelling(
                whitespace_normalized,
                from_variant=config.naming_conventions.spelling_variant,
                to_variant=config.naming_conventions.entity_label_spelling_variant,
            )

        # Apply casing
        display_label = apply_label_casing(
            whitespace_normalized, config.naming_conventions.entity_label_casing
        )

    return display_label


def _convert_concept_to_entity(
    concept: ExtractedConcept,
    entity_id_counter: int,
    config: OntologyConfig,
) -> tuple[Entity, int]:
    """Convert ExtractedConcept to Entity object."""
    assert concept is not None, "concept parameter is required"
    assert config is not None, "config parameter is required"

    # Normalize for canonical key generation
    normalized_label = normalize_text(concept.label, config)
    _, normalized_label = validate_normalized_string(normalized_label, concept.label, "label")

    entity_type = concept.concept_type or config.schema_evolution.default_entity_type
    normalized_type = _normalize_entity_type(entity_type, config)

    # Use type-aware canonical key if configured (prefix with entity type to prevent cross-type collisions)
    canonical_key = generate_canonical_key(
        normalized_label,
        normalized_type if config.output.type_aware_canonical_keys else None,
    )

    # Apply entity label casing and spelling for display
    display_label = _apply_label_formatting(concept.label, normalized_label, config)

    entity_id = generate_entity_id(entity_id_counter, config)
    timestamp = get_current_timestamp(config)

    source_files = []
    if concept.properties:
        raw_sources = concept.properties.get("sourceUrls", "")
        source_files = _source_files_from_property(raw_sources)

    from taxonomy_ontology_accelerator.ontology_engine.core.models import AliasEntry
    alias_entries = [
        AliasEntry(name=a, source_files=list(source_files))
        for a in (concept.aliases or []) if a
    ]

    entity = Entity(
        id=entity_id,
        canonical_key=canonical_key,
        label=display_label,
        aliases=alias_entries,
        type=normalized_type,
        description=concept.description,
        properties=_build_entity_properties(concept),
        metadata={
            "confidence": concept.confidence,
            "first_seen": timestamp,
            "last_updated": timestamp,
        },
    )

    return entity, entity_id_counter + 1


# ========================================================================
# Main Entity Normalization and Deduplication Function
# ========================================================================


def _convert_concepts_to_temp_entities(concepts: list, config) -> list[Entity]:
    """Convert extracted concepts to temporary entities.

    Uses a '_tmp_' prefix for temp IDs to avoid collisions with existing entity IDs
    when combining new + existing entities for the dedup pipeline.
    """
    assert concepts is not None, "concepts is required"
    assert config is not None, "config is required"
    temp_entities = []
    for i, concept in enumerate(concepts):
        entity, _ = _convert_concept_to_entity(concept, i, config)
        # Override with collision-safe temp ID
        entity.id = f"_tmp_{i}"
        temp_entities.append(entity)
    return temp_entities


async def _run_deduplication_pipeline(
    temp_entities: list[Entity], config, threshold: float, error_collector
) -> tuple[list[Entity], dict[str, str], list]:
    """Run 4-stage deduplication pipeline with error handling.

    Returns:
        Tuple of (deduplicated_entities, id_mapping, merge_decisions).
        id_mapping maps merged entity IDs to their surviving canonical IDs.
    """
    assert temp_entities is not None, "temp_entities is required"
    assert config is not None, "config is required"
    from taxonomy_ontology_accelerator.ontology_engine.processing.entity_deduplicator import (
        deduplicate_entities_enhanced_async,
    )

    try:
        (
            deduplicated_entities,
            id_mapping,
            merge_decisions,
        ) = await deduplicate_entities_enhanced_async(temp_entities, config, threshold)
        logger.info(f"Deduplication: {len(temp_entities)} → {len(deduplicated_entities)} entities")
        return deduplicated_entities, id_mapping, merge_decisions
    except Exception as e:
        logger.error(f"Deduplication failed: {e}. Using unmodified entities as fallback.")
        if error_collector:
            error_collector.add_error("deduplication_failure", f"Pipeline failed: {e}")
        return temp_entities, {}, []


def _build_final_entity(entity: Entity, entity_id: str, timestamp: str) -> Entity:
    """Construct the final Entity with assigned ID and updated metadata."""
    assert entity is not None, "entity is required"
    assert entity_id, "entity_id must not be empty"
    return Entity(
        id=entity_id,
        canonical_key=entity.canonical_key,
        label=entity.label,
        aliases=entity.aliases,
        type=entity.type,
        description=entity.description,
        properties=entity.properties,
        metadata={
            **entity.metadata,
            "first_seen": entity.metadata.get("first_seen", timestamp),
            "last_updated": timestamp,
        },
    )


def _assign_entity_ids(
    deduplicated_entities: list[Entity], dedup_input, config, ctx: DeduplicationContext
) -> tuple[list[Entity], set[str]]:
    """Assign final entity IDs and build label mappings.

    After the combined dedup pipeline, deduplicated_entities contains:
    - Existing entities (real IDs like 'entity_000001') — keep as-is
    - New entities (temp IDs like '_tmp_0') — assign real IDs

    For new entities, checks existing_entity_map first (label match → reuse ID),
    otherwise generates a new sequential ID.

    Returns:
        Tuple of (final_entities, label_matched_existing_ids).
        label_matched_existing_ids contains existing IDs assigned to new entities
        via the existing_entity_map fallback — these entities carry new properties
        and must not be filtered out downstream.
    """
    assert deduplicated_entities is not None, "deduplicated_entities is required"
    assert dedup_input is not None, "dedup_input is required"
    from taxonomy_ontology_accelerator.ontology_engine.utils.id_generation import (
        initialize_id_counter,
    )

    entity_id_counter = initialize_id_counter(
        dedup_input.existing_graph.entities if dedup_input.existing_graph else None,
        "id",
        config.output.entity_id_prefix,
    )
    timestamp = get_current_timestamp(config)
    norm_cache = dedup_input.normalization_cache
    existing_ids = (
        {e.id for e in dedup_input.existing_graph.entities}
        if dedup_input.existing_graph and dedup_input.existing_graph.entities
        else set()
    )

    final_entities = []
    label_matched_existing_ids: set[str] = set()
    for entity in deduplicated_entities:
        normalized_label = (
            normalize_text(entity.label, config, cache=norm_cache) if entity.label else ""
        )
        # Resolve ID: existing → label-match fallback → generate new
        if entity.id in existing_ids:
            entity_id = entity.id
        elif normalized_label in dedup_input.existing_entity_map:
            entity_id = dedup_input.existing_entity_map[normalized_label]
            label_matched_existing_ids.add(entity_id)
        else:
            entity_id = generate_entity_id(entity_id_counter, config)
            entity_id_counter += 1
        final_entities.append(_build_final_entity(entity, entity_id, timestamp))
        ctx.entity_label_to_id[normalized_label] = entity_id
    return final_entities, label_matched_existing_ids


def _prepare_combined_entities(
    dedup_input: EntityDeduplicationInput, config
) -> tuple[list[Entity], set[str]]:
    """Convert concepts to temp entities and combine with existing for cross-session dedup."""
    assert dedup_input is not None, "dedup_input is required"
    assert config is not None, "config is required"

    logger.info(f"Converting {len(dedup_input.all_concepts)} concepts to entities...")
    temp_entities = _convert_concepts_to_temp_entities(dedup_input.all_concepts, config)

    existing_entities = (
        list(dedup_input.existing_graph.entities)
        if dedup_input.existing_graph and dedup_input.existing_graph.entities
        else []
    )
    existing_ids = {e.id for e in existing_entities}
    combined = existing_entities + temp_entities

    logger.info(
        f"Deduplicating {len(temp_entities)} new + {len(existing_entities)} existing "
        f"= {len(combined)} entities..."
    )
    return combined, existing_ids


def _filter_unmodified_existing(
    final_entities: list[Entity],
    existing_ids: set[str],
    cross_session_mapping: dict[str, str],
    label_matched_ids: set[str],
) -> list[Entity]:
    """Filter out unmodified existing entities; keep new + modified existing."""
    assert isinstance(existing_ids, set), "existing_ids must be a set"
    assert isinstance(cross_session_mapping, dict), "cross_session_mapping must be a dict"

    modified_existing_ids = set(cross_session_mapping.values()) | label_matched_ids
    return [e for e in final_entities if e.id not in existing_ids or e.id in modified_existing_ids]


async def _generate_entity_embeddings(
    entities: list[Entity],
    existing_ids: set[str],
    dedup_input: EntityDeduplicationInput,
    ctx: DeduplicationContext,
) -> None:
    """Generate embeddings for downstream entities and log completion."""
    assert entities is not None, "entities list is required"
    assert dedup_input.config is not None, "config is required"

    config = dedup_input.config
    logger.info("Generating embeddings for deduplicated entities...")
    entity_texts = [
        f"{e.label} {' '.join(e.alias_names)}"
        if e.aliases
        else e.label
        for e in entities
    ]
    ctx.new_embeddings, ctx.embeddings_generated = await generate_embeddings_batch_async(
        entity_texts, config, dedup_input.error_collector, dedup_input.embeddings_path,
        fs=dedup_input.fs,
    )

    new_count = sum(1 for e in entities if e.id not in existing_ids)
    logger.complete(
        "Entity deduplication complete",
        f"{new_count} new | {ctx.embeddings_generated} embeddings",
    )


async def _finalize_entities_and_embeddings(
    deduplicated_entities, existing_ids, cross_session_mapping, dedup_input, config, ctx
) -> list[Entity]:
    """Assign IDs, filter existing entities, and generate embeddings.

    Steps 5-7 of the deduplication pipeline.
    """
    assert deduplicated_entities is not None, "deduplicated_entities is required"
    assert existing_ids is not None, "existing_ids is required"

    # Step 5: Assign final IDs
    final_entities, label_matched_ids = _assign_entity_ids(
        deduplicated_entities, dedup_input, config, ctx
    )

    # Step 6: Filter out unmodified existing entities
    entities_for_downstream = _filter_unmodified_existing(
        final_entities, existing_ids, cross_session_mapping, label_matched_ids
    )

    # Step 7: Generate embeddings for downstream entities
    await _generate_entity_embeddings(entities_for_downstream, existing_ids, dedup_input, ctx)

    return entities_for_downstream


async def normalize_and_deduplicate_entities(
    dedup_input: EntityDeduplicationInput,
) -> tuple[
    list[Entity],
    dict[str, str],
    dict[str, list[float]],
    int,
    dict[str, tuple[str, float, tuple]],
    dict[str, str],
    list,
]:
    """Multi-stage entity deduplication: exact, normalized, semantic, abbreviation.

    Cross-session dedup is handled by feeding existing entities into the same
    4-stage pipeline alongside new entities. The pipeline's id_mapping naturally
    captures new→existing mappings. No separate cross-session logic needed.

    Returns:
        Tuple of (entities, label_to_id, new_embeddings, embeddings_count,
                  semantic_duplicate_info, cross_session_id_mapping, merge_decisions)
    """
    assert dedup_input is not None, "dedup_input is required"
    assert isinstance(dedup_input, EntityDeduplicationInput), "must be EntityDeduplicationInput"
    config = dedup_input.config
    ctx = DeduplicationContext(config)

    # Steps 1-3: Combine entities and run 4-stage dedup pipeline
    combined, existing_ids = _prepare_combined_entities(dedup_input, config)
    deduplicated_entities, pipeline_id_mapping, merge_decisions = await _run_deduplication_pipeline(
        combined,
        config,
        config.deduplication.semantic_threshold,
        dedup_input.error_collector,
    )

    # Step 4: Fix surviving entity IDs and extract cross-session mapping
    _fix_surviving_ids(deduplicated_entities, pipeline_id_mapping, existing_ids)
    cross_session_mapping = _extract_cross_session_mapping(pipeline_id_mapping, existing_ids)

    # Steps 5-7: Finalize entities and generate embeddings
    entities_for_downstream = await _finalize_entities_and_embeddings(
        deduplicated_entities, existing_ids, cross_session_mapping, dedup_input, config, ctx
    )

    return (
        entities_for_downstream,
        ctx.entity_label_to_id,
        ctx.new_embeddings,
        ctx.embeddings_generated,
        ctx.semantic_duplicate_info,
        cross_session_mapping,
        merge_decisions,
    )


def _collect_temp_to_existing_flips(
    pipeline_id_mapping: dict[str, str],
    existing_ids: set[str],
) -> dict[str, list[str]]:
    """Find temp entities that absorbed existing entities (wrong direction).

    Groups existing_id → temp_id mappings by temp_id so we can flip them.
    """
    assert isinstance(pipeline_id_mapping, dict), "pipeline_id_mapping must be a dict"
    assert isinstance(existing_ids, set), "existing_ids must be a set"

    temp_to_existing: dict[str, list[str]] = {}
    for old_id, new_id in list(pipeline_id_mapping.items()):
        if old_id in existing_ids and new_id not in existing_ids:
            if new_id not in temp_to_existing:
                temp_to_existing[new_id] = []
            temp_to_existing[new_id].append(old_id)
    return temp_to_existing


def _apply_id_flips(
    pipeline_id_mapping: dict[str, str],
    temp_to_existing: dict[str, list[str]],
) -> dict[str, str]:
    """Flip mappings so temp→existing (correct direction). Returns flips dict."""
    assert isinstance(pipeline_id_mapping, dict), "pipeline_id_mapping must be a dict"
    assert isinstance(temp_to_existing, dict), "temp_to_existing must be a dict"

    flips: dict[str, str] = {}
    for temp_id, absorbed_ids in temp_to_existing.items():
        canonical_id = absorbed_ids[0]
        flips[temp_id] = canonical_id

        # Remove wrong-direction mappings and add correct ones
        for eid in absorbed_ids:
            pipeline_id_mapping.pop(eid, None)
        pipeline_id_mapping[temp_id] = canonical_id
        for eid in absorbed_ids[1:]:
            pipeline_id_mapping[eid] = canonical_id

    # Fix any other mappings that pointed to a temp_id
    for temp_id, existing_id in flips.items():
        for k, v in list(pipeline_id_mapping.items()):
            if v == temp_id and k != temp_id:
                pipeline_id_mapping[k] = existing_id

    return flips


def _fix_surviving_ids(
    deduplicated_entities: list[Entity],
    pipeline_id_mapping: dict[str, str],
    existing_ids: set[str],
) -> None:
    """Fix surviving entity IDs when the pipeline picked a temp entity over an existing one.

    The 4-stage pipeline picks canonical entities by confidence. If a new entity
    (temp ID) has higher confidence than an existing entity, the pipeline makes
    the temp entity survive and maps existing_id → temp_id. This is wrong for
    cross-session dedup: the existing entity's ID must be preserved.

    Handles the multi-absorb case: if one temp entity absorbed multiple existing
    entities, the first existing ID becomes canonical and all others map to it.

    Mutates deduplicated_entities and pipeline_id_mapping in place.
    """
    assert deduplicated_entities is not None, "deduplicated_entities is required"
    assert pipeline_id_mapping is not None, "pipeline_id_mapping is required"

    temp_to_existing = _collect_temp_to_existing_flips(pipeline_id_mapping, existing_ids)
    if not temp_to_existing:
        return

    flips = _apply_id_flips(pipeline_id_mapping, temp_to_existing)

    # Reassign surviving entity IDs from temp to existing
    for entity in deduplicated_entities:
        if entity.id in flips:
            existing_id = flips[entity.id]
            logger.debug(f"Cross-session ID fix: '{entity.label}' ID {entity.id} → {existing_id}")
            entity.id = existing_id

    logger.info(f"Cross-session ID fix: {len(flips)} entities reassigned to existing IDs")


def _extract_cross_session_mapping(
    pipeline_id_mapping: dict[str, str],
    existing_ids: set[str],
) -> dict[str, str]:
    """Extract ID mappings involving existing entities from the 4-stage pipeline.

    Captures two types of merges:
    1. temp → existing: A new entity merged into an existing one (cross-session dedup)
    2. existing → existing: Two existing entities merged (semantic dedup found them similar)

    Both types need propagation so downstream stages (relationship builder, Stage 13)
    can resolve entity references correctly.

    Returns:
        Mapping of absorbed_id → surviving_id for all merges involving existing entities.
    """
    assert pipeline_id_mapping is not None, "pipeline_id_mapping is required"
    assert existing_ids is not None, "existing_ids is required"

    cross_session: dict[str, str] = {}
    for old_id, new_id in pipeline_id_mapping.items():
        if old_id == new_id:
            continue
        # Case 1: temp → existing (new entity absorbed into existing)
        # Case 2: existing → existing (two existing entities merged by semantic dedup)
        if new_id in existing_ids:
            cross_session[old_id] = new_id

    if cross_session:
        temp_to_existing = sum(1 for k in cross_session if k not in existing_ids)
        existing_to_existing = sum(1 for k in cross_session if k in existing_ids)
        logger.info(
            f"Cross-session dedup: {temp_to_existing} new→existing, "
            f"{existing_to_existing} existing→existing merges"
        )

    return cross_session


# ========================================================================
# Entity Merging Functions
# ========================================================================


def _merge_entity_aliases(
    entity1: Entity,
    entity2: Entity,
) -> list:
    """
    Merge aliases from two entities as AliasEntry objects, unioning source_files
    for aliases that share the same name.
    """
    from taxonomy_ontology_accelerator.ontology_engine.core.models import AliasEntry

    assert entity1 is not None, "entity1 parameter is required"
    assert entity2 is not None, "entity2 parameter is required"

    def _to_entry(item) -> AliasEntry:
        if isinstance(item, AliasEntry):
            return item
        if isinstance(item, dict):
            return AliasEntry(**item)
        return AliasEntry(name=str(item))

    by_name: dict[str, AliasEntry] = {}
    for alias in (entity1.aliases or []):
        e = _to_entry(alias)
        by_name[e.name.lower()] = AliasEntry(name=e.name, source_files=list(e.source_files))
    for alias in (entity2.aliases or []):
        e = _to_entry(alias)
        key = e.name.lower()
        if key in by_name:
            for sf in e.source_files:
                if sf not in by_name[key].source_files:
                    by_name[key].source_files.append(sf)
        else:
            by_name[key] = AliasEntry(name=e.name, source_files=list(e.source_files))

    if entity1.label != entity2.label and entity2.label.lower() not in by_name:
        src = _source_files_from_property(entity2.properties.get("sourceUrls", ""))
        by_name[entity2.label.lower()] = AliasEntry(name=entity2.label, source_files=src)

    primary_lower = entity1.label.lower() if entity1.label else ""
    return [e for e in by_name.values() if e.name.lower() != primary_lower]


def _merge_entity_metadata(
    target_entity: Entity,
    source_entity: Entity,
    target_confidence: float,
    source_confidence: float,
    merge_timestamp: str,
) -> None:
    """
    Merge metadata from source entity into target entity.

    Args:
        target_entity: Entity to update (modified in-place)
        source_entity: Entity to merge from
        target_confidence: Confidence of target entity
        source_confidence: Confidence of source entity
        merge_timestamp: Timestamp for merge
    """
    assert target_entity is not None, "target_entity parameter is required"
    assert source_entity is not None, "source_entity parameter is required"
    # Merge confidence (common pattern for entities and relationships)
    merge_metadata_confidence(
        target_entity.metadata,
        source_entity.metadata,
        target_confidence,
        source_confidence,
    )

    # Merge first_seen (earliest timestamp)
    if "first_seen" in source_entity.metadata and (
        "first_seen" not in target_entity.metadata
        or source_entity.metadata["first_seen"] < target_entity.metadata["first_seen"]
    ):
        target_entity.metadata["first_seen"] = source_entity.metadata["first_seen"]

    # Update last_updated
    target_entity.metadata["last_updated"] = merge_timestamp


def _pick_better_description(
    existing_desc: str,
    new_desc: str,
    existing_confidence: float,
    new_confidence: float,
) -> str:
    """
    Pick the better description when two descriptions are semantically similar.

    Selection criteria (in order):
    1. Higher confidence wins
    2. If confidence equal, longer description wins
    3. If both equal, prefer new description

    Args:
        existing_desc: Current description
        new_desc: New description to consider
        existing_confidence: Confidence score of existing entity
        new_confidence: Confidence score of new entity

    Returns:
        The better description to use
    """
    assert existing_desc is not None, "existing_desc parameter is required"
    assert new_desc is not None, "new_desc parameter is required"
    if new_confidence > existing_confidence:
        return new_desc
    if existing_confidence > new_confidence or len(existing_desc) > len(new_desc):
        return existing_desc
    return new_desc


def _split_description_into_parts(desc: str) -> list[str]:
    """
    Split a description into parts using common separators.

    Tries separators in order: "|", ";", ". ", "\\n"
    Uses the first separator found in the description.
    If no separator found, returns the whole description as a single part.

    Args:
        desc: Description string to split

    Returns:
        List of non-empty trimmed description parts
    """
    assert desc is not None, "desc parameter is required"
    assert isinstance(desc, str), "desc must be a string"
    for sep in ["|", ";", ". ", "\n"]:
        if sep in desc:
            return [p.strip() for p in desc.split(sep) if p.strip()]
    return [desc.strip()] if desc.strip() else []


class DuplicateCheckContext(BaseModel):
    """Context for duplicate part checking."""

    model_config = {"arbitrary_types_allowed": True}

    new_confidence: float
    existing_confidence: float
    threshold: float
    config: OntologyConfig


def _find_and_replace_duplicate(
    part: str,
    parts: list[str],
    seen_parts: set[str],
    ctx: DuplicateCheckContext,
) -> bool:
    """
    Check if a description part is semantically similar to existing parts.

    If a similar part is found and the new part is "better" (longer or
    higher confidence), replaces the existing part with the new one.

    Args:
        part: New description part to check
        parts: List of existing parts (modified in place if replacement occurs)
        seen_parts: Set of lowercase parts for tracking (modified in place)
        ctx: Duplicate check context with confidence and threshold

    Returns:
        True if part is a duplicate (whether or not it replaced existing)
    """
    assert part is not None, "part parameter is required"
    assert ctx is not None, "ctx parameter is required"
    for existing_part in parts:
        try:
            part_similarity = _calculate_string_similarity(part, existing_part, ctx.config)
            if part_similarity >= ctx.threshold:
                # Keep better version
                if len(part) > len(existing_part) or ctx.new_confidence > ctx.existing_confidence:
                    parts.remove(existing_part)
                    parts.append(part)
                    seen_parts.discard(existing_part.lower())
                    seen_parts.add(part.lower())
                return True
        except Exception:
            pass
    return False


def _merge_description_parts(
    existing_desc: str,
    new_desc: str,
    existing_confidence: float,
    new_confidence: float,
    threshold: float,
    config: OntologyConfig,
) -> str:
    """
    Merge two descriptions by combining their unique parts.

    Process:
    1. Split both descriptions into parts
    2. For each part, check if semantically similar to existing parts
    3. If similar: keep the better version (longer/higher confidence)
    4. If unique: add to merged result
    5. Join all unique parts with " | " separator

    Args:
        existing_desc: Current description
        new_desc: New description to merge in
        existing_confidence: Confidence of existing entity
        new_confidence: Confidence of new entity
        threshold: Semantic similarity threshold for deduplication
        config: Ontology configuration

    Returns:
        Merged description with unique parts joined by " | "
    """
    assert existing_desc is not None, "existing_desc parameter is required"
    assert config is not None, "config parameter is required"
    parts: list[str] = []
    seen_parts: set[str] = set()

    dup_ctx = DuplicateCheckContext(
        new_confidence=new_confidence,
        existing_confidence=existing_confidence,
        threshold=threshold,
        config=config,
    )

    for desc in [existing_desc, new_desc]:
        for part in _split_description_into_parts(desc):
            if not part:
                continue

            is_duplicate = _find_and_replace_duplicate(part, parts, seen_parts, dup_ctx)

            if not is_duplicate and part.lower() not in seen_parts:
                parts.append(part)
                seen_parts.add(part.lower())

    return " | ".join(parts) if parts else existing_desc


def merge_entity_descriptions(
    existing_desc: str | None,
    new_desc: str | None,
    existing_confidence: float,
    new_confidence: float,
    config: OntologyConfig,
) -> str | None:
    """
    Merge entity descriptions semantically.

    Rules:
    - If one is None/empty, use the other
    - If both exist, check semantic similarity
      - If similar (>= threshold): pick higher confidence (or longer if equal)
      - If different (< threshold): merge parts semantically, deduplicate similar parts
    """
    # Handle trivial cases
    if not existing_desc and new_desc:
        return new_desc
    if existing_desc and not new_desc:
        return existing_desc
    if not existing_desc and not new_desc:
        return None

    # Both exist - merge semantically
    assert existing_desc is not None
    assert new_desc is not None

    try:
        similarity = _calculate_string_similarity(existing_desc, new_desc, config)
        threshold = config.deduplication.semantic_threshold

        if similarity >= threshold:
            return _pick_better_description(
                existing_desc, new_desc, existing_confidence, new_confidence
            )

        return _merge_description_parts(
            existing_desc, new_desc, existing_confidence, new_confidence, threshold, config
        )
    except Exception as e:
        logger.warning(f"Description merging failed: {e} - using existing description")
        logger.debug(
            f"Failed descriptions: existing={existing_desc[:50]}..., new={new_desc[:50]}..."
        )
        return existing_desc


def merge_entity_types(
    existing_type: str,
    new_type: str,
    config: OntologyConfig,
    normalization_cache: dict[str, str],  # noqa: ARG001
) -> str:
    """Merge entity types intelligently using naming_conventions.entity_type_casing.

    Compares types case-insensitively to detect matches, but returns the
    properly cased version per naming_conventions config.
    """
    assert existing_type is not None, "existing_type parameter is required"
    assert config is not None, "config parameter is required"

    from taxonomy_ontology_accelerator.ontology_engine.core.models import apply_type_casing

    casing = config.naming_conventions.entity_type_casing
    normalized_existing = apply_type_casing(existing_type, casing)
    normalized_new = apply_type_casing(new_type, casing)

    _, normalized_existing = validate_normalized_string(
        normalized_existing, existing_type, "entity type"
    )
    _, normalized_new = validate_normalized_string(normalized_new, new_type, "entity type")

    if normalized_existing == normalized_new:
        return normalized_existing

    # Types differ: prefer existing for stability
    return normalized_existing


def _select_canonical_entity(existing_entities: list[Entity]) -> Entity:
    """Select canonical entity with highest confidence."""
    assert existing_entities is not None, "existing_entities parameter is required"
    assert len(existing_entities) > 0, "must have at least one entity"

    canonical = max(
        existing_entities, key=lambda e: validate_confidence(e.metadata.get("confidence"), 1.0)
    )
    max_conf = validate_confidence(canonical.metadata.get("confidence"), 1.0)
    ties = [
        e
        for e in existing_entities
        if validate_confidence(e.metadata.get("confidence"), 1.0) == max_conf
    ]
    return ties[0] if len(ties) > 1 else canonical


def merge_existing_entities(
    existing_entities: list[Entity], config: OntologyConfig, _normalization_cache: dict[str, str]
) -> tuple[Entity, dict[str, str]]:
    """Merge multiple existing entities with same normalized label."""
    assert existing_entities is not None, "existing_entities parameter is required"
    assert config is not None, "config parameter is required"
    if len(existing_entities) == 1:
        return existing_entities[0], {}

    canonical = _select_canonical_entity(existing_entities)
    id_mapping: dict[str, str] = {}
    merge_ts = get_current_timestamp(config)

    for entity in existing_entities:
        if entity.id == canonical.id:
            continue
        id_mapping[entity.id] = canonical.id
        canon_conf = validate_confidence(canonical.metadata.get("confidence"), 1.0)
        ent_conf = validate_confidence(entity.metadata.get("confidence"), 1.0)

        canonical.properties = merge_properties(
            canonical.properties, entity.properties, canon_conf, ent_conf, config=config
        )
        canonical.aliases = _merge_entity_aliases(canonical, entity)
        canonical.description = merge_entity_descriptions(
            canonical.description, entity.description, canon_conf, ent_conf, config
        )
        _merge_entity_metadata(canonical, entity, canon_conf, ent_conf, merge_ts)

        if "merged_from" not in canonical.metadata:
            canonical.metadata["merged_from"] = []
        canonical.metadata["merged_from"].append(
            {
                "entity_id": entity.id,
                "label": entity.label,
                "merge_reason": "existing_duplicate",
                "timestamp": merge_ts,
            }
        )

    from taxonomy_ontology_accelerator.ontology_engine.processing.merge_validator import (
        validate_entity_merge,
    )

    errors = validate_entity_merge(canonical, existing_entities)
    if errors:
        logger.debug(f"Merge validation found {len(errors)} issues for '{canonical.id}'")

    return canonical, id_mapping


def merge_new_with_existing(
    new_entity: Entity,
    existing_entity: Entity,
    config: OntologyConfig,
    normalization_cache: dict[str, str],
    merge_reason: str = "exact_match",
) -> tuple[Entity, dict[str, str]]:
    """Merge new entity with existing entity, preserving existing ID for relationships."""
    assert new_entity is not None, "new_entity parameter is required"
    assert existing_entity is not None, "existing_entity parameter is required"

    original_new_id = new_entity.id
    merge_ts = get_current_timestamp(config)
    id_mapping: dict[str, str] = (
        {original_new_id: existing_entity.id} if original_new_id != existing_entity.id else {}
    )

    existing_entity.type = merge_entity_types(
        existing_entity.type, new_entity.type, config, normalization_cache
    )
    exist_conf = validate_confidence(existing_entity.metadata.get("confidence"), 1.0)
    new_conf = validate_confidence(new_entity.metadata.get("confidence"), 1.0)

    existing_entity.properties = merge_properties(
        existing_entity.properties, new_entity.properties, exist_conf, new_conf, config=config
    )
    existing_entity.aliases = _merge_entity_aliases(existing_entity, new_entity)
    existing_entity.description = merge_entity_descriptions(
        existing_entity.description, new_entity.description, exist_conf, new_conf, config
    )
    _merge_entity_metadata(existing_entity, new_entity, exist_conf, new_conf, merge_ts)

    if "merged_from" not in existing_entity.metadata:
        existing_entity.metadata["merged_from"] = []
    existing_entity.metadata["merged_from"].append(
        {
            "entity_id": original_new_id,
            "label": new_entity.label,
            "merge_reason": merge_reason,
            "timestamp": merge_ts,
        }
    )

    from taxonomy_ontology_accelerator.ontology_engine.processing.merge_validator import (
        validate_entity_merge,
    )

    errors = validate_entity_merge(existing_entity, [new_entity])
    if errors:
        logger.debug(f"Merge validation found {len(errors)} issues for '{existing_entity.id}'")

    return existing_entity, id_mapping
