"""
Schema evolution functions for ontology extraction.
"""

import re
from contextlib import suppress
from dataclasses import dataclass
from typing import TypedDict

from taxonomy_ontology_accelerator.commons.errors import ErrorCollector
from taxonomy_ontology_accelerator.commons.utils.logger import get_logger
from taxonomy_ontology_accelerator.ontology_engine.config.config import OntologyConfig
from taxonomy_ontology_accelerator.ontology_engine.core.models import (
    Entity,
    EntityTypeDefinition,
    OntologySchema,
    OWLRestriction,
    Relationship,
    RelationshipTypeDefinition,
)
from taxonomy_ontology_accelerator.ontology_engine.processing.type_similarity import (
    check_type_similarity_batch,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.error_helpers import (
    collect_error_if_enabled,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.id_generation import get_current_timestamp
from taxonomy_ontology_accelerator.ontology_engine.utils.text_normalization import (
    correct_text_against_vocabulary,
    normalize_type_with_validation,
    split_identifier_words,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.versioning import increment_schema_version


class RelTypeInfo(TypedDict):
    """Type information for a relationship type."""

    from_type_counts: dict[str, int]
    to_type_counts: dict[str, int]
    from_types: set[str]
    to_types: set[str]

logger = get_logger()

_RELATION_TOKEN_EXPANSIONS = {
    "into": ("in", "to"),
    "onto": ("on", "to"),
}
_RELATION_ALIAS_KEY_CANONICAL = {
    "subclassof": "isa",
    "typeof": "isa",
    "kindof": "isa",
}
_NON_COLLAPSIBLE_RELATION_BASE_ALIAS_KEYS = frozenset(
    {
        "has",
        "have",
        "isa",
        "relatedto",
        "partof",
        "dependson",
        "appliesto",
    }
)

_NOISY_ROOT_TYPE_NAMES = frozenset(
    {
        "entity",
        "thing",
        "object",
        "item",
        "concept",
        "resource",
        "node",
        "element",
        "misc",
        "other",
        "individual",   # OWL reserved — never a domain concept_type
        "class",        # OWL reserved — never a domain concept_type
        "unknown",
        "error",
        "errors",
        "exception",
    }
)

def _is_noisy_root_type_name(type_name: str, core_entity_name: str) -> bool:
    assert type_name is not None, "type_name must not be None"
    assert core_entity_name is not None, "core_entity_name must not be None"
    normalized = type_name.strip().lower()
    return (
        normalized in _NOISY_ROOT_TYPE_NAMES
        or normalized == core_entity_name.strip().lower()
        or re.fullmatch(r"error\d+", normalized) is not None
    )

def _create_initial_schema(domain: str, config: OntologyConfig) -> OntologySchema:
    """
    Create a new schema with core entity type and core relationship types.

    This is called when no existing schema exists. The schema starts with:
    - One core entity type (e.g., "entity") with base fields
    - Core relationship types defined in config (e.g., "is_a", "related_to")

    Args:
        domain: Domain identifier (e.g., "travel", "medical")
        config: Ontology configuration containing schema evolution settings

    Returns:
        New OntologySchema with initial version and core types
    """
    assert domain is not None, "Domain must not be None"
    assert isinstance(domain, str), "Domain must be a string"
    assert config is not None, "Config must not be None"
    assert hasattr(config, "schema_evolution"), "Config must have schema_evolution attribute"

    core_entity = config.schema_evolution.core_entity_type
    entity_types = {
        core_entity.name: EntityTypeDefinition(
            fields=core_entity.fields,
            required_fields=core_entity.required_fields,
        )
    }

    relationship_types = {}
    for rel_config in config.schema_evolution.core_relationship_types:
        relationship_types[rel_config.name] = RelationshipTypeDefinition(
            is_core=rel_config.is_core,
            from_type=rel_config.from_type,
            to_type=rel_config.to_type,
        )

    return OntologySchema(
        domain=domain,
        version=config.schema_evolution.initial_version,
        entity_types=entity_types,
        relationship_types=relationship_types,  # pyright: ignore[reportUnknownArgumentType]
    )

def _normalize_schema_types(
    schema: OntologySchema,
    config: OntologyConfig,
    cache: dict[str, str],
    error_collector: ErrorCollector,
) -> dict[str, str]:
    """
    Normalize existing schema entity type names for comparison.

    Creates a mapping from normalized type names to original type names,
    enabling case-insensitive and format-normalized type matching.

    Args:
        schema: Existing ontology schema
        config: Ontology configuration with normalization settings
        cache: Shared normalization cache for efficiency
        error_collector: Collector for non-fatal errors

    Returns:
        Dict mapping normalized_type_name -> original_type_name
    """
    assert schema is not None, "Schema must not be None"
    assert isinstance(cache, dict), "Cache must be a dict"
    assert config is not None, "Config must not be None"
    assert error_collector is not None, "Error collector must not be None"

    normalized_types: dict[str, str] = {}
    for existing_type_name in schema.entity_types:
        normalized = normalize_type_with_validation(
            existing_type_name, config, cache, error_collector, context="existing schema type"
        )
        normalized_types[normalized] = existing_type_name
    return normalized_types

def _filter_existing_types(
    unique_types: dict[str, str | None],
    normalized_schema_types: dict[str, str],
    entities: list[Entity],
    config: OntologyConfig,
    cache: dict[str, str],
    error_collector: ErrorCollector,
) -> dict[str, str | None]:
    """
    Filter out entity types that already exist in schema via normalization.

    For types that match existing schema types (after normalization), updates
    the entity's type to use the existing type name. Returns only types that
    need semantic similarity checking.

    Args:
        unique_types: Dict of type_name -> description from extracted entities
        normalized_schema_types: Dict of normalized_name -> original_name from schema
        entities: List of entities to update if type matches existing
        config: Ontology configuration
        cache: Shared normalization cache
        error_collector: Collector for non-fatal errors

    Returns:
        Dict of types that need similarity checking (not found via normalization)
    """
    assert unique_types is not None, "Unique types must not be None"
    assert isinstance(unique_types, dict), "Unique types must be a dict"
    assert isinstance(normalized_schema_types, dict), "Normalized schema types must be a dict"
    assert isinstance(entities, list), "Entities must be a list"

    types_needing_check: dict[str, str | None] = {}
    schema_token_vocabulary = {
        token.lower()
        for existing_name in normalized_schema_types
        for token in split_identifier_words(existing_name).split()
        if token
    }

    for type_name, type_desc in unique_types.items():
        normalized = normalize_type_with_validation(
            type_name, config, cache, error_collector, context="entity type"
        )
        corrected_spaced = correct_text_against_vocabulary(
            split_identifier_words(normalized),
            schema_token_vocabulary,
            config,
        )
        if corrected_spaced != split_identifier_words(normalized):
            from taxonomy_ontology_accelerator.ontology_engine.core.models import apply_type_casing

            normalized = apply_type_casing(corrected_spaced, config.naming_conventions.entity_type_casing)

        if normalized in normalized_schema_types:
            existing_name = normalized_schema_types[normalized]
            if existing_name != type_name:
                logger.debug(f"Type '{type_name}' matches '{existing_name}'. Using existing.")
                for e in entities:
                    if e.type == type_name:
                        e.type = existing_name
        else:
            types_needing_check[type_name] = type_desc

    return types_needing_check

def _collect_restrictions_from_entities(
    entities: list[Entity], type_name: str
) -> list[OWLRestriction]:
    """
    Collect OWL restrictions from entities of a given type.

    Reads the '_restrictions' key from entity properties (set by entity_processor
    from ExtractedConcept.restrictions) and converts raw dicts to OWLRestriction objects.

    Args:
        entities: All entities
        type_name: Entity type to collect restrictions for

    Returns:
        List of valid OWLRestriction objects
    """
    assert isinstance(entities, list), "entities must be a list"
    assert type_name is not None, "type_name must not be None"

    restrictions: list[OWLRestriction] = []
    seen: set[tuple[str, str]] = set()

    for entity in entities:
        if entity.type != type_name:
            continue
        raw_restrictions = entity.properties.get("_restrictions", [])
        if not isinstance(raw_restrictions, list):
            continue
        for raw in raw_restrictions:
            if not isinstance(raw, dict):
                continue
            prop = raw.get("property")
            rtype = raw.get("restriction_type")
            if not prop or not rtype:
                continue
            # Deduplicate by (property, restriction_type)
            # Deduplicate by (property, restriction_type)
            key = (str(prop), str(rtype))
            if key in seen:
                continue
            seen.add(key)
            with suppress(Exception):
                restrictions.append(
                    OWLRestriction(
                        property=prop,
                        restriction_type=rtype,
                        value=raw.get("value"),
                        on_class=raw.get("on_class"),
                    )
                )

    return restrictions

def _normalize_type_name_and_metadata(
    type_name: str,
    entities: list[Entity],
    config: OntologyConfig,
    cache: dict[str, str],
    error_collector: ErrorCollector,
) -> tuple[str, str | None, str | None]:
    """Normalize type name and extract metadata if formal identifier."""
    assert type_name is not None, "type_name must not be None"
    assert isinstance(entities, list), "entities must be a list"

    from taxonomy_ontology_accelerator.ontology_engine.utils.text_normalization import (
        is_formal_identifier,
    )

    if is_formal_identifier(type_name, config):
        type_entities = [e for e in entities if e.type == type_name]
        label = type_entities[0].label if type_entities else None
        desc = type_entities[0].description if type_entities else None
        return type_name, label, desc

    normalized = normalize_type_with_validation(
        type_name, config, cache, error_collector, context="entity type"
    )
    type_entities = [e for e in entities if e.type == type_name]
    desc = type_entities[0].description if type_entities else None
    return normalized, None, desc

def _create_new_entity_type(
    type_name: str,
    schema: OntologySchema,
    entities: list[Entity],
    config: OntologyConfig,
    cache: dict[str, str],
    error_collector: ErrorCollector,
) -> None:
    """Create a new entity type in the schema."""
    assert type_name is not None, "Type name must not be None"
    assert schema is not None, "Schema must not be None"

    normalized_name, label, desc = _normalize_type_name_and_metadata(
        type_name, entities, config, cache, error_collector
    )

    core_entity_name = config.schema_evolution.core_entity_type.name
    target_type_name = normalized_name
    if _is_noisy_root_type_name(normalized_name, core_entity_name):
        target_type_name = core_entity_name

    if target_type_name not in schema.entity_types:
        schema.entity_types[target_type_name] = EntityTypeDefinition(
            parent_type=None if target_type_name == core_entity_name else core_entity_name,
            label=label,
            description=desc,
            fields=config.schema_evolution.default_new_type_fields,
            required_fields=config.schema_evolution.default_new_type_required_fields,
            created_at=get_current_timestamp(config),
            similarity_check=None,
            restrictions=_collect_restrictions_from_entities(entities, type_name),
        )
    else:
        existing_restrictions = {
            (r.property, r.restriction_type.value, r.on_class, str(r.value))
            for r in schema.entity_types[target_type_name].restrictions
        }
        for restriction in _collect_restrictions_from_entities(entities, type_name):
            key = (
                restriction.property,
                restriction.restriction_type.value,
                restriction.on_class,
                str(restriction.value),
            )
            if key not in existing_restrictions:
                schema.entity_types[target_type_name].restrictions.append(restriction)
                existing_restrictions.add(key)

    if target_type_name != type_name:
        for e in entities:
            if e.type == type_name:
                e.type = target_type_name

    logger.debug(f"Created new entity type: {target_type_name}")

_TYPE_MERGE_SIMILARITY_THRESHOLD = 0.95
"""Similarity score at or above which a new type is merged into the existing type.
Below this threshold the new type is kept as a distinct subtype linked via parent_type."""


def _use_existing_entity_type(
    type_name: str,
    similar_type: str,
    similarity_score: float,
    schema: OntologySchema,
    entities: list[Entity],
    config: OntologyConfig,
) -> None:
    """
    Use an existing similar type instead of creating a new one.

    If similarity_score >= _TYPE_MERGE_SIMILARITY_THRESHOLD, the types are treated as
    duplicates: entities are redirected to similar_type and type_name is not added to schema.

    If similarity_score < _TYPE_MERGE_SIMILARITY_THRESHOLD, type_name is a distinct subtype:
    it is added to schema with parent_type = similar_type so the hierarchy is preserved.

    Args:
        type_name: Original type name
        similar_type: Existing similar type to use
        similarity_score: Similarity score between types
        schema: Ontology schema to update
        entities: Entities to update with the similar type
        config: Ontology configuration
    """
    assert type_name is not None, "Type name must not be None"
    assert similar_type is not None, "Similar type must not be None"
    assert isinstance(similarity_score, float), "Similarity score must be a float"
    assert isinstance(entities, list), "Entities must be a list"

    if _would_invert_lexical_specificity(type_name, similar_type):
        logger.info(
            f"Skipping similarity-based hierarchy '{type_name}' -> '{similar_type}' "
            "because it would invert lexical specificity"
        )
        return

    if similarity_score >= _TYPE_MERGE_SIMILARITY_THRESHOLD:
        # Near-duplicate: redirect entities and record similarity on the existing type
        logger.info(
            f"Using existing type '{similar_type}' for '{type_name}' | Similarity: {similarity_score:.3f}"
        )
        for e in entities:
            if e.type == type_name:
                e.type = similar_type

        if similar_type in schema.entity_types:
            existing_def = schema.entity_types[similar_type]
            if existing_def.similarity_check is None:
                existing_def.similarity_check = {}
            existing_def.similarity_check[type_name] = {
                "similarity": similarity_score,
                "checked_at": get_current_timestamp(config),
            }
    else:
        # Semantically related but distinct subtype — keep the type and link it
        if not _can_assign_parent_type(type_name, similar_type, schema):
            logger.info(
                f"Skipping similarity-based hierarchy '{type_name}' -> '{similar_type}' "
                f"(similarity={similarity_score:.3f}) because it is invalid"
            )
            return

        logger.info(
            f"Linking '{type_name}' as subtype of '{similar_type}' (similarity={similarity_score:.3f})"
        )
        if type_name not in schema.entity_types:
            schema.entity_types[type_name] = EntityTypeDefinition(
                parent_type=similar_type,
                fields=config.schema_evolution.default_new_type_fields,
                required_fields=config.schema_evolution.default_new_type_required_fields,
                created_at=get_current_timestamp(config),
                similarity_check={type_name: {"similarity": similarity_score,
                                              "similar_to": similar_type}},
            )
        else:
            schema.entity_types[type_name].parent_type = similar_type

def _apply_similarity_results(
    types_needing_check: dict[str, str | None],
    similarity_results: dict[str, tuple[bool, str | None, float]],
    schema: OntologySchema,
    entities: list[Entity],
    config: OntologyConfig,
    cache_and_errors: tuple[dict[str, str], ErrorCollector],
) -> int:
    """
    Apply similarity check results by creating or reusing entity types.

    Args:
        types_needing_check: Dict of type_name -> description
        similarity_results: Similarity check results
        schema: Ontology schema to update
        entities: Entities to update
        config: Ontology configuration
        cache_and_errors: Tuple of (cache, error_collector)

    Returns:
        Count of new entity types created
    """
    assert types_needing_check is not None, "Types needing check must not be None"
    assert similarity_results is not None, "Similarity results must not be None"
    assert isinstance(cache_and_errors, tuple), "Cache and errors must be a tuple"

    cache, error_collector = cache_and_errors

    new_count = 0
    for type_name in types_needing_check:
        should_create, similar_type, similarity_score = similarity_results.get(
            type_name, (True, None, 0.0)
        )

        if should_create:
            _create_new_entity_type(type_name, schema, entities, config, cache, error_collector)
            new_count += 1
        elif similar_type:
            if _would_invert_lexical_specificity(type_name, similar_type):
                logger.info(
                    f"Keeping '{type_name}' as a distinct type instead of linking it under "
                    f"more specific '{similar_type}'"
                )
                _create_new_entity_type(
                    type_name, schema, entities, config, cache, error_collector
                )
                new_count += 1
                continue
            _use_existing_entity_type(
                type_name, similar_type, similarity_score, schema, entities, config
            )

    return new_count

async def _process_entity_type_similarity(
    types_needing_check: dict[str, str | None],
    schema: OntologySchema,
    entities: list[Entity],
    config: OntologyConfig,
    cache: dict[str, str],
    error_collector: ErrorCollector,
) -> int:
    """
    Process entity types using semantic similarity checking.

    For each type that wasn't found via normalization:
    1. Batch check similarity against all existing schema types
    2. If similar type found (above threshold): use existing type, update entities
    3. If no similar type: create new type in schema with core entity as parent

    Args:
        types_needing_check: Dict of type_name -> description to check
        schema: Ontology schema to update with new types
        entities: List of entities to update with matched/normalized types
        config: Ontology configuration with similarity threshold
        cache: Shared normalization cache
        error_collector: Collector for non-fatal errors

    Returns:
        Count of new entity types created in schema
    """
    assert types_needing_check is not None, "Types needing check must not be None"
    assert isinstance(types_needing_check, dict), "Types needing check must be a dict"
    assert schema is not None, "Schema must not be None"
    assert isinstance(entities, list), "Entities must be a list"

    if not types_needing_check:
        return 0

    threshold = config.schema_evolution.type_similarity_threshold
    msg = (
        f"Batch checking {len(types_needing_check)} types against "
        f"{len(schema.entity_types)} existing"
    )
    logger.debug(msg)
    similarity_results = await check_type_similarity_batch(
        types_needing_check, schema, threshold, config
    )

    if similarity_results is None or not hasattr(similarity_results, "get"):  # pyright: ignore[reportUnnecessaryComparison]
        similarity_results = {}

    return _apply_similarity_results(
        types_needing_check, similarity_results, schema, entities, config, (cache, error_collector)
    )

@dataclass
class RelProcessingContext:
    """Context for relationship processing."""

    schema: OntologySchema
    entity_by_id: dict[str, Entity]
    normalized_rel_types: dict[str, str]
    rel_cache: dict[str, str]

def _normalize_relationship_types(
    schema: OntologySchema,
    config: OntologyConfig,
    rel_cache: dict[str, str],
    error_collector: ErrorCollector,
) -> dict[str, str]:
    """
    Normalize existing relationship types for comparison.

    Args:
        schema: Ontology schema
        config: Ontology configuration
        rel_cache: Relationship type normalization cache
        error_collector: Error collector

    Returns:
        Dict mapping normalized_name -> original_name
    """
    assert schema is not None, "Schema must not be None"
    assert isinstance(schema.relationship_types, dict), "Relationship types must be a dict"

    normalized_rel_types: dict[str, str] = {}
    for rel_type in schema.relationship_types:
        normalized = normalize_type_with_validation(
            rel_type, config, rel_cache, error_collector, context="existing relationship type"
        )
        normalized_rel_types[normalized] = rel_type
    return normalized_rel_types

def _process_relationships(
    relationships: list[Relationship],
    ctx: RelProcessingContext,
    config: OntologyConfig,
    error_collector: ErrorCollector,
) -> dict[str, RelTypeInfo]:
    """
    Process relationships and collect type info for new relationship types.

    Args:
        relationships: List of relationships to process
        ctx: Relationship processing context
        config: Ontology configuration
        error_collector: Error collector

    Returns:
        Dict of rel_type -> RelTypeInfo for new relationship types
    """
    assert isinstance(relationships, list), "Relationships must be a list"
    assert ctx is not None, "Context must not be None"

    rel_type_info: dict[str, RelTypeInfo] = {}

    for rel in relationships:
        passive_by_match = _find_existing_active_relationship_for_passive_by(rel, ctx)
        if passive_by_match is not None:
            rel.type = passive_by_match
            rel.from_, rel.to = rel.to, rel.from_

            existing_def = ctx.schema.relationship_types.get(passive_by_match)
            if existing_def:
                _relax_type_constraints(
                    existing_def,
                    rel,
                    ctx.entity_by_id,
                    passive_by_match,
                    ctx.schema,
                    config.schema_evolution.core_entity_type.name,
                )
            continue

        normalized = _normalize_relationship_type_against_schema_vocabulary(
            rel.type,
            ctx.schema,
            ctx.normalized_rel_types,
            config,
            ctx.rel_cache,
            error_collector,
        )

        if normalized in ctx.normalized_rel_types:
            existing_name = ctx.normalized_rel_types[normalized]
            if existing_name != rel.type:
                rel.type = existing_name

            existing_def = ctx.schema.relationship_types.get(existing_name)
            if existing_def:
                _relax_type_constraints(
                    existing_def,
                    rel,
                    ctx.entity_by_id,
                    existing_name,
                    ctx.schema,
                    config.schema_evolution.core_entity_type.name,
                )
            continue

        if rel.type not in rel_type_info:
            rel_type_info[rel.type] = RelTypeInfo(
                from_type_counts={}, to_type_counts={}, from_types=set(), to_types=set()
            )

        _track_relationship_entities(rel, rel_type_info[rel.type], ctx.entity_by_id)

    return rel_type_info


def _passive_by_relationship_match_key(rel_type: str) -> str | None:
    """Return the active-voice lexical key for a passive-by relationship name."""
    assert rel_type is not None, "Relationship type must not be None"

    tokens = [
        _normalize_relationship_inverse_token(token)
        for token in _split_relationship_type_tokens(rel_type)
    ]
    tokens = [token for token in tokens if token]
    if len(tokens) < 2 or tokens[-1] != "by":
        return None

    active_tokens = tokens[:-1]
    if not active_tokens:
        return None

    return "".join(active_tokens)


def _relationship_inverse_match_key(rel_type: str) -> str:
    """Build a lemmatized lexical key for inverse/passive property matching."""
    assert rel_type is not None, "Relationship type must not be None"

    return "".join(
        _normalize_relationship_inverse_token(token)
        for token in _split_relationship_type_tokens(rel_type)
        if token
    )


def _find_existing_active_relationship_for_passive_by(
    rel: Relationship,
    ctx: RelProcessingContext,
) -> str | None:
    """Reuse an existing active property when a passive-by variant only flips direction."""
    assert rel is not None, "Relationship must not be None"
    assert ctx is not None, "Context must not be None"

    passive_key = _passive_by_relationship_match_key(rel.type)
    if passive_key is None:
        return None

    source_entity = ctx.entity_by_id.get(rel.from_)
    target_entity = ctx.entity_by_id.get(rel.to)
    if source_entity is None or target_entity is None:
        return None

    candidates: list[str] = []
    for existing_name, rel_def in ctx.schema.relationship_types.items():
        existing_tokens = _split_relationship_type_tokens(existing_name)
        if existing_tokens and existing_tokens[-1].lower() == "by":
            continue
        if _relationship_inverse_match_key(existing_name) != passive_key:
            continue
        if not _types_are_hierarchically_compatible(
            rel_def.from_type,
            target_entity.type,
            ctx.schema,
        ):
            continue
        if not _types_are_hierarchically_compatible(
            rel_def.to_type,
            source_entity.type,
            ctx.schema,
        ):
            continue
        candidates.append(existing_name)

    if len(candidates) != 1:
        return None

    return candidates[0]


def _normalize_relationship_inverse_token(token: str) -> str:
    """Apply a lightweight lemmatization heuristic for inverse/property matching."""
    assert token is not None, "token must not be None"

    lowered = token.lower()
    if lowered.endswith("ies") and len(lowered) > 4:
        return lowered[:-3] + "y"
    if lowered.endswith("ing") and len(lowered) > 5:
        return lowered[:-3]
    if lowered.endswith("ed") and len(lowered) > 4:
        root = lowered[:-2]
        if root.endswith("e"):
            return root
        return root + "e"
    if lowered.endswith("es") and len(lowered) > 4:
        root = lowered[:-2]
        if root.endswith("e"):
            return root
        return root + "e"
    if lowered.endswith("s") and len(lowered) > 3:
        return lowered[:-1]
    return lowered


def _link_passive_by_inverse_pairs(schema: OntologySchema) -> int:
    """Link active/passive-by property pairs as inverses when endpoints are clean reversals."""
    assert schema is not None, "schema must not be None"

    linked = 0
    for rel_name, rel_def in schema.relationship_types.items():
        passive_key = _passive_by_relationship_match_key(rel_name)
        if passive_key is None:
            continue

        candidates: list[str] = []
        for existing_name, existing_def in schema.relationship_types.items():
            if existing_name == rel_name:
                continue
            existing_tokens = _split_relationship_type_tokens(existing_name)
            if existing_tokens and existing_tokens[-1].lower() == "by":
                continue
            if _relationship_inverse_match_key(existing_name) != passive_key:
                continue
            if not _types_are_hierarchically_compatible(
                existing_def.from_type,
                rel_def.to_type,
                schema,
            ):
                continue
            if not _types_are_hierarchically_compatible(
                existing_def.to_type,
                rel_def.from_type,
                schema,
            ):
                continue
            candidates.append(existing_name)

        if len(candidates) != 1:
            continue

        inverse_name = candidates[0]
        inverse_def = schema.relationship_types[inverse_name]
        changed = False
        if rel_def.inverse_of != inverse_name:
            rel_def.inverse_of = inverse_name
            changed = True
        if inverse_def.inverse_of != rel_name:
            inverse_def.inverse_of = rel_name
            changed = True
        if changed:
            linked += 1

    return linked

def _evolve_relationship_types(
    schema: OntologySchema,
    relationships: list[Relationship],
    entities: list[Entity],
    config: OntologyConfig,
    error_collector: ErrorCollector,
) -> int:
    """
    Evolve relationship types in schema based on extracted relationships.

    Process:
    1. Normalize existing relationship types for comparison
    2. For each relationship, check if type exists (via normalization)
    3. If exists: use existing type, relax constraints if needed
    4. If new: track entity types used, then create type with inferred constraints

    Args:
        schema: Ontology schema to evolve
        relationships: List of extracted relationships
        entities: List of entities (for inferring from/to types)
        config: Ontology configuration
        error_collector: Collector for non-fatal errors

    Returns:
        Count of new relationship types created
    """
    assert schema is not None, "Schema must not be None"
    assert isinstance(relationships, list), "Relationships must be a list"
    assert isinstance(entities, list), "Entities must be a list"
    assert config is not None, "Config must not be None"

    entity_by_id = {e.id: e for e in entities}
    rel_cache: dict[str, str] = {}

    normalized_rel_types = _normalize_relationship_types(schema, config, rel_cache, error_collector)

    proc_ctx = RelProcessingContext(
        schema=schema,
        entity_by_id=entity_by_id,
        normalized_rel_types=normalized_rel_types,
        rel_cache=rel_cache,
    )

    rel_type_info = _process_relationships(relationships, proc_ctx, config, error_collector)

    # Create new relationship types
    # Create new relationship types
    rel_ctx = RelTypeCreationContext(
        schema=schema,
        relationships=relationships,
        normalized_rel_types=normalized_rel_types,
        cache=rel_cache,
    )
    return _create_new_relationship_types(rel_type_info, rel_ctx, config, error_collector)

def _relax_type_constraints(
    rel_def: RelationshipTypeDefinition,
    rel: Relationship,
    entity_by_id: dict[str, Entity],
    rel_type: str,
    schema: OntologySchema,
    core_entity_name: str,
) -> None:
    """
    Relax relationship type constraints to accommodate new entity types.

    If a new relationship uses entity types different from the constraint,
    relaxes the constraint to "entity" (base type) to allow all entity types.
    This prevents over-specialization when relationships span multiple types.

    Example: If "requires" was constrained to Person->Document but a new
    relationship has Organization->Document, from_type becomes "entity".

    Args:
        rel_def: Relationship type definition to potentially modify
        rel: The relationship triggering the check
        entity_by_id: Map of entity_id -> Entity for type lookup
        rel_type: Name of the relationship type (for logging)
    """
    assert rel_def is not None, "Relationship definition must not be None"
    assert rel is not None, "Relationship must not be None"
    assert isinstance(entity_by_id, dict), "Entity by ID must be a dict"
    assert isinstance(rel_type, str), "Relationship type must be a string"
    assert schema is not None, "Schema must not be None"
    assert core_entity_name is not None, "Core entity name must not be None"

    from_entity = entity_by_id.get(rel.from_)
    to_entity = entity_by_id.get(rel.to)

    if from_entity and rel_def.from_type not in ("entity", from_entity.type):
        common_parent = _find_best_common_parent(
            {rel_def.from_type, from_entity.type},
            schema,
            core_entity_name,
        )
        if common_parent and common_parent != rel_def.from_type:
            logger.debug(
                f"Relaxing '{rel_type}' from_type constraint: "
                f"'{rel_def.from_type}' -> '{common_parent}' "
                f"(triggered by entity type '{from_entity.type}')"
            )
            rel_def.from_type = common_parent

    if to_entity and rel_def.to_type not in ("entity", to_entity.type):
        common_parent = _find_best_common_parent(
            {rel_def.to_type, to_entity.type},
            schema,
            core_entity_name,
        )
        if common_parent and common_parent != rel_def.to_type:
            logger.debug(
                f"Relaxing '{rel_type}' to_type constraint: "
                f"'{rel_def.to_type}' -> '{common_parent}' "
                f"(triggered by entity type '{to_entity.type}')"
            )
            rel_def.to_type = common_parent

def _track_relationship_entities(
    rel: Relationship, info: RelTypeInfo, entity_by_id: dict[str, Entity]
) -> None:
    """
    Track entity types used in a relationship for type inference.

    Updates the RelTypeInfo with:
    - from_types: Set of all entity types used as source
    - to_types: Set of all entity types used as target
    - from_type_counts: Count of each source entity type
    - to_type_counts: Count of each target entity type

    Args:
        rel: Relationship to track
        info: RelTypeInfo to update with entity type information
        entity_by_id: Map of entity_id -> Entity for type lookup
    """
    assert rel is not None, "Relationship must not be None"
    assert info is not None, "RelTypeInfo must not be None"
    assert isinstance(entity_by_id, dict), "Entity by ID must be a dict"
    assert "from_types" in info, "Info must have from_types key"

    from_entity = entity_by_id.get(rel.from_)
    to_entity = entity_by_id.get(rel.to)

    if from_entity:
        info["from_types"].add(from_entity.type)
        info["from_type_counts"][from_entity.type] = (
            info["from_type_counts"].get(from_entity.type, 0) + 1
        )

    if to_entity:
        info["to_types"].add(to_entity.type)
        info["to_type_counts"][to_entity.type] = info["to_type_counts"].get(to_entity.type, 0) + 1

def _infer_endpoint_type(
    type_counts: dict[str, int],
    all_types: set[str],
    schema: OntologySchema | None = None,
    core_entity_name: str = "entity",
) -> str:
    """
    Infer the relationship endpoint type from observed entity types.

    Strategy:
    - If multiple entity types observed: return "entity" (base type)
    - If single entity type: return the most common one
    - If no types observed: return "entity" (fallback)

    This prevents over-specialization when relationships span multiple entity types.

    Args:
        type_counts: Dict of entity_type -> count of occurrences
        all_types: Set of all unique entity types observed

    Returns:
        Inferred entity type constraint for the relationship endpoint
    """
    assert type_counts is not None, "Type counts must not be None"
    assert isinstance(type_counts, dict), "Type counts must be a dict"
    assert isinstance(all_types, set), "All types must be a set"
    assert len(all_types) >= 0, "All types length must be non-negative"

    if len(all_types) > 1:
        common_parent = _find_best_common_parent(all_types, schema, core_entity_name)
        if common_parent is not None:
            return common_parent
        return core_entity_name
    if type_counts:
        return max(type_counts.items(), key=lambda x: x[1])[0]
    return core_entity_name

def _type_parent(type_name: str, schema: OntologySchema | None) -> str | None:
    if schema is None or type_name not in schema.entity_types:
        return None
    return schema.entity_types[type_name].parent_type

def _type_depth(type_name: str, schema: OntologySchema | None) -> int:
    if schema is None:
        return 0
    depth = 0
    current = type_name
    visited: set[str] = set()
    while current and current not in visited:
        visited.add(current)
        parent = _type_parent(current, schema)
        if parent is None:
            break
        depth += 1
        current = parent
    return depth

def _ancestor_chain(type_name: str, schema: OntologySchema | None) -> list[str]:
    if schema is None:
        return [type_name]
    chain: list[str] = [type_name]
    visited = {type_name}
    current = type_name
    while current in schema.entity_types:
        parent = schema.entity_types[current].parent_type
        if parent is None or parent in visited:
            break
        chain.append(parent)
        visited.add(parent)
        current = parent
    return chain


def _types_are_hierarchically_compatible(
    left_type: str,
    right_type: str,
    schema: OntologySchema | None,
    core_entity_name: str = "entity",
) -> bool:
    """Return True when two types are equal or one is an ancestor of the other."""
    assert left_type is not None, "left_type must not be None"
    assert right_type is not None, "right_type must not be None"

    if left_type == right_type:
        return True
    if left_type == core_entity_name or right_type == core_entity_name:
        return True
    if schema is None:
        return False

    left_chain = set(_ancestor_chain(left_type, schema))
    right_chain = set(_ancestor_chain(right_type, schema))
    return left_type in right_chain or right_type in left_chain

def _find_best_common_parent(
    type_names: set[str],
    schema: OntologySchema | None,
    core_entity_name: str,
) -> str | None:
    assert type_names is not None, "type_names must not be None"
    if not type_names:
        return None
    if len(type_names) == 1:
        return next(iter(type_names))
    if schema is None:
        return core_entity_name

    ancestor_sets: list[set[str]] = []
    for type_name in type_names:
        ancestor_sets.append(set(_ancestor_chain(type_name, schema)))

    common = set.intersection(*ancestor_sets) if ancestor_sets else set()
    if not common:
        return core_entity_name

    preferred = [
        t for t in common if t != core_entity_name and t.lower() not in _NOISY_ROOT_TYPE_NAMES
    ]
    candidates = preferred if preferred else list(common)
    return max(candidates, key=lambda t: _type_depth(t, schema))

@dataclass
class RelTypeCreationContext:
    """Context for relationship type creation."""

    schema: OntologySchema
    relationships: list[Relationship]
    normalized_rel_types: dict[str, str]
    cache: dict[str, str]


def _split_relationship_type_tokens(rel_type: str) -> list[str]:
    """Split relationship type into normalized lexical tokens."""
    assert rel_type is not None, "Relationship type must not be None"

    spaced = split_identifier_words(rel_type).replace("_", " ").replace("-", " ")
    tokens: list[str] = []
    for token in spaced.split():
        lowered = token.lower()
        expanded = _RELATION_TOKEN_EXPANSIONS.get(lowered)
        if expanded:
            tokens.extend(expanded)
            continue
        tokens.append(lowered)
    return tokens


def _relationship_alias_key(rel_type: str) -> str:
    """Build a canonical comparison key for relationship types."""
    assert rel_type is not None, "Relationship type must not be None"

    alias_key = "".join(token for token in _split_relationship_type_tokens(rel_type) if token)
    return _RELATION_ALIAS_KEY_CANONICAL.get(alias_key, alias_key)


def _relationship_endpoint_tokens(info: RelTypeInfo) -> set[str]:
    """Collect normalized endpoint-type tokens observed for a relationship."""
    assert info is not None, "Relationship type info must not be None"

    endpoint_tokens: set[str] = set()
    for type_name in info["from_types"] | info["to_types"]:
        endpoint_tokens.update(token.lower() for token in _split_type_tokens(type_name))
    return endpoint_tokens


def _normalize_relationship_type_against_schema_vocabulary(
    rel_type: str,
    schema: OntologySchema,
    normalized_rel_types: dict[str, str],
    config: OntologyConfig,
    cache: dict[str, str],
    error_collector: ErrorCollector,
) -> str:
    """Normalize a relationship type and conservatively correct near-miss tokens."""
    assert rel_type is not None, "Relationship type must not be None"
    assert schema is not None, "Schema must not be None"
    assert normalized_rel_types is not None, "normalized_rel_types must not be None"
    assert config is not None, "Config must not be None"
    assert cache is not None, "cache must not be None"

    normalized = normalize_type_with_validation(
        rel_type, config, cache, error_collector, context="relationship type"
    )

    vocabulary: set[str] = set()
    existing_names = set(schema.relationship_types) | set(normalized_rel_types)
    for existing_name in existing_names:
        spaced_name = split_identifier_words(existing_name).replace("_", " ").replace("-", " ")
        vocabulary.update(token for token in spaced_name.split() if token.isalpha())

    if not vocabulary:
        return normalized

    spaced_normalized = split_identifier_words(normalized).replace("_", " ").replace("-", " ")
    corrected_spaced = correct_text_against_vocabulary(spaced_normalized, vocabulary, config)
    if corrected_spaced == spaced_normalized:
        return normalized

    return normalize_type_with_validation(
        corrected_spaced, config, cache, error_collector, context="relationship type"
    )


def _find_existing_relationship_type_match(
    rel_type: str,
    info: RelTypeInfo,
    ctx: RelTypeCreationContext,
) -> str | None:
    """Find an existing relationship type to reuse for a new lexical variant."""
    assert rel_type is not None, "Relationship type must not be None"
    assert info is not None, "Relationship type info must not be None"
    assert ctx is not None, "Relationship type creation context must not be None"

    target_alias_key = _relationship_alias_key(rel_type)
    exact_matches = [
        existing_name
        for existing_name in ctx.schema.relationship_types
        if _relationship_alias_key(existing_name) == target_alias_key
    ]
    if exact_matches:
        return min(exact_matches, key=lambda name: len(_split_relationship_type_tokens(name)))

    new_tokens = _split_relationship_type_tokens(rel_type)
    if len(new_tokens) <= 1:
        return None

    endpoint_tokens = _relationship_endpoint_tokens(info)
    prefix_matches: list[str] = []
    subsequence_matches: list[str] = []
    for existing_name in ctx.schema.relationship_types:
        existing_tokens = _split_relationship_type_tokens(existing_name)
        if len(existing_tokens) >= len(new_tokens):
            continue
        if new_tokens[: len(existing_tokens)] != existing_tokens:
            matched_positions: list[int] = []
            new_idx = 0
            for token in existing_tokens:
                while new_idx < len(new_tokens) and new_tokens[new_idx] != token:
                    new_idx += 1
                if new_idx == len(new_tokens):
                    matched_positions = []
                    break
                matched_positions.append(new_idx)
                new_idx += 1
            if not matched_positions:
                continue
            matched_position_set = set(matched_positions)
            extra_tokens = [
                token for idx, token in enumerate(new_tokens) if idx not in matched_position_set
            ]
            if extra_tokens and all(token in endpoint_tokens for token in extra_tokens):
                subsequence_matches.append(existing_name)
            continue
        extra_tokens = new_tokens[len(existing_tokens) :]
        if extra_tokens and all(token in endpoint_tokens for token in extra_tokens):
            prefix_matches.append(existing_name)

    if not prefix_matches:
        if not subsequence_matches:
            return None
        return max(subsequence_matches, key=lambda name: len(_split_relationship_type_tokens(name)))

    return max(prefix_matches, key=lambda name: len(_split_relationship_type_tokens(name)))


def _derive_endpoint_qualified_base_relationship_type(
    rel_type: str,
    info: RelTypeInfo,
    config: OntologyConfig,
    cache: dict[str, str],
    error_collector: ErrorCollector,
) -> str | None:
    """Derive a reusable base predicate from an endpoint-qualified relationship name."""
    assert rel_type is not None, "Relationship type must not be None"
    assert info is not None, "Relationship type info must not be None"
    assert config is not None, "Config must not be None"
    assert cache is not None, "cache must not be None"
    assert error_collector is not None, "error_collector must not be None"

    new_tokens = _split_relationship_type_tokens(rel_type)
    if len(new_tokens) <= 1:
        return None

    endpoint_tokens = _relationship_endpoint_tokens(info)
    if not endpoint_tokens:
        return None

    split_index = len(new_tokens)
    while split_index > 1 and new_tokens[split_index - 1] in endpoint_tokens:
        split_index -= 1

    if split_index == len(new_tokens):
        return None

    base_tokens = new_tokens[:split_index]
    suffix_tokens = new_tokens[split_index:]
    if not base_tokens or not suffix_tokens:
        return None
    if not all(token in endpoint_tokens for token in suffix_tokens):
        return None

    base_alias_key = _RELATION_ALIAS_KEY_CANONICAL.get("".join(base_tokens), "".join(base_tokens))
    if base_alias_key in _NON_COLLAPSIBLE_RELATION_BASE_ALIAS_KEYS:
        return None

    candidate = normalize_type_with_validation(
        " ".join(base_tokens),
        config,
        cache,
        error_collector,
        context="relationship type",
    )
    if len(_split_relationship_type_tokens(candidate)) >= len(new_tokens):
        return None

    return candidate

def _extract_owl_features_from_relationships(
    rel_type: str, extracted_relationships: list | None
) -> tuple[list, str | None]:
    """Extract OWL features from extracted relationships for a given type."""
    from taxonomy_ontology_accelerator.ontology_engine.core.models import PropertyCharacteristic

    assert rel_type is not None, "Relationship type must not be None"
    assert isinstance(rel_type, str), "Relationship type must be a string"

    characteristics: list[PropertyCharacteristic] = []
    inverse_of: str | None = None

    if extracted_relationships:
        for ext_rel in extracted_relationships:
            if ext_rel.type == rel_type:
                for char_str in ext_rel.characteristics:
                    with suppress(Exception):
                        characteristics.append(PropertyCharacteristic(char_str))
                if ext_rel.inverse_of:
                    inverse_of = ext_rel.inverse_of

    return list(set(characteristics)), inverse_of

def _update_relationship_types(
    relationships: list[Relationship], old_type: str, new_type: str
) -> None:
    """Update relationship types from old_type to new_type."""
    assert relationships is not None, "Relationships must not be None"
    assert old_type is not None, "Old type must not be None"
    for r in relationships:
        if r.type == old_type:
            r.type = new_type

def _create_single_relationship_type(
    rel_type: str,
    info: RelTypeInfo,
    ctx: RelTypeCreationContext,
    config: OntologyConfig,
    error_collector: ErrorCollector,
    extracted_relationships: list | None = None,
) -> tuple[bool, str]:
    """
    Create a single relationship type in schema.

    Args:
        rel_type: Relationship type name
        info: Relationship type information
        ctx: Relationship type creation context
        config: Ontology configuration
        error_collector: Error collector
        extracted_relationships: Optional list of ExtractedRelationships for OWL features

    Returns:
        Tuple of (created, normalized_name)
    """
    assert rel_type is not None, "Relationship type must not be None"
    assert info is not None, "Relationship type info must not be None"

    normalized = _normalize_relationship_type_against_schema_vocabulary(
        rel_type,
        ctx.schema,
        ctx.normalized_rel_types,
        config,
        ctx.cache,
        error_collector,
    )

    if normalized in ctx.normalized_rel_types:
        existing = ctx.normalized_rel_types[normalized]
        _update_relationship_types(ctx.relationships, rel_type, existing)
        return False, normalized

    existing_match = _find_existing_relationship_type_match(normalized, info, ctx)
    if existing_match is not None:
        _update_relationship_types(ctx.relationships, rel_type, existing_match)
        if normalized != rel_type:
            _update_relationship_types(ctx.relationships, normalized, existing_match)
        return False, existing_match

    base_candidate = _derive_endpoint_qualified_base_relationship_type(
        normalized,
        info,
        config,
        ctx.cache,
        error_collector,
    )
    if base_candidate is not None:
        if base_candidate in ctx.normalized_rel_types:
            existing = ctx.normalized_rel_types[base_candidate]
            _update_relationship_types(ctx.relationships, rel_type, existing)
            if normalized != rel_type:
                _update_relationship_types(ctx.relationships, normalized, existing)
            return False, existing

        normalized = base_candidate

    from_type = _infer_endpoint_type(
        info["from_type_counts"],
        info["from_types"],
        schema=ctx.schema,
        core_entity_name=config.schema_evolution.core_entity_type.name,
    )
    to_type = _infer_endpoint_type(
        info["to_type_counts"],
        info["to_types"],
        schema=ctx.schema,
        core_entity_name=config.schema_evolution.core_entity_type.name,
    )

    characteristics, inverse_of = _extract_owl_features_from_relationships(
        rel_type, extracted_relationships
    )

    ctx.schema.relationship_types[normalized] = RelationshipTypeDefinition(
        is_core=False,
        from_type=from_type,
        to_type=to_type,
        direction=None,
        created_at=get_current_timestamp(config),
        characteristics=characteristics,
        inverse_of=inverse_of,
    )

    if normalized != rel_type:
        _update_relationship_types(ctx.relationships, rel_type, normalized)

    ctx.normalized_rel_types[normalized] = normalized

    logger.debug(f"Created relationship type: {normalized} (from: {from_type}, to: {to_type})")

    return True, normalized

def _create_new_relationship_types(
    rel_type_info: dict[str, RelTypeInfo],
    ctx: RelTypeCreationContext,
    config: OntologyConfig,
    error_collector: ErrorCollector,
    extracted_relationships: list | None = None,
) -> int:
    """
    Create new relationship types in schema based on collected type info.

    For each new relationship type:
    1. Normalize the type name
    2. Check if normalized name already exists (skip if so)
    3. Infer from_type and to_type from observed entity types
    4. Create RelationshipTypeDefinition in schema
    5. Update relationships to use normalized type name

    Args:
        rel_type_info: Dict of type_name -> RelTypeInfo with observed entity types
        ctx: Relationship type creation context
        config: Ontology configuration
        error_collector: Collector for non-fatal errors
        extracted_relationships: Optional list of ExtractedRelationships for OWL features

    Returns:
        Count of new relationship types created
    """
    assert rel_type_info is not None, "Relationship type info must not be None"
    assert isinstance(rel_type_info, dict), "Relationship type info must be a dict"
    assert ctx is not None, "Context must not be None"
    assert config is not None, "Config must not be None"

    new_count = 0

    for rel_type, info in rel_type_info.items():
        created, _ = _create_single_relationship_type(
            rel_type, info, ctx, config, error_collector, extracted_relationships
        )
        if created:
            new_count += 1

    return new_count

async def _evolve_entity_types(
    schema: OntologySchema,
    entities: list[Entity],
    config: OntologyConfig,
    error_collector: ErrorCollector,
) -> int:
    """
    Evolve entity types in schema based on extracted entities.

    Args:
        schema: Ontology schema to evolve
        entities: List of extracted entities
        config: Ontology configuration
        error_collector: Error collector

    Returns:
        Count of new entity types created
    """
    assert schema is not None, "Schema must not be None"
    assert isinstance(entities, list), "Entities must be a list"

    type_normalization_cache: dict[str, str] = {}

    unique_types: dict[str, str | None] = {}
    for entity in entities:
        if entity.type not in unique_types:
            unique_types[entity.type] = entity.description

    normalized_schema_types = _normalize_schema_types(
        schema, config, type_normalization_cache, error_collector
    )

    types_needing_check = _filter_existing_types(
        unique_types,
        normalized_schema_types,
        entities,
        config,
        type_normalization_cache,
        error_collector,
    )

    return await _process_entity_type_similarity(
        types_needing_check, schema, entities, config, type_normalization_cache, error_collector
    )

                                                     
# Relationship types that express taxonomic hierarchy
_SUBCLASS_REL_TYPES = frozenset(
    {
        "isa",
        "is",
        "subclassof",
        "typeof",
        "kindof",
    }
)

def _is_subclass_relationship(rel_type: str) -> bool:
    """Check if a relationship type expresses taxonomic hierarchy."""
    assert rel_type is not None, "Relationship type must not be None"
    assert isinstance(rel_type, str), "Relationship type must be a string"

    normalized = rel_type.lower().replace("_", "").replace("-", "")
    return normalized in _SUBCLASS_REL_TYPES

def _build_entity_id_to_type_map(entities: list[Entity]) -> dict[str, str]:
    """Build mapping from entity ID to entity type."""
    assert entities is not None, "Entities list must not be None"
    assert isinstance(entities, list), "Entities must be a list"

    return {entity.id: entity.type for entity in entities}

def _collect_parent_candidates(
    relationships: list[Relationship],
    entity_id_to_type: dict[str, str],
    schema: OntologySchema,
    skip_types: frozenset[str],
) -> dict[str, dict[str, int]]:
    """
    Collect parent type candidates from subclass relationships.

    Returns:
        Maps child_type -> {parent_type: count}
    """
    assert isinstance(relationships, list), "Relationships must be a list"
    assert schema is not None, "Schema must not be None"

    parent_candidates: dict[str, dict[str, int]] = {}

    for rel in relationships:
        if not _is_subclass_relationship(rel.type):
            continue

        from_type = entity_id_to_type.get(rel.from_)
        to_type = entity_id_to_type.get(rel.to)

        # Skip invalid or self-referential relationships
        # Skip invalid or self-referential relationships
        if not from_type or not to_type or from_type == to_type:
            continue

                                                
        # Skip if either type should be excluded
        if {from_type, to_type} & skip_types:
            continue

        # Skip if either type doesn't exist in schema
        # Skip if either type doesn't exist in schema
        if from_type not in schema.entity_types or to_type not in schema.entity_types:
            continue

                                      
        # Record this parent candidate
        if from_type not in parent_candidates:
            parent_candidates[from_type] = {}
        parent_candidates[from_type][to_type] = parent_candidates[from_type].get(to_type, 0) + 1

    return parent_candidates

def _has_children(type_name: str, schema: OntologySchema) -> bool:
    """Return True if any type in the schema has type_name as its parent_type."""
    assert type_name is not None, "type_name must not be None"
    assert schema is not None, "schema must not be None"

    return any(
        t_def.parent_type == type_name
        for t_def in schema.entity_types.values()
    )


def _would_create_cycle(child: str, parent: str, schema: OntologySchema) -> bool:
    """Check if setting child.parent_type = parent would create a cycle."""
    assert child is not None, "Child type must not be None"
    assert parent is not None, "Parent type must not be None"
    assert schema is not None, "Schema must not be None"

    visited = {child}
    current = parent

    while current and current in schema.entity_types:
        if current in visited:
            return True
        visited.add(current)
        current = schema.entity_types[current].parent_type

    return False


def _is_lexical_parent_candidate(child_type: str, parent_type: str) -> bool:
    """Return True when the parent name is a lexical generalization of the child."""
    assert child_type is not None, "child_type must not be None"
    assert parent_type is not None, "parent_type must not be None"

    child_tokens = [token.lower() for token in _split_type_tokens(child_type)]
    parent_tokens = [token.lower() for token in _split_type_tokens(parent_type)]
    if not child_tokens or not parent_tokens or len(parent_tokens) > len(child_tokens):
        return False

    window = len(parent_tokens)
    return any(
        child_tokens[idx : idx + window] == parent_tokens
        for idx in range(len(child_tokens) - window + 1)
    )


def _should_accept_parent_candidate(
    child_type: str,
    parent_type: str,
    evidence_count: int,
    schema: OntologySchema,
    config: OntologyConfig,
    core_entity_name: str,
) -> bool:
    """Require either repeated evidence or lexical support for type hierarchy updates."""
    assert child_type is not None, "child_type must not be None"
    assert parent_type is not None, "parent_type must not be None"
    assert isinstance(evidence_count, int), "evidence_count must be an integer"
    assert schema is not None, "schema must not be None"
    assert config is not None, "config must not be None"
    assert core_entity_name is not None, "core_entity_name must not be None"

    scaffold_parent_map = _get_structural_scaffold_parent_map(config)
    if child_type in scaffold_parent_map:
        configured_parent = scaffold_parent_map.get(child_type)
        allowed_parent = configured_parent or core_entity_name
        return parent_type == allowed_parent

    if _is_lexical_parent_candidate(child_type, parent_type):
        return True

    if _find_within_vocabulary_parent(child_type, schema, core_entity_name) == parent_type:
        return True

    if evidence_count >= 3:
        if _has_children(child_type, schema) and not _has_children(parent_type, schema):
            return False
        return True

    return False

def _update_parent_types(
    parent_candidates: dict[str, dict[str, int]],
    schema: OntologySchema,
    core_entity_name: str,
    config: OntologyConfig,
) -> int:
    """
    Update parent_type for entity types based on majority voting.

    Returns:
        Number of entity types updated
    """
    assert schema is not None, "Schema must not be None"
    assert core_entity_name is not None, "Core entity name must not be None"
    assert config is not None, "config must not be None"

    updated_count = 0
    just_assigned: set[str] = set()

    for child_type, candidates in parent_candidates.items():
        if not candidates or child_type not in schema.entity_types:
            continue

        type_def = schema.entity_types[child_type]

        # Only update if currently set to core entity (flat hierarchy)
        # Only update if currently set to core entity (flat hierarchy)
        if type_def.parent_type is not None and type_def.parent_type != core_entity_name:
            continue

                                          
        ordered_candidates = sorted(
            candidates.items(),
            key=lambda item: (
                _is_lexical_parent_candidate(child_type, item[0]),
                _find_within_vocabulary_parent(child_type, schema, core_entity_name) == item[0],
                item[0] in _get_structural_scaffold_parent_map(config),
                item[1],
                _type_depth(item[0], schema),
                len(_split_type_tokens(item[0])),
            ),
            reverse=True,
        )

        for best_parent, best_parent_evidence in ordered_candidates:
            if best_parent not in schema.entity_types:
                continue

            if _is_noisy_root_type_name(best_parent, core_entity_name):
                continue

            if not _can_assign_parent_type(child_type, best_parent, schema):
                logger.debug(
                    f"Skipping hierarchy {child_type} -> {best_parent}: invalid parent assignment"
                )
                continue

            if not _should_accept_parent_candidate(
                child_type,
                best_parent,
                best_parent_evidence,
                schema,
                config,
                core_entity_name,
            ):
                logger.debug(
                    f"Skipping hierarchy {child_type} -> {best_parent}: "
                    "candidate lacks lexical or structural support"
                )
                continue

            type_def.parent_type = best_parent
            updated_count += 1
            just_assigned.add(child_type)
            logger.debug(
                f"Set hierarchy: {child_type} -> {best_parent} "
                f"(based on {best_parent_evidence} relationships)"
            )
            break

    # Post-assignment structural reversal: revert cases where an established parent
    # (has children) was assigned under a leaf node (has no children).
    reversed_count = 0
    for child_type in just_assigned:
        type_def = schema.entity_types[child_type]
        parent = type_def.parent_type
        if parent is None or parent == core_entity_name:
            continue
        if _has_children(child_type, schema) and not _has_children(parent, schema):
            logger.info(
                f"Reverting inverted hierarchy: '{child_type}' has children but "
                f"was assigned under leaf '{parent}' — resetting to '{core_entity_name}'"
            )
            type_def.parent_type = core_entity_name
            reversed_count += 1

    if reversed_count > 0:
        updated_count -= reversed_count

    return updated_count

def _build_hierarchy_from_subclass_relationships(
    schema: OntologySchema,
    relationships: list[Relationship],
    entities: list[Entity],
    config: OntologyConfig,
) -> int:
    """
    Build entity type hierarchy from SUBCLASS_OF/IS_A relationships.

    This function examines relationships that express taxonomic hierarchy
    (is_a, subclass_of, etc.) and uses them to set parent_type on entity types.

    For example, if entity A (type "mrna_vaccine") has a subclass_of relationship
    to entity B (type "vaccine"), then mrna_vaccine.parent_type = vaccine.

    Args:
        schema: Ontology schema to update
        relationships: List of relationships to analyze
        entities: List of entities for ID-to-type lookup
        config: Ontology configuration

    Returns:
        Number of entity types that had their parent_type updated
    """
    assert schema is not None, "Schema must not be None"
    assert isinstance(relationships, list), "Relationships must be a list"
    assert isinstance(entities, list), "Entities must be a list"

    core_entity_name = config.schema_evolution.core_entity_type.name
    skip_types = frozenset({core_entity_name})

    entity_id_to_type = _build_entity_id_to_type_map(entities)
    parent_candidates = _collect_parent_candidates(
        relationships, entity_id_to_type, schema, skip_types
    )
    updated_count = _update_parent_types(parent_candidates, schema, core_entity_name, config)

    if updated_count > 0:
        logger.info(f"Built entity type hierarchy: {updated_count} types updated")

    return updated_count


def _get_structural_scaffold_parent_map(config: OntologyConfig) -> dict[str, str | None]:
    """Return configured structural scaffold parent assignments."""
    assert config is not None, "config must not be None"
    return dict(config.schema_evolution.structural_scaffold.parent_map)


def _get_structural_scaffold_suffix_parent_map(config: OntologyConfig) -> dict[str, str]:
    """Return configured structural scaffold suffix rules."""
    assert config is not None, "config must not be None"
    return dict(config.schema_evolution.structural_scaffold.suffix_parent_map)


def _split_type_tokens(type_name: str) -> list[str]:
    """Split type name into normalized token components."""
    assert type_name is not None, "type_name must not be None"

    spaced = re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", type_name.replace("_", " ").replace("-", " "))
    return [token for token in spaced.split() if token]


def _choose_best_parent_candidate(candidates: set[str], schema: OntologySchema) -> str | None:
    """Choose the most specific parent candidate available."""
    assert schema is not None, "schema must not be None"
    if not candidates:
        return None
    return max(candidates, key=lambda t: (_type_depth(t, schema), len(_split_type_tokens(t))))


def _find_within_vocabulary_parent(
    type_name: str,
    schema: OntologySchema,
    core_entity_name: str,
) -> str | None:
    """Infer a parent from the extracted vocabulary before introducing scaffold types."""
    assert type_name is not None, "type_name must not be None"
    assert schema is not None, "schema must not be None"

    candidates: set[str] = set()
    tokens = _split_type_tokens(type_name)

    for idx in range(1, len(tokens)):
        candidate = "".join(tokens[idx:])
        if candidate in schema.entity_types and candidate != type_name:
            if not _is_noisy_root_type_name(candidate, core_entity_name):
                candidates.add(candidate)

    best_parent = _choose_best_parent_candidate(candidates, schema)
    if best_parent == type_name:
        return None
    return best_parent


def _consolidate_hierarchy_from_type_names(
    schema: OntologySchema,
    config: OntologyConfig,
) -> int:
    """
    Consolidate a global hierarchy from the full extracted type vocabulary.

    This is a deterministic pass that repairs flatness introduced by chunk-local
    extraction by using the whole schema vocabulary at once.
    """
    assert schema is not None, "schema must not be None"
    assert config is not None, "config must not be None"

    core_entity_name = config.schema_evolution.core_entity_type.name
    updated_count = 0
    type_names = sorted(schema.entity_types.keys(), key=lambda t: len(_split_type_tokens(t)))

    for child_type in type_names:
        if child_type == core_entity_name:
            continue
        if child_type not in schema.entity_types:
            continue

        type_def = schema.entity_types[child_type]
        if type_def.metadata.get("scaffold_type"):
            continue
        if type_def.parent_type is not None and type_def.parent_type != core_entity_name:
            continue

        parent_type = _find_within_vocabulary_parent(child_type, schema, core_entity_name)
        if not parent_type or parent_type not in schema.entity_types:
            continue
        if not _can_assign_parent_type(child_type, parent_type, schema):
            continue

        type_def.parent_type = parent_type
        updated_count += 1
        logger.debug(f"[Hierarchy Consolidation] Set {child_type}.parent_type = {parent_type}")

    if updated_count > 0:
        logger.info(f"[Hierarchy Consolidation] Linked {updated_count} types from global vocabulary")

    return updated_count


def _create_scaffold_entity_type_definition(
    parent_type: str | None,
    config: OntologyConfig,
) -> EntityTypeDefinition:
    """Create a deterministic upper-ontology scaffold type definition."""
    assert config is not None, "config must not be None"

    return EntityTypeDefinition(
        parent_type=parent_type,
        fields=list(config.schema_evolution.default_new_type_fields),
        required_fields=list(config.schema_evolution.default_new_type_required_fields),
        metadata={"scaffold_type": True, "structure_stage": "upper_ontology"},
        created_at=get_current_timestamp(config),
    )


def _ensure_scaffold_type(
    type_name: str,
    schema: OntologySchema,
    config: OntologyConfig,
    created_types: set[str],
) -> None:
    """Ensure a scaffold type and its ancestors exist in schema."""
    assert type_name is not None, "type_name must not be None"
    assert schema is not None, "schema must not be None"
    assert config is not None, "config must not be None"

    core_entity_name = config.schema_evolution.core_entity_type.name
    scaffold_parent = _get_structural_scaffold_parent_map(config).get(type_name)

    if scaffold_parent is not None:
        _ensure_scaffold_type(scaffold_parent, schema, config, created_types)

    desired_parent = scaffold_parent or core_entity_name

    if type_name not in schema.entity_types:
        schema.entity_types[type_name] = _create_scaffold_entity_type_definition(
            desired_parent,
            config,
        )
        created_types.add(type_name)
        return

    type_def = schema.entity_types[type_name]
    if type_def.parent_type in (None, core_entity_name) and type_name != desired_parent:
        if desired_parent in schema.entity_types and _can_assign_parent_type(
            type_name, desired_parent, schema
        ):
            type_def.parent_type = desired_parent


def _resolve_scaffold_parent_for_type(
    type_name: str,
    schema: OntologySchema,
    config: OntologyConfig,
) -> str | None:
    """Map a concrete type to a deterministic upper-ontology parent."""
    assert type_name is not None, "type_name must not be None"
    assert schema is not None, "schema must not be None"
    assert config is not None, "config must not be None"

    parent_map = _get_structural_scaffold_parent_map(config)
    suffix_parent_map = _get_structural_scaffold_suffix_parent_map(config)

    if type_name in parent_map:
        return parent_map[type_name]

    lowered = type_name.lower()

    for suffix, parent_name in suffix_parent_map.items():
        normalized_suffix = suffix.strip().lower()
        if normalized_suffix and lowered.endswith(normalized_suffix):
            return parent_name

    return None


def apply_structural_upper_ontology_scaffold(
    schema: OntologySchema,
    config: OntologyConfig,
) -> tuple[int, set[str]]:
    """
    Apply deterministic upper-ontology scaffolding over the evolved vocabulary.

    Unlike the optional LLM-based upper-ontology stage, this pass is always
    deterministic and creates only a small reusable scaffold needed by the
    current vocabulary.
    """
    assert schema is not None, "schema must not be None"
    assert config is not None, "config must not be None"

    if not config.schema_evolution.structural_scaffold.enabled:
        return 0, set()

    core_entity_name = config.schema_evolution.core_entity_type.name
    updated_count = 0
    created_types: set[str] = set()
    parent_map = _get_structural_scaffold_parent_map(config)

    for type_name in list(schema.entity_types.keys()):
        if type_name == core_entity_name:
            continue

        target_parent = _resolve_scaffold_parent_for_type(type_name, schema, config)
        if not target_parent:
            continue

        if target_parent in parent_map:
            _ensure_scaffold_type(target_parent, schema, config, created_types)

        if target_parent not in schema.entity_types or target_parent == type_name:
            continue

        type_def = schema.entity_types[type_name]
        if type_def.parent_type is not None and type_def.parent_type != core_entity_name:
            continue
        if type_name == target_parent or _would_create_cycle(type_name, target_parent, schema):
            continue

        type_def.parent_type = target_parent
        updated_count += 1
        logger.debug(f"[Upper Ontology] Set {type_name}.parent_type = {target_parent}")

    if created_types or updated_count > 0:
        logger.info(
            f"[Upper Ontology] Applied deterministic scaffold: {updated_count} links, "
            f"{len(created_types)} new abstract types"
        )

    return updated_count, created_types


def _is_broad_scaffold_parent(
    parent_type: str | None,
    schema: OntologySchema,
    config: OntologyConfig,
) -> bool:
    """Return True when the current parent is a generic scaffold anchor."""
    assert schema is not None, "schema must not be None"
    assert config is not None, "config must not be None"

    if not parent_type or parent_type not in schema.entity_types:
        return False

    parent_def = schema.entity_types[parent_type]
    if parent_def.metadata.get("scaffold_type"):
        return True

    return parent_type in _get_structural_scaffold_parent_map(config)


def refine_hierarchy_from_specific_vocabulary(
    schema: OntologySchema,
    config: OntologyConfig,
) -> int:
    """
    Replace broad scaffold parents with more specific lexical vocabulary parents.

    This keeps the generic scaffold as a safety net while still allowing extracted
    vocabulary to supply deeper structure when the child name already contains a
    more specific parent such as `EvidenceRequirement -> Requirement`.
    """
    assert schema is not None, "schema must not be None"
    assert config is not None, "config must not be None"

    core_entity_name = config.schema_evolution.core_entity_type.name
    updated_count = 0

    for child_type, type_def in schema.entity_types.items():
        if child_type == core_entity_name:
            continue
        if type_def.metadata.get("scaffold_type"):
            continue
        if not _is_broad_scaffold_parent(type_def.parent_type, schema, config):
            continue

        refined_parent = _find_within_vocabulary_parent(child_type, schema, core_entity_name)
        if not refined_parent or refined_parent == child_type:
            continue
        if refined_parent not in schema.entity_types:
            continue
        if not _can_assign_parent_type(child_type, refined_parent, schema):
            continue
        if schema.entity_types[refined_parent].metadata.get("scaffold_type"):
            continue
        if refined_parent == type_def.parent_type:
            continue

        type_def.parent_type = refined_parent
        updated_count += 1
        logger.debug(
            f"[Hierarchy Refinement] Replaced broad parent of {child_type} with {refined_parent}"
        )

    if updated_count > 0:
        logger.info(f"[Hierarchy Refinement] Linked {updated_count} types to specific parents")

    return updated_count

def _enforce_type_limits(schema: OntologySchema, config: OntologyConfig) -> None:
    """
    Enforce schema type count limits.

    Args:
        schema: Ontology schema to check
        config: Ontology configuration with limits

    Raises:
        ValueError: If type counts exceed limits
    """
    assert schema is not None, "Schema must not be None"
    assert config is not None, "Config must not be None"

    if (
        config.limits.max_entity_types is not None
        and len(schema.entity_types) > config.limits.max_entity_types
    ):
        msg = (
            f"Schema has {len(schema.entity_types)} entity types, exceeds limit of {config.limits.max_entity_types}. "
            f"Increase limits.max_entity_types in config."
        )
        raise ValueError(msg)

    if (
        config.limits.max_relationship_types is not None
        and len(schema.relationship_types) > config.limits.max_relationship_types
    ):
        msg = (
            f"Schema has {len(schema.relationship_types)} relationship types, "
            f"exceeds limit of {config.limits.max_relationship_types}. "
            f"Increase limits.max_relationship_types in config."
        )
        raise ValueError(msg)

def _update_schema_version(
    schema: OntologySchema,
    new_entity_types: int,
    new_relationship_types: int,
    config: OntologyConfig,
    error_collector: ErrorCollector,
) -> None:
    """
    Update schema version if new types were added.

    Args:
        schema: Ontology schema to update
        new_entity_types: Count of new entity types
        new_relationship_types: Count of new relationship types
        config: Ontology configuration
        error_collector: Error collector
    """
    assert schema is not None, "Schema must not be None"
    assert isinstance(new_entity_types, int), "New entity types must be an integer"

    total_new_types = new_entity_types + new_relationship_types
    if total_new_types > 0:
        try:
            schema.version = increment_schema_version(
                schema.version, config.schema_evolution.version_increment
            )
            schema.last_updated = get_current_timestamp(config)
            msg = (
                f"Schema evolved: version {schema.version}, "
                f"{new_entity_types} new entity types, {new_relationship_types} new relationship types"
            )
            logger.info(msg)
        except ValueError as e:
            severity = "error"
            collect_error_if_enabled(
                error_collector,
                config,
                severity,
                "config_error",
                f"Failed to increment schema version: {e}",
            )
            logger.warning(
                f"Schema version increment failed: {e}. Keeping version {schema.version}"
            )


def _should_accept_upper_ontology_parent(
    child_type: str,
    parent_type: str,
    schema: OntologySchema,
    config: OntologyConfig,
) -> bool:
    """
    Accept upper-ontology links conservatively for configured generic scaffold families.

    The LLM is allowed to propose within-vocabulary structure, but links that touch the
    generic scaffold anchors must agree with deterministic lexical/scaffold evidence so
    anchors like Place, InformationEntity, Service, and Agent are not misused as catch-all
    parents across domains.
    """
    assert child_type is not None, "child_type must not be None"
    assert parent_type is not None, "parent_type must not be None"
    assert schema is not None, "schema must not be None"
    assert config is not None, "config must not be None"

    core_entity_name = config.schema_evolution.core_entity_type.name
    scaffold_parent_map = _get_structural_scaffold_parent_map(config)

    lexical_parent = _find_within_vocabulary_parent(child_type, schema, core_entity_name)
    if _is_lexical_parent_candidate(child_type, parent_type):
        return True
    if lexical_parent == parent_type:
        return True
    if _would_invert_lexical_specificity(child_type, parent_type):
        return False

    direct_scaffold_parent = _resolve_scaffold_parent_for_type(child_type, schema, config)
    if direct_scaffold_parent == parent_type:
        return True

    if child_type in scaffold_parent_map:
        return scaffold_parent_map.get(child_type) == parent_type

    if parent_type in scaffold_parent_map:
        return direct_scaffold_parent == parent_type

    return True


def _repair_hierarchy_inversions_with_scaffold(
    schema: OntologySchema,
    config: OntologyConfig,
) -> int:
    """
    Deterministically repair common hierarchy inversions using the structural scaffold rules.

    Repairs:
    1) Anchor guardrails: types in structural_scaffold.parent_map must keep their configured
       parent (or remain root-ish when configured parent is None). If an anchor was placed
       under a non-anchor leaf type, flip that leaf under the anchor when safe.
    2) Scaffold-family consistency: if a type has a deterministic scaffold parent anchor via
       suffix rules (e.g. *Document -> DocumentType) but is currently attached outside that
       family, re-anchor it to the expected scaffold parent.
    """
    assert schema is not None, "schema must not be None"
    assert config is not None, "config must not be None"

    if not config.schema_evolution.structural_scaffold.enabled:
        return 0

    core_entity_name = config.schema_evolution.core_entity_type.name
    scaffold_parent_map = _get_structural_scaffold_parent_map(config)
    anchor_types = frozenset(scaffold_parent_map.keys())

    def _is_rootish(parent_type: str | None) -> bool:
        return parent_type in (None, core_entity_name)

    updated_count = 0

    # Pass 1: enforce anchor placement and flip inverted edges when safe.
    for anchor_type, configured_parent in scaffold_parent_map.items():
        if anchor_type not in schema.entity_types:
            continue

        allowed_parent = configured_parent or core_entity_name
        current_parent = schema.entity_types[anchor_type].parent_type

        wrong_parent: str | None = None
        if current_parent not in (None, core_entity_name, allowed_parent):
            wrong_parent = current_parent

        # Enforce the anchor's allowed parent (configured parent or core entity/root).
        if configured_parent is None:
            if current_parent not in (None, core_entity_name):
                schema.entity_types[anchor_type].parent_type = core_entity_name
                updated_count += 1
        else:
            if configured_parent in schema.entity_types and _can_assign_parent_type(
                anchor_type, configured_parent, schema
            ):
                if current_parent != configured_parent:
                    schema.entity_types[anchor_type].parent_type = configured_parent
                    updated_count += 1

        # Flip: if anchor was placed under a non-anchor root-ish type, attach that type under the anchor.
        if not wrong_parent:
            continue
        if wrong_parent not in schema.entity_types or wrong_parent in anchor_types:
            continue
        wrong_parent_def = schema.entity_types[wrong_parent]
        if not _is_rootish(wrong_parent_def.parent_type):
            continue
        if not _can_assign_parent_type(wrong_parent, anchor_type, schema):
            continue
        wrong_parent_def.parent_type = anchor_type
        updated_count += 1

    # Pass 2: enforce suffix-derived scaffold families (without flattening within-family structure).
    for type_name, type_def in schema.entity_types.items():
        if type_name == core_entity_name:
            continue
        if type_name in anchor_types:
            continue

        expected_parent = _resolve_scaffold_parent_for_type(type_name, schema, config)
        if not expected_parent or expected_parent not in anchor_types:
            continue
        if expected_parent not in schema.entity_types:
            continue

        current_parent = type_def.parent_type
        if current_parent == expected_parent:
            continue

        # Avoid flattening within-family hierarchies:
        # keep T -> P when P is itself a member of the same scaffold family.
        if current_parent and current_parent in schema.entity_types:
            current_parent_expected = _resolve_scaffold_parent_for_type(
                current_parent, schema, config
            )
            if current_parent_expected == expected_parent:
                continue

        if type_name == expected_parent:
            continue
        if _would_create_cycle(type_name, expected_parent, schema):
            continue

        type_def.parent_type = expected_parent
        updated_count += 1

    return updated_count


def apply_upper_ontology_map(
    schema: OntologySchema,
    hierarchy_map: dict[str, str],
    config: OntologyConfig,
) -> tuple[int, set[str]]:
    """
    Apply a within-vocabulary hierarchy map to the schema.

    For each {child_type: parent_type} pair in the map:
    - Both types must already exist in the schema (no abstract types are created).
    - Sets child_type.parent_type = parent_type (structural subclass link).

    This is called after schema evolution to link types that were extracted from the
    source text into a hierarchy using only vocabulary present in the source text.

    Args:
        schema: Ontology schema to update in-place
        hierarchy_map: Dict mapping child concept_type -> parent concept_type
        config: Ontology configuration

    Returns:
        Tuple of (updated_parent_count, new_type_names) where
        updated_parent_count is how many child types had parent_type set and
        new_type_names is always an empty set (no abstract types are created).
    """
    assert schema is not None, "Schema must not be None"
    assert isinstance(hierarchy_map, dict), "hierarchy_map must be a dict"
    assert config is not None, "Config must not be None"

    updated_count = 0

    for child_type, parent_type in hierarchy_map.items():
        if not child_type or not parent_type:
            continue
        if child_type == parent_type:
            continue
        if child_type not in schema.entity_types:
            logger.debug(f"[Upper Ontology] Skipping unknown child type: {child_type!r}")
            continue
        if parent_type not in schema.entity_types:
            logger.debug(f"[Upper Ontology] Skipping unknown parent type: {parent_type!r}")
            continue

        if not _can_assign_parent_type(child_type, parent_type, schema):
            logger.warning(
                f"[Upper Ontology] Skipping invalid hierarchy: {child_type} -> {parent_type}"
            )
            continue

        if not _should_accept_upper_ontology_parent(child_type, parent_type, schema, config):
            logger.debug(
                "[Upper Ontology] Skipping incompatible hierarchy: "
                f"{child_type} -> {parent_type}"
            )
            continue

        schema.entity_types[child_type].parent_type = parent_type
        updated_count += 1
        logger.debug(f"[Upper Ontology] Set {child_type}.parent_type = {parent_type!r}")

    updated_count += _repair_hierarchy_inversions_with_scaffold(schema, config)

    if updated_count > 0:
        logger.info(f"[Upper Ontology] Applied hierarchy map: {updated_count} types linked")

    return updated_count, set()


async def evolve_schema(
    existing_schema: OntologySchema | None,
    entities: list[Entity],
    relationships: list[Relationship],
    domain: str,
    config: OntologyConfig,
    error_collector: ErrorCollector,
) -> tuple[OntologySchema, int, int]:
    """
    Evolve schema by adding new entity types and relationship types.

    OWL features are automatically included in entity/relationship type definitions.

    Args:
        existing_schema: Existing schema or None for fresh extraction
        entities: List of entities
        relationships: List of relationships
        domain: Domain identifier
        config: Ontology configuration
        error_collector: Error collector

    Returns:
        Tuple of (schema, new_entity_types_count, new_relationship_types_count)
    """
    assert isinstance(entities, list), "Entities must be a list"
    assert isinstance(relationships, list), "Relationships must be a list"
    assert isinstance(domain, str), "Domain must be a string"
    assert config is not None, "Config must not be None"

    schema = existing_schema if existing_schema else _create_initial_schema(domain, config)

    logger.info(
        f"Evolving schema for {len(entities)} entities and {len(relationships)} relationships..."
    )
    new_entity_types = await _evolve_entity_types(schema, entities, config, error_collector)
    logger.info(f"Entity type evolution: {new_entity_types} new types added")

    new_relationship_types = _evolve_relationship_types(
        schema, relationships, entities, config, error_collector
    )
    logger.info(f"Relationship type evolution: {new_relationship_types} new types added")
    _link_passive_by_inverse_pairs(schema)

    # Build entity type hierarchy from SUBCLASS_OF relationships
    # This must happen after both entity types and relationships are processed
    # Build entity type hierarchy from SUBCLASS_OF relationships
    # This must happen after both entity types and relationships are processed
    hierarchy_updates = _build_hierarchy_from_subclass_relationships(
        schema, relationships, entities, config
    )
    hierarchy_updates += _consolidate_hierarchy_from_type_names(schema, config)
    _scaffold_updates, scaffold_types = apply_structural_upper_ontology_scaffold(schema, config)
    hierarchy_updates += refine_hierarchy_from_specific_vocabulary(schema, config)
    hierarchy_updates += _repair_hierarchy_inversions_with_scaffold(schema, config)

    _enforce_type_limits(schema, config)

    _update_schema_version(
        schema,
        new_entity_types + len(scaffold_types) + hierarchy_updates,
        new_relationship_types,
        config,
        error_collector,
    )

    return schema, new_entity_types, new_relationship_types

def _would_invert_lexical_specificity(child_type: str, parent_type: str) -> bool:
    """Return True when the proposed parent is lexically more specific than the child."""
    assert child_type is not None, "child_type must not be None"
    assert parent_type is not None, "parent_type must not be None"

    if child_type == parent_type:
        return False

    return _is_lexical_parent_candidate(parent_type, child_type)

def _can_assign_parent_type(
    child_type: str,
    parent_type: str,
    schema: OntologySchema,
) -> bool:
    """Return True only when the parent assignment is structurally safe."""
    assert child_type is not None, "child_type must not be None"
    assert parent_type is not None, "parent_type must not be None"
    assert schema is not None, "schema must not be None"

    if child_type == parent_type:
        return False
    if _would_create_cycle(child_type, parent_type, schema):
        return False
    if _would_invert_lexical_specificity(child_type, parent_type):
        return False
    return True
