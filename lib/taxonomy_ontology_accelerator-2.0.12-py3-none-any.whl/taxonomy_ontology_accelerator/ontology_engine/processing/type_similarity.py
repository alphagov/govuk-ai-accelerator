"""
Semantic type similarity checking for schema evolution.
"""

import threading
from typing import TYPE_CHECKING, Any, Optional

if TYPE_CHECKING:
    from taxonomy_ontology_accelerator.ontology_engine.config.config import OntologyConfig
    from taxonomy_ontology_accelerator.ontology_engine.core.models import OntologySchema

from taxonomy_ontology_accelerator.commons.utils.logger import get_logger

logger = get_logger()

# Process-level in-memory cache: SHA256 hash → embedding vector.
# Shared across all parallel file workers within a single run; avoids
# repeated disk I/O (load_embeddings reads the full JSON on every call) for
# type names that never change once they've been added to the schema.
_PROCESS_TYPE_EMBEDDING_CACHE: dict[str, list[float]] = {}

# Lazy import to avoid circular import issues (thread-safe with lock)
_embeddings_module = None
_embeddings_available = None
_embeddings_lock = threading.Lock()


def _check_embeddings_available() -> bool:
    """
    Check if embeddings module is available (lazy import, thread-safe).

    Uses double-checked locking pattern for thread safety.
    """
    assert _embeddings_lock is not None, "embeddings lock must be initialized"
    assert isinstance(_embeddings_lock, type(threading.Lock())), "lock must be a Lock"
    global _embeddings_module, _embeddings_available

    # Fast path check (outside lock for performance)
    if _embeddings_available is not None:
        return _embeddings_available

    with _embeddings_lock:
        # Re-check after acquiring lock (another thread may have loaded it)
        if _embeddings_available is not None:
            return _embeddings_available

        try:
            # Import directly from module file to avoid circular import via __init__.py
            import taxonomy_ontology_accelerator.ontology_engine.processing.embeddings as embeddings_mod

            _embeddings_module = embeddings_mod
            _embeddings_available = True
            return True
        except ImportError:
            _embeddings_available = False
            logger.warning("Embeddings not available - semantic type checking will be disabled")
            return False


def _get_embeddings_module():
    """Get embeddings module (lazy import)."""
    assert _embeddings_lock is not None, "embeddings lock must be initialized"
    assert callable(_check_embeddings_available), "check function must be callable"
    if _check_embeddings_available():
        return _embeddings_module
    return None


# For backward compatibility - check on first access
def _get_embeddings_available():
    assert _embeddings_lock is not None, "embeddings lock must be initialized"
    assert callable(_check_embeddings_available), "check function must be callable"
    return _check_embeddings_available()


# Create a simple object that can be checked as a boolean
class _EmbeddingsAvailable:
    def __bool__(self):
        assert callable(_check_embeddings_available), "check function must be callable"
        assert self is not None, "self must not be None"
        return _check_embeddings_available()

    def __repr__(self):
        assert callable(_check_embeddings_available), "check function must be callable"
        assert self is not None, "self must not be None"
        return str(_check_embeddings_available())


EMBEDDINGS_AVAILABLE = _EmbeddingsAvailable()


# ========================================================================
# Type Embedding Generation
# ========================================================================


def generate_type_embedding(
    type_name: str,
    type_description: str | None,
    config: "OntologyConfig",
) -> list[float] | None:
    """
    Generate embedding for an entity type.

    Args:
        type_name: Name of the entity type
        type_description: Optional description of the type
        config: Ontology configuration

    Returns:
        Embedding vector or None if generation fails
    """
    assert type_name is not None, "type_name parameter is required"
    assert config is not None, "config parameter is required"
    embeddings_mod = _get_embeddings_module()
    if not embeddings_mod:
        return None

    text = type_name
    if type_description:
        text = f"{type_name}: {type_description}"

    try:
        return embeddings_mod.generate_embedding(text, config)
    except Exception as e:
        logger.error(f"Failed to generate embedding for type {type_name}: {e}")
        return None


# ========================================================================
# Similarity Calculation
# ========================================================================


def calculate_type_similarity(
    type1_name: str,
    type1_description: str | None,
    type2_name: str,
    type2_description: str | None,
    config: "OntologyConfig",
) -> float:
    """
    Calculate similarity between two entity types.

    Args:
        type1_name: Name of first type
        type1_description: Optional description of first type
        type2_name: Name of second type
        type2_description: Optional description of second type
        config: Ontology configuration

    Returns:
        Similarity score (0.0-1.0), or 0.0 if embeddings unavailable
    """
    assert type1_name is not None, "type1_name parameter is required"
    assert type2_name is not None, "type2_name parameter is required"

    def _fallback_similarity(name1: str, name2: str) -> float:
        """Calculate fallback similarity based on name comparison."""
        assert name1 is not None, "name1 parameter is required"
        assert name2 is not None, "name2 parameter is required"
        name1_lower, name2_lower = name1.lower(), name2.lower()
        if name1_lower == name2_lower:  # Exact match (case-insensitive)
            return 1.0  # Perfect similarity
        if name1_lower in name2_lower or name2_lower in name1_lower:  # Substring match
            return 0.7  # Partial similarity
        return 0.0  # No similarity

    embeddings_mod = _get_embeddings_module()  # Get embeddings module
    if not embeddings_mod:  # Embeddings not available, use fallback
        return _fallback_similarity(type1_name, type2_name)

    embedding1 = generate_type_embedding(
        type1_name, type1_description, config
    )  # Generate embedding for type1
    embedding2 = generate_type_embedding(
        type2_name, type2_description, config
    )  # Generate embedding for type2

    if embedding1 is None or embedding2 is None:  # Embedding generation failed
        return _fallback_similarity(type1_name, type2_name)

    try:
        return embeddings_mod.cosine_similarity(
            embedding1, embedding2
        )  # Calculate cosine similarity
    except Exception as e:  # Handle calculation errors
        logger.warning(f"Failed to calculate type similarity: {e}")
        return 0.0  # Return no similarity on error


# ========================================================================
# Type Similarity Search
# ========================================================================


def find_similar_type(
    new_type_name: str,
    new_type_description: str | None,
    existing_schema: "OntologySchema",
    threshold: float,
    config: "OntologyConfig",
) -> tuple[str | None, float]:
    """
    Find existing entity type similar to the new type.

    Args:
        new_type_name: Name of the new type to check
        new_type_description: Optional description of the new type
        existing_schema: Existing schema to check against
        threshold: Similarity threshold (0.0-1.0)
        config: Ontology configuration

    Returns:
        Tuple of (similar_type_name, similarity_score) or (None, 0.0) if no similar type found
    """
    assert new_type_name is not None, "new_type_name parameter is required"
    assert config is not None, "config parameter is required"
    if not existing_schema or not existing_schema.entity_types:  # No existing schema or types
        return None, 0.0  # No match possible

    best_match: str | None = None  # Track best matching type
    best_similarity = 0.0  # Track best similarity score

    for (
        existing_type_name,
        _existing_type_def,
    ) in existing_schema.entity_types.items():  # Check each existing type
        if existing_type_name.lower() == new_type_name.lower():  # Exact match (case-insensitive)
            return existing_type_name, 1.0  # Return immediately (perfect match)

        similarity = calculate_type_similarity(  # Calculate semantic similarity
            new_type_name,
            new_type_description,
            existing_type_name,
            None,  # No description for existing type
            config,
        )

        if (
            similarity > best_similarity and similarity >= threshold
        ):  # Better match and above threshold
            best_similarity = similarity  # Update best similarity
            best_match = existing_type_name  # Update best match

    return best_match, best_similarity  # Return best match and score


# ========================================================================
# Type Creation Check
# ========================================================================


def check_type_similarity_before_creation(
    new_type_name: str,
    new_type_description: str | None,
    existing_schema: Optional["OntologySchema"],
    threshold: float,
    config: "OntologyConfig",
) -> tuple[bool, str | None, float]:
    """
    Check if a new type is similar to existing types before creating it.

    Args:
        new_type_name: Name of the new type to check
        new_type_description: Optional description of the new type
        existing_schema: Existing schema to check against
        threshold: Similarity threshold (0.0-1.0)
        config: Ontology configuration

    Returns:
        Tuple of (should_create_new_type, similar_type_name, similarity_score)
        - should_create_new_type: True if new type should be created, False if similar type exists
        - similar_type_name: Name of similar type if found, None otherwise
        - similarity_score: Similarity score (0.0-1.0)
    """
    assert new_type_name is not None, "new_type_name parameter is required"
    assert config is not None, "config parameter is required"
    if not existing_schema:  # No existing schema
        return True, None, 0.0  # Create new type

    if new_type_name in existing_schema.entity_types:  # Exact match found
        return False, new_type_name, 1.0  # Use existing type (perfect match)

    similar_type, similarity = find_similar_type(  # Search for similar type
        new_type_name,
        new_type_description,
        existing_schema,
        threshold,
        config,
    )

    if similar_type:  # Similar type found
        logger.info(
            f"Type '{new_type_name}' is similar to existing type '{similar_type}' "
            f"(similarity: {similarity:.3f} >= {threshold}). "
            f"Using existing type instead of creating new one."
        )
        return False, similar_type, similarity  # Use existing similar type

    return True, None, 0.0  # No similar type found, create new


# ========================================================================
# Batch Type Similarity Helper Functions
# ========================================================================


def _log_debug_or_dim(message: str) -> None:
    """
    Log using debug or dim method depending on logger capabilities.

    Args:
        message: Message to log
    """
    assert message is not None, "message parameter is required"
    assert isinstance(message, str), "message must be a string"
    if hasattr(logger, "debug"):
        logger.debug(message)
    elif hasattr(logger, "dim"):
        logger.dim(message)


def _fallback_exact_matching(
    new_types: dict[str, str | None],
    existing_entity_types: dict,
) -> dict[str, tuple[bool, str | None, float]]:
    """
    Fall back to exact string matching when embeddings unavailable.

    Args:
        new_types: Dictionary mapping type_name to optional description
        existing_entity_types: Existing entity types dict

    Returns:
        Results dictionary
    """
    assert new_types is not None, "new_types parameter is required"
    assert isinstance(existing_entity_types, dict), "existing_entity_types must be a dict"
    _log_debug_or_dim("Embeddings not available, using exact matching for type similarity")
    results = {}
    for name in new_types:
        if name in existing_entity_types:
            results[name] = (False, name, 1.0)
        else:
            results[name] = (True, None, 0.0)
    return results


def _separate_exact_matches(
    new_types: dict[str, str | None],
    existing_entity_types: dict,
) -> tuple[dict[str, tuple[bool, str | None, float]], dict[str, str | None]]:
    """
    Separate types with exact matches from those needing similarity check.

    Args:
        new_types: Dictionary mapping type_name to optional description
        existing_entity_types: Existing entity types dict

    Returns:
        Tuple of (exact_match_results, types_needing_check)
    """
    assert new_types is not None, "new_types parameter is required"
    assert isinstance(existing_entity_types, dict), "existing_entity_types must be a dict"
    results: dict[str, tuple[bool, str | None, float]] = {}
    types_to_check: dict[str, str | None] = {}

    for type_name, type_description in new_types.items():
        if type_name in existing_entity_types:
            results[type_name] = (False, type_name, 1.0)
        else:
            types_to_check[type_name] = type_description

    return results, types_to_check


async def _generate_batch_embeddings(
    types_to_check: dict[str, str | None],
    existing_entity_types: dict,
    embeddings_mod,
    config: "OntologyConfig",
) -> tuple[dict, dict]:
    """
    Generate embeddings for new and existing types in batch.

    Args:
        types_to_check: Types needing similarity check
        existing_entity_types: Existing entity types
        embeddings_mod: Embeddings module
        config: Ontology configuration

    Returns:
        Tuple of (new_embeddings_dict, existing_embeddings_dict)
    """
    assert types_to_check is not None, "types_to_check parameter is required"
    assert embeddings_mod is not None, "embeddings_mod parameter is required"

    # Generate embeddings for new types (always fresh — they are genuinely new).
    # Also populate the process cache so subsequent files see them as "existing".
    new_type_texts = [f"{name}: {desc}" if desc else name for name, desc in types_to_check.items()]
    new_embeddings_dict, generated = await embeddings_mod.generate_embeddings_batch_async(
        new_type_texts, config
    )
    if generated > 0:
        _log_debug_or_dim(f"Generated {generated} new type embeddings in batch")
        _PROCESS_TYPE_EMBEDDING_CACHE.update(new_embeddings_dict)

    # For existing types, check the process-level in-memory cache first.
    # Type names that have already been embedded in this run are served directly
    # from memory, avoiding a full load_embeddings disk read per call.
    existing_type_texts = list(existing_entity_types.keys())
    existing_hashes = {embeddings_mod._text_hash(t): t for t in existing_type_texts}

    cached_existing = {h: _PROCESS_TYPE_EMBEDDING_CACHE[h] for h in existing_hashes if h in _PROCESS_TYPE_EMBEDDING_CACHE}
    texts_needing_generation = [t for h, t in existing_hashes.items() if h not in _PROCESS_TYPE_EMBEDDING_CACHE]

    if texts_needing_generation:
        newly_generated, generated = await embeddings_mod.generate_embeddings_batch_async(
            texts_needing_generation, config
        )
        if generated > 0:
            _log_debug_or_dim(f"Generated {generated} existing type embeddings (uncached)")
        _PROCESS_TYPE_EMBEDDING_CACHE.update(newly_generated)
        cached_existing.update(newly_generated)

    return new_embeddings_dict, cached_existing


def _build_hash_to_name_maps(
    types_to_check: dict[str, str | None],
    existing_entity_types: dict,
    embeddings_mod,
) -> tuple[dict[str, str], dict[str, str]]:
    """
    Build mappings from text hashes to type names.

    Args:
        types_to_check: Types needing similarity check
        existing_entity_types: Existing entity types
        embeddings_mod: Embeddings module

    Returns:
        Tuple of (new_hash_to_name, existing_hash_to_name)
    """
    assert types_to_check is not None, "types_to_check parameter is required"
    assert embeddings_mod is not None, "embeddings_mod parameter is required"
    new_type_hash_to_name = {}
    for type_name, type_desc in types_to_check.items():
        text = f"{type_name}: {type_desc}" if type_desc else type_name
        text_hash = embeddings_mod._text_hash(text)
        new_type_hash_to_name[text_hash] = type_name

    existing_type_hash_to_name = {}
    for type_name in existing_entity_types:
        text_hash = embeddings_mod._text_hash(type_name)
        existing_type_hash_to_name[text_hash] = type_name

    return new_type_hash_to_name, existing_type_hash_to_name


def _process_semantic_matches(
    semantic_matches: dict,
    new_type_hash_to_name: dict[str, str],
    existing_type_hash_to_name: dict[str, str],
    threshold: float,
    results: dict[str, tuple[bool, str | None, float]],
) -> int:
    """
    Process semantic matches and apply threshold.

    Args:
        semantic_matches: Dict mapping new_hash to (existing_hash, similarity)
        new_type_hash_to_name: Mapping of new type hashes to names
        existing_type_hash_to_name: Mapping of existing type hashes to names
        threshold: Similarity threshold
        results: Results dictionary to update

    Returns:
        Count of matched types
    """
    assert semantic_matches is not None, "semantic_matches parameter is required"
    assert results is not None, "results parameter is required"
    matched_count = 0

    for new_hash, (best_match_hash, similarity) in semantic_matches.items():
        new_type_name = new_type_hash_to_name.get(new_hash)
        if not new_type_name:
            continue

        if similarity >= threshold:
            similar_type = existing_type_hash_to_name.get(best_match_hash)
            if similar_type:
                logger.info(
                    f"Type '{new_type_name}' is similar to existing type '{similar_type}' "
                    f"(similarity: {similarity:.3f} >= {threshold}). "
                    f"Using existing type instead of creating new one."
                )
                results[new_type_name] = (False, similar_type, similarity)
                matched_count += 1
            else:
                results[new_type_name] = (True, None, 0.0)
        else:
            results[new_type_name] = (True, None, similarity)

    return matched_count


def _handle_missing_type_embeddings(
    types_to_check: dict[str, str | None],
    results: dict[str, tuple[bool, str | None, float]],
) -> None:
    """
    Handle types that weren't in semantic matches (embedding generation failed).

    Args:
        types_to_check: All types that should have been processed
        results: Results dictionary to update
    """
    assert types_to_check is not None, "types_to_check parameter is required"
    assert results is not None, "results parameter is required"
    for type_name in types_to_check:
        if type_name not in results:
            _log_debug_or_dim(f"No embedding for type '{type_name}', creating new type")
            results[type_name] = (True, None, 0.0)


async def _perform_batch_similarity_check(
    types_to_check: dict[str, str | None],
    existing_types: dict[str, Any],
    embeddings_mod: Any,
    config: "OntologyConfig",
    threshold: float,
    results: dict[str, tuple[bool, str | None, float]],
) -> None:
    """Perform batch similarity check using embeddings."""
    assert types_to_check is not None, "types_to_check parameter is required"
    assert embeddings_mod is not None, "embeddings_mod parameter is required"

    new_embeddings_dict, existing_embeddings_dict = await _generate_batch_embeddings(
        types_to_check, existing_types, embeddings_mod, config
    )
    new_hash_map, existing_hash_map = _build_hash_to_name_maps(
        types_to_check, existing_types, embeddings_mod
    )
    semantic_matches = await embeddings_mod.find_semantic_duplicates_async(
        new_embeddings_dict, existing_embeddings_dict, config, use_faiss=True
    )
    matched = _process_semantic_matches(
        semantic_matches, new_hash_map, existing_hash_map, threshold, results
    )
    _handle_missing_type_embeddings(types_to_check, results)

    if matched > 0:
        _log_debug_or_dim(
            f"Batch similarity: {matched} matched, {len(types_to_check) - matched} new"
        )


# ========================================================================
# Main Batch Type Similarity Function
# ========================================================================


async def check_type_similarity_batch(
    new_types: dict[str, str | None],
    existing_schema: Optional["OntologySchema"],
    threshold: float,
    config: "OntologyConfig",
) -> dict[str, tuple[bool, str | None, float]]:
    """BATCH: Check similarity for multiple new types at once (production-grade, scalable)."""
    assert new_types is not None, "new_types parameter is required"
    assert config is not None, "config parameter is required"

    if not new_types:
        return {}

    if not existing_schema or not existing_schema.entity_types:
        return dict.fromkeys(new_types.keys(), (True, None, 0.0))

    embeddings_mod = _get_embeddings_module()
    if not embeddings_mod:
        return _fallback_exact_matching(new_types, existing_schema.entity_types)

    results, types_to_check = _separate_exact_matches(new_types, existing_schema.entity_types)
    if not types_to_check:
        return results

    _log_debug_or_dim(
        f"Batch checking {len(types_to_check)} types against {len(existing_schema.entity_types)} existing"
    )

    try:
        await _perform_batch_similarity_check(
            types_to_check, existing_schema.entity_types, embeddings_mod, config, threshold, results
        )
    except Exception as e:
        logger.error(f"Batch type similarity check failed: {e}")
        raise RuntimeError(f"Failed to perform batch type similarity check: {e}") from e

    return results
