"""
Multi-stage entity deduplication pipeline with zero information loss.

Implements a 4-stage deduplication process:
- Exact match deduplication (identical normalized strings)
- Normalization-based deduplication (singular/plural, case variations)
- Semantic deduplication (embedding similarity)
- Abbreviation detection and linking (SKOS:altLabel)

All stages merge entities instead of skipping duplicates to ensure zero information loss.
"""

import asyncio
import re
from typing import TYPE_CHECKING, Any

import inflect

from taxonomy_ontology_accelerator.commons.utils.logger import get_logger
from taxonomy_ontology_accelerator.ontology_engine.core.models import Entity, MergeDecision
from taxonomy_ontology_accelerator.ontology_engine.processing.embeddings import (
    _text_hash,
    cosine_similarity,
    generate_embeddings_batch_async,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.property_merger import merge_properties
from taxonomy_ontology_accelerator.ontology_engine.utils.text_normalization import normalize_text

if TYPE_CHECKING:
    from taxonomy_ontology_accelerator.ontology_engine.config.config import OntologyConfig

logger = get_logger()

# Initialize inflect engine for singular/plural conversion
_inflect_engine = inflect.engine()

# Constants for thresholds and limits (non-configurable)
CONFIDENCE_DIFF_THRESHOLD = 0.1  # Significant confidence difference for merging decisions
MIN_ABBREVIATION_LENGTH = 2  # Minimum length for abbreviation detection
MAX_ABBREVIATION_WORDS = 5  # Maximum words in full form for abbreviation matching
MAX_WORD_DIFFERENCE = 10  # Max word count difference for abbreviation detection

# NOTE: FAISS_SEARCH_K, MIN_LABEL_SIMILARITY, HIGH_SEMANTIC_SIMILARITY, FAISS_THRESHOLD
# are now configured via config.deduplication.faiss.top_k, config.deduplication.min_label_similarity,
# config.deduplication.high_semantic_similarity, config.deduplication.faiss.threshold


def _compute_label_similarity(label1: str, label2: str) -> float:
    """
    Compute string similarity between two labels using token overlap.

    This prevents merging entities with very different labels even if they have
    high semantic similarity (e.g., "entity0" and "entity1" should not merge).

    Args:
        label1: First label
        label2: Second label

    Returns:
        Similarity score between 0.0 and 1.0
    """
    assert label1 is not None, "label1 parameter is required"
    assert label2 is not None, "label2 parameter is required"

    if not label1 or not label2:
        return 0.0

    # Normalize to lowercase for comparison
    l1 = label1.lower().strip()
    l2 = label2.lower().strip()

    # Exact match
    if l1 == l2:
        return 1.0

    # Check if one contains the other (e.g., "USA" in "United States of America")
    if l1 in l2 or l2 in l1:
        # Compute overlap ratio
        shorter_len = min(len(l1), len(l2))
        longer_len = max(len(l1), len(l2))
        return shorter_len / longer_len

    # Token-based similarity (Jaccard)
    tokens1 = set(l1.split())
    tokens2 = set(l2.split())

    if not tokens1 or not tokens2:
        return 0.0

    # Jaccard similarity: intersection / union
    intersection = len(tokens1 & tokens2)
    union = len(tokens1 | tokens2)

    return intersection / union if union > 0 else 0.0


# ========================================================================
# Entity Merging (Zero Information Loss)
# ========================================================================


def _merge_aliases(existing: Entity, duplicate: Entity) -> list:
    """
    Merge aliases from two entities, deduplicating by name while preserving order.
    When both entities carry the same alias name, union their source_files lists.
    """
    from taxonomy_ontology_accelerator.ontology_engine.core.models import AliasEntry

    assert existing is not None, "existing entity is required"
    assert duplicate is not None, "duplicate entity is required"

    def _to_entry(item) -> AliasEntry:
        if isinstance(item, AliasEntry):
            return item
        if isinstance(item, dict):
            return AliasEntry(**item)
        return AliasEntry(name=str(item))

    by_name: dict[str, AliasEntry] = {}
    for entry in (existing.aliases or []):
        e = _to_entry(entry)
        key = e.name.lower()
        if key not in by_name:
            by_name[key] = AliasEntry(name=e.name, source_files=list(e.source_files))
        else:
            for sf in e.source_files:
                if sf not in by_name[key].source_files:
                    by_name[key].source_files.append(sf)

    if existing.label:
        by_name.setdefault("__exclude_label__", None)
        by_name.pop("__exclude_label__", None)
        exclude = existing.label.lower()
    else:
        exclude = None

    if duplicate.label and duplicate.label.lower() != exclude and duplicate.label.lower() not in by_name:
        dup_source = _source_files_from_entity(duplicate)
        by_name[duplicate.label.lower()] = AliasEntry(name=duplicate.label, source_files=dup_source)

    for entry in (duplicate.aliases or []):
        e = _to_entry(entry)
        key = e.name.lower()
        if key == exclude:
            continue
        if key in by_name:
            for sf in e.source_files:
                if sf not in by_name[key].source_files:
                    by_name[key].source_files.append(sf)
        else:
            by_name[key] = AliasEntry(name=e.name, source_files=list(e.source_files))

    return list(by_name.values())


def _source_files_from_entity(entity: Entity) -> list[str]:
    """Extract source files from entity's sourceUrls property."""
    raw = entity.properties.get("sourceUrls", "")
    if not raw:
        return []
    if isinstance(raw, list | tuple | set):
        return [str(source).strip() for source in raw if str(source).strip()]
    return [s.strip() for s in str(raw).split(",") if s.strip()]


def _get_validated_confidence(entity: Entity) -> float:
    """Extract and validate confidence score from entity metadata."""
    assert entity is not None, "entity is required"
    assert hasattr(entity, "metadata"), "entity must have metadata attribute"
    confidence = entity.metadata.get("confidence", 1.0) if entity.metadata else 1.0
    if not isinstance(confidence, int | float) or not (0.0 <= confidence <= 1.0):
        logger.warning(f"Invalid confidence {confidence} for entity {entity.id}, using 1.0")
        return 1.0
    return float(confidence)


def _merge_entity_properties(
    existing: Entity,
    duplicate: Entity,
    existing_conf: float,
    duplicate_conf: float,
    config: "OntologyConfig",
) -> dict:
    """Merge properties from two entities with fallback handling."""
    assert existing is not None, "existing entity is required"
    assert duplicate is not None, "duplicate entity is required"
    try:
        return merge_properties(
            existing.properties or {},
            duplicate.properties or {},
            existing_conf,
            duplicate_conf,
            config,
        )
    except Exception as e:
        logger.warning(
            f"Property merge failed for entities '{existing.label}' and '{duplicate.label}': {e}. "
            f"Using existing properties as fallback."
        )
        # Fallback: keep existing properties and add non-conflicting duplicate properties
        merged_properties = dict(existing.properties) if existing.properties else {}
        if duplicate.properties:
            for key, value in duplicate.properties.items():
                if key not in merged_properties:
                    merged_properties[key] = value
        return merged_properties


def _merge_entity_types(
    existing: Entity,
    duplicate: Entity,
    existing_conf: float,
    duplicate_conf: float,
    config: "OntologyConfig",
) -> tuple[str, str, str]:
    """Merge types from two entities. Returns (merged_type, existing_normalized, duplicate_normalized)."""
    assert existing is not None, "existing entity is required"
    assert duplicate is not None, "duplicate entity is required"
    existing_type_normalized = (
        normalize_text(existing.type, config).lower() if existing.type else ""
    )
    duplicate_type_normalized = (
        normalize_text(duplicate.type, config).lower() if duplicate.type else ""
    )

    if duplicate_conf > existing_conf and duplicate.type:
        merged_type = duplicate.type
    else:
        merged_type = existing.type

    # Log warning if types differ
    if duplicate.type and existing.type and duplicate_type_normalized != existing_type_normalized:
        logger.debug(
            f"Entity type mismatch during merge: '{existing.label}' has type '{existing.type}' "
            f"but duplicate has type '{duplicate.type}'. Keeping '{merged_type}' as primary."
        )

    return merged_type, existing_type_normalized, duplicate_type_normalized


def _merge_descriptions(
    existing_desc: str | None,
    duplicate_desc: str | None,
    existing_conf: float,
    duplicate_conf: float,
) -> str | None:
    """Merge descriptions from two entities based on confidence and length."""
    assert existing_conf >= 0.0, "existing_conf must be >= 0.0"
    assert existing_conf <= 1.0, "existing_conf must be <= 1.0"
    assert duplicate_conf >= 0.0, "duplicate_conf must be >= 0.0"
    assert duplicate_conf <= 1.0, "duplicate_conf must be <= 1.0"
    if not duplicate_desc:
        return existing_desc
    if not existing_desc:
        return duplicate_desc
    if duplicate_desc == existing_desc:
        return existing_desc

    # If confidence difference is significant, use higher confidence version
    conf_diff = abs(duplicate_conf - existing_conf)
    if conf_diff > CONFIDENCE_DIFF_THRESHOLD:
        return duplicate_desc if duplicate_conf > existing_conf else existing_desc

    # Confidence is similar - prefer longer description (more information)
    return duplicate_desc if len(duplicate_desc) > len(existing_desc) else existing_desc


def _merge_timestamps(merged: dict, duplicate_metadata: dict) -> None:
    """Merge timestamp fields from duplicate metadata into merged dict."""
    assert merged is not None, "merged dict is required"
    assert isinstance(merged, dict), "merged must be a dict"
    for key, value in duplicate_metadata.items():
        if key == "first_seen":
            if "first_seen" not in merged:
                merged["first_seen"] = value
            elif isinstance(value, str) and isinstance(merged.get("first_seen"), str):
                merged["first_seen"] = min(merged["first_seen"], value)
        elif key == "last_updated":
            if "last_updated" not in merged:
                merged["last_updated"] = value
            elif isinstance(value, str) and isinstance(merged.get("last_updated"), str):
                merged["last_updated"] = max(merged["last_updated"], value)
        elif key != "confidence" and key not in merged:
            merged[key] = value


def _add_alternative_types(
    merged: dict,
    existing_type: str | None,
    duplicate_type: str | None,
    existing_type_norm: str,
    duplicate_type_norm: str,
) -> None:
    """Add alternative types to merged metadata if types differ."""
    assert merged is not None, "merged dict is required"
    assert isinstance(merged, dict), "merged must be a dict"
    if not (duplicate_type and existing_type and duplicate_type_norm != existing_type_norm):
        return

    existing_alt_types = merged.get("alternative_types", [])
    if not isinstance(existing_alt_types, list):
        existing_alt_types = [existing_alt_types]

    for alt_type in [t for t in [existing_type, duplicate_type] if t]:
        if alt_type not in existing_alt_types:
            existing_alt_types.append(alt_type)

    if existing_alt_types:
        merged["alternative_types"] = existing_alt_types


def _merge_metadata(
    existing: Entity,
    duplicate: Entity,
    existing_conf: float,
    duplicate_conf: float,
    existing_type_norm: str,
    duplicate_type_norm: str,
) -> dict:
    """Merge metadata from two entities."""
    assert existing is not None, "existing entity is required"
    assert duplicate is not None, "duplicate entity is required"
    merged = dict(existing.metadata) if existing.metadata else {}

    if duplicate.metadata:
        _merge_timestamps(merged, duplicate.metadata)

    merged["confidence"] = max(existing_conf, duplicate_conf)
    _add_alternative_types(
        merged, existing.type, duplicate.type, existing_type_norm, duplicate_type_norm
    )

    return merged


def _merge_entities(existing: Entity, duplicate: Entity, config: "OntologyConfig") -> Entity:
    """
    Merge two entities, preserving all information.

    Args:
        existing: The entity to keep
        duplicate: The entity to merge into existing
        config: Ontology configuration

    Returns:
        Merged entity with combined information
    """
    assert existing is not None, "existing entity is required"
    assert duplicate is not None, "duplicate entity is required"
    assert config is not None, "config is required"

    if existing.label is None or duplicate.label is None:
        logger.error(
            f"Cannot merge entities with None labels: existing={existing.id}, duplicate={duplicate.id}"
        )
        return existing

    # Use helper functions to break down the merge logic
    merged_aliases = _merge_aliases(existing, duplicate)
    existing_conf = _get_validated_confidence(existing)
    duplicate_conf = _get_validated_confidence(duplicate)
    merged_properties = _merge_entity_properties(
        existing, duplicate, existing_conf, duplicate_conf, config
    )
    merged_type, existing_type_norm, duplicate_type_norm = _merge_entity_types(
        existing, duplicate, existing_conf, duplicate_conf, config
    )
    merged_description = _merge_descriptions(
        existing.description, duplicate.description, existing_conf, duplicate_conf
    )
    merged_metadata = _merge_metadata(
        existing,
        duplicate,
        existing_conf,
        duplicate_conf,
        existing_type_norm,
        duplicate_type_norm,
    )

    return Entity(
        id=existing.id,
        canonical_key=existing.canonical_key,
        label=existing.label,
        aliases=merged_aliases,
        type=merged_type,
        description=merged_description,
        properties=merged_properties,
        metadata=merged_metadata,
    )


# ========================================================================
# Exact Match Deduplication
# ========================================================================


def _normalize_entity_label_safely(entity: Entity, config: "OntologyConfig") -> str | None:
    """Normalize entity label with error handling. Returns None if label is invalid."""
    assert entity is not None, "entity is required"
    assert config is not None, "config is required"
    if entity.label is None:
        logger.error(f"Entity {entity.id} has None label, skipping")
        return None

    try:
        normalized_label = normalize_text(entity.label, config)
        if not isinstance(normalized_label, str):
            logger.warning(
                f"normalize_text returned non-string for entity {entity.id}, using original"
            )
            normalized_label = entity.label
        normalized_label = normalized_label.lower()
    except Exception as e:
        logger.warning(f"Failed to normalize label for entity {entity.id}: {e}, using original")
        normalized_label = entity.label.lower()

    # Skip entities with empty normalized labels to prevent incorrect grouping
    if not normalized_label or not normalized_label.strip():
        logger.warning(
            f"Entity '{entity.label}' (ID: {entity.id}) has empty normalized label, "
            f"using original label as fallback"
        )
        normalized_label = entity.label.lower().strip()
        if not normalized_label:
            logger.error(f"Entity {entity.id} has completely empty label, skipping")
            return None

    return normalized_label


def _get_entity_confidence(e: Entity) -> float:
    """Extract confidence score from entity metadata."""
    assert e is not None, "entity is required"
    assert hasattr(e, "metadata"), "entity must have metadata attribute"
    if e.metadata and "confidence" in e.metadata:
        conf = e.metadata["confidence"]
        if isinstance(conf, (int, float)) and 0.0 <= conf <= 1.0:
            return float(conf)
    return 1.0


def _merge_entity_group(
    group: list[Entity],
    config: "OntologyConfig",
    reason: str,
    similarity_score: float | None = None,
    threshold: float | None = None,
) -> tuple[Entity, dict[str, str], list[MergeDecision]]:
    """Merge a group of duplicate entities, returning the merged entity, ID mapping, and merge decisions."""
    assert group is not None, "group is required"
    assert config is not None, "config is required"
    assert reason is not None, "reason is required"
    assert isinstance(reason, str), "reason must be a string"
    if len(group) == 1:
        return group[0], {}, []

    # Performance optimization: skip decision collection if logging disabled
    collect_decisions = config.output.emit_deduplication_logs

    merged = max(group, key=_get_entity_confidence)
    id_mapping: dict[str, str] = {}
    merge_decisions: list[MergeDecision] = []
    canonical_confidence = _get_entity_confidence(merged) if collect_decisions else 0.0

    # Merge all other entities in group
    for entity in group:
        if entity.id == merged.id:
            continue
        id_mapping[entity.id] = merged.id

        # Only create merge decision if collection is enabled
        if collect_decisions:
            merge_decisions.append(
                MergeDecision(
                    canonical_id=merged.id,
                    canonical_label=merged.label or "",
                    merged_id=entity.id,
                    merged_label=entity.label or "",
                    reason=reason,
                    similarity_score=similarity_score,
                    confidence=canonical_confidence,
                    threshold=threshold,
                )
            )

        try:
            merged = _merge_entities(merged, entity, config)
        except Exception as e:
            logger.error(
                f"Failed to merge entity {entity.id} into {merged.id} in {reason}: {e}. "
                f"Skipping this entity."
            )

    return merged, id_mapping, merge_decisions


def _remove_exact_duplicates(
    entities: list[Entity], config: "OntologyConfig"
) -> tuple[list[Entity], dict[str, str], list[MergeDecision]]:
    """
    Remove exact duplicates based on normalized label.

    Merges all entities with identical normalized labels.

    Args:
        entities: List of entities
        config: Ontology configuration

    Returns:
        Tuple of (deduplicated entities, id_mapping dict, merge_decisions list)
    """
    assert entities is not None, "entities is required"
    assert config is not None, "config is required"

    if not entities:
        return [], {}, []

    # Group entities by normalized label (type-agnostic).
    # Same label = same real-world concept regardless of type.
    # Type conflicts are resolved by _merge_entities via confidence-based selection.
    label_groups: dict[str, list[Entity]] = {}
    for entity in entities:
        normalized_label = _normalize_entity_label_safely(entity, config)
        if normalized_label is None:
            continue

        if normalized_label not in label_groups:
            label_groups[normalized_label] = []
        label_groups[normalized_label].append(entity)

    # Merge entities in each group
    deduplicated: list[Entity] = []
    total_id_mapping: dict[str, str] = {}
    all_merge_decisions: list[MergeDecision] = []

    for _group_key, group in label_groups.items():
        merged_entity, group_id_mapping, group_decisions = _merge_entity_group(
            group, config, reason="exact_match"
        )
        deduplicated.append(merged_entity)
        total_id_mapping.update(group_id_mapping)
        all_merge_decisions.extend(group_decisions)

    if total_id_mapping:
        logger.debug(
            f"Exact Match: Merged {len(total_id_mapping)} duplicates into "
            f"{len(deduplicated)} unique entities"
        )

    return deduplicated, total_id_mapping, all_merge_decisions


# ========================================================================
# Normalization-based Deduplication (Singular/Plural)
# ========================================================================


def _normalize_to_singular(text: str) -> str:
    """
    Normalize text to singular form using inflect.

    Handles multi-word phrases and hyphenated terms (e.g., "tax-benefits" -> "tax-benefit").

    Args:
        text: Input text

    Returns:
        Singular form of text
    """
    assert text is not None, "text is required"
    assert _inflect_engine is not None, "inflect engine must be initialized"

    # Handle multi-word phrases and hyphenated terms
    # Split on both spaces and hyphens, but preserve the separators
    # Split while keeping track of separators
    parts = re.split(r"(\s+|-)", text)
    singular_parts = []

    for part in parts:
        # If it's a separator (space or hyphen), keep it as-is
        if re.match(r"^(\s+|-)$", part):
            singular_parts.append(part)
        elif part:  # If it's an actual word
            try:
                # Try to get singular form
                singular = _inflect_engine.singular_noun(str(part))  # pyright: ignore[reportArgumentType]
                # singular_noun returns False if word is already singular
                singular_parts.append(singular if singular else part)
            except Exception as e:
                logger.warning(f"inflect.singular_noun failed for '{part}': {e}, using original")
                singular_parts.append(part)

    return "".join(singular_parts)


def _normalize_and_singularize_label(entity: Entity, config: "OntologyConfig") -> str | None:
    """Normalize entity label and convert to singular form. Returns None if label is invalid."""
    assert entity is not None, "entity is required"
    assert config is not None, "config is required"
    if entity.label is None:
        logger.error(f"Entity {entity.id} has None label in Normalization, skipping")
        return None

    try:
        normalized_label = normalize_text(entity.label, config)
        if not isinstance(normalized_label, str):
            logger.warning(f"normalize_text returned non-string in Normalization for {entity.id}")
            normalized_label = entity.label
        normalized_label = normalized_label.lower()
    except Exception as e:
        logger.warning(f"Failed to normalize in Normalization for {entity.id}: {e}")
        normalized_label = entity.label.lower()

    # Skip entities with empty normalized labels
    if not normalized_label or not normalized_label.strip():
        logger.warning(
            f"Entity '{entity.label}' (ID: {entity.id}) has empty normalized label in Normalization, "
            f"using original label as fallback"
        )
        normalized_label = entity.label.lower().strip()
        if not normalized_label:
            logger.error(
                f"Entity {entity.id} has completely empty label in Normalization, skipping"
            )
            return None

    singular_form = _normalize_to_singular(normalized_label)

    if not singular_form or not singular_form.strip():
        logger.warning(
            f"Entity '{entity.label}' (ID: {entity.id}) has empty singular form, using normalized label"
        )
        singular_form = normalized_label

    return singular_form


def _normalize_entities(
    entities: list[Entity], config: "OntologyConfig"
) -> tuple[list[Entity], dict[str, str], list[MergeDecision]]:
    """
    Deduplicate entities based on singular/plural normalization.

    Merges entities that differ only in singular/plural form or case.

    Args:
        entities: List of entities
        config: Ontology configuration

    Returns:
        Tuple of (deduplicated entities, id_mapping dict, merge_decisions list)
    """
    assert entities is not None, "entities is required"
    assert config is not None, "config is required"

    if not entities:
        return [], {}, []

    # Group entities by normalized singular form (type-agnostic).
    # Same singular form = same concept regardless of type.
    # Type conflicts are resolved by _merge_entities via confidence-based selection.
    normalized_groups: dict[str, list[Entity]] = {}

    for entity in entities:
        singular_form = _normalize_and_singularize_label(entity, config)
        if singular_form is None:
            continue

        if singular_form not in normalized_groups:
            normalized_groups[singular_form] = []
        normalized_groups[singular_form].append(entity)

    # Merge entities in each group
    deduplicated: list[Entity] = []
    total_id_mapping: dict[str, str] = {}
    all_merge_decisions: list[MergeDecision] = []

    for _group_key, group in normalized_groups.items():
        merged_entity, group_id_mapping, group_decisions = _merge_entity_group(
            group, config, reason="normalization"
        )
        deduplicated.append(merged_entity)
        total_id_mapping.update(group_id_mapping)
        all_merge_decisions.extend(group_decisions)

    if total_id_mapping:
        logger.debug(
            f"Normalization: Merged {len(total_id_mapping)} duplicates "
            f"into {len(deduplicated)} unique entities"
        )

    return deduplicated, total_id_mapping, all_merge_decisions


# ========================================================================
# Semantic Deduplication (Embeddings)
# ========================================================================


def _prepare_entity_texts_for_embedding(entities: list[Entity]) -> tuple[list[str], list[str]]:
    """Prepare entity texts for embedding generation. Returns (entity_texts, entity_ids)."""
    assert entities is not None, "entities is required"
    assert isinstance(entities, list), "entities must be a list"
    MAX_TEXT_LENGTH = 8000  # Conservative limit for most embedding models
    entity_texts = []
    entity_ids = []

    for entity in entities:
        if entity.label is None:
            logger.warning(f"Entity {entity.id} has None label in Semantic deduplication, skipping")
            continue

        # Combine label and aliases for better semantic matching
        text = entity.label
        if entity.aliases:
            valid_aliases = entity.alias_names
            if valid_aliases:
                text = f"{text} {' '.join(valid_aliases)}"

        # Validate and truncate text length to prevent embedding API errors
        if len(text) > MAX_TEXT_LENGTH:
            logger.warning(
                f"Entity '{entity.label}' (ID: {entity.id}) has very long text ({len(text)} chars), "
                f"truncating to {MAX_TEXT_LENGTH} chars for embedding"
            )
            text = text[:MAX_TEXT_LENGTH]

        entity_texts.append(text)
        entity_ids.append(entity.id)

    return entity_texts, entity_ids


def _build_entity_embeddings_map(
    entity_ids: list[str], entity_texts: list[str], embeddings_dict: dict
) -> dict[str, list[float]]:
    """Build mapping from entity ID to embedding vector."""
    assert entity_ids is not None, "entity_ids is required"
    assert entity_texts is not None, "entity_texts is required"
    entity_embeddings: dict[str, list[float]] = {}
    failed_embeddings = []

    for i, entity_id in enumerate(entity_ids):
        text_hash = _text_hash(entity_texts[i])
        if text_hash in embeddings_dict:
            entity_embeddings[entity_id] = embeddings_dict[text_hash]
        else:
            failed_embeddings.append(entity_id)

    # Log partial embedding failures for debugging
    if failed_embeddings:
        logger.warning(
            f"Failed to generate embeddings for {len(failed_embeddings)} out of {len(entity_ids)} entities. "
            f"These entities will not be compared semantically. "
            f"Failed entity IDs: {failed_embeddings[:MAX_ABBREVIATION_WORDS]}{'...' if len(failed_embeddings) > MAX_ABBREVIATION_WORDS else ''}"
        )

    return entity_embeddings


def _is_valid_semantic_duplicate(
    entity_label: str,
    similar_label: str,
    similarity: float,
    config: "OntologyConfig",
) -> bool:
    """Check if two entities are valid semantic duplicates (type-agnostic).

    Validates via:
      1. Semantic similarity >= threshold
      2. (Optional) Label similarity check to prevent false positives
    """
    assert similarity >= 0.0, "similarity must be >= 0.0"
    # Clamp similarity to [0, 1] range to handle floating point precision issues
    # FAISS inner product can return values slightly > 1.0 (e.g., 1.0000001)
    similarity = min(1.0, max(0.0, similarity))
    assert config is not None, "config is required"
    # 1. Semantic similarity check
    threshold = config.deduplication.semantic_threshold
    if similarity < threshold:
        return False
    # 2. Label similarity check to prevent false positives (optional)
    if not config.deduplication.enable_label_similarity_check:
        return True  # Skip label check - rely only on semantic similarity
    label_sim = _compute_label_similarity(entity_label, similar_label)
    min_label_sim = config.deduplication.min_label_similarity
    high_sem_sim = config.deduplication.high_semantic_similarity
    return label_sim >= min_label_sim or similarity >= high_sem_sim


def _merge_similar_entities_semantic(
    similar_entities: list[Entity],
    config: "OntologyConfig",
    _stage_name: str,
    similarity_score: float | None = None,
) -> tuple[Entity, dict[str, str], list[MergeDecision]]:
    """Merge similar entities found in semantic deduplication."""
    assert similar_entities is not None, "similar_entities is required"
    assert config is not None, "config is required"
    if len(similar_entities) <= 1:
        return (similar_entities[0] if similar_entities else None, {}, [])

    threshold = (
        config.deduplication.semantic_threshold if hasattr(config, "deduplication") else 0.85
    )

    merged, id_mapping, merge_decisions = _merge_entity_group(
        similar_entities,
        config,
        reason="semantic",
        similarity_score=similarity_score,
        threshold=threshold,
    )

    return merged, id_mapping, merge_decisions


def _build_faiss_index(
    entity_list: list[Entity],
    entity_embeddings: dict[str, list[float]],
    config: "OntologyConfig",
) -> Any:
    """Build and return a FAISSIndex from entity embeddings. Raises on failure."""
    assert len(entity_list) > 0, "entity_list must not be empty"
    assert config.embeddings.dimension > 0, "embedding dimension must be positive"

    from taxonomy_ontology_accelerator.ontology_engine.processing.embeddings import FAISSIndex

    embeddings_dict = {
        e.id: entity_embeddings[e.id] for e in entity_list if e.id in entity_embeddings
    }
    faiss_index = FAISSIndex(
        dimension=config.embeddings.dimension,
        index_type=config.deduplication.faiss.index_type,
        config=config,
    )
    faiss_index.build(embeddings_dict)
    if not faiss_index._built:
        raise RuntimeError("FAISS index failed to build")
    return faiss_index


def _find_duplicates_using_faiss(
    entity_list: list[Entity],
    entity_embeddings: dict[str, list[float]],
    config: "OntologyConfig",
    processed_ids: set[str],
) -> tuple[list[Entity], dict[str, str], list[MergeDecision]]:
    """Find semantic duplicates using FAISS."""
    assert entity_list is not None, "entity_list is required"
    assert entity_embeddings is not None, "entity_embeddings is required"
    deduplicated: list[Entity] = []
    id_mapping: dict[str, str] = {}
    all_merge_decisions: list[MergeDecision] = []
    try:
        faiss_index = _build_faiss_index(entity_list, entity_embeddings, config)
        entity_by_id = {e.id: e for e in entity_list}
        logger.info(f"Using FAISS index for {len(entity_list)} entities")
        top_k = min(config.deduplication.faiss.top_k, len(entity_list))

        for entity in entity_list:
            if entity.id in processed_ids:
                continue
            entity_embedding = entity_embeddings.get(entity.id)
            if not entity_embedding:
                deduplicated.append(entity)
                processed_ids.add(entity.id)
                continue

            results = faiss_index.search(
                entity_embedding,
                top_k=top_k,
                similarity_threshold=config.deduplication.semantic_threshold,
            )
            similar_entities = [entity]
            for similar_id, similarity in results:
                if similar_id == entity.id or similar_id in processed_ids:
                    continue
                similar_entity = entity_by_id.get(similar_id)
                if not similar_entity:
                    continue
                if _is_valid_semantic_duplicate(
                    entity.label, similar_entity.label, similarity, config
                ):
                    similar_entities.append(similar_entity)
                    processed_ids.add(similar_id)
            if len(similar_entities) > 1:
                merged, group_mapping, group_decisions = _merge_similar_entities_semantic(
                    similar_entities, config, "Semantic (FAISS)"
                )
                deduplicated.append(merged)
                id_mapping.update(group_mapping)
                all_merge_decisions.extend(group_decisions)
            else:
                deduplicated.append(entity)
            processed_ids.add(entity.id)
        return deduplicated, id_mapping, all_merge_decisions
    except Exception as e:
        logger.warning(f"FAISS failed ({e}), using linear search")
        return [], {}, []


def _find_duplicates_linear_search(
    entities: list[Entity],
    entity_embeddings: dict[str, list[float]],
    config: "OntologyConfig",
    processed_ids: set[str],
) -> tuple[list[Entity], dict[str, str], list[MergeDecision]]:
    """Find semantic duplicates via linear search."""
    assert entities is not None, "entities is required"
    assert entity_embeddings is not None, "entity_embeddings is required"
    deduplicated: list[Entity] = []
    id_mapping: dict[str, str] = {}
    all_merge_decisions: list[MergeDecision] = []
    for entity in entities:
        if entity.id in processed_ids:
            continue
        similar_entities = [entity]
        entity_embedding = entity_embeddings.get(entity.id)
        if entity_embedding:
            for other_entity in entities:
                if other_entity.id == entity.id or other_entity.id in processed_ids:
                    continue
                other_embedding = entity_embeddings.get(other_entity.id)
                if not other_embedding:
                    continue
                try:
                    similarity = cosine_similarity(entity_embedding, other_embedding)
                    if _is_valid_semantic_duplicate(
                        entity.label,
                        other_entity.label,
                        similarity,
                        config,
                    ):
                        similar_entities.append(other_entity)
                        processed_ids.add(other_entity.id)
                except Exception as e:
                    logger.warning(f"Failed to compare embeddings: {e}")
        if len(similar_entities) > 1:
            merged, group_mapping, group_decisions = _merge_similar_entities_semantic(
                similar_entities, config, "Semantic (linear)"
            )
            deduplicated.append(merged)
            id_mapping.update(group_mapping)
            all_merge_decisions.extend(group_decisions)
        else:
            deduplicated.append(entity)
        processed_ids.add(entity.id)
    return deduplicated, id_mapping, all_merge_decisions


async def _find_semantic_duplicates_async(
    entities: list[Entity], config: "OntologyConfig"
) -> tuple[list[Entity], dict[str, str], list[MergeDecision]]:
    """Deduplicate entities using semantic similarity (embeddings)."""
    assert entities is not None, "entities is required"
    assert config is not None, "config is required"
    if not entities or len(entities) < MIN_ABBREVIATION_LENGTH:
        return entities, {}, []
    entity_texts, entity_ids = _prepare_entity_texts_for_embedding(entities)
    embeddings_dict, _ = await generate_embeddings_batch_async(
        entity_texts, config, error_collector=None, embeddings_path=None
    )
    if not embeddings_dict:
        logger.warning("No embeddings generated for semantic deduplication")
        return entities, {}, []
    entity_embeddings = _build_entity_embeddings_map(entity_ids, entity_texts, embeddings_dict)
    processed_ids: set[str] = set()
    use_faiss = len(entity_embeddings) > config.deduplication.faiss.threshold
    entity_list = [e for e in entities if e.id in entity_embeddings]
    all_merge_decisions: list[MergeDecision] = []
    if use_faiss:
        deduplicated, id_mapping, merge_decisions = _find_duplicates_using_faiss(
            entity_list, entity_embeddings, config, processed_ids
        )
        all_merge_decisions.extend(merge_decisions)
        if not deduplicated and not id_mapping:
            # FAISS failed - reset processed_ids to avoid dropping entities
            processed_ids.clear()
            use_faiss = False
    if not use_faiss:
        deduplicated, id_mapping, merge_decisions = _find_duplicates_linear_search(
            entities, entity_embeddings, config, processed_ids
        )
        all_merge_decisions.extend(merge_decisions)
    for entity in entities:
        if entity.id not in entity_embeddings and entity.id not in processed_ids:
            deduplicated.append(entity)
            processed_ids.add(entity.id)
    if id_mapping:
        logger.debug(
            f"Semantic: Merged {len(id_mapping)} duplicates "
            f"into {len(deduplicated)} unique entities (threshold: {config.deduplication.semantic_threshold})"
        )
    return deduplicated, id_mapping, all_merge_decisions


# ========================================================================
# Abbreviation Detection and Linking
# ========================================================================


def _is_abbreviation(short_text: str, long_text: str) -> bool:
    """
    Check if short_text is an abbreviation of long_text.

    Args:
        short_text: Potential abbreviation
        long_text: Potential full form

    Returns:
        True if short_text is an abbreviation of long_text
    """
    assert short_text is not None, "short_text is required"
    assert long_text is not None, "long_text is required"

    short_text = short_text.strip().upper()
    long_text = long_text.strip().upper()

    # Don't match single-word variations (e.g., "Test" and "Testing")
    words = long_text.split()
    if len(words) == 1:
        return False

    # Common words to skip when forming abbreviations
    skip_words = {"OF", "THE", "AND", "A", "AN", "IN", "ON", "AT", "TO", "FOR"}

    # Remove dots and spaces from short_text to get actual letter count
    short_text_clean = short_text.replace(".", "").replace(" ", "")

    # Check if short text is just the initials of long text (skipping common words)
    significant_words = [word for word in words if word and word not in skip_words]

    if len(significant_words) >= len(short_text_clean):
        initials = "".join(word[0] for word in significant_words)
        if initials == short_text_clean:
            return True

    # Also try with all words (no skipping) in case it's a strict abbreviation
    if len(words) >= len(short_text_clean):
        all_initials = "".join(word[0] for word in words if word)
        if all_initials == short_text_clean:
            return True

    return False


def _is_potential_abbreviation(label: str) -> bool:
    """Check if a label could be an abbreviation."""
    assert label is not None, "label is required"
    assert isinstance(label, str), "label must be a string"
    potential_abbrev = label.strip()

    # Too long to be an abbreviation
    if len(potential_abbrev) > MAX_WORD_DIFFERENCE:
        return False

    # Must match abbreviation pattern (starts with uppercase/digit)
    if not re.match(r"^[A-Z0-9][A-Za-z0-9.\s]*$", potential_abbrev):
        return False

    # Must have at least some uppercase or digits
    cleaned = potential_abbrev.replace(".", "").replace(" ", "")
    return any(c.isupper() or c.isdigit() for c in cleaned)


def _get_current_alt_labels(
    entity_id: str, entity: Entity, updated_properties: dict[str, dict]
) -> tuple[dict, list[str]]:
    """Get current properties and altLabels for an entity."""
    assert entity is not None, "entity is required"
    assert updated_properties is not None, "updated_properties is required"
    if entity_id in updated_properties:
        current_props = updated_properties[entity_id]
    else:
        current_props = dict(entity.properties) if entity.properties else {}

    alt_labels = current_props.get("skos:altLabel", [])
    if isinstance(alt_labels, str):
        alt_labels = [alt_labels]
    elif not isinstance(alt_labels, list):
        alt_labels = []

    return current_props, alt_labels


def _add_alt_label_link(
    entity_id: str,
    full_form_label: str,
    abbrev_label: str,
    current_props: dict,
    alt_labels: list[str],
    updated_properties: dict[str, dict],
) -> None:
    """Add an altLabel link if not already present."""
    assert full_form_label is not None, "full_form_label is required"
    assert alt_labels is not None, "alt_labels is required"
    if full_form_label not in alt_labels:
        alt_labels = list(alt_labels)  # Create new list
        alt_labels.append(full_form_label)
        current_props = dict(current_props)  # Create new dict
        current_props["skos:altLabel"] = alt_labels
        updated_properties[entity_id] = current_props

        logger.debug(f"Linked abbreviation '{abbrev_label}' to full form '{full_form_label}'")


def _create_entity_with_properties(entity: Entity, properties: dict) -> Entity:
    """Create a new Entity with updated properties."""
    assert entity is not None, "entity is required"
    assert properties is not None, "properties is required"
    return Entity(
        id=entity.id,
        canonical_key=entity.canonical_key,
        label=entity.label,
        aliases=entity.aliases,
        type=entity.type,
        description=entity.description,
        properties=properties,
        metadata=entity.metadata,
    )


def _find_and_link_full_forms(
    entity: Entity,
    entity_type_normalized: str,
    sorted_entities: list[Entity],
    start_index: int,
    updated_properties: dict[str, dict],
    config: "OntologyConfig",
) -> None:
    """Find and link full forms for a potential abbreviation."""
    assert entity is not None, "entity is required"
    assert sorted_entities is not None, "sorted_entities is required"
    abbrev_label = entity.label.strip()

    for other_entity in sorted_entities[start_index:]:
        if len(other_entity.label) <= len(abbrev_label):
            continue

        # Only link abbreviations with the same type
        other_type_normalized = (
            normalize_text(other_entity.type, config).lower() if other_entity.type else ""
        )
        if other_type_normalized != entity_type_normalized:
            continue

        if _is_abbreviation(abbrev_label, other_entity.label):
            current_props, alt_labels = _get_current_alt_labels(
                entity.id, entity, updated_properties
            )
            _add_alt_label_link(
                entity.id,
                other_entity.label,
                entity.label,
                current_props,
                alt_labels,
                updated_properties,
            )


def _link_abbreviations_to_full_forms(
    entities: list[Entity], config: "OntologyConfig"
) -> list[Entity]:
    """
    Detect abbreviations and link them to full forms using SKOS:altLabel.

    Does not merge entities, only adds altLabel property for abbreviations.
    Returns new Entity objects to avoid in-place mutation.

    Args:
        entities: List of entities
        config: Ontology configuration

    Returns:
        List of entities with abbreviation links added (new Entity objects)
    """
    assert entities is not None, "entities is required"
    assert config is not None, "config is required"

    if not entities or len(entities) < MIN_ABBREVIATION_LENGTH:
        return entities

    # Build a mapping of entity ID to updated properties
    updated_properties: dict[str, dict] = {}

    # Sort by label length to process shorter (potential abbreviations) first
    sorted_entities = sorted(entities, key=lambda e: len(e.label))

    for i, entity in enumerate(sorted_entities):
        # Check if this could be an abbreviation
        if not _is_potential_abbreviation(entity.label):
            continue

        # Find potential full forms
        entity_type_normalized = normalize_text(entity.type, config).lower() if entity.type else ""
        _find_and_link_full_forms(
            entity, entity_type_normalized, sorted_entities, i + 1, updated_properties, config
        )

    # Create new entity list with updated properties (avoid in-place mutation)
    if not updated_properties:
        return entities

    result_entities = []
    for entity in entities:
        if entity.id in updated_properties:
            new_entity = _create_entity_with_properties(entity, updated_properties[entity.id])
            result_entities.append(new_entity)
        else:
            result_entities.append(entity)

    return result_entities


# ========================================================================
# Main Deduplication Function
# ========================================================================


async def deduplicate_entities_enhanced_async(
    entities: list[Entity], config: "OntologyConfig", threshold: float = 0.85
) -> tuple[list[Entity], dict[str, str], list[MergeDecision]]:
    """Multi-stage deduplication: exact, normalized, semantic, abbreviation linking."""
    assert entities is not None, "entities is required"
    assert config is not None, "config is required"
    assert 0.0 <= threshold <= 1.0, "threshold must be between 0.0 and 1.0"
    if not entities:
        return [], {}, []
    original_count = len(entities)
    total_mapping: dict[str, str] = {}
    all_merge_decisions: list[MergeDecision] = []

    def _resolve_id_chain(entity_id: str, mapping: dict[str, str]) -> str:
        """Follow mapping chain to final entity ID with cycle detection."""
        assert entity_id is not None, "entity_id is required"
        assert mapping is not None, "mapping is required"
        visited = set()
        current_id = entity_id
        while current_id in mapping and current_id not in visited:
            visited.add(current_id)
            current_id = mapping[current_id]
        return current_id

    def _update_mappings(new_stage_mapping: dict[str, str]) -> None:
        """Update total_mapping with new mappings and resolve all chains."""
        assert new_stage_mapping is not None, "new_stage_mapping is required"
        assert isinstance(new_stage_mapping, dict), "new_stage_mapping must be a dict"
        total_mapping.update(new_stage_mapping)
        for old_id in list(total_mapping.keys()):
            total_mapping[old_id] = _resolve_id_chain(old_id, total_mapping)

    entities, stage1_mapping, stage1_decisions = _remove_exact_duplicates(entities, config)
    _update_mappings(stage1_mapping)
    all_merge_decisions.extend(stage1_decisions)
    entities, stage2_mapping, stage2_decisions = _normalize_entities(entities, config)
    _update_mappings(stage2_mapping)
    all_merge_decisions.extend(stage2_decisions)
    entities, stage3_mapping, stage3_decisions = await _find_semantic_duplicates_async(
        entities, config
    )
    _update_mappings(stage3_mapping)
    all_merge_decisions.extend(stage3_decisions)
    entities = _link_abbreviations_to_full_forms(entities, config)
    final_count = len(entities)
    duplicates_removed = original_count - final_count
    if duplicates_removed > 0:
        logger.info(
            f"Deduplication complete: {original_count} → {final_count} entities "
            f"({duplicates_removed} duplicates merged, {len(total_mapping)} ID mappings)"
        )
    return entities, total_mapping, all_merge_decisions


def deduplicate_entities_enhanced(
    entities: list[Entity], config: "OntologyConfig", threshold: float = 0.85
) -> tuple[list[Entity], dict[str, str], list[MergeDecision]]:
    """
    Deduplicate entities using multi-stage pipeline (sync wrapper).

    Stages:
    1. Exact match deduplication
    2. Normalization-based deduplication (singular/plural, case)
    3. Semantic deduplication (embedding similarity)
    4. Abbreviation detection and linking

    Args:
        entities: List of entities to deduplicate
        config: Ontology configuration
        threshold: Similarity threshold for semantic deduplication (0.0-1.0)

    Returns:
        Tuple of (deduplicated entities, id_mapping dict, merge_decisions list)
        id_mapping maps old entity IDs to new entity IDs
        merge_decisions contains records of all merges performed

    Raises:
        RuntimeError: If called from async context. Use deduplicate_entities_enhanced_async() instead.
    """
    assert entities is not None, "entities is required"
    assert config is not None, "config is required"
    assert 0.0 <= threshold <= 1.0, "threshold must be between 0.0 and 1.0"

    # Check if there's already a running event loop
    try:
        asyncio.get_running_loop()
        raise RuntimeError(
            "deduplicate_entities_enhanced() cannot be called from async context. "
            "Use 'await deduplicate_entities_enhanced_async()' instead."
        )
    except RuntimeError as e:
        if "cannot be called from async context" in str(e):
            raise
        # No running loop - safe to proceed with sync wrapper
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        return loop.run_until_complete(
            deduplicate_entities_enhanced_async(entities, config, threshold)
        )
