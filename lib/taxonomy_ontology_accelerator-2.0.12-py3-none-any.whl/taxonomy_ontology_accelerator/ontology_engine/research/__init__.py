"""Web research module for domain exploration."""

from taxonomy_ontology_accelerator.ontology_engine.research.research_scraper import (
    WebResearchScraper,
)

__all__ = ["WebResearchScraper"]
