"""Simple web research scraper for domain exploration."""

import asyncio
import json
import re
import time
from pathlib import Path
from urllib.parse import urlparse

import fsspec
import httpx
from bs4 import BeautifulSoup
from markdownify import markdownify
from pydantic import BaseModel, Field
from pydantic_ai import Agent

from taxonomy_ontology_accelerator.commons.io.fsspec_utils import get_default_filesystem
from taxonomy_ontology_accelerator.commons.utils.logger import get_logger

logger = get_logger()

# Default prompts (used when no custom prompt is configured)
DEFAULT_SYSTEM_PROMPT = (
    "You are a research assistant that generates effective web search queries. "
    "Given a domain name, generate diverse, specific search queries that will find "
    "authoritative content about that domain's ontology, structure, and key concepts."
)

DEFAULT_USER_PROMPT_TEMPLATE = (
    "Generate {num_queries} diverse web search queries "
    "to research the domain: '{domain}'. "
    "Focus on finding ontologies, classifications, key concepts, and authoritative sources. "
    "Make queries specific and likely to return high-quality results."
)


class SearchQueries(BaseModel):
    """Generated search queries for domain research."""

    queries: list[str] = Field(
        description="List of diverse, specific web search queries for researching the domain"
    )


class WebResearchScraper:
    """
    Simple web scraper for domain research.

    Generates domain-focused queries, searches the web, and saves
    raw markdown content for later ontology extraction.

    Configuration options (via config.research):
    - num_queries: Number of search queries to generate
    - results_per_query: Results to fetch per query
    - max_fetches: Maximum total pages to scrape
    - allowed_domains: Whitelist domains (empty = all allowed)
    - blocked_domains: Blacklist domains
    - http_timeout: HTTP request timeout in seconds
    - rate_limit_delay: Delay between queries in seconds
    - system_prompt: Custom LLM system prompt
    - user_prompt_template: Custom LLM user prompt template
    """

    def __init__(
        self,
        domain: str,
        config,
        output_dir: Path,
        custom_prompt_path: Path | None = None,
    ):
        """
        Initialize scraper with domain and config.

        Args:
            domain: Domain name to research
            config: OntologyConfig with research settings
            output_dir: Directory to save scraped content
            custom_prompt_path: Optional path to custom research prompt file
        """
        assert output_dir is not None, "Output dir required"
        assert config is not None, "Config required"

        self.domain = domain
        self.config = config
        self.output_dir = output_dir
        self.custom_prompt_path = custom_prompt_path
        self.metadata: dict[str, list] = {"sources": []}
        self.fetched_urls: set[str] = set()  # Track fetched URLs for deduplication

        # Use configurable timeout (with fallback for older configs)
        timeout = config.research.http_timeout if hasattr(config.research, "http_timeout") else 30.0
        self.http_client = httpx.AsyncClient(timeout=timeout, follow_redirects=True)

    async def __aenter__(self):
        """Async context manager entry."""
        assert hasattr(self, "http_client"), "HTTP client must be initialized"
        assert self.http_client is not None, "HTTP client must not be None"
        return self

    async def __aexit__(self, _exc_type, _exc_val, _exc_tb):
        """Async context manager exit - cleanup HTTP client."""
        assert hasattr(self, "http_client"), "HTTP client must exist"
        assert self.http_client is not None, "HTTP client must not be None"
        await self.http_client.aclose()

    def _normalize_domain_name(self, domain: str) -> str:
        """Convert domain slug to readable name."""
        assert domain is not None, "Domain required"
        assert len(domain) > 0, "Domain must not be empty"

        return domain.replace("_", " ").replace("-", " ")

    def _read_prompt_file(self, file_path: str | None) -> str | None:
        """Read prompt content from file if it exists and has non-comment content."""
        assert file_path is None or isinstance(file_path, str), "File path must be string or None"
        assert hasattr(self, "config"), "Config must be set"

        if not file_path:
            return None

        path = Path(file_path)

        fs = get_default_filesystem()
        if not fs.exists(str(path)):
            logger.debug(f"Prompt file not found: {path}")
            return None

        content = path.read_text(encoding="utf-8").strip()
        if not content:
            logger.debug(f"Prompt file is empty: {path}")
            return None

        # Check if file contains only comments (lines starting with #)
        non_comment_lines = [
            line
            for line in content.split("\n")
            if line.strip() and not line.strip().startswith("#")
        ]
        if not non_comment_lines:
            logger.debug(f"Prompt file contains only comments: {path}")
            return None

        logger.debug(f"Loaded prompt from file: {path}")
        return content

    def _get_system_prompt(self) -> str:
        """Get system prompt from file or default."""
        assert hasattr(self, "config"), "Config must be set"
        assert hasattr(self, "custom_prompt_path"), "Custom prompt path must be set"

        # Priority 1: Config-specified file path
        file_content = self._read_prompt_file(self.config.research.system_prompt_file)
        if file_content:
            return file_content

        # Priority 2: Convention-based file (custom_prompt_path)

        fs = get_default_filesystem()
        if self.custom_prompt_path and fs.exists(str(self.custom_prompt_path)):
            content = self.custom_prompt_path.read_text(encoding="utf-8").strip()
            if content:
                logger.debug(f"Using system prompt from convention path: {self.custom_prompt_path}")
                return content

        # Priority 3: Default
        logger.debug("Using default system prompt")
        return DEFAULT_SYSTEM_PROMPT

    def _get_user_prompt(self, normalized_domain: str) -> str:
        """Get user prompt from file or default, with variable substitution."""
        assert normalized_domain is not None, "Normalized domain required"
        assert len(normalized_domain) > 0, "Normalized domain must not be empty"

        # Try to load from config-specified file
        file_content = self._read_prompt_file(self.config.research.user_prompt_file)
        template = file_content if file_content else DEFAULT_USER_PROMPT_TEMPLATE

        # Substitute placeholders
        return template.format(
            domain=normalized_domain,
            num_queries=self.config.research.num_queries,
        )

    async def generate_queries(self) -> list[str]:
        """Generate intelligent search queries using LLM."""
        assert hasattr(self, "domain"), "Domain must be set"
        assert len(self.domain) > 0, "Domain must not be empty"

        normalized_domain = self._normalize_domain_name(self.domain)
        system_prompt = self._get_system_prompt()
        user_prompt = self._get_user_prompt(normalized_domain)

        from taxonomy_ontology_accelerator.ontology_engine.core.extractor import (
            _build_retry_strategy,
        )

        retry_strategy = _build_retry_strategy(self.config)

        agent = Agent(
            self.config.llm.model,
            output_type=SearchQueries,
            system_prompt=system_prompt,
            retries=retry_strategy,
        )

        result = await agent.run(user_prompt)
        queries = result.output.queries
        logger.info(f"LLM generated queries: {queries}")
        return queries

    def _sanitize_filename(self, url: str, index: int) -> str:
        """Create clean filename from URL and index."""
        assert url is not None, "URL required"
        assert isinstance(index, int), "Index must be integer"
        assert index >= 0, "Index must be non-negative"

        parsed = urlparse(url)
        domain = parsed.netloc.replace("www.", "").split(".")[0]
        path_parts = [p for p in parsed.path.strip("/").split("/") if p]

        meaningful_part = path_parts[-1] if path_parts else ""

        clean_part = re.sub(r"[^a-zA-Z0-9_]", "_", meaningful_part)
        clean_part = re.sub(r"_+", "_", clean_part).strip("_").lower()

        if clean_part:
            filename = f"{index:02d}_{domain}_{clean_part}.md"
        else:
            filename = f"{index:02d}_{domain}.md"

        return filename[:100]

    def _save_markdown(self, filename: str, content: str, source_url: str):
        """Save content to markdown file with frontmatter."""
        assert filename is not None, "Filename required"
        assert content is not None, "Content required"
        assert source_url is not None, "Source URL required"

        fs = fsspec.filesystem("file")
        fs.makedirs(str(self.output_dir), exist_ok=True)
        filepath = self.output_dir / filename

        with fs.open(str(filepath), "w", encoding="utf-8") as f:
            f.write(f"---\nsource: {source_url}\n---\n\n")
            f.write(content)

        self.metadata["sources"].append(
            {"file": filename, "url": source_url, "timestamp": time.time()}
        )

    def _save_metadata(self):
        """Save metadata.json with source URLs and timestamps."""
        assert hasattr(self, "output_dir"), "Output dir must be set"
        assert hasattr(self, "metadata"), "Metadata must exist"

        fs = fsspec.filesystem("file")
        fs.makedirs(str(self.output_dir), exist_ok=True)
        metadata_file = self.output_dir / "metadata.json"

        with metadata_file.open("w", encoding="utf-8") as f:
            json.dump(self.metadata, f, indent=2)

    def _matches_domain_pattern(self, domain: str, pattern: str) -> bool:
        """Check if domain matches a pattern (TLD or domain substring)."""
        assert domain is not None, "Domain required"
        assert pattern is not None, "Pattern required"

        pattern_lower = pattern.lower()
        # TLD check (e.g., ".edu", ".gov", ".ru")
        if pattern_lower.startswith("."):
            return domain.endswith(pattern_lower)
        # Domain substring check (e.g., "pinterest.com")
        return pattern_lower in domain

    def _is_blocked(self, domain: str, url: str) -> bool:
        """Check if domain is in blocked list."""
        assert domain is not None, "Domain required"
        assert url is not None, "URL required"

        for blocked in self.config.research.blocked_domains:
            if self._matches_domain_pattern(domain, blocked):
                logger.debug(f"Blocked: {url} (matched {blocked})")
                return True
        return False

    def _is_in_allowed_list(self, domain: str) -> bool:
        """Check if domain is in allowed list (when list is non-empty)."""
        assert domain is not None, "Domain required"
        assert self.config.research.allowed_domains, "Allowed domains must be non-empty"

        for allowed in self.config.research.allowed_domains:
            if self._matches_domain_pattern(domain, allowed):
                return True
        return False

    def _is_domain_allowed(self, url: str) -> bool:
        """
        Check if URL's domain is allowed based on allowed/blocked lists.

        Args:
            url: URL to check

        Returns:
            True if domain is allowed, False if blocked
        """
        assert url is not None, "URL required"
        assert isinstance(url, str), "URL must be a string"

        try:
            parsed = urlparse(url)
            domain = parsed.netloc.lower()
        except Exception:
            return False

        # Check blocked domains first (takes precedence)
        if self._is_blocked(domain, url):
            return False

        # Check allowed domains (if list is non-empty, only these are allowed)
        if self.config.research.allowed_domains:
            is_allowed = self._is_in_allowed_list(domain)
            if not is_allowed:
                logger.debug(f"Not in allowed domains: {url}")
            return is_allowed

        # No allowed list = all domains allowed (except blocked)
        return True

    async def _web_search(self, query: str) -> list[dict]:
        """
        Perform web search for query using DuckDuckGo API.

        Returns list of dicts with 'url' and 'title' keys.
        Results are filtered by allowed_domains and blocked_domains config.

        Requires the 'research' dependency group: uv sync --group research
        """
        assert query is not None, "Query required"
        assert len(query) > 0, "Query must not be empty"

        try:
            from ddgs import DDGS  # pyright: ignore[reportMissingImports]
        except ImportError as e:
            raise ImportError(
                "The 'ddgs' package is required for web research. "
                "Install it with: uv sync --group research"
            ) from e

        try:
            loop = asyncio.get_event_loop()
            search_results = await loop.run_in_executor(
                None,
                lambda: DDGS().text(query, max_results=self.config.research.results_per_query),
            )

            results = []
            for result in search_results or []:
                if "href" in result:
                    url = result["href"]
                    # Skip empty URLs
                    if not url or not url.strip():
                        continue
                    # Apply domain filtering
                    if self._is_domain_allowed(url):
                        results.append({"url": url, "title": result.get("title", "")})

            filtered_count = len(search_results or []) - len(results)
            if filtered_count > 0:
                logger.debug(f"Filtered {filtered_count} results by domain rules")

            return results

        except Exception as e:
            logger.warning(f"Search failed for query '{query}': {e}")
            return []

    async def _fetch_content(self, url: str) -> str:
        """Fetch HTML content from URL."""
        assert url is not None, "URL required"
        assert len(url) > 0, "URL must not be empty"

        try:
            response = await self.http_client.get(url)
            response.raise_for_status()
            return response.text
        except Exception as e:
            logger.debug(f"Failed to fetch {url}: {e}")
            return ""

    def _html_to_markdown(self, html: str) -> str:
        """Convert HTML to markdown."""
        assert html is not None, "HTML content required"
        assert isinstance(html, str), "HTML must be a string"

        if not html:
            return ""

        try:
            soup = BeautifulSoup(html, "html.parser")

            for script in soup(["script", "style", "nav", "footer", "header"]):
                script.decompose()

            markdown = markdownify(str(soup), heading_style="ATX")
            return markdown.strip()

        except Exception:
            return html

    def _get_rate_limit_delay(self) -> float:
        """Get rate limit delay from config with fallback."""
        assert hasattr(self, "config"), "Config must be set"
        assert hasattr(self.config, "research"), "Research config must exist"

        if hasattr(self.config.research, "rate_limit_delay"):
            return self.config.research.rate_limit_delay
        return 1.0

    async def _process_url(self, url: str, file_count: int) -> int | None:
        """Process a single URL and save content. Returns new file_count or None if skipped."""
        assert url is not None, "URL required"
        assert isinstance(file_count, int), "File count must be integer"

        html_content = await self._fetch_content(url)
        if not html_content:
            return None

        markdown = self._html_to_markdown(html_content)
        if not markdown:
            return None

        filename = self._sanitize_filename(url, file_count)
        self._save_markdown(filename, markdown, url)
        logger.debug(f"Saved: {filename}")
        return file_count + 1

    async def _process_query_results(
        self, results: list[dict], file_count: int, urls_skipped: int
    ) -> tuple[int, int]:
        """Process results from a single query. Returns (file_count, urls_skipped)."""
        assert results is not None, "Results required"
        assert isinstance(file_count, int), "File count must be integer"

        for result in results[: self.config.research.results_per_query]:
            if file_count >= self.config.research.max_fetches:
                break

            url = result.get("url", "")

            # Skip empty URLs
            if not url or not url.strip():
                logger.debug("Skipping empty URL in results")
                continue

            # Skip already fetched URLs (deduplication)
            if url in self.fetched_urls:
                logger.debug(f"Skipping duplicate URL: {url}")
                urls_skipped += 1
                continue

            self.fetched_urls.add(url)
            new_count = await self._process_url(url, file_count)
            if new_count is not None:
                file_count = new_count

        return file_count, urls_skipped

    async def scrape(self) -> dict:
        """
        Main scraping pipeline.

        Returns dict with 'files_created', 'output_dir', 'urls_skipped', and 'queries_used' keys.
        """
        assert self.domain is not None, "Domain must be set"
        assert self.config is not None, "Config must be set"

        queries = await self.generate_queries()
        file_count = 0
        urls_skipped = 0
        rate_limit_delay = self._get_rate_limit_delay()

        normalized_domain = self._normalize_domain_name(self.domain)
        logger.info(f"Searching for '{normalized_domain}' with {len(queries)} queries...")

        for query in queries:
            if file_count >= self.config.research.max_fetches:
                break

            results = await self._web_search(query)
            if not results:
                logger.warning(f"No results found for query: {query}")
                continue

            file_count, urls_skipped = await self._process_query_results(
                results, file_count, urls_skipped
            )

            if rate_limit_delay > 0:
                await asyncio.sleep(rate_limit_delay)

        self._save_metadata()
        logger.info(f"Research complete: saved {file_count} files to {self.output_dir}")

        return {
            "files_created": file_count,
            "output_dir": str(self.output_dir),
            "urls_skipped": urls_skipped,
            "queries_used": len(queries),
        }
