"""Ontology Agent with graph manipulation tools."""

import json
from collections import defaultdict
from pathlib import Path
import boto3

import fsspec
from pydantic import BaseModel
from pydantic_ai import Agent, RunContext

from taxonomy_ontology_accelerator.commons.utils.logger import get_logger
from taxonomy_ontology_accelerator.ontology_engine.core.models import (
    OntologyGraph,
    OntologySchema,
)

try:
    import owlready2
except ImportError:
    owlready2 = None

logger = get_logger()

MAX_SEARCH_RESULTS = 20
BUCKET = "govuk-ai-accelerator-data-integration"


class CameraPosition(BaseModel):
    """Camera position for graph navigation."""

    entity_id: str | None = None
    x: float | None = None
    y: float | None = None
    zoom: float = 0.5


class GraphState(BaseModel):
    """Frontend graph visualization state."""

    highlighted_nodes: list[str] = []
    visible_nodes: list[str] | None = None
    camera_position: CameraPosition | None = None
    node_colors: dict[str, str] = {}
    node_sizes: dict[str, int] = {}
    filter_type: str | None = None


class AgentDependencies(BaseModel):
    """Dependencies for the ontology agent."""

    domains: dict[str, tuple[OntologySchema | None, OntologyGraph | None]]
    current_domain: str = "test"
    graph_state: GraphState = GraphState()

    class Config:
        arbitrary_types_allowed = True


def load_ontology_data(
    domain: str, output_dir: str | Path
) -> tuple[OntologySchema | None, OntologyGraph | None]:
    """Load schema and graph for a domain."""
    assert domain is not None, "Domain must not be None"
    assert output_dir is not None, "Output directory must not be None"
    s3_client = boto3.client("s3")
    response = s3_client.list_objects_v2(Bucket=BUCKET, Prefix=output_dir)

    schema = None
    graph = None
    print(domain, output_dir)
    for obj in response["Contents"]:
        if obj["Key"].rsplit("/")[-1] == "schema.json":
            try:
                response = s3_client.get_object(Bucket=BUCKET, Key=obj["Key"])
                schema_data = json.loads(response["Body"].read().decode("utf-8"))
                schema = OntologySchema(**schema_data)
                logger.info(f"Successfully loaded schema")
            except Exception as e:
                logger.warning(f"Failed to load schema: {e}")
        if obj["Key"].rsplit("/")[-1] == "graph.json":
            try:
                response = s3_client.get_object(Bucket=BUCKET, Key=obj["Key"])
                graph_data = json.loads(response["Body"].read().decode("utf-8"))
                graph = OntologyGraph(**graph_data)
                logger.info(f"Successfully loaded graph")
            except Exception as e:
                logger.warning(f"Failed to load graph: {e}")
    return schema, graph


def load_domain(
    output_base_dir: str | Path,
) -> dict[str, tuple[OntologySchema | None, OntologyGraph | None]]:
    """Load all available ontology domains."""
    assert output_base_dir is not None, "Output directory must not be None"

    domains = {}
    domain_name = output_base_dir.rsplit("/")[0]
    schema, graph = load_ontology_data(domain_name, output_base_dir)
    if graph is not None:
        domains[domain_name] = (schema, graph)

    return domains


def get_system_prompt() -> str:
    """Generate dynamic system prompt."""

    return f"""You are an Ontology Copilot.

Explore knowledge graphs with visual navigation.
Please only rely with the knowledge graph as your source of data - NEVER rely on outside sources of data.
For example, if it is not in the knowledge graph, do not mention it.

**RULES:**
1. ALWAYS call tools - never just describe
2. Be PROACTIVE - manipulate graph with every response
3. Navigate VISUALLY - show, highlight, explore

**NAVIGATION TOOLS:**
- navigate_to_node - Zoom to entity
- find_connected - Explore connections
- filter_by_type - Show specific types
- search_entities - Find by label
- switch_domain - Change domains
- reset_view - Show all

**ANALYSIS TOOLS:**
- analyze_hierarchy - Find roots, leaves, depth
- find_disconnected - Isolated entities
- analyze_connectivity - Connection patterns
- find_hubs - Most connected nodes

**OWL REASONING (owlready2):**
- infer_relationships - Discover implicit relationships
- check_consistency - Verify logical consistency
- find_equivalent_classes - Find potentially equivalent concepts

Make the graph interactive and insightful!"""

def create_ontology_agent(
    domains: dict[str, tuple[OntologySchema | None, OntologyGraph | None]],
    config=None,
) -> Agent[AgentDependencies, str]:
    """Create pydantic-ai agent with graph tools."""
    assert domains is not None, "Domains must not be None"
    assert len(domains) > 0, "At least one domain required"

    total_entities = sum(len(g.entities) for _, g in domains.values() if g)
    available = ", ".join(domains.keys())

    # Determine retry strategy
    if config is not None:
        from taxonomy_ontology_accelerator.ontology_engine.core.extractor import (
            _build_retry_strategy,
        )

        retry_strategy = _build_retry_strategy(config)
    else:
        # Default: 3 retries for UI agent (simple integer)
        retry_strategy = 3

    agent = Agent(
        "bedrock:eu.anthropic.claude-sonnet-4-6",
        deps_type=AgentDependencies,
        instructions=lambda ctx: get_system_prompt(),
        retries=retry_strategy,
    )

    # _add_domain_tools(agent)
    _add_search_tools(agent)
    _add_navigation_tools(agent)
    _add_graph_tools(agent)
    _add_hierarchy_analysis(agent)
    _add_disconnected_tool(agent)
    _add_connectivity_tool(agent)
    _add_hubs_tool(agent)
    _add_infer_tool(agent)
    _add_consistency_tool(agent)
    _add_equivalence_tool(agent)

    return agent


# def _add_domain_tools(agent: Agent[AgentDependencies, str]) -> None:
#     """Add domain management tools."""
#     assert agent is not None, "Agent must not be None"
#     assert hasattr(agent, "tool"), "Agent must have tool decorator"
#
#     @agent.tool
#     async def switch_domain(ctx: RunContext[AgentDependencies], domain: str) -> dict:
#         """Switch to different domain."""
#         assert ctx.deps.domains is not None, "Domains must be loaded"
#         assert domain is not None, "Domain must not be None"
#
#         if domain not in ctx.deps.domains:
#             return {"error": f"Domain '{domain}' not found"}
#
#         if ctx.deps.current_domain == domain:
#             return {"message": f"Already viewing {domain}"}
#
#         ctx.deps.current_domain = domain
#         _, graph = ctx.deps.domains[domain]
#         nodes = len(graph.entities) if graph else 0
#
#         return {"domain": domain, "nodes": nodes}


def _add_search_tools(agent: Agent[AgentDependencies, str]) -> None:
    """Add search tools."""
    assert agent is not None, "Agent must not be None"
    assert hasattr(agent, "tool"), "Agent must have tool decorator"

    @agent.tool
    async def search_entities(ctx: RunContext[AgentDependencies], query: str) -> list[dict]:
        """Search entities by label."""
        assert ctx.deps.domains is not None, "Domains must be loaded"
        assert query is not None, "Query must not be None"

        results = []
        query_lower = query.lower()

        for domain_name, (_, graph) in ctx.deps.domains.items():
            if not graph:
                continue
            for entity in graph.entities[:100]:
                if query_lower in entity.label.lower():
                    results.append(
                        {
                            "domain": domain_name,
                            "id": entity.id,
                            "label": entity.label,
                            "type": entity.type,
                        }
                    )
                    if len(results) >= MAX_SEARCH_RESULTS:
                        return results

        return results


def _add_navigation_tools(agent: Agent[AgentDependencies, str]) -> None:
    """Add navigation tools."""
    assert agent is not None, "Agent must not be None"
    assert hasattr(agent, "tool"), "Agent must have tool decorator"

    @agent.tool
    async def navigate_to_node(
        ctx: RunContext[AgentDependencies], domain: str, entity_id: str
    ) -> dict:
        """Navigate to specific node."""
        assert ctx.deps.domains is not None, "Domains must be loaded"
        assert entity_id is not None, "Entity ID must not be None"

        if domain not in ctx.deps.domains:
            return {"error": f"Domain {domain} not found"}

        _, graph = ctx.deps.domains[domain]
        if not graph:
            return {"error": "No graph data"}

        entity = next((e for e in graph.entities if e.id == entity_id), None)
        if not entity:
            return {"error": f"Entity {entity_id} not found"}

        ctx.deps.graph_state.highlighted_nodes = [entity_id]
        ctx.deps.graph_state.camera_position = CameraPosition(entity_id=entity_id)
        ctx.deps.graph_state.node_colors = {entity_id: "#3b82f6"}

        return {"action": "navigated", "entity": entity.label}

    @agent.tool
    async def reset_view(ctx: RunContext[AgentDependencies]) -> dict:
        """Reset view to show all nodes."""
        assert ctx.deps.domains is not None, "Domains must be loaded"
        assert ctx.deps.graph_state is not None, "Graph state must exist"

        ctx.deps.graph_state = GraphState()
        return {"action": "reset", "message": "Showing all nodes"}


def _add_graph_tools(agent: Agent[AgentDependencies, str]) -> None:
    """Add graph manipulation tools."""
    assert agent is not None, "Agent must not be None"
    assert hasattr(agent, "tool"), "Agent must have tool decorator"

    @agent.tool
    async def find_connected(
        ctx: RunContext[AgentDependencies], domain: str, entity_id: str
    ) -> dict:
        """Find connected entities."""
        assert ctx.deps.domains is not None, "Domains must be loaded"
        assert entity_id is not None, "Entity ID must not be None"

        if domain not in ctx.deps.domains:
            return {"error": f"Domain {domain} not found"}

        _, graph = ctx.deps.domains[domain]
        if not graph:
            return {"error": "No graph data"}

        visited = {entity_id}
        for rel in graph.relationships:
            if rel.from_ == entity_id:
                visited.add(rel.to)
            elif rel.to == entity_id:
                visited.add(rel.from_)

        ctx.deps.graph_state.highlighted_nodes = list(visited)
        ctx.deps.graph_state.node_colors = {entity_id: "#3b82f6"}

        return {"connected_count": len(visited) - 1}

    @agent.tool
    async def filter_by_type(
        ctx: RunContext[AgentDependencies], domain: str, entity_type: str
    ) -> dict:
        """Filter by entity type."""
        assert ctx.deps.domains is not None, "Domains must be loaded"
        assert entity_type is not None, "Entity type must not be None"

        if domain not in ctx.deps.domains:
            return {"error": f"Domain {domain} not found"}

        _, graph = ctx.deps.domains[domain]
        if not graph:
            return {"error": "No graph data"}

        filtered = [e.id for e in graph.entities if e.type == entity_type]
        ctx.deps.graph_state.visible_nodes = filtered
        ctx.deps.graph_state.filter_type = entity_type

        return {"type": entity_type, "count": len(filtered)}


def _calculate_max_depth(children: dict, roots: list) -> int:
    """Calculate maximum depth of hierarchy using BFS."""
    assert children is not None, "Children dict must not be None"
    assert roots is not None, "Roots list must not be None"

    max_depth = 0
    for root in roots:
        queue = [(root, 1)]
        visited = {root}
        while queue:
            node_id, depth = queue.pop(0)
            max_depth = max(max_depth, depth)
            if node_id in children:
                for child in children[node_id]:
                    if child not in visited:
                        visited.add(child)
                        queue.append((child, depth + 1))
    return max_depth


def _build_owl_ontology(graph: OntologyGraph) -> tuple | None:
    """Build owlready2 ontology from graph. Returns (onto, class_map) or None."""
    assert owlready2 is not None, "owlready2 must be available"
    assert graph is not None, "Graph must not be None"

    try:
        onto = owlready2.get_ontology("http://temp.org/onto.owl")
        class_map = {}

        with onto:
            # Create classes for entity types (limit for performance)
            for entity in graph.entities[:100]:
                clean_name = entity.id.replace(" ", "_").replace("-", "_")
                clean_name = "".join(c for c in clean_name if c.isalnum() or c == "_")
                if clean_name and clean_name[0].isdigit():
                    clean_name = "C_" + clean_name

                try:
                    cls = owlready2.types.new_class(clean_name, (owlready2.Thing,))
                    class_map[entity.id] = cls
                except Exception:
                    continue

            # Create relationships (limit for performance)
            for rel in graph.relationships[:200]:
                if rel.from_ in class_map and rel.to in class_map:
                    from_cls = class_map[rel.from_]
                    to_cls = class_map[rel.to]
                    if rel.type in ["subClassOf", "is_a", "type_of"]:
                        from_cls.is_a.append(to_cls)

        return onto, class_map
    except Exception:
        return None


def _add_hierarchy_analysis(agent: Agent[AgentDependencies, str]) -> None:
    """Add hierarchy analysis tool."""
    assert agent is not None, "Agent must not be None"
    assert hasattr(agent, "tool"), "Agent must have tool decorator"

    @agent.tool
    async def analyze_hierarchy(ctx: RunContext[AgentDependencies], domain: str) -> dict:
        """Analyze the class hierarchy structure - find roots, leaves, depth."""
        assert ctx.deps.domains is not None, "Domains must be loaded"
        assert domain is not None, "Domain must not be None"

        if domain not in ctx.deps.domains:
            return {"error": f"Domain {domain} not found"}

        _, graph = ctx.deps.domains[domain]
        if not graph:
            return {"error": "No graph data"}

        # Build parent-child relationships
        children = defaultdict(set)
        parents = defaultdict(set)

        for rel in graph.relationships:
            if rel.type in ["subClassOf", "is_a", "type_of"]:
                children[rel.from_].add(rel.to)
                parents[rel.to].add(rel.from_)

        # Find roots (no parents) and leaves (no children)
        all_entities = {e.id for e in graph.entities}
        roots = [e.id for e in graph.entities if e.id not in parents or len(parents[e.id]) == 0]
        leaves = [e.id for e in graph.entities if e.id not in children or len(children[e.id]) == 0]

        # Calculate max depth
        max_depth = _calculate_max_depth(children, roots)

        return {
            "roots": roots[:10],
            "leaves": leaves[:10],
            "root_count": len(roots),
            "leaf_count": len(leaves),
            "max_depth": max_depth,
            "total_entities": len(all_entities),
        }


def _add_disconnected_tool(agent: Agent[AgentDependencies, str]) -> None:
    """Add find_disconnected tool."""
    assert agent is not None, "Agent must not be None"
    assert hasattr(agent, "tool"), "Agent must have tool decorator"

    @agent.tool
    async def find_disconnected(ctx: RunContext[AgentDependencies], domain: str) -> dict:
        """Find disconnected or isolated entities with no relationships."""
        assert ctx.deps.domains is not None, "Domains must be loaded"
        assert domain is not None, "Domain must not be None"

        if domain not in ctx.deps.domains:
            return {"error": f"Domain {domain} not found"}

        _, graph = ctx.deps.domains[domain]
        if not graph:
            return {"error": "No graph data"}

        # Find entities with relationships
        connected = set()
        for rel in graph.relationships:
            connected.add(rel.from_)
            connected.add(rel.to)

        # Find disconnected entities
        all_entities = {e.id: e.label for e in graph.entities}
        disconnected = [
            {"id": eid, "label": label}
            for eid, label in all_entities.items()
            if eid not in connected
        ]

        return {"disconnected": disconnected[:20], "count": len(disconnected)}


def _add_connectivity_tool(agent: Agent[AgentDependencies, str]) -> None:
    """Add analyze_connectivity tool."""
    assert agent is not None, "Agent must not be None"
    assert hasattr(agent, "tool"), "Agent must have tool decorator"

    @agent.tool
    async def analyze_connectivity(
        ctx: RunContext[AgentDependencies], domain: str, entity_id: str
    ) -> dict:
        """Analyze connectivity patterns for a specific entity."""
        assert ctx.deps.domains is not None, "Domains must be loaded"
        assert entity_id is not None, "Entity ID must not be None"

        if domain not in ctx.deps.domains:
            return {"error": f"Domain {domain} not found"}

        _, graph = ctx.deps.domains[domain]
        if not graph:
            return {"error": "No graph data"}

        entity = next((e for e in graph.entities if e.id == entity_id), None)
        if not entity:
            return {"error": f"Entity {entity_id} not found"}

        # Count relationship types
        incoming = defaultdict(list)
        outgoing = defaultdict(list)

        for rel in graph.relationships:
            if rel.from_ == entity_id:
                outgoing[rel.type].append(rel.to)
            elif rel.to == entity_id:
                incoming[rel.type].append(rel.from_)

        return {
            "entity": entity.label,
            "incoming": {k: len(v) for k, v in incoming.items()},
            "outgoing": {k: len(v) for k, v in outgoing.items()},
            "total_connections": sum(len(v) for v in incoming.values())
            + sum(len(v) for v in outgoing.values()),
        }


def _add_hubs_tool(agent: Agent[AgentDependencies, str]) -> None:
    """Add find_hubs tool."""
    assert agent is not None, "Agent must not be None"
    assert hasattr(agent, "tool"), "Agent must have tool decorator"

    @agent.tool
    async def find_hubs(ctx: RunContext[AgentDependencies], domain: str, top_n: int = 10) -> dict:
        """Find the most connected entities (hub nodes) in the graph."""
        assert ctx.deps.domains is not None, "Domains must be loaded"
        assert domain is not None, "Domain must not be None"

        if domain not in ctx.deps.domains:
            return {"error": f"Domain {domain} not found"}

        _, graph = ctx.deps.domains[domain]
        if not graph:
            return {"error": "No graph data"}

        # Count connections per entity
        connections = defaultdict(int)
        for rel in graph.relationships:
            connections[rel.from_] += 1
            connections[rel.to] += 1

        # Get entity labels
        entity_labels = {e.id: e.label for e in graph.entities}

        # Sort by connection count
        hubs = sorted(connections.items(), key=lambda x: x[1], reverse=True)[:top_n]

        result = [
            {"id": eid, "label": entity_labels.get(eid, eid), "connections": count}
            for eid, count in hubs
        ]

        # Highlight hub nodes
        if result:
            ctx.deps.graph_state.highlighted_nodes = [h["id"] for h in result]
            ctx.deps.graph_state.node_colors = {h["id"]: "#f59e0b" for h in result}

        return {"hubs": result, "count": len(result)}


def _add_infer_tool(agent: Agent[AgentDependencies, str]) -> None:
    """Add infer_relationships tool."""
    assert agent is not None, "Agent must not be None"
    assert hasattr(agent, "tool"), "Agent must have tool decorator"

    @agent.tool
    async def infer_relationships(ctx: RunContext[AgentDependencies], domain: str) -> dict:
        """Use OWL reasoning (owlready2+Pellet) to infer implicit relationships."""
        assert ctx.deps.domains is not None, "Domains must be loaded"
        assert domain is not None, "Domain must not be None"

        if owlready2 is None:
            return {"error": "owlready2 not available"}

        if domain not in ctx.deps.domains:
            return {"error": f"Domain {domain} not found"}

        _, graph = ctx.deps.domains[domain]
        if not graph:
            return {"error": "No graph data"}

        try:
            result = _build_owl_ontology(graph)
            if result is None:
                return {"error": "Failed to build OWL ontology"}

            _onto, class_map = result

            # Run Pellet reasoner for inference
            owlready2.sync_reasoner_pellet(
                infer_property_values=True, infer_data_property_values=False
            )

            # Extract inferred relationships
            inferred = []
            for entity_id, cls in list(class_map.items())[:20]:
                ancestors = [c.name for c in cls.ancestors() if c.name not in (cls.name, "Thing")]
                if ancestors:
                    inferred.append({"entity": entity_id, "inferred_supertypes": ancestors[:5]})

            return {
                "inferred_count": len(inferred),
                "sample_inferences": inferred[:10],
                "message": "Reasoning complete - found implicit relationships",
            }

        except Exception as e:
            return {"error": f"Reasoning failed: {str(e)[:100]}"}


def _add_consistency_tool(agent: Agent[AgentDependencies, str]) -> None:
    """Add check_consistency tool."""
    assert agent is not None, "Agent must not be None"
    assert hasattr(agent, "tool"), "Agent must have tool decorator"

    @agent.tool
    async def check_consistency(ctx: RunContext[AgentDependencies], domain: str) -> dict:
        """Check ontology consistency using owlready2+Pellet reasoner."""
        assert ctx.deps.domains is not None, "Domains must be loaded"
        assert domain is not None, "Domain must not be None"

        # Validation
        errors = []
        if owlready2 is None:
            errors.append("owlready2 not available")
        elif domain not in ctx.deps.domains:
            errors.append(f"Domain {domain} not found")
        elif not ctx.deps.domains[domain][1]:
            errors.append("No graph data")

        if errors:
            return {"error": errors[0]}

        _, graph = ctx.deps.domains[domain]

        try:
            result = _build_owl_ontology(graph)
            if result is None:
                return {"error": "Failed to build OWL ontology"}

            onto, _class_map = result
            owlready2.sync_reasoner_pellet(infer_property_values=False)
            inconsistencies = list(onto.inconsistent_classes())

            # Return consistent or inconsistent result
            return {
                "consistent": len(inconsistencies) == 0,
                "inconsistent_classes": [c.name for c in inconsistencies[:10]]
                if inconsistencies
                else [],
                "count": len(inconsistencies),
                "message": "Ontology is logically consistent" if not inconsistencies else None,
            }

        except owlready2.OwlReadyInconsistentOntologyError:
            return {"consistent": False, "message": "Ontology contains logical inconsistencies"}
        except Exception as e:
            return {"error": f"Consistency check failed: {str(e)[:100]}"}


def _add_equivalence_tool(agent: Agent[AgentDependencies, str]) -> None:
    """Add find_equivalent_classes tool."""
    assert agent is not None, "Agent must not be None"
    assert hasattr(agent, "tool"), "Agent must have tool decorator"

    @agent.tool
    async def find_equivalent_classes(ctx: RunContext[AgentDependencies], domain: str) -> dict:
        """Find potentially equivalent classes using OWL reasoning."""
        assert ctx.deps.domains is not None, "Domains must be loaded"
        assert domain is not None, "Domain must not be None"

        if owlready2 is None:
            return {"error": "owlready2 not available"}

        if domain not in ctx.deps.domains:
            return {"error": f"Domain {domain} not found"}

        _, graph = ctx.deps.domains[domain]
        if not graph:
            return {"error": "No graph data"}

        # Find classes with same set of parents
        parent_sets = defaultdict(list)
        for entity in graph.entities:
            parents = tuple(sorted(rel.to for rel in graph.relationships if rel.from_ == entity.id))
            if parents:
                parent_sets[parents].append(entity.id)

        # Find potential equivalents
        equivalents = [
            {"classes": ids, "count": len(ids)} for ids in parent_sets.values() if len(ids) > 1
        ]

        return {
            "equivalent_groups": equivalents[:10],
            "total_groups": len(equivalents),
            "message": f"Found {len(equivalents)} groups of potentially equivalent classes",
        }
