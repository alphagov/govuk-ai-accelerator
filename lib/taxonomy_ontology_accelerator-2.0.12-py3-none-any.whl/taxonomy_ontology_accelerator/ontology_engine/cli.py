"""
CLI commands for ontology engine.

This module contains CLI command definitions for the ontology engine.
All helper functions are in cli_helpers.py.
"""

from pathlib import Path

import typer
from rich.console import Console

from taxonomy_ontology_accelerator.commons.cli_completion import (
    complete_domain,
)
from taxonomy_ontology_accelerator.commons.utils.logger import get_logger
from taxonomy_ontology_accelerator.ontology_engine.cli_helpers import OntologyCLIHelpers

logger = get_logger()

__version__ = "0.1.0"
_MIN_VERSION_PARTS = 2  # Semantic versioning requires at least major.minor

app = typer.Typer(
    help=(
        "AI-powered ontology engine - Extract knowledge graphs from text. "
        "Build semantic networks with entities, relationships, and properties."
    ),
    no_args_is_help=False,
    invoke_without_command=True,
    context_settings={"help_option_names": ["--help", "-h"]},
    rich_markup_mode=None,
    epilog="""
EXAMPLES:

  toa extract --domain travel                           # Extract entities
  toa export --domain travel --format turtle            # Export to OWL
  toa info --domain travel                              # Show statistics
  toa visualize --domain travel                         # View in browser

Run 'toa COMMAND --help' for detailed options.
""",
)
console = Console()


def version_callback(value: bool):
    """Print version and exit."""
    assert __version__, "Version string must not be empty"
    assert len(__version__.split(".")) >= _MIN_VERSION_PARTS, (
        "Version must have at least major.minor format"
    )

    if value:
        console.print(f"ontology version {__version__}")
        raise typer.Exit()


@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    _version: bool = typer.Option(
        False,
        "--version",
        "-V",
        help="Show version and exit",
        callback=version_callback,
        is_eager=True,
    ),
):
    """
    AI-powered ontology engine - Extract knowledge graphs from unstructured text.

    Build semantic networks with entities, relationships, and properties
    for knowledge management, semantic search, and data integration.

    EXAMPLES:

    Extract ontology from a file:
      toa extract --domain travel

    Export existing ontology to OWL format:
      toa export --domain travel --format turtle

    Show ontology info:
      toa info --domain travel

    Visualize ontology in browser:
      toa visualize --domain travel

    Run 'toa COMMAND --help' for detailed options.
    """
    assert app.registered_commands, "At least one command must be registered"
    assert console is not None, "Console must be initialized"

    # Show help if no subcommand provided
    if ctx.invoked_subcommand is None:
        console.print(ctx.get_help())
        raise typer.Exit(0)


# =============================================================================
# CLI COMMANDS
# =============================================================================


def _validate_and_sanitize_domain(ctx: typer.Context, domain: str | None) -> str:
    """Validate and sanitize domain parameter."""
    assert ctx is not None, "Context must be provided"
    assert domain is None or isinstance(domain, str), "domain must be string or None"

    if domain is None:
        console.print(ctx.get_help())
        raise typer.Exit(0)

    from taxonomy_ontology_accelerator.ontology_engine.utils.domain_resolver import (
        sanitize_domain_name,
    )

    try:
        return sanitize_domain_name(domain.strip())
    except ValueError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(1) from e


def _handle_deprecated_config_param(config: Path | None, domain: str) -> None:
    """Handle deprecated --config parameter."""
    assert domain is not None, "Domain must not be None"
    assert isinstance(domain, str), "Domain must be a string"

    if config:
        logger.warning(
            f"--config parameter is deprecated and ignored. "
            f"Use domain-specific config at: domains/{domain}/config.yaml"
        )


@app.command()
def extract(
    ctx: typer.Context,
    domain: str | None = typer.Option(
        None,
        "--domain",
        help="Domain name (required)",
        autocompletion=complete_domain,
    ),
    config: Path | None = typer.Option(
        None, "--config", help="Path to config file (overrides default)"
    ),
    resume: bool = typer.Option(
        True,
        "--resume/--no-resume",
        help="Resume from checkpoint if available (default: yes)",
    ),
    continue_run: int | None = typer.Option(
        None,
        "--continue",
        help="Continue from an existing run number (reuses that run checkpoints)",
    ),
):
    """
    Extract ontology from input text using AI.

    Uses convention-based configuration:
    - Input files: {domain}/input/ folder
    - Prompt: {domain}/prompts/prompt.txt
    - Output: output/ontology/{domain}/
    - Config: {domain}/config.yaml (optional overrides)

    All paths can be overridden in {domain}/config.yaml.

    EXAMPLES:

    toa extract --domain travel              # Basic
    toa extract --domain healthcare          # Different domain
    toa extract --config custom.yaml         # Custom config
    toa extract --domain travel --no-resume  # Start fresh
    """
    assert ctx is not None, "Context must be provided"
    assert isinstance(resume, bool), "resume must be a boolean"
    assert continue_run is None or continue_run > 0, "--continue must be a positive integer"

    domain = _validate_and_sanitize_domain(ctx, domain)
    _handle_deprecated_config_param(config, domain)
    OntologyCLIHelpers.run_extraction(domain=domain, resume=resume, continue_run=continue_run)


@app.command()
def export(
    ctx: typer.Context,
    domain: str | None = typer.Option(
        None, "--domain", help="Domain name (required)", autocompletion=complete_domain
    ),
    output_dir: Path | None = typer.Option(None, "--output", help="Output directory"),
    export_format: str = typer.Option("turtle", "--format", help="Format: 'turtle' or 'xml'"),
    schema_file: Path | None = typer.Option(None, "--schema", help="Path to schema.json"),
    graph_file: Path | None = typer.Option(None, "--graph", help="Path to graph.json"),
):
    """
    Export ontology to OWL/RDF format for Protégé, GraphDB, etc.

    EXAMPLES:

    toa export --domain travel
    toa export --domain travel --format xml --output ./exports/
    """
    # Show help when no domain is provided
    if domain is None:
        console.print(ctx.get_help())
        raise typer.Exit(0)

    assert domain is not None, "Domain must be provided"
    assert export_format in ("turtle", "xml"), "Format must be 'turtle' or 'xml'"

    # Map 'xml' to 'rdfxml' for the exporter
    actual_format = "rdfxml" if export_format == "xml" else export_format
    _run_export(domain, output_dir, actual_format, schema_file, graph_file)


def _run_export(
    domain: str,
    output_dir: Path | None,
    export_format: str,
    schema_file: Path | None,
    graph_file: Path | None,
) -> None:
    """Execute the ontology export."""
    assert domain, "Domain must not be empty"
    assert export_format in ("turtle", "rdfxml"), "Invalid export format (internal)"

    from taxonomy_ontology_accelerator.ontology_engine.utils.domain_resolver import (
        sanitize_domain_name,
    )

    try:
        domain = sanitize_domain_name(domain.strip())
    except ValueError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(1) from e

    OntologyCLIHelpers.run_export(
        domain=domain,
        output_dir=output_dir,
        export_format=export_format,
        schema_file=schema_file,
        graph_file=graph_file,
    )


@app.command()
def verify_alignment(
    ctx: typer.Context,
    domain: str | None = typer.Option(
        None, "--domain", help="Domain name", autocompletion=complete_domain
    ),
    output_dir: Path | None = typer.Option(
        None, "--output", help="Output directory containing graph.json and ontology.ttl"
    ),
    graph_file: Path | None = typer.Option(
        None, "--graph", help="Path to graph.json (overrides domain resolution)"
    ),
    ontology_file: Path | None = typer.Option(
        None, "--ontology", help="Path to ontology.ttl (overrides domain resolution)"
    ),
    output_format: str = typer.Option(
        "text", "--format", help="Output format: 'text' or 'json'"
    ),
):
    """Verify graph.json and ontology.ttl present the same entities, properties and aliases."""
    if domain is None and output_dir is None and graph_file is None:
        console.print(ctx.get_help())
        raise typer.Exit(0)
    OntologyCLIHelpers.run_verify_alignment(
        domain, output_dir, output_format, graph_file, ontology_file
    )


@app.command()
def info(
    ctx: typer.Context,
    domain: str | None = typer.Option(
        None,
        "--domain",
        help="Domain name (required)",
        autocompletion=complete_domain,
    ),
    output_dir: Path | None = typer.Option(
        None, "--output", help="Output directory containing ontology files"
    ),
):
    """
    Show information about an extracted ontology.

    Displays statistics about entities, relationships, and schema types
    in the specified domain's ontology.

    EXAMPLES:

    toa info --domain travel                              # Show stats
    toa info --domain healthcare --output ./custom/output/
    """
    # Show help when no domain is provided
    if domain is None:
        console.print(ctx.get_help())
        raise typer.Exit(0)

    assert domain is not None, "Domain must be provided"
    assert isinstance(domain, str), "domain must be a string"

    # Sanitize and validate domain
    from taxonomy_ontology_accelerator.ontology_engine.utils.domain_resolver import (
        sanitize_domain_name,
    )

    try:
        domain = sanitize_domain_name(domain.strip())
    except ValueError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(1) from e

    OntologyCLIHelpers.show_info(domain=domain, output_dir=output_dir)


@app.command()
def research(
    ctx: typer.Context,
    domain: str | None = typer.Option(
        None, "--domain", "-d", help="Domain name (required)", autocompletion=complete_domain
    ),
    output_dir: Path | None = typer.Option(
        None, "--output", "-o", help="Output directory (default: {domain}/input/)"
    ),
    num_queries: int | None = typer.Option(
        None, "--num-queries", "-n", help="Number of search queries (overrides config)"
    ),
):
    """
    Research domain using web search to gather content for ontology construction.

    Output: {domain}/input/ (or --output). Config: {domain}/config.yaml.
    Prompt: {domain}/prompts/research_prompt.txt (optional).

    EXAMPLES:

    toa research --domain healthcare
    toa research --domain travel --num-queries 10
    """
    assert ctx is not None, "Context must be provided"
    assert console is not None, "Console must be initialized"
    _execute_research_command(ctx, domain, output_dir, num_queries)


def _execute_research_command(
    ctx: typer.Context,
    domain: str | None,
    output_dir: Path | None,
    num_queries: int | None,
) -> None:
    """Execute research command logic."""
    # Show help when no domain is provided
    if domain is None:
        console.print(ctx.get_help())
        raise typer.Exit(0)

    assert domain is not None, "Domain must be provided"
    assert isinstance(domain, str), "domain must be a string"

    # Sanitize and validate domain
    from taxonomy_ontology_accelerator.ontology_engine.utils.domain_resolver import (
        sanitize_domain_name,
    )

    try:
        domain = sanitize_domain_name(domain.strip())
    except ValueError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(1) from e

    OntologyCLIHelpers.run_research(
        domain=domain,
        output_dir=output_dir,
        num_queries=num_queries,
    )


@app.command()
def visualize(
    ctx: typer.Context,
    domain: str | None = typer.Option(
        None,
        "--domain",
        "-d",
        help="Domain name (required)",
        autocompletion=complete_domain,
    ),
    output_dir: Path | None = typer.Option(
        None, "--output", "-o", help="Output directory containing ontology files"
    ),
    port: int = typer.Option(8080, "--port", "-p", help="Port for local server (default: 8080)"),
    export: Path | None = typer.Option(
        None, "--export", "-e", help="Export standalone HTML file instead of serving"
    ),
    no_open: bool = typer.Option(False, "--no-open", help="Don't automatically open browser"),
):
    """
    Visualize ontology graph in an interactive browser interface.

    By default, starts a local HTTP server and opens the visualization in your
    browser. Use --export to generate a standalone HTML file instead.

    EXAMPLES:

    toa visualize --domain travel                    # Start server
    toa visualize --domain travel --port 9000        # Custom port
    toa visualize --domain travel --export ./viz.html # Export HTML
    toa visualize --domain travel --no-open          # Don't open browser
    """
    # Show help when no domain is provided
    if domain is None:
        console.print(ctx.get_help())
        raise typer.Exit(0)

    assert domain is not None, "Domain must be provided"
    assert isinstance(domain, str), "domain must be a string"

    # Sanitize and validate domain
    from taxonomy_ontology_accelerator.ontology_engine.utils.domain_resolver import (
        sanitize_domain_name,
    )

    try:
        domain = sanitize_domain_name(domain.strip())
    except ValueError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(1) from e

    OntologyCLIHelpers.run_visualization(
        domain=domain,
        output_dir=output_dir,
        port=port,
        export_path=export,
        open_browser=not no_open,
    )
