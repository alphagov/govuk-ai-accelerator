"""
CLI helper utilities for ontology engine.

This module contains helper functions for CLI commands:
- Extraction helpers
- Export helpers
- Display helpers
- Visualization helpers
"""

import asyncio
import contextlib
import csv
import io
import json
import os
import socket
import threading
import webbrowser
from dataclasses import dataclass
from datetime import UTC, datetime
from decimal import ROUND_HALF_UP, Decimal
from functools import lru_cache
from http.server import HTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from typing import Any

import fsspec
import typer
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table

from taxonomy_ontology_accelerator.commons.io.file_utils import join_path, safe_write_file
from taxonomy_ontology_accelerator.commons.io.fsspec_utils import (
    get_filesystem_from_config,
)
from taxonomy_ontology_accelerator.ontology_engine.alignment import (
    ALIGNMENT_REPORT_FILENAME,
    align_files,
    format_report,
    report_to_dict,
)
from taxonomy_ontology_accelerator.ontology_engine.config.config import (
    OntologyConfig,
    OntologyConfigLoader,
)
from taxonomy_ontology_accelerator.ontology_engine.core.extractor import extract_ontology
from taxonomy_ontology_accelerator.ontology_engine.core.models import (
    OntologyGraph,
    OntologyOutput,
    OntologySchema,
    ProcessingMetadata,
)
from taxonomy_ontology_accelerator.ontology_engine.storage.export import (
    export_to_owl_rdf_from_files,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.run_artifacts import (
    allocate_run_output_dir,
    build_next_run_name,
    capture_run_logs,
    capture_run_logs_to_stream,
    extract_run_sequence,
    get_current_commit_hash,
    prepare_run_snapshot,
)

console = Console()

# Constants for display formatting
# Constants for display formatting
FIELDS_PREVIEW_COUNT = 3


# Constants for visualization
MAX_PORT_ATTEMPTS = 10

TOKENS_PER_MILLION = 1_000_000
AWS_BEDROCK_PRICING_SOURCE_URL = "https://aws.amazon.com/bedrock/pricing/"
AWS_BEDROCK_PRICING_REVIEWED_DATE = "2026-06-19"
AWS_PRICE_LIST_BULK_OFFER_CODES = (
    "AmazonBedrock",
    "AmazonBedrockFoundationModels",
)
AWS_PRICE_LIST_BULK_TIMEOUT_SECONDS = 5


@dataclass(frozen=True)
class BedrockModelPricing:
    """USD token rates per 1M tokens for a Bedrock model."""

    input_usd_per_million: float
    output_usd_per_million: float
    cache_read_usd_per_million: float | None = None
    cache_write_usd_per_million: float | None = None
    source: str = "aws_published_fallback"


@dataclass(frozen=True)
class BedrockCostEstimate:
    """A Bedrock cost estimate and the price source used to compute it."""

    cost: float
    pricing_source: str


def _anthropic_pricing(input_rate: float, output_rate: float) -> BedrockModelPricing:
    return BedrockModelPricing(
        input_usd_per_million=input_rate,
        output_usd_per_million=output_rate,
        cache_read_usd_per_million=input_rate * 0.10,
        cache_write_usd_per_million=input_rate * 1.25,
    )


# AWS-published Bedrock on-demand rates. Source: AWS Bedrock pricing page.
# Reviewed: 2026-06-19.
AWS_PUBLISHED_BEDROCK_PRICING_USD_PER_MILLION: dict[str, BedrockModelPricing] = {
    "anthropic.claude-3-haiku-20240307-v1:0": _anthropic_pricing(0.25, 1.25),
    "anthropic.claude-3-sonnet-20240229-v1:0": _anthropic_pricing(3.00, 15.00),
    "anthropic.claude-3-opus-20240229-v1:0": _anthropic_pricing(15.00, 75.00),
    "anthropic.claude-3-5-haiku-20241022-v1:0": _anthropic_pricing(0.80, 4.00),
    "anthropic.claude-3-5-sonnet-20240620-v1:0": _anthropic_pricing(3.00, 15.00),
    "anthropic.claude-3-5-sonnet-20241022-v2:0": _anthropic_pricing(3.00, 15.00),
    "anthropic.claude-3-7-sonnet-20250219-v1:0": _anthropic_pricing(3.00, 15.00),
    "anthropic.claude-sonnet-4-20250514-v1:0": _anthropic_pricing(3.00, 15.00),
    "anthropic.claude-sonnet-4-6": _anthropic_pricing(3.00, 15.00),
    "eu.anthropic.claude-sonnet-4-6": _anthropic_pricing(3.30, 16.50),
    "amazon.nova-micro-v1:0": BedrockModelPricing(0.035, 0.14),
    "amazon.nova-lite-v1:0": BedrockModelPricing(0.06, 0.24),
    "amazon.nova-pro-v1:0": BedrockModelPricing(0.80, 3.20),
    "amazon.titan-embed-text-v1": BedrockModelPricing(0.10, 0.00),
    "amazon.titan-embed-text-v2:0": BedrockModelPricing(0.10, 0.00),
    "amazon.titan-text-lite-v1": BedrockModelPricing(0.30, 0.40),
    "amazon.titan-text-express-v1": BedrockModelPricing(1.30, 1.70),
    "amazon.titan-text-premier-v1:0": BedrockModelPricing(0.50, 1.50),
    "cohere.embed-english-v3": BedrockModelPricing(0.10, 0.00),
    "cohere.embed-multilingual-v3": BedrockModelPricing(0.10, 0.00),
    "meta.llama3-8b-instruct-v1:0": BedrockModelPricing(0.30, 0.60),
    "meta.llama3-70b-instruct-v1:0": BedrockModelPricing(2.65, 3.50),
    "meta.llama3-1-8b-instruct-v1:0": BedrockModelPricing(0.22, 0.22),
    "meta.llama3-1-70b-instruct-v1:0": BedrockModelPricing(0.72, 0.72),
    "meta.llama3-1-405b-instruct-v1:0": BedrockModelPricing(2.40, 2.40),
    "meta.llama3-3-70b-instruct-v1:0": BedrockModelPricing(0.72, 0.72),
    "mistral.mistral-large-2402-v1:0": BedrockModelPricing(0.50, 1.50),
}
ROUGH_BEDROCK_LLM_PRICING_USD_PER_MILLION = BedrockModelPricing(
    3.00,
    15.00,
    source="rough_estimate",
)
ROUGH_BEDROCK_EMBEDDING_PRICING_USD_PER_MILLION = BedrockModelPricing(
    0.10,
    0.00,
    source="rough_estimate",
)
BEDROCK_COSTS_CSV_HEADER = [
    "status",
    "run_tag",
    "usage_tag",
    "model_id",
    "input_tokens",
    "output_tokens",
    "cache_read_tokens",
    "cache_write_tokens",
    "estimated_cost_usd",
    "estimated_cost_text",
    "start_time_utc",
    "end_time_utc",
    "error_code",
    "error_message",
]


def _strip_model_provider_prefix(model_ref: str | None) -> str:
    """Remove provider prefix from a configured model reference."""
    if not model_ref:
        return ""
    return model_ref.split(":", 1)[1] if ":" in model_ref else model_ref


def _base_bedrock_model_id(model_id: str) -> str:
    """Remove regional Bedrock prefixes for fallback pricing lookups."""
    base_model_id = model_id
    for prefix in ("eu.", "us.", "ap.", "global."):
        if base_model_id.startswith(prefix):
            return base_model_id[len(prefix) :]
    return base_model_id


def _usage_totals(source: Any, prefix: str = "") -> dict[str, int]:
    """Read token totals from metadata or state objects using a common shape."""
    return {
        "input_tokens": int(getattr(source, f"{prefix}input_tokens", 0) or 0),
        "output_tokens": int(getattr(source, f"{prefix}output_tokens", 0) or 0),
        "cache_read_tokens": int(getattr(source, f"{prefix}cache_read_tokens", 0) or 0),
        "cache_write_tokens": int(getattr(source, f"{prefix}cache_write_tokens", 0) or 0),
    }


def _usage_token_sum(usage: dict[str, int]) -> int:
    """Return the total tracked tokens for a usage row."""
    return sum(usage.values())


def _format_cost(cost: float) -> tuple[str, str]:
    """Format a numeric USD cost for CSV output."""
    rounded_cost = Decimal(str(cost)).quantize(Decimal("0.000001"), rounding=ROUND_HALF_UP)
    cost_text = f"{rounded_cost:.6f}"
    return cost_text, f"${cost_text}"


def _estimate_bedrock_usage_cost(
    model_id: str,
    usage: dict[str, int],
    *,
    usage_tag: str,
) -> BedrockCostEstimate:
    """Estimate cost for a Bedrock usage snapshot using AWS pricing sources."""
    if _usage_token_sum(usage) == 0:
        return BedrockCostEstimate(0.0, "none")

    pricing = _resolve_bedrock_model_pricing(model_id)
    if pricing is None:
        pricing = (
            ROUGH_BEDROCK_EMBEDDING_PRICING_USD_PER_MILLION
            if usage_tag == "embedding"
            else ROUGH_BEDROCK_LLM_PRICING_USD_PER_MILLION
        )

    return BedrockCostEstimate(
        _calculate_bedrock_cost_from_pricing(usage, pricing),
        pricing.source,
    )


def _calculate_bedrock_cost_from_pricing(
    usage: dict[str, int],
    pricing: BedrockModelPricing,
) -> float:
    """Calculate token cost from AWS per-million rates."""
    cache_read_tokens = usage["cache_read_tokens"]
    cache_write_tokens = usage["cache_write_tokens"]
    regular_input_tokens = max(
        0,
        usage["input_tokens"] - cache_read_tokens - cache_write_tokens,
    )
    cache_read_rate = pricing.cache_read_usd_per_million
    cache_write_rate = pricing.cache_write_usd_per_million
    if cache_read_rate is None:
        cache_read_rate = pricing.input_usd_per_million
    if cache_write_rate is None:
        cache_write_rate = pricing.input_usd_per_million

    return (
        (regular_input_tokens / TOKENS_PER_MILLION * pricing.input_usd_per_million)
        + (usage["output_tokens"] / TOKENS_PER_MILLION * pricing.output_usd_per_million)
        + (cache_read_tokens / TOKENS_PER_MILLION * cache_read_rate)
        + (cache_write_tokens / TOKENS_PER_MILLION * cache_write_rate)
    )


def _resolve_bedrock_model_pricing(model_id: str) -> BedrockModelPricing | None:
    """Resolve model pricing from AWS Price List, then the AWS-published fallback table."""
    if not model_id:
        return None

    aws_pricing = _resolve_bedrock_model_pricing_from_aws_price_list(model_id)
    if aws_pricing is not None:
        return aws_pricing

    aws_bulk_pricing = _resolve_bedrock_model_pricing_from_aws_price_list_bulk(
        model_id,
        _aws_price_list_region_code(),
    )
    if aws_bulk_pricing is not None:
        return aws_bulk_pricing

    for key in _bedrock_pricing_lookup_keys(model_id):
        pricing = AWS_PUBLISHED_BEDROCK_PRICING_USD_PER_MILLION.get(key)
        if pricing is not None:
            return pricing
    return None


def _bedrock_pricing_lookup_keys(model_id: str) -> list[str]:
    base_model_id = _base_bedrock_model_id(model_id)
    keys = [model_id]
    if base_model_id != model_id:
        keys.append(base_model_id)
    return keys


@lru_cache(maxsize=128)
def _resolve_bedrock_model_pricing_from_aws_price_list(
    model_id: str,
) -> BedrockModelPricing | None:
    """Best-effort lookup through the AWS Price List Query API."""
    try:
        import boto3

        session = boto3.Session()
        if session.get_credentials() is None:
            return None
        client = session.client("pricing", region_name="us-east-1")
    except Exception:
        return None

    for service_code in ("AmazonBedrock", "Bedrock"):
        for field in ("model", "modelId", "modelName", "groupDescription"):
            try:
                response = client.get_products(
                    ServiceCode=service_code,
                    Filters=[
                        {
                            "Type": "CONTAINS",
                            "Field": field,
                            "Value": _base_bedrock_model_id(model_id),
                        }
                    ],
                    MaxResults=100,
                )
            except Exception:
                continue

            pricing = _pricing_from_aws_price_list_items(response.get("PriceList", []), model_id)
            if pricing is not None:
                return pricing
    return None


def _resolve_bedrock_model_pricing_from_aws_price_list_bulk(
    model_id: str,
    region_code: str,
) -> BedrockModelPricing | None:
    """Best-effort lookup through public AWS Price List Bulk offer files."""
    for offer_code in AWS_PRICE_LIST_BULK_OFFER_CODES:
        offer = _fetch_aws_price_list_bulk_offer(offer_code)
        pricing = _pricing_from_aws_price_list_bulk_offer(
            offer,
            model_id=model_id,
            region_code=region_code,
        )
        if pricing is not None:
            return pricing
    return None


@lru_cache(maxsize=4)
def _fetch_aws_price_list_bulk_offer(offer_code: str) -> dict[str, Any] | None:
    url = f"https://pricing.us-east-1.amazonaws.com/offers/v1.0/aws/{offer_code}/current/index.json"
    try:
        from urllib.request import Request, urlopen

        request = Request(url, headers={"User-Agent": "gds-accelerator-bedrock-costs/1.0"})
        with urlopen(request, timeout=AWS_PRICE_LIST_BULK_TIMEOUT_SECONDS) as response:
            return json.load(response)
    except Exception:
        return None


def _pricing_from_aws_price_list_bulk_offer(
    offer: dict[str, Any] | None,
    *,
    model_id: str,
    region_code: str,
) -> BedrockModelPricing | None:
    if not offer:
        return None

    products = offer.get("products", {})
    ondemand_terms = offer.get("terms", {}).get("OnDemand", {})
    region_matches: list[tuple[str, dict[str, Any]]] = []
    any_region_matches: list[tuple[str, dict[str, Any]]] = []

    for sku, product in products.items():
        if not isinstance(product, dict):
            continue
        attrs = product.get("attributes", {})
        if not _aws_bulk_product_matches_bedrock_model(attrs, model_id):
            continue
        any_region_matches.append((sku, product))
        if attrs.get("regionCode") == region_code:
            region_matches.append((sku, product))

    for matches in (region_matches, any_region_matches):
        pricing = _pricing_from_aws_bulk_matches(matches, ondemand_terms, model_id)
        if pricing is not None:
            return pricing
    return None


def _pricing_from_aws_bulk_matches(
    matches: list[tuple[str, dict[str, Any]]],
    ondemand_terms: dict[str, Any],
    model_id: str,
) -> BedrockModelPricing | None:
    rates: dict[str, tuple[int, float]] = {}
    for sku, _product in matches:
        for term in ondemand_terms.get(sku, {}).values():
            for dimension in term.get("priceDimensions", {}).values():
                role = _aws_bulk_price_dimension_role(dimension)
                if role is None:
                    continue
                rate = _price_dimension_usd_per_million(dimension)
                if rate is None:
                    continue
                score = _aws_bulk_price_dimension_scope_score(dimension, model_id)
                current = rates.get(role)
                if current is None or score < current[0]:
                    rates[role] = (score, rate)

    input_rate = rates.get("input", (0, None))[1]
    output_rate = rates.get("output", (0, None))[1]
    if input_rate is None:
        return None
    if output_rate is None:
        if _is_embedding_model_id(model_id):
            output_rate = 0.0
        else:
            return None

    return BedrockModelPricing(
        input_rate,
        output_rate,
        rates.get("cache_read", (0, None))[1],
        rates.get("cache_write", (0, None))[1],
        source="aws_price_list_bulk",
    )


def _aws_bulk_price_dimension_role(dimension: dict[str, Any]) -> str | None:
    description = str(dimension.get("description", "")).casefold()
    unit = str(dimension.get("unit", "")).casefold()
    combined = f"{description} {unit}"
    if "token" not in combined:
        return None
    if any(term in combined for term in ("batch", "reserved", "provisioned", " per hour", "tpm")):
        return None
    if "image" in combined:
        return None
    if "1 hour cache write" in combined or "1h" in combined:
        return None
    if "cache read" in combined or "cached input" in combined:
        return "cache_read"
    if "cache write" in combined:
        return "cache_write"
    if "output" in combined or "response" in combined:
        return "output"
    if "input" in combined:
        return "input"
    return None


def _aws_bulk_price_dimension_scope_score(dimension: dict[str, Any], model_id: str) -> int:
    description = str(dimension.get("description", "")).casefold()
    has_regional_cris = "regional cris" in description
    has_global = "global" in description
    regional_profile = model_id.startswith(("eu.", "us.", "ap."))
    global_profile = model_id.startswith("global.")

    if regional_profile:
        if has_regional_cris:
            return 0
        return 2 if has_global else 1
    if global_profile:
        return 0 if has_global else 1
    if has_global:
        return 0
    return 1 if has_regional_cris else 0


def _aws_bulk_product_matches_bedrock_model(attrs: dict[str, Any], model_id: str) -> bool:
    base_model_id = _base_bedrock_model_id(model_id).casefold()
    service_name = str(attrs.get("servicename", "")).casefold()
    provider = str(attrs.get("provider", "")).casefold()
    model_name = str(attrs.get("model", "")).casefold()
    titan_model = str(attrs.get("titanModel", "")).casefold()
    usage_type = str(attrs.get("usagetype", "")).casefold()
    searchable = f"{service_name} {provider} {model_name} {titan_model} {usage_type}"

    if base_model_id == "cohere.embed-multilingual-v3":
        return "cohere" in searchable and "embed" in searchable and "multilingual" in searchable
    if base_model_id == "cohere.embed-english-v3":
        return (
            "cohere" in searchable
            and "embed" in searchable
            and "english" in searchable
            and "multilingual" not in searchable
        )
    if base_model_id == "amazon.titan-embed-text-v2:0":
        return "titanembeddingv2-text" in searchable
    if base_model_id == "amazon.titan-embed-text-v1":
        return "titan" in searchable and "embedding" in searchable and "v2" not in searchable
    if base_model_id == "anthropic.claude-sonnet-4-6":
        return "claude sonnet 4.6" in searchable
    if base_model_id == "anthropic.claude-sonnet-4-20250514-v1:0":
        return "claude sonnet 4" in searchable and "4.6" not in searchable
    if base_model_id == "anthropic.claude-3-7-sonnet-20250219-v1:0":
        return "claude 3.7 sonnet" in searchable
    if "claude-3-5-sonnet" in base_model_id:
        return "claude 3.5 sonnet" in searchable
    return base_model_id.replace(".", " ").replace("-", " ").replace(":0", "") in searchable


def _aws_price_list_region_code() -> str:
    return os.environ.get("AWS_REGION") or os.environ.get("AWS_DEFAULT_REGION") or "us-east-1"


def _is_embedding_model_id(model_id: str) -> bool:
    return "embed" in _base_bedrock_model_id(model_id).casefold()


def _pricing_from_aws_price_list_items(
    items: list[Any],
    model_id: str,
) -> BedrockModelPricing | None:
    input_rate = None
    output_rate = None
    cache_read_rate = None
    cache_write_rate = None
    for item in items:
        try:
            product = json.loads(item) if isinstance(item, str) else item
        except (TypeError, json.JSONDecodeError):
            continue
        for term in product.get("terms", {}).get("OnDemand", {}).values():
            for dimension in term.get("priceDimensions", {}).values():
                rate = _price_dimension_usd_per_million(dimension)
                if rate is None:
                    continue
                description = str(dimension.get("description", "")).casefold()
                if "cache read" in description or "cached input" in description:
                    cache_read_rate = rate
                elif "cache write" in description:
                    cache_write_rate = rate
                elif "output" in description:
                    output_rate = rate
                elif "input" in description:
                    input_rate = rate
    if input_rate is None:
        return None
    if output_rate is None:
        if _is_embedding_model_id(model_id):
            output_rate = 0.0
        else:
            return None
    return BedrockModelPricing(
        input_rate,
        output_rate,
        cache_read_rate,
        cache_write_rate,
        source="aws_price_list",
    )


def _price_dimension_usd_per_million(dimension: dict[str, Any]) -> float | None:
    try:
        usd = float(dimension.get("pricePerUnit", {}).get("USD"))
    except (TypeError, ValueError):
        return None
    unit = str(dimension.get("unit", "")).casefold()
    description = str(dimension.get("description", "")).casefold()
    if "1m" in unit or "million" in unit or "1m" in description or "million" in description:
        return usd
    if "1k" in unit or "1,000" in unit or "1000" in unit or "1k" in description:
        return usd * 1000
    return usd * 1000


def _llm_calls_made(source: Any) -> int:
    return int(getattr(source, "llm_calls_made", getattr(source, "llm_calls", 0)) or 0)


def _estimated_llm_usage_totals(source: Any) -> dict[str, int]:
    return {
        "input_tokens": int(getattr(source, "estimated_llm_input_tokens", 0) or 0),
        "output_tokens": int(getattr(source, "estimated_llm_output_tokens", 0) or 0),
        "cache_read_tokens": 0,
        "cache_write_tokens": 0,
    }


def _combined_llm_usage_totals(
    source: Any,
    config: OntologyConfig,
) -> tuple[dict[str, int], bool, bool]:
    actual_usage = _usage_totals(source)
    estimated_usage = _estimated_llm_usage_totals(source)
    combined_usage = {
        key: actual_usage[key] + estimated_usage[key]
        for key in actual_usage
    }
    used_estimated_usage = _usage_token_sum(estimated_usage) > 0
    used_rough_missing_usage = False
    if _usage_token_sum(combined_usage) == 0 and _llm_calls_made(source) > 0:
        combined_usage = _rough_missing_llm_usage(source, config)
        used_estimated_usage = True
        used_rough_missing_usage = True
    return combined_usage, used_estimated_usage, used_rough_missing_usage


def _rough_missing_llm_usage(source: Any, config: OntologyConfig) -> dict[str, int]:
    llm_calls = max(1, _llm_calls_made(source))
    configured_input_budget = int(getattr(config.batching, "max_input_tokens", 0) or 0)
    if configured_input_budget <= 0:
        configured_input_budget = max(1, int(getattr(config.batching, "chunks_per_batch", 1) or 1)) * 1000
    input_tokens = llm_calls * configured_input_budget
    output_tokens = max(1, int(input_tokens * 0.25))
    max_output_tokens = int(getattr(config.llm, "max_tokens", 0) or 0)
    if max_output_tokens > 0:
        output_tokens = min(output_tokens, llm_calls * max_output_tokens)
    return {
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "cache_read_tokens": 0,
        "cache_write_tokens": 0,
    }


class OntologyCLIHelpers:
    """Helper class for ontology CLI operations."""

    # =========================================================================
    # PATH RESOLUTION
    # =========================================================================

    @staticmethod
    def _get_output_base_dir(domain: str, output_dir: Path | None = None) -> Path:
        """Get base output directory for a domain."""
        assert isinstance(domain, str), "Domain must be a string"
        assert output_dir is None or isinstance(output_dir, Path), "output_dir must be Path or None"

        if output_dir:
            return output_dir

        # Load config to get default output directory
        config = OntologyConfigLoader.load()
        base_dir = Path(config.output.base_directory)

        if domain:
            return base_dir / domain / "output"
        return base_dir

    @staticmethod
    def _resolve_ontology_files(
        domain: str,
        output_dir: Path | None,
        schema_file: Path | None,
        graph_file: Path | None,
    ) -> tuple[Path, Path]:
        """Resolve schema and graph file paths."""
        assert domain, "Domain must not be empty"
        assert isinstance(domain, str), "Domain must be a string"

        base_dir = OntologyCLIHelpers._get_output_base_dir(domain, output_dir)
        config = OntologyConfigLoader.load()

        # Resolve schema and graph paths (use provided or default from config)
        # Resolve schema and graph paths (use provided or default from config)
        schema_path = schema_file or base_dir / config.output.schema_filename
        graph_path = graph_file or base_dir / config.output.graph_filename

        # Validate files exist
        fs = fsspec.filesystem("file")
        if not fs.exists(str(schema_path)):
            console.print(f"[red]Schema file not found: {schema_path}[/red]")
            console.print("[dim]Run 'toa ontology extract' first to create the ontology.[/dim]")
            raise typer.Exit(1)

        if not fs.exists(str(graph_path)):
            console.print(f"[red]Graph file not found: {graph_path}[/red]")
            console.print("[dim]Run 'toa ontology extract' first to create the ontology.[/dim]")
            raise typer.Exit(1)

        return schema_path, graph_path

    # =========================================================================
    # EXTRACTION HELPERS
    # =========================================================================

    @staticmethod
    @contextlib.contextmanager
    def _capture_run_logs(log_path: Path):
        with capture_run_logs(log_path, consoles=[console]):
            yield

    @staticmethod
    def _get_current_commit_hash() -> str:
        return get_current_commit_hash()

    @staticmethod
    def _resolve_run_storage(domain: str) -> tuple[Path, object, Path | str, OntologyConfig]:
        from taxonomy_ontology_accelerator.ontology_engine.utils.domain_resolver import (
            DomainResolver,
        )

        config = OntologyConfigLoader.load_for_domain(domain)
        protocol = getattr(config.filesystem, "protocol", "local")
        if protocol != "local":
            fs = get_filesystem_from_config(
                protocol,
                getattr(config.filesystem, "options", None) or {},
            )
        else:
            fs = fsspec.filesystem("file")
        domain_folder = DomainResolver.validate_domain_folder(domain)
        output_dir = DomainResolver.resolve_output_directory(domain, config)
        return domain_folder, fs, output_dir, config

    @staticmethod
    def _run_snapshot_dir_from_output_dir(output_dir: Path | str) -> Path | str:
        if isinstance(output_dir, Path):
            return output_dir.parent
        return output_dir.rstrip("/").rsplit("/", 1)[0]

    @staticmethod
    def _resolve_existing_run_snapshot_dir_in_fs(
        run_root_dir: Path | str, run_number: int, fs
    ) -> Path | str:
        assert run_number > 0, "run_number must be positive"
        matches: list[str] = []
        for item in fs.ls(str(run_root_dir), detail=True):
            if isinstance(item, dict):
                item_name = str(item.get("name", "")).rstrip("/")
                is_directory = item.get("type") == "directory"
            else:
                item_name = str(item).rstrip("/")
                info = fs.info(item_name)
                is_directory = info.get("type") == "directory"
            if is_directory and extract_run_sequence(item_name.split("/")[-1]) == run_number:
                matches.append(item_name)

        if not matches:
            raise ValueError(f"Run {run_number} not found for domain at {run_root_dir}")
        if len(matches) > 1:
            raise ValueError(
                f"Multiple run directories found for run {run_number} in {run_root_dir}"
            )
        if isinstance(run_root_dir, Path):
            return Path(matches[0])
        return matches[0]

    @staticmethod
    def _build_next_run_snapshot_dir(domain_folder: Path) -> Path:
        fs = fsspec.filesystem("file")
        assert fs.exists(str(domain_folder)), "Domain folder must exist"
        assert fs.isdir(str(domain_folder)), "Domain folder must be a directory"

        existing_names: list[str] = []
        for child in domain_folder.iterdir():
            if fs.isdir(str(child)):
                existing_names.append(child.name)

        run_name = build_next_run_name(existing_names)
        return domain_folder / run_name

    @staticmethod
    def _resolve_existing_run_snapshot_dir(domain_folder: Path, run_number: int) -> Path:
        fs = fsspec.filesystem("file")
        assert fs.exists(str(domain_folder)), "Domain folder must exist"
        assert run_number > 0, "run_number must be positive"

        matches = [
            child
            for child in domain_folder.iterdir()
            if fs.isdir(str(child)) and extract_run_sequence(child.name) == run_number
        ]
        if not matches:
            raise ValueError(f"Run {run_number} not found for domain at {domain_folder}")
        if len(matches) > 1:
            raise ValueError(
                f"Multiple run directories found for run {run_number} in {domain_folder}"
            )
        return matches[0]

    @staticmethod
    def _prepare_new_run_snapshot(
        domain: str,
        *,
        domain_folder: Path | None = None,
        output_dir: Path | str | None = None,
        fs=None,
    ) -> Path | str:
        assert domain, "Domain must not be empty"
        assert isinstance(domain, str), "Domain must be a string"

        if domain_folder is None or output_dir is None or fs is None:
            domain_folder, fs, output_dir, _config = OntologyCLIHelpers._resolve_run_storage(domain)

        protocol = getattr(fs, "protocol", "file")
        protocols = {protocol} if isinstance(protocol, str) else set(protocol)
        if protocols.issubset({"file", "local"}):
            run_snapshot_dir = OntologyCLIHelpers._build_next_run_snapshot_dir(domain_folder)
            run_output_dir = join_path(run_snapshot_dir, "output")
        else:
            run_output_dir = allocate_run_output_dir(output_dir, domain, fs)
            run_snapshot_dir = OntologyCLIHelpers._run_snapshot_dir_from_output_dir(run_output_dir)
        fs.makedirs(str(run_snapshot_dir), exist_ok=False)

        prepare_run_snapshot(
            run_snapshot_dir,
            fs,
            input_path=domain_folder / "input",
            prompt_path=domain_folder / "prompts",
            config_path=domain_folder / "config.yaml",
            source_fs=fsspec.filesystem("file"),
        )

        return run_snapshot_dir

    @staticmethod
    @contextlib.contextmanager
    def _capture_run_logs_for_snapshot(run_snapshot_dir: Path | str, fs):
        log_path = join_path(run_snapshot_dir, "stdout.log")
        if isinstance(log_path, Path):
            with OntologyCLIHelpers._capture_run_logs(log_path):
                yield
            return

        buffer = io.StringIO()
        with capture_run_logs_to_stream(buffer, consoles=[console]):
            yield
        safe_write_file(log_path, buffer.getvalue(), fs=fs)

    @staticmethod
    def _run_bedrock_cost_script(
        run_snapshot_dir: Path | str,
        start_time_utc: datetime,
        end_time_utc: datetime,
        run_tag: str | None = None,
        metadata: ProcessingMetadata | None = None,
        config: OntologyConfig | None = None,
        state: Any | None = None,
        fs=None,
    ) -> Path | str | None:
        assert run_snapshot_dir is not None, "run_snapshot_dir must not be None"
        assert start_time_utc.tzinfo is not None, "start_time_utc must be timezone-aware"
        assert end_time_utc.tzinfo is not None, "end_time_utc must be timezone-aware"

        csv_path = join_path(run_snapshot_dir, "bedrock_costs.csv")
        resolved_run_tag = run_tag or str(run_snapshot_dir).rstrip("/").split("/")[-1]

        def _write_csv(rows: list[list[str | int]]) -> Path | str:
            buffer = io.StringIO(newline="")
            writer = csv.writer(buffer)
            for row in rows:
                writer.writerow(row)
            safe_write_file(csv_path, buffer.getvalue(), fs=fs)
            return csv_path

        def _write_error_csv(error_code: str, error_text: str) -> Path | str:
            return _write_csv(
                [
                    [
                        "status",
                        "run_tag",
                        "usage_tag",
                        "error_code",
                        "error_message",
                        "start_time_utc",
                        "end_time_utc",
                    ],
                    [
                        "error",
                        resolved_run_tag,
                        "unknown",
                        error_code,
                        error_text,
                        start_time_utc.astimezone(UTC).isoformat(),
                        end_time_utc.astimezone(UTC).isoformat(),
                    ],
                ]
            )

        if end_time_utc <= start_time_utc:
            message = "end_time_utc must be after start_time_utc"
            console.print(f"[yellow]Bedrock costs unavailable: {message}[/yellow]")
            return _write_error_csv("invalid_window", message)

        usage_source = metadata if metadata is not None else state
        resolved_config = config or getattr(state, "config", None)
        if usage_source is None or resolved_config is None:
            message = "Run usage metadata is unavailable"
            console.print(f"[yellow]Bedrock costs unavailable: {message}[/yellow]")
            return _write_error_csv("missing_usage_source", message)

        llm_model_id = _strip_model_provider_prefix(str(getattr(resolved_config.llm, "model", "") or ""))
        embedding_model_id = _strip_model_provider_prefix(
            str(getattr(resolved_config.embeddings, "model", "") or "")
        )
        llm_usage, llm_uses_estimated_usage, _ = _combined_llm_usage_totals(
            usage_source, resolved_config
        )
        embedding_usage = _usage_totals(usage_source, prefix="embedding_")
        total_usage = {
            key: llm_usage[key] + embedding_usage[key]
            for key in llm_usage
        }

        if _usage_token_sum(total_usage) == 0:
            return _write_error_csv("no_usage", "No Bedrock token usage found for this run")

        component_rows = [
            ("ok", "llm", llm_model_id, llm_usage, llm_uses_estimated_usage),
            ("ok", "embedding", embedding_model_id, embedding_usage, False),
        ]
        rows_to_write: list[list[str | int]] = [BEDROCK_COSTS_CSV_HEADER]
        known_total_cost = 0.0
        total_uses_estimated_fallback = False
        total_uses_estimated_usage = False
        total_uses_rough_pricing = False

        for status, usage_tag, model_id, usage, uses_estimated_usage in component_rows:
            cost_estimate = _estimate_bedrock_usage_cost(model_id, usage, usage_tag=usage_tag)
            error_code = ""
            error_message = ""
            numeric_cost, text_cost = _format_cost(cost_estimate.cost)
            known_total_cost += cost_estimate.cost
            if uses_estimated_usage and _usage_token_sum(usage) > 0:
                total_uses_estimated_usage = True
                error_code = "estimated_missing_llm_usage"
                if cost_estimate.pricing_source == "aws_price_list_bulk":
                    error_message = (
                        "Estimated token usage because provider LLM usage was unavailable; "
                        "priced using AWS Price List Bulk API"
                    )
                elif cost_estimate.pricing_source == "aws_price_list":
                    error_message = (
                        "Estimated token usage because provider LLM usage was unavailable; "
                        "priced using AWS Price List Query API"
                    )
                elif cost_estimate.pricing_source == "aws_published_fallback":
                    error_message = (
                        "Estimated token usage because provider LLM usage was unavailable; "
                        "priced using reviewed AWS-published fallback rates"
                    )
                else:
                    error_message = (
                        "Estimated token usage because provider LLM usage was unavailable"
                    )
            elif cost_estimate.pricing_source == "aws_price_list_bulk" and _usage_token_sum(usage) > 0:
                error_code = "aws_price_list_bulk"
                error_message = "Priced using AWS Price List Bulk API"
            elif cost_estimate.pricing_source == "aws_price_list" and _usage_token_sum(usage) > 0:
                error_code = "aws_price_list"
                error_message = "Priced using AWS Price List Query API"
            elif cost_estimate.pricing_source == "aws_published_fallback" and _usage_token_sum(usage) > 0:
                total_uses_estimated_fallback = True
                error_code = "estimated_fallback_price"
                error_message = f"Estimated using fallback token price for Bedrock model {model_id}"
            elif cost_estimate.pricing_source == "rough_estimate" and _usage_token_sum(usage) > 0:
                total_uses_rough_pricing = True
                error_code = "estimated_pricing_unavailable"
                error_message = f"Estimated using rough fallback price for Bedrock model {model_id}"

            rows_to_write.append(
                [
                    status,
                    resolved_run_tag,
                    usage_tag,
                    model_id,
                    usage["input_tokens"],
                    usage["output_tokens"],
                    usage["cache_read_tokens"],
                    usage["cache_write_tokens"],
                    numeric_cost,
                    text_cost,
                    start_time_utc.astimezone(UTC).isoformat(),
                    end_time_utc.astimezone(UTC).isoformat(),
                    error_code,
                    error_message,
                ]
            )

        total_numeric_cost = ""
        total_text_cost = "UNKNOWN"
        total_error_code = "partial_pricing_unavailable"
        total_error_message = "One or more nonzero usage rows could not be priced"
        total_numeric_cost, total_text_cost = _format_cost(known_total_cost)
        if total_uses_rough_pricing:
            total_error_code = "contains_estimated_pricing_unavailable"
            total_error_message = "One or more nonzero usage rows used rough fallback pricing"
        elif total_uses_estimated_usage:
            total_error_code = "contains_estimated_missing_llm_usage"
            total_error_message = "One or more LLM usage rows used estimated token counts"
        elif total_uses_estimated_fallback:
            total_error_code = "contains_estimated_fallback_price"
            total_error_message = "One or more nonzero usage rows used fallback pricing estimates"
        else:
            total_error_code = ""
            total_error_message = ""

        rows_to_write.append(
            [
                "total",
                resolved_run_tag,
                "all",
                "__TOTAL__",
                total_usage["input_tokens"],
                total_usage["output_tokens"],
                total_usage["cache_read_tokens"],
                total_usage["cache_write_tokens"],
                total_numeric_cost,
                total_text_cost,
                start_time_utc.astimezone(UTC).isoformat(),
                end_time_utc.astimezone(UTC).isoformat(),
                total_error_code,
                total_error_message,
            ]
        )
        csv_path = _write_csv(rows_to_write)
        console.print(f"[dim]Bedrock costs: {csv_path}[/dim]")
        return csv_path

    @staticmethod
    def _validate_domain_folder(domain: str):
        """Validate domain folder exists."""
        assert domain, "Domain must not be empty"
        assert isinstance(domain, str), "Domain must be a string"

        from taxonomy_ontology_accelerator.ontology_engine.utils.domain_resolver import (
            DomainResolver,
        )

        try:
            DomainResolver.validate_domain_folder(domain)
        except FileNotFoundError as e:
            console.print(f"[red]Domain folder not found: {e}[/red]")
            console.print(f"[dim]Create a folder named '{domain}' with an 'input' subfolder[/dim]")
            raise typer.Exit(1) from e

    @staticmethod
    def _get_input_files(domain: str, config: OntologyConfigLoader) -> list[Path]:
        """Get input files for a domain."""
        assert domain, "Domain must not be empty"
        assert config is not None, "Config must not be None"

        from taxonomy_ontology_accelerator.ontology_engine.utils.domain_resolver import (
            DomainResolver,
        )

        input_dir = DomainResolver.resolve_input_path(domain, config)
        return (
            list(input_dir.glob("**/*.txt"))
            + list(input_dir.glob("**/*.md"))
            + list(input_dir.glob("**/*.json"))
        )

    @staticmethod
    def _calculate_token_estimates(
        input_files: list[Path], config: OntologyConfigLoader
    ) -> tuple[int, int]:
        """Calculate estimated input and output tokens."""
        assert input_files, "Input files must not be empty"
        assert config is not None, "Config must not be None"

        fs = fsspec.filesystem("file")
        total_chars = sum(f.stat().st_size for f in input_files if fs.isfile(str(f)))
        chars_per_token = config.text_processing.chunking.chars_per_token_estimate
        estimated_input_tokens = (
            int(total_chars / chars_per_token) if chars_per_token > 0 else total_chars
        )

        # Add prompt overhead per batch
        # Add prompt overhead per batch
        chunks_per_batch = config.batching.chunks_per_batch or 10
        estimated_batches = max(1, estimated_input_tokens // (chunks_per_batch * 1000))
        prompt_overhead_per_batch = 500
        total_input_tokens = estimated_input_tokens + (
            estimated_batches * prompt_overhead_per_batch
        )

        # Estimate output tokens (25% of input for entity extraction)
        estimated_output_tokens = int(total_input_tokens * 0.25)
        return total_input_tokens, estimated_output_tokens

    @staticmethod
    def _calculate_cost_from_tokens(
        input_tokens: int, output_tokens: int, model: str
    ) -> float | None:
        """Calculate cost from tokens, preferring AWS pricing for Bedrock models."""
        assert input_tokens >= 0, "Input tokens must be non-negative"
        assert output_tokens >= 0, "Output tokens must be non-negative"

        if str(model).startswith("bedrock:"):
            usage = {
                "input_tokens": input_tokens,
                "output_tokens": output_tokens,
                "cache_read_tokens": 0,
                "cache_write_tokens": 0,
            }
            return _estimate_bedrock_usage_cost(
                _strip_model_provider_prefix(model),
                usage,
                usage_tag="llm",
            ).cost

        try:
            from genai_prices import Usage as GenaiUsage
            from genai_prices import calc_price

            usage = GenaiUsage(input_tokens=input_tokens, output_tokens=output_tokens)
            model_ref = model.split(":", 1)[1] if ":" in model else model
            result = calc_price(usage, model_ref)
            return float(result.total_price)
        except (ImportError, Exception):
            return None

    @staticmethod
    def _estimate_extraction_cost(domain: str, config: OntologyConfigLoader) -> dict | None:
        """Estimate extraction cost before starting."""
        assert domain, "Domain must not be empty"
        assert config is not None, "Config must not be None"

        try:
            input_files = OntologyCLIHelpers._get_input_files(domain, config)
            if not input_files:
                return None

            input_tokens, output_tokens = OntologyCLIHelpers._calculate_token_estimates(
                input_files, config
            )
            cost = OntologyCLIHelpers._calculate_cost_from_tokens(
                input_tokens, output_tokens, str(config.llm.model)
            )

            return {
                "input_tokens": input_tokens,
                "output_tokens": output_tokens,
                "total_tokens": input_tokens + output_tokens,
                "estimated_cost": cost,
                "files_count": len(input_files),
            }
        except Exception:
            return None

    @staticmethod
    def _display_extraction_header(domain: str):
        """Display extraction header with configuration info."""
        assert domain, "Domain must not be empty"
        assert isinstance(domain, str), "Domain must be a string"

        # Load config to show settings
        # Load config to show settings
        config = OntologyConfigLoader.load_for_domain(domain)

        console.print(Panel.fit("[bold blue]ONTOLOGY EXTRACTION[/bold blue]", border_style="blue"))
        console.print(f"[dim]Domain: {domain}[/dim]")
        console.print(f"[dim]Model: {config.llm.model}[/dim]")
        console.print(f"[dim]Incremental: {config.features.incremental_updates}[/dim]")

        # Show cost estimate
        estimate = OntologyCLIHelpers._estimate_extraction_cost(domain, config)
        if estimate:
            console.print()
            console.print("[bold yellow]Estimated Cost[/bold yellow]")
            console.print(f"[dim]  Input files: {estimate['files_count']}[/dim]")
            console.print(f"[dim]  Est. input tokens: ~{estimate['input_tokens']:,}[/dim]")
            console.print(f"[dim]  Est. output tokens: ~{estimate['output_tokens']:,}[/dim]")
            if estimate.get("estimated_cost") is not None:
                cost_str = f"${estimate['estimated_cost']:.4f}"
                console.print(f"[dim]  Est. cost: [bold yellow]{cost_str}[/bold yellow][/dim]")
            else:
                console.print(
                    "[dim]  Est. cost: [yellow]Install genai-prices for cost estimates[/yellow][/dim]"
                )
            console.print()

    @staticmethod
    def _run_extraction_with_progress(
        domain: str, resume: bool = True, output_dir_override: Path | str | None = None
    ) -> OntologyOutput:
        """Run extraction with progress display."""
        assert domain, "Domain must not be empty"
        assert isinstance(domain, str), "Domain must be a string"

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task("Extracting ontology...", total=None)

            try:
                # Convert bool to "auto"/False for API
                resume_param = "auto" if resume else False
                result: OntologyOutput = asyncio.run(
                    extract_ontology(
                        domain=domain,
                        resume=resume_param,
                        output_dir_override=output_dir_override,
                    )
                )
                progress.update(task, completed=True)
                return result
            except FileNotFoundError as e:
                progress.stop()
                console.print(f"[red]File not found: {e}[/red]")
                raise typer.Exit(1) from e
            except ValueError as e:
                progress.stop()
                console.print(f"[red]Invalid input: {e}[/red]")
                raise typer.Exit(1) from e

    @staticmethod
    def run_extraction(domain: str, resume: bool = True, continue_run: int | None = None):
        """Run ontology extraction with progress display."""
        assert domain, "Domain must not be empty"
        assert isinstance(domain, str), "Domain must be a string"
        assert continue_run is None or continue_run > 0, (
            "continue_run must be positive when provided"
        )

        OntologyCLIHelpers._validate_domain_folder(domain)
        domain_folder, fs, base_output_dir, _config = OntologyCLIHelpers._resolve_run_storage(domain)
        run_root_dir = OntologyCLIHelpers._run_snapshot_dir_from_output_dir(base_output_dir)
        if continue_run is not None:
            if not resume:
                console.print("[red]--continue requires --resume[/red]")
                raise typer.Exit(1)
            run_snapshot_dir = OntologyCLIHelpers._resolve_existing_run_snapshot_dir_in_fs(
                run_root_dir, continue_run, fs
            )
        else:
            run_snapshot_dir = OntologyCLIHelpers._prepare_new_run_snapshot(
                domain,
                domain_folder=domain_folder,
                output_dir=base_output_dir,
                fs=fs,
            )

        output_dir_override = join_path(run_snapshot_dir, "output")
        started_at_utc = datetime.now(UTC)

        with OntologyCLIHelpers._capture_run_logs_for_snapshot(run_snapshot_dir, fs):
            OntologyCLIHelpers._display_extraction_header(domain)
            console.print(f"[dim]Run snapshot: {run_snapshot_dir}[/dim]")
            result = OntologyCLIHelpers._run_extraction_with_progress(
                domain,
                resume=resume,
                output_dir_override=output_dir_override,
            )
            OntologyCLIHelpers._display_extraction_results(result)
            ended_at_utc = datetime.now(UTC)
            OntologyCLIHelpers._run_bedrock_cost_script(
                run_snapshot_dir=run_snapshot_dir,
                start_time_utc=started_at_utc,
                end_time_utc=ended_at_utc,
                metadata=result.metadata,
                config=_config,
                fs=fs,
            )

    @staticmethod
    def _display_extraction_results(result: OntologyOutput):
        """Display extraction results in a formatted table."""
        assert result is not None, "Result must not be None"
        assert hasattr(result, "metadata"), "Result must have metadata"

        console.print("\n[bold green]✓ Extraction Complete[/bold green]\n")

        # Create summary table
        # Create summary table
        table = Table(title="Extraction Summary", show_header=True)
        table.add_column("Metric", style="cyan")
        table.add_column("Value", style="green")

        metadata = result.metadata
        table.add_row("Entities Extracted", str(metadata.total_entities_extracted))
        table.add_row("Entities (after dedup)", str(metadata.entities_after_deduplication))
        table.add_row("Relationships Extracted", str(metadata.total_relationships_extracted))
        table.add_row(
            "Relationships (after dedup)", str(metadata.relationships_after_deduplication)
        )
        table.add_row("New Entity Types", str(metadata.new_entity_types_created))
        table.add_row("New Relationship Types", str(metadata.new_relationship_types_created))
        table.add_row("Processing Time", f"{metadata.processing_time_seconds:.2f}s")
        table.add_row("LLM Calls", str(metadata.llm_calls_made))

        console.print(table)

        # Display token usage and cost information
        if metadata.total_tokens > 0 or metadata.estimated_cost_usd is not None:
            console.print("\n[bold cyan]Token Usage & Cost[/bold cyan]")
            token_table = Table(show_header=False, box=None, padding=(0, 2))
            token_table.add_column("Metric", style="dim")
            token_table.add_column("Value", style="white")

            if metadata.input_tokens > 0:
                token_table.add_row("Input tokens", f"{metadata.input_tokens:,}")
            if metadata.output_tokens > 0:
                token_table.add_row("Output tokens", f"{metadata.output_tokens:,}")
            if metadata.cache_read_tokens > 0:
                token_table.add_row("Cache read tokens", f"{metadata.cache_read_tokens:,}")
            if metadata.cache_write_tokens > 0:
                token_table.add_row("Cache write tokens", f"{metadata.cache_write_tokens:,}")
            if metadata.total_tokens > 0:
                token_table.add_row("Total tokens", f"{metadata.total_tokens:,}")
            if metadata.estimated_cost_usd is not None:
                token_table.add_row(
                    "Estimated cost", f"[bold green]${metadata.estimated_cost_usd:.4f}[/bold green]"
                )

            console.print(token_table)

        # Display output paths
        # Display output paths
        console.print(f"\n[dim]Schema: {result.schema_path}[/dim]")
        console.print(f"[dim]Graph: {result.graph_path}[/dim]")

        if result.errors:
            OntologyCLIHelpers._display_error_summary(result.errors)

    @staticmethod
    def _display_error_summary(errors: list[dict]) -> None:
        """Display errors and warnings with breakdown by type."""
        assert errors is not None, "errors parameter is required"
        assert isinstance(errors, list), "errors must be a list"
        error_count = sum(1 for e in errors if e.get("severity", "error") == "error")
        warning_count = len(errors) - error_count
        if error_count > 0:
            console.print(f"\n[red]❌ {error_count} error(s) during extraction[/red]")
        if warning_count > 0:
            warning_types: dict[str, int] = {}
            for e in errors:
                if e.get("severity", "error") != "error":
                    wtype = str(e.get("type", "unknown")).replace("_", " ")
                    warning_types[wtype] = warning_types.get(wtype, 0) + 1
            breakdown = ", ".join(f"{c} {t}" for t, c in warning_types.items())
            console.print(f"\n[yellow]⚠ {warning_count} warning(s): {breakdown}[/yellow]")

    # =========================================================================
    # EXPORT HELPERS
    # =========================================================================

    @staticmethod
    def _run_export_with_progress(
        schema_path: Path, graph_path: Path, output_path: Path, export_format: str
    ):
        """Run export with progress display."""
        fs = fsspec.filesystem("file")
        assert fs.exists(str(schema_path)), "Schema path must exist"
        assert fs.exists(str(graph_path)), "Graph path must exist"

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task("Exporting to OWL/RDF...", total=None)

            try:
                export_to_owl_rdf_from_files(
                    schema_path=schema_path,
                    graph_path=graph_path,
                    output_path=output_path,
                    format=export_format,
                )
                progress.update(task, completed=True)
            except ImportError as e:
                progress.stop()
                console.print("[red]Export failed: rdflib not installed[/red]")
                console.print("[dim]Install with: uv add rdflib[/dim]")
                raise typer.Exit(1) from e
            except (FileNotFoundError, ValueError) as e:
                progress.stop()
                console.print(f"[red]Export failed: {e}[/red]")
                raise typer.Exit(1) from e

    @staticmethod
    def run_export(
        domain: str,
        output_dir: Path | None,
        export_format: str,
        schema_file: Path | None,
        graph_file: Path | None,
    ):
        """Run OWL/RDF export."""
        assert domain, "Domain must not be empty"
        assert export_format in ("turtle", "rdfxml"), "Invalid export format"

        # Resolve file paths
        # Resolve file paths
        schema_path, graph_path = OntologyCLIHelpers._resolve_ontology_files(
            domain, output_dir, schema_file, graph_file
        )

        # Determine output path
        base_dir = OntologyCLIHelpers._get_output_base_dir(domain, output_dir)
        config = OntologyConfigLoader.load()
        export_filename = config.output.export.filename
        extension = ".ttl" if export_format == "turtle" else ".owl"  # rdfxml -> .owl
        output_path = base_dir / f"{export_filename}{extension}"

        console.print(Panel.fit("[bold blue]ONTOLOGY EXPORT[/bold blue]", border_style="blue"))
        console.print(f"[dim]Domain: {domain}[/dim]")
        console.print(f"[dim]Format: {export_format}[/dim]")
        console.print(f"[dim]Schema: {schema_path}[/dim]")
        console.print(f"[dim]Graph: {graph_path}[/dim]")

        OntologyCLIHelpers._run_export_with_progress(
            schema_path, graph_path, output_path, export_format
        )

        console.print("\n[bold green]✓ Export Complete[/bold green]")
        console.print(f"[dim]Output: {output_path}[/dim]")

        if export_format == "turtle":
            OntologyCLIHelpers.run_post_export_alignment(
                graph_path, output_path, base_dir, config
            )

    @staticmethod
    def run_verify_alignment(
        domain: str | None,
        output_dir: Path | None,
        output_format: str,
        graph_file: Path | None,
        ontology_file: Path | None,
    ) -> None:
        base_dir = OntologyCLIHelpers._get_output_base_dir(domain or "", output_dir)
        graph_path = graph_file or (base_dir / "graph.json")
        ontology_path = ontology_file or (base_dir / "ontology.ttl")
        for path in (graph_path, ontology_path):
            if not Path(path).exists():
                console.print(f"[red]File not found: {path}[/red]")
                raise typer.Exit(2)
        report = align_files(graph_path, ontology_path)
        if output_format == "json":
            print(json.dumps(report_to_dict(report), indent=2))
        else:
            console.print(format_report(report))
        raise typer.Exit(0 if report.fully_aligned else 1)

    @staticmethod
    def run_post_export_alignment(
        graph_path: Path,
        ontology_path: Path,
        output_dir: Path,
        config: OntologyConfig,
    ) -> None:
        if not config.alignment_check.enabled:
            return
        try:
            report = align_files(graph_path, ontology_path)
        except Exception as error:
            console.print(f"[yellow]Alignment check skipped: {error}[/yellow]")
            return
        console.print()
        console.print(format_report(report))
        report_path = Path(output_dir) / ALIGNMENT_REPORT_FILENAME
        safe_write_file(report_path, json.dumps(report_to_dict(report), indent=2))
        if report.fully_aligned:
            console.print("[green]✓ Outputs are fully aligned.[/green]")
        else:
            console.print(
                f"[yellow]⚠ Outputs not fully aligned (see above). "
                f"Wrote {report_path}[/yellow]"
            )
        if config.alignment_check.fail_on_misalignment and not report.fully_aligned:
            raise typer.Exit(1)

    # =========================================================================
    # INFO HELPERS
    # =========================================================================

    @staticmethod
    def _load_ontology_files(
        schema_path: Path, graph_path: Path
    ) -> tuple[OntologySchema, OntologyGraph]:
        """Load schema and graph from JSON files."""
        fs = fsspec.filesystem("file")
        assert fs.exists(str(schema_path)), "Schema path must exist"
        assert fs.exists(str(graph_path)), "Graph path must exist"

        try:
            schema_data = json.loads(schema_path.read_text())
            schema = OntologySchema(**schema_data)

            graph_data = json.loads(graph_path.read_text())
            graph = OntologyGraph(**graph_data)
            return schema, graph
        except (json.JSONDecodeError, ValueError) as e:
            console.print(f"[red]Failed to load ontology files: {e}[/red]")
            raise typer.Exit(1) from e

    @staticmethod
    def _display_schema_info(schema: OntologySchema):
        """Display schema information."""
        assert schema is not None, "Schema must not be None"
        assert hasattr(schema, "version"), "Schema must have version"

        console.print("\n[bold cyan]Schema[/bold cyan]")
        console.print(f"  Version: {schema.version}")
        console.print(f"  Last Updated: {schema.last_updated}")
        console.print(f"  Entity Types: {len(schema.entity_types)}")
        console.print(f"  Relationship Types: {len(schema.relationship_types)}")

    @staticmethod
    def _display_graph_info(graph: OntologyGraph):
        """Display graph information."""
        assert graph is not None, "Graph must not be None"
        assert hasattr(graph, "entities"), "Graph must have entities"

        console.print("\n[bold cyan]Graph[/bold cyan]")
        console.print(f"  Entities: {len(graph.entities)}")
        console.print(f"  Relationships: {len(graph.relationships)}")
        console.print(f"  Extracted At: {graph.extracted_at}")

    @staticmethod
    def _display_entity_types_table(schema: OntologySchema, graph: OntologyGraph):
        """Display entity types table."""
        assert schema is not None, "Schema must not be None"
        assert graph is not None, "Graph must not be None"

        if not schema.entity_types:
            return

        console.print("\n[bold cyan]Entity Types[/bold cyan]")
        type_table = Table(show_header=True)
        type_table.add_column("Type", style="cyan")
        type_table.add_column("Count", style="green")
        type_table.add_column("Fields", style="dim")

        # Count entities per type
        # Count entities per type
        type_counts: dict[str, int] = {}
        for entity in graph.entities:
            type_counts[entity.type] = type_counts.get(entity.type, 0) + 1

        for type_name, type_def in schema.entity_types.items():
            count = type_counts.get(type_name, 0)
            fields = ", ".join(type_def.fields[:FIELDS_PREVIEW_COUNT])
            if len(type_def.fields) > FIELDS_PREVIEW_COUNT:
                fields += f" (+{len(type_def.fields) - FIELDS_PREVIEW_COUNT})"
            type_table.add_row(type_name, str(count), fields)

        console.print(type_table)

    @staticmethod
    def _display_relationship_types_table(schema: OntologySchema, graph: OntologyGraph):
        """Display relationship types table."""
        assert schema is not None, "Schema must not be None"
        assert graph is not None, "Graph must not be None"

        if not schema.relationship_types:
            return

        console.print("\n[bold cyan]Relationship Types[/bold cyan]")
        rel_table = Table(show_header=True)
        rel_table.add_column("Type", style="cyan")
        rel_table.add_column("Count", style="green")
        rel_table.add_column("From → To", style="dim")

        # Count relationships per type
        # Count relationships per type
        rel_counts: dict[str, int] = {}
        for rel in graph.relationships:
            rel_counts[rel.type] = rel_counts.get(rel.type, 0) + 1

        for type_name, type_def in schema.relationship_types.items():
            count = rel_counts.get(type_name, 0)
            direction = f"{type_def.from_type} → {type_def.to_type}"
            rel_table.add_row(type_name, str(count), direction)

        console.print(rel_table)

    @staticmethod
    def show_info(domain: str, output_dir: Path | None):
        """Show information about an extracted ontology."""
        assert domain, "Domain must not be empty"
        assert isinstance(domain, str), "Domain must be a string"

        # Resolve file paths
        # Resolve file paths
        schema_path, graph_path = OntologyCLIHelpers._resolve_ontology_files(
            domain, output_dir, None, None
        )

        # Load schema and graph
        # Load schema and graph
        schema, graph = OntologyCLIHelpers._load_ontology_files(schema_path, graph_path)

        # Display header
        console.print(
            Panel.fit(f"[bold blue]ONTOLOGY INFO: {domain}[/bold blue]", border_style="blue")
        )

        # Display info sections
        # Display info sections
        OntologyCLIHelpers._display_schema_info(schema)
        OntologyCLIHelpers._display_graph_info(graph)
        OntologyCLIHelpers._display_entity_types_table(schema, graph)
        OntologyCLIHelpers._display_relationship_types_table(schema, graph)

        # File paths
        console.print("\n[bold cyan]Files[/bold cyan]")
        console.print(f"  Schema: {schema_path}")
        console.print(f"  Graph: {graph_path}")

    # =========================================================================
    # VISUALIZATION HELPERS
    # =========================================================================
    # =========================================================================
    # VISUALIZATION HELPERS
    # =========================================================================

    @staticmethod
    def _get_visualization_dir() -> Path:
        """Get the path to the visualization directory."""

        # Find the package root directory
        import taxonomy_ontology_accelerator

        fs = fsspec.filesystem("file")
        package_root = Path(taxonomy_ontology_accelerator.__file__).parent.parent
        assert fs.exists(str(package_root)), "Package root directory must exist"

        visualization_dir = package_root / "scripts" / "ontology_visualization"
        assert isinstance(visualization_dir, Path), "visualization_dir must be a Path"

        if not fs.exists(str(visualization_dir)):
            console.print(f"[red]Visualization files not found: {visualization_dir}[/red]")
            console.print("[dim]Ensure the scripts/ontology_visualization/ directory exists.[/dim]")
            raise typer.Exit(1)

        return visualization_dir

    @staticmethod
    def _find_available_port(start_port: int) -> int:
        """Find an available port starting from the given port."""
        assert isinstance(start_port, int), "start_port must be an integer"
        assert start_port > 0, "start_port must be positive"

        for port in range(start_port, start_port + MAX_PORT_ATTEMPTS):
            try:
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                    s.bind(("127.0.0.1", port))
                    return port
            except OSError:
                continue

        console.print(
            f"[red]Could not find an available port in range "
            f"{start_port}-{start_port + MAX_PORT_ATTEMPTS}[/red]"
        )
        raise typer.Exit(1)

    @staticmethod
    def _create_server_handler(directory: Path):
        """Create a custom HTTP request handler that serves from the specified directory."""
        fs = fsspec.filesystem("file")
        assert fs.exists(str(directory)), "Directory must exist"
        assert fs.isdir(str(directory)), "Directory must be a directory"

        dir_str = str(directory)

        class QuietHandler(SimpleHTTPRequestHandler):
            """HTTP handler that serves files quietly (no logging to stdout)."""

            def __init__(self, *args, **kwargs):
                assert dir_str, "Directory string must not be empty"
                assert isinstance(dir_str, str), "Directory must be a string"
                super().__init__(*args, directory=dir_str, **kwargs)

            def log_message(self, format, *args):
                """Suppress logging - intentionally empty."""
                assert format is not None, "Format must not be None"
                assert isinstance(args, tuple), "Args must be a tuple"

        return QuietHandler

    @staticmethod
    def _start_visualization_server(
        visualization_dir: Path,
        port: int,
    ) -> HTTPServer:
        """Start an HTTP server for visualization."""
        fs = fsspec.filesystem("file")
        assert fs.exists(str(visualization_dir)), "Visualization directory must exist"
        assert port > 0, "Port must be positive"

        handler_class = OntologyCLIHelpers._create_server_handler(visualization_dir)
        return HTTPServer(("127.0.0.1", port), handler_class)

    @staticmethod
    def _open_browser_with_delay(url: str, delay: float = 0.5):
        """Open browser after a short delay to ensure server is ready."""
        assert url, "URL must not be empty"
        assert delay >= 0, "Delay must be non-negative"
        import time

        time.sleep(delay)
        webbrowser.open(url)

    @staticmethod
    def _generate_standalone_html(
        graph_path: Path,
        schema_path: Path,
        output_path: Path,
    ) -> None:
        """Generate a standalone HTML file with embedded graph data."""
        fs = fsspec.filesystem("file")
        assert fs.exists(str(graph_path)), "Graph path must exist"
        assert fs.exists(str(schema_path)), "Schema path must exist"

        visualization_dir = OntologyCLIHelpers._get_visualization_dir()

        # Read the graph and schema data
        # Read the graph and schema data
        graph_data = graph_path.read_text(encoding="utf-8")
        schema_data = schema_path.read_text(encoding="utf-8")

        # Read the JavaScript files
        graph_core_js = (visualization_dir / "graph-core.js").read_text(encoding="utf-8")
        graph_render_js = (visualization_dir / "graph-render.js").read_text(encoding="utf-8")
        graph_js = (visualization_dir / "graph.js").read_text(encoding="utf-8")
        schema_comparison_js = (visualization_dir / "schema-comparison.js").read_text(
            encoding="utf-8"
        )

        # Generate standalone HTML with embedded data
        # Generate standalone HTML with embedded data
        standalone_html = OntologyCLIHelpers._build_standalone_html(
            graph_core_js=graph_core_js,
            graph_render_js=graph_render_js,
            graph_js=graph_js,
            schema_comparison_js=schema_comparison_js,
            graph_data=graph_data,
            schema_data=schema_data,
        )

        # Write the standalone HTML file
        fs = fsspec.filesystem("file")
        fs.makedirs(str(output_path.parent), exist_ok=True)
        with fs.open(str(output_path), "w", encoding="utf-8") as f:
            f.write(standalone_html)

    @staticmethod
    def _build_inline_scripts(
        graph_core_js: str,
        graph_render_js: str,
        graph_js: str,
        schema_comparison_js: str,
        graph_data: str,
        schema_data: str,
    ) -> str:
        """Build the inline scripts section for standalone HTML."""
        assert graph_data, "Graph data must not be empty"
        assert schema_data, "Schema data must not be empty"

        auto_load_script = OntologyCLIHelpers._build_autoload_script()
        return f"""
    <!-- Embedded JavaScript (standalone version) -->
    <script>
    // Embedded graph data
    const EMBEDDED_GRAPH_DATA = {graph_data};
    const EMBEDDED_SCHEMA_DATA = {schema_data};
    </script>
    <script>{graph_core_js}</script>
    <script>{graph_render_js}</script>
    <script>{graph_js}</script>
    <script>{schema_comparison_js}</script>
    {auto_load_script}
"""

    @staticmethod
    def _build_autoload_script() -> str:
        """Build the autoload JavaScript for standalone HTML."""
        assert True, "Always builds autoload script"  # Defensive assertion
        assert isinstance(str, type), "String type must exist"  # Type check
        return """<script>
        // Auto-load embedded data on page load
        document.addEventListener('DOMContentLoaded', function() {
            setTimeout(function() {
                if (EMBEDDED_GRAPH_DATA && EMBEDDED_GRAPH_DATA.entities) {
                    loadGraph(EMBEDDED_GRAPH_DATA);
                }
                if (EMBEDDED_SCHEMA_DATA) {
                    GraphState.schemaData = EMBEDDED_SCHEMA_DATA;
                    window.schemaData = EMBEDDED_SCHEMA_DATA;
                }
            }, 100);
        });
        // Modal functions
        window.showHelpModal = function() {
            document.getElementById('helpModal').classList.add('active');
            document.body.style.overflow = 'hidden';
        };
        window.closeHelpModal = function() {
            document.getElementById('helpModal').classList.remove('active');
            document.body.style.overflow = '';
        };
        window.showShortcutsModal = function() {
            document.getElementById('shortcutsModal').classList.add('active');
            document.body.style.overflow = 'hidden';
        };
        window.closeShortcutsModal = function() {
            document.getElementById('shortcutsModal').classList.remove('active');
            document.body.style.overflow = '';
        };
        // Enhanced modal keyboard handling - close on Escape
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape') {
                const activeModals = document.querySelectorAll('.modal-overlay.active');
                activeModals.forEach(modal => {
                    modal.classList.remove('active');
                    document.body.style.overflow = '';
                });
            }
        });
    </script>"""

    @staticmethod
    def _build_standalone_html(
        graph_core_js: str,
        graph_render_js: str,
        graph_js: str,
        schema_comparison_js: str,
        graph_data: str,
        schema_data: str,
    ) -> str:
        """Build the standalone HTML content."""
        assert graph_data, "Graph data must not be empty"
        assert schema_data, "Schema data must not be empty"

        visualization_dir = OntologyCLIHelpers._get_visualization_dir()
        base_html = (visualization_dir / "index.html").read_text(encoding="utf-8")

        script_marker = "<!-- Load modules in order -->"
        script_start = base_html.find(script_marker)
        if script_start == -1:
            script_start = base_html.find('<script src="graph-core.js">')

        body_end = base_html.find("</body>")
        inline_scripts = OntologyCLIHelpers._build_inline_scripts(
            graph_core_js,
            graph_render_js,
            graph_js,
            schema_comparison_js,
            graph_data,
            schema_data,
        )

        if script_start != -1 and body_end != -1:
            return base_html[:script_start] + inline_scripts + "\n" + base_html[body_end:]

        # Fallback: append scripts before </body>
        # Fallback: append scripts before </body>
        return base_html.replace("</body>", inline_scripts + "\n</body>")

    @staticmethod
    def run_visualization(
        domain: str,
        output_dir: Path | None,
        port: int,
        export_path: Path | None,
        open_browser: bool,
    ) -> None:
        """Run ontology visualization (server mode or export mode)."""
        assert domain, "Domain must not be empty"
        assert isinstance(domain, str), "Domain must be a string"
        assert port > 0, "Port must be positive"

        # Resolve file paths
        # Resolve file paths
        schema_path, graph_path = OntologyCLIHelpers._resolve_ontology_files(
            domain, output_dir, None, None
        )

        # Export mode: generate standalone HTML
        if export_path:
            OntologyCLIHelpers._run_export_visualization(
                domain, graph_path, schema_path, export_path, open_browser
            )
            return

        # Server mode: start local server
        OntologyCLIHelpers._run_server_visualization(
            domain, graph_path, schema_path, port, open_browser
        )

    @staticmethod
    def _run_export_visualization(
        domain: str,
        graph_path: Path,
        schema_path: Path,
        export_path: Path,
        open_browser: bool,
    ) -> None:
        """Generate and optionally open standalone HTML visualization."""
        fs = fsspec.filesystem("file")
        assert domain, "Domain must not be empty"
        assert fs.exists(str(graph_path)), "Graph path must exist"
        assert fs.exists(str(schema_path)), "Schema path must exist"

        console.print(
            Panel.fit("[bold blue]ONTOLOGY VISUALIZATION[/bold blue]", border_style="blue")
        )
        console.print(f"[dim]Domain: {domain}[/dim]")
        console.print("[dim]Mode: Export standalone HTML[/dim]")
        console.print(f"[dim]Graph: {graph_path}[/dim]")
        console.print(f"[dim]Schema: {schema_path}[/dim]")

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task("Generating standalone HTML...", total=None)

            try:
                OntologyCLIHelpers._generate_standalone_html(
                    graph_path=graph_path,
                    schema_path=schema_path,
                    output_path=export_path,
                )
                progress.update(task, completed=True)
            except (FileNotFoundError, OSError) as e:
                progress.stop()
                console.print(f"[red]Failed to generate HTML: {e}[/red]")
                raise typer.Exit(1) from e

        console.print("\n[bold green]✓ Standalone HTML Generated[/bold green]")
        console.print(f"[dim]Output: {export_path}[/dim]")
        console.print(f"[dim]File size: {export_path.stat().st_size / 1024:.1f} KB[/dim]")

        if open_browser:
            console.print("\n[dim]Opening in browser...[/dim]")
            webbrowser.open(f"file://{export_path.absolute()}")

    @staticmethod
    def _run_server_visualization(
        domain: str,
        graph_path: Path,
        schema_path: Path,
        port: int,
        open_browser: bool,
    ) -> None:
        """Start local HTTP server for visualization."""
        fs = fsspec.filesystem("file")
        assert domain, "Domain must not be empty"
        assert fs.exists(str(graph_path)), "Graph path must exist"
        assert fs.exists(str(schema_path)), "Schema path must exist"

        visualization_dir = OntologyCLIHelpers._get_visualization_dir()
        actual_port = OntologyCLIHelpers._find_available_port(port)

        console.print(
            Panel.fit("[bold blue]ONTOLOGY VISUALIZATION[/bold blue]", border_style="blue")
        )
        console.print(f"[dim]Domain: {domain}[/dim]")
        console.print("[dim]Mode: Local server[/dim]")
        console.print(f"[dim]Graph: {graph_path}[/dim]")
        console.print(f"[dim]Schema: {schema_path}[/dim]")

        # Start server
        # Start server
        server = OntologyCLIHelpers._start_visualization_server(
            visualization_dir=visualization_dir,
            port=actual_port,
        )

        url = f"http://127.0.0.1:{actual_port}/"
        console.print("\n[bold green]✓ Server started[/bold green]")
        console.print(f"[cyan]URL: {url}[/cyan]")
        console.print()
        console.print("[bold]To load your ontology:[/bold]")
        console.print("  1. Click [cyan]'View Ontology Graph'[/cyan] in the browser")
        console.print(f"  2. Select: [cyan]{graph_path}[/cyan]")
        console.print()
        console.print("[dim]Press Ctrl+C to stop the server[/dim]")

        if open_browser:
            # Open browser in background thread
            # Open browser in background thread
            browser_thread = threading.Thread(
                target=OntologyCLIHelpers._open_browser_with_delay,
                args=(url, 0.5),
                daemon=True,
            )
            browser_thread.start()

        try:
            server.serve_forever()
        except KeyboardInterrupt:
            console.print("\n[yellow]Server stopped[/yellow]")
            server.shutdown()

    # =========================================================================
    # RESEARCH HELPERS
    # =========================================================================

    @staticmethod
    def _validate_research_dependencies() -> None:
        """Validate that research dependencies are installed."""
        assert console is not None, "Console must be initialized"
        assert typer is not None, "Typer must be available"

        try:
            from ddgs import DDGS  # pyright: ignore[reportMissingImports]  # noqa: F401
        except ImportError as e:
            console.print("[red]Research dependencies not installed[/red]")
            console.print("[dim]Install with: uv sync --group research[/dim]")
            raise typer.Exit(1) from e

    @staticmethod
    def _display_research_header(domain: str, config) -> None:
        """Display research header with configuration info."""
        assert domain, "Domain must not be empty"
        assert isinstance(domain, str), "Domain must be a string"

        console.print(Panel.fit("[bold blue]WEB RESEARCH[/bold blue]", border_style="blue"))
        console.print(f"[dim]Domain: {domain}[/dim]")
        console.print(f"[dim]Model: {config.llm.model}[/dim]")
        console.print(f"[dim]Queries: {config.research.num_queries}[/dim]")
        console.print(f"[dim]Max fetches: {config.research.max_fetches}[/dim]")

        # Show domain filtering if configured
        if config.research.allowed_domains:
            console.print(
                f"[dim]Allowed domains: {', '.join(config.research.allowed_domains)}[/dim]"
            )
        if config.research.blocked_domains:
            console.print(
                f"[dim]Blocked domains: {', '.join(config.research.blocked_domains)}[/dim]"
            )

    @staticmethod
    def _run_research_with_progress(
        domain: str, config, output_dir: Path, custom_prompt_path: Path | None
    ) -> dict:
        """Run research scraping with progress display."""
        assert domain, "Domain must not be empty"
        assert isinstance(domain, str), "Domain must be a string"

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task("Researching domain...", total=None)

            try:
                result = asyncio.run(
                    OntologyCLIHelpers._execute_research_scraper(
                        domain, config, output_dir, custom_prompt_path
                    )
                )
                progress.update(task, completed=True)
                return result
            except ImportError as e:
                progress.stop()
                console.print("[red]Research dependencies not installed[/red]")
                console.print("[dim]Install with: uv sync --group research[/dim]")
                raise typer.Exit(1) from e
            except Exception as e:
                progress.stop()
                console.print(f"[red]Research failed: {e}[/red]")
                raise typer.Exit(1) from e

    @staticmethod
    async def _execute_research_scraper(
        domain: str, config, output_dir: Path, custom_prompt_path: Path | None
    ) -> dict:
        """Execute the web scraper asynchronously."""
        assert domain, "Domain must not be empty"
        assert config is not None, "Config must not be None"

        from taxonomy_ontology_accelerator.ontology_engine.research import WebResearchScraper

        async with WebResearchScraper(domain, config, output_dir, custom_prompt_path) as scraper:
            return await scraper.scrape()

    @staticmethod
    def _display_research_results(result: dict, domain: str) -> None:
        """Display research results in a formatted table."""
        assert result is not None, "Result must not be None"
        assert domain is not None, "Domain must not be None"

        console.print("\n[bold green]✓ Research Complete[/bold green]\n")

        # Create summary table
        # Create summary table
        table = Table(title="Research Summary", show_header=True)
        table.add_column("Metric", style="cyan")
        table.add_column("Value", style="green")

        table.add_row("Files Created", str(result.get("files_created", 0)))
        table.add_row("Queries Used", str(result.get("queries_used", 0)))
        table.add_row("URLs Skipped (duplicates)", str(result.get("urls_skipped", 0)))
        table.add_row("Output Directory", str(result.get("output_dir", "")))

        console.print(table)

        # Display next steps
        console.print("\n[bold]Next steps:[/bold]")
        console.print(
            f"  1. Review scraped content in: [cyan]{result.get('output_dir', '')}[/cyan]"
        )
        console.print(f"  2. Extract ontology: [cyan]toa ontology extract --domain {domain}[/cyan]")

    @staticmethod
    def run_research(
        domain: str,
        output_dir: Path | None = None,
        num_queries: int | None = None,
    ) -> None:
        """
        Run web research for a domain.

        Args:
            domain: Domain name to research
            output_dir: Custom output directory (default: {domain}/input/)
            num_queries: Override number of search queries
        """
        assert domain, "Domain must not be empty"
        assert isinstance(domain, str), "Domain must be a string"

        # Validate dependencies first
        # Validate dependencies first
        OntologyCLIHelpers._validate_research_dependencies()

        # Load domain-specific config
        # Load domain-specific config
        config = OntologyConfigLoader.load_for_domain(domain)

        # Override num_queries if provided
        if num_queries is not None:
            config.research.num_queries = num_queries

        # Resolve output directory (default: domains/{domain}/input/)
        # Resolve output directory (default: domains/{domain}/input/)
        if output_dir is None:
            output_dir = Path("domains") / domain / "input"

        # Resolve custom research prompt
        from taxonomy_ontology_accelerator.ontology_engine.utils.domain_resolver import (
            DomainResolver,
        )

        custom_prompt_path = DomainResolver.resolve_research_prompt_path(domain, config)

        # Display header
        # Display header
        OntologyCLIHelpers._display_research_header(domain, config)

        # Run research with progress
        result = OntologyCLIHelpers._run_research_with_progress(
            domain, config, output_dir, custom_prompt_path
        )

        # Display results
        # Display results
        OntologyCLIHelpers._display_research_results(result, domain)
