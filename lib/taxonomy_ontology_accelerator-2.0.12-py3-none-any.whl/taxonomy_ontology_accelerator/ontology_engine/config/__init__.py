"""
Configuration layer for ontology engine.

Contains configuration models and loaders.
"""

from taxonomy_ontology_accelerator.ontology_engine.config.config import (
    ConflictResolutionStrategy,
    OntologyConfig,
    OntologyConfigLoader,
)

__all__ = [
    "ConflictResolutionStrategy",
    "OntologyConfig",
    "OntologyConfigLoader",
]
