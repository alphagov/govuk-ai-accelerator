"""
Configuration loader for ontology engine with strict validation.

Enforces fail-fast behavior: missing required parameters cause immediate failure
with clear, actionable error messages.

Provides:
- Pydantic models for all configuration sections with sensible defaults
- Strict validation with clear error messages
- Domain-specific YAML overrides via deep merging
- Cross-field validation (e.g., min <= max)

Architecture:
- All defaults are defined in Pydantic Field(default=...) - no external YAML needed
- Domain configs ({domain}/config.yaml) override defaults via deep merge
- API keys use environment variables (GOOGLE_API_KEY, ANTHROPIC_API_KEY, etc.)

Configuration Priority (highest to lowest):
1. Domain YAML config ({domain}/config.yaml) - Highest priority
2. Pydantic defaults (defined in Field(default=...)) - Lowest priority

Note: Only API keys use environment variables. All other configuration
      is done via Pydantic defaults or domain YAML files.
"""

from pathlib import Path
from typing import Annotated, Any, Literal, Self

import yaml
from pydantic import (
    BaseModel,
    Field,
    PrivateAttr,
    ValidationError,
    ValidationInfo,
    field_validator,
    model_validator,
)
from pydantic_ai.embeddings import KnownEmbeddingModelName
from pydantic_ai.models import KnownModelName

from taxonomy_ontology_accelerator.commons.config.config_loader import FilesystemConfig
from taxonomy_ontology_accelerator.commons.io.file_utils import safe_read_file
from taxonomy_ontology_accelerator.commons.utils.logger import get_logger

logger = get_logger()

ConflictResolutionStrategy = Literal["confidence", "latest"]

class DomainConfig(BaseModel):
    """
    Domain-specific configuration.

    Supports convention-over-configuration:
    - input: Optional explicit input path (overrides {domain}/input/ convention)
    - prompt: Optional explicit prompt path (overrides {domain}/prompts/ convention)
    """

    input: str | None = Field(
        default=None,
        description=(
            "Input file or directory path. "
            "If not specified, uses {domain}/input/ folder (convention). "
            "Can be relative (to CWD) or absolute path."
        ),
    )
    prompt: str | None = Field(
        default=None,
        description=(
            "Domain-specific prompt file path. "
            "If not specified, uses {domain}/prompts/*.txt (convention) or library default. "
            "Can be relative (to CWD) or absolute path."
        ),
    )


# LLM and Text Processing Configuration
# ========================================================================
# LLM and Text Processing Configuration
# ========================================================================


class RetryStrategyConfig(BaseModel):
    """
    Retry strategy configuration for LLM calls.

    Supports sophisticated retry strategies with exponential backoff, custom delays,
    and error-type specific behavior for handling rate limits and transient failures.
    """

    enabled: bool = Field(
        default=True,
        description="Enable advanced retry strategy. If False, uses simple integer retries.",
    )
    strategy_type: Literal["exponential", "linear", "constant"] = Field(
        default="exponential",
        description=(
            "Retry strategy type: "
            "'exponential' (delay doubles each retry), "
            "'linear' (delay increases by fixed amount), "
            "'constant' (same delay between retries)"
        ),
    )
    initial_delay: float = Field(
        default=1.0,
        ge=0.0,
        le=60.0,
        description="Initial delay in seconds before first retry",
    )
    max_delay: float = Field(
        default=60.0,
        ge=0.0,
        le=300.0,
        description="Maximum delay in seconds between retries (caps exponential growth)",
    )
    backoff_multiplier: float = Field(
        default=2.0,
        ge=1.0,
        le=10.0,
        description="Multiplier for exponential/linear backoff (e.g., 2.0 doubles delay each retry)",
    )
    retry_on_timeout: bool = Field(
        default=True,
        description="Retry on timeout errors",
    )
    retry_on_rate_limit: bool = Field(
        default=True,
        description="Retry on rate limit errors (429)",
    )
    jitter: bool = Field(
        default=True,
        description="Add random jitter to retry delays to avoid thundering herd",
    )

class BedrockQuotaGovernorConfig(BaseModel):
    enabled: bool = Field(default=False)
    requests_per_minute: int = Field(default=100, gt=0)
    tokens_per_minute: int = Field(default=100_000, gt=0)
    max_concurrency: int = Field(default=8, ge=1, le=100)
    window_seconds: int = Field(default=60, ge=1, le=300)
    jitter_min_seconds: float = Field(default=0.2, ge=0.0, le=5.0)
    jitter_max_seconds: float = Field(default=1.5, ge=0.1, le=10.0)
    bedrock_region_prefix: str = Field(
        default="us",
        description="AWS region prefix for Bedrock model IDs (e.g., 'us', 'eu', 'ap')",
    )

class LLMConfig(BaseModel):
    """
    LLM configuration for ontology extraction.

    Supports all PydanticAI-compatible model providers:
    - Anthropic: "anthropic:claude-sonnet-4-20250514", "anthropic:claude-3-5-sonnet-20241022"
    - OpenAI: "openai:gpt-4o", "openai:gpt-4-turbo", "openai:gpt-3.5-turbo"
    - Gemini: "gemini-2.5-pro", "gemini:gemini-2.0-flash-exp"
    - Groq: "groq:llama-3-70b", "groq:mixtral-8x7b"
    - xAI: "xai:grok-2"
    - Cohere: "cohere:command-r-plus"
    - Mistral: "mistral:mistral-large"
    - Cerebras: "cerebras:llama3.1-8b"
    - OpenRouter: "openrouter:anthropic/claude-3.5-sonnet"
    - And other OpenAI-compatible providers (Ollama, DeepSeek, Together AI, etc.)

    Note: Anthropic models have a 10-minute timeout when max_tokens > 20000.

    AWS Bedrock Integration:
    - Set aws_bedrock_enabled=true to use AWS Bedrock instead of direct API
    - Requires boto3 (install with: uv sync --extra bedrock)
    - Uses AWS SDK default credential chain (env vars, ~/.aws/credentials, IAM roles)
    """

    model: KnownModelName | str = Field(
        default="google-gla:gemini-2.5-pro",
        description=(
            "Model identifier in PydanticAI format. "
            "Format: '<provider>:<model-name>' "
            "(e.g., 'openai:gpt-4o', 'anthropic:claude-3-5-sonnet'). "
            "Gemini can omit prefix (e.g., 'gemini-2.5-pro' or 'gemini:gemini-2.5-pro'). "
            "Supports: OpenAI, Anthropic, Gemini, Groq, xAI, Cohere, Mistral, Cerebras, "
            "OpenRouter, and OpenAI-compatible providers "
            "(Ollama, DeepSeek, Together AI, Perplexity, etc.)"
        ),
    )
    retries: int = Field(
        default=2,
        ge=0,
        description="Number of retry attempts (used when retry_strategy.enabled=False or as max retries)",
    )
    retry_strategy: RetryStrategyConfig = Field(
        default_factory=RetryStrategyConfig,
        description="Advanced retry strategy configuration with exponential backoff",
    )
    max_tokens: int | None = Field(
        default=100000,
        description=(
            "Maximum tokens for response. "
            "Warning: Anthropic models timeout after 10 minutes if max_tokens > 20000. "
            "Recommended: 16000 for Anthropic, 50000+ for Gemini."
        ),
    )
    temperature: float | None = Field(
        default=0.0, ge=0.0, le=2.0, description="Temperature for generation"
    )
    aws_bedrock_enabled: bool = Field(
        default=False,
        description=(
            "Enable AWS Bedrock integration. "
            "When true, uses AWS Bedrock for LLM calls instead of direct API. "
            "Requires boto3 (install with: uv sync --extra bedrock). "
            "AWS credentials: environment variables, ~/.aws/credentials, or IAM roles."
        ),
    )
    bedrock_enable_context_1m_beta: bool = Field(
        default=False,
        description="Enable Anthropic 1M context beta field for Bedrock Claude requests",
    )
    bedrock_context_1m_beta_flag: str = Field(
        default="context-1m-2025-08-07",
        description="Anthropic beta flag value sent via Bedrock additional model request fields",
    )
    bedrock_read_timeout_seconds: float = Field(
        default=300.0,
        gt=0,
        description=(
            "Read timeout in seconds for AWS Bedrock runtime requests. "
            "Use a value comfortably above the expected longest single Converse call."
        ),
    )
    bedrock_connect_timeout_seconds: float = Field(
        default=10.0,
        gt=0,
        description="Connect timeout in seconds for AWS Bedrock client connections.",
    )
    extraction_prompt_file: str | None = Field(
        default=None,
        description=(
            "Optional path to custom extraction prompt file. "
            "This is the main system prompt that defines extraction behavior. "
            "If not specified, uses built-in default. "
            "Can be relative (to CWD) or absolute path."
        ),
    )
    bedrock_quota_governor: BedrockQuotaGovernorConfig = Field(
        default_factory=BedrockQuotaGovernorConfig,
    )

class ChunkingConfig(BaseModel):
    """
    Text chunking configuration.

    Chunks are created to fit within LLM context windows while maintaining semantic coherence.
    Default values are optimized for most LLMs (5000 tokens ≈ 20KB text).
    """

    chunk_size: int = Field(
        default=5000,
        gt=0,
        description="Maximum chunk size in tokens. Larger = more context per LLM call, fewer calls",
    )
    chunk_overlap: int = Field(
        default=500,
        ge=0,
        description="Overlap between chunks in tokens. Prevents losing context at boundaries",
    )
    separators: list[str] = Field(
        default=["\n\n", "\n", ". ", " "],
        description="Separators for text splitting (priority order). Preserves semantic boundaries",
    )
    input_sharding_strategy: Literal["file", "paragraph"] = Field(
        default="file",
        description=(
            "How raw input files are segmented before chunking. "
            "'file' preserves whole-file context and lets the chunker split later. "
            "'paragraph' pre-splits on the highest-priority separator before chunking."
        ),
    )
    min_chunk_size: int = Field(
        default=100, gt=0, description="Minimum chunk size in tokens. Filters out tiny fragments"
    )
    chars_per_token_estimate: int = Field(
        default=4,
        gt=0,
        description="Character-to-token estimation multiplier. ~4 chars/token for English",
    )
    max_chunks: int | None = Field(
        default=None, description="Maximum number of chunks to create (null = unlimited)"
    )

    custom_chunking_function_file: str | None = Field(
        default=None,
        description=(
            "Optional path to Python file containing custom chunking function. "
            "If specified, loads custom chunking logic instead of default recursive splitting. "
            "Function must have signature: custom_chunk_text(text: str, chunk_size: int, chunk_overlap: int, separators: list[str], chars_per_token: float) -> list[str]. "
            "Returns list of text chunks. Falls back to default on error. "
            "Example: 'domains/travel/chunking/example_custom_splitter.py'. "
            "See domains/travel/chunking/README.md for detailed documentation."
        ),
    )

    custom_chunking_function_name: str = Field(
        default="custom_chunk_text",
        description=(
            "Name of the custom chunking function to load from custom_chunking_function_file. "
            "Defaults to 'custom_chunk_text'."
        ),
    )

    @field_validator("chunk_size")
    @classmethod
    def validate_chunk_size(cls, v: int, info: ValidationInfo) -> int:
        """Validate chunk_size >= min_chunk_size."""
        assert isinstance(v, int), "v must be an integer"
        assert info is not None, "info parameter is required"
        data = info.data or {}
        if "min_chunk_size" in data and v < data["min_chunk_size"]:
            raise ValueError(
                f"chunk_size ({v}) must be >= min_chunk_size ({data['min_chunk_size']})"
            )
        return v

    @field_validator("chunk_overlap")
    @classmethod
    def validate_chunk_overlap(cls, v: int, info: ValidationInfo) -> int:
        """Validate chunk_overlap < chunk_size."""
        assert isinstance(v, int), "v must be an integer"
        assert info is not None, "info parameter is required"
        data = info.data or {}
        if "chunk_size" in data and v >= data["chunk_size"]:
            raise ValueError(f"chunk_overlap ({v}) must be < chunk_size ({data['chunk_size']})")
        return v

CasingType = Literal["lowercase", "uppercase", "preserve"]
PunctuationHandlingType = Literal["remove", "preserve", "normalize"]

class NormalizationConfig(BaseModel):
    """Text normalization configuration."""

    casing: CasingType = Field(
        default="lowercase", description="Text casing: 'lowercase', 'uppercase', 'preserve'"
    )
    punctuation_handling: PunctuationHandlingType = Field(
        default="remove", description="Punctuation handling: 'remove', 'preserve', 'normalize'"
    )
    remove_common_words: list[str] = Field(
        default_factory=list, description="Common words to remove"
    )
    abbreviation_mappings: dict[str, str] = Field(
        default_factory=dict,
        description=(
            "Abbreviation to full-form mappings (e.g., {'NY': 'New York', 'USA': 'United States of America'}). "
            "Matching is case-insensitive and matches whole words only. "
            "Use abbreviations without punctuation in mappings (e.g., 'USA' not 'U.S.A.'). "
            "Expansions happen after possessive removal but before casing and punctuation normalization."
        ),
    )
    preserve_identifier_patterns: list[str] = Field(
        default=[
            "^[A-Z][A-Za-z0-9]*_\\d+$",
            "^[A-Z][A-Za-z0-9]*:\\d+$",
            "^[A-Z][A-Za-z0-9]*:[A-Z0-9.]+$",
        ],
        description=(
            "Regex patterns for formal ontology identifiers that should skip normalization. "
            "Default patterns match: "
            "OBO underscore format (VO_0010343, DOID_4325, NCBITaxon_186538), "
            "HPO/MONDO colon format (HP:0001234, MONDO:0000001), "
            "ICD colon format (ICD10CM:E11.9). "
            "Add custom patterns to support other ontology identifier conventions."
        ),
    )
    fuzzy_vocabulary_correction_enabled: bool = Field(
        default=True,
        description=(
            "Enable conservative correction of low-edit-distance tokens against known vocabulary. "
            "Applies only when there is a unique near match."
        ),
    )
    fuzzy_vocabulary_correction_max_edit_distance: int = Field(
        default=1,
        ge=0,
        le=2,
        description="Maximum token edit distance allowed for conservative vocabulary correction.",
    )
    fuzzy_vocabulary_correction_min_token_length: int = Field(
        default=6,
        ge=1,
        le=64,
        description="Minimum token length before conservative vocabulary correction is considered.",
    )

class TextProcessingConfig(BaseModel):
    """Text processing configuration."""

    chunking: ChunkingConfig = Field(default_factory=ChunkingConfig)
    normalization: NormalizationConfig = Field(default_factory=NormalizationConfig)


# Deduplication and Embeddings Configuration
# ========================================================================
IndexType = Literal["auto", "IndexFlatL2", "IndexIVFFlat", "IndexHNSW"]

class FAISSConfig(BaseModel):
    """FAISS index configuration."""

    threshold: int = Field(
        default=1000, gt=0, description="Use FAISS when entity count exceeds this"
    )
    index_type: IndexType = Field(default="auto", description="FAISS index type")
    top_k: int = Field(default=50, gt=0, description="Number of neighbors to search in FAISS")
    rebuild_threshold: int = Field(
        default=10000, gt=0, description="Rebuild index after N new entities"
    )
    batch_size: int = Field(
        default=100, gt=0, description="Batch size for FAISS batch search queries"
    )

class DeduplicationConfig(BaseModel):
    """
    Deduplication configuration.

    Two-stage deduplication:
    1. Exact: Hash-based deduplication (fast, deterministic)
    2. Semantic: Embedding-based similarity (slower, handles variations)
    """

    exact_threshold: float = Field(
        default=1.0,
        ge=0.0,
        le=1.0,
        description="Exact deduplication threshold (1.0 = perfect match only)",
    )
    semantic_threshold: float = Field(
        default=0.85,
        ge=0.0,
        le=1.0,
        description="Semantic similarity threshold (0.85 = 85% similar). Lower = more aggressive merging. Increased from 0.80 to prevent over-merging of similar but distinct entities.",
    )
    min_label_similarity: float = Field(
        default=0.7,
        ge=0.0,
        le=1.0,
        description="Minimum label token overlap (Jaccard) required for merging entities (0.7 = 70% token overlap). Prevents merging entities with different qualifiers (e.g., 'visa for algeria' vs 'visa for angola').",
    )
    high_semantic_similarity: float = Field(
        default=0.98,
        ge=0.0,
        le=1.0,
        description="High semantic similarity threshold - bypasses label check when exceeded (0.98 = 98% similar). Very strict to prevent merging semantically similar but factually different entities.",
    )
    enable_label_similarity_check: bool = Field(
        default=True,
        description=(
            "Enable label similarity check during semantic deduplication. "
            "When True, entities must have similar labels (token overlap) OR very high semantic similarity to merge. "
            "When False, only semantic similarity is checked (may merge entities with very different labels if embeddings are similar)."
        ),
    )
    conflict_resolution_strategy: ConflictResolutionStrategy = Field(
        default="confidence",
        description=(
            "Conflict resolution strategy: 'confidence' (pick higher confidence - recommended), 'latest' (always pick new value)"
        ),
    )

    faiss: FAISSConfig = Field(
        default_factory=FAISSConfig,
        description="FAISS index configuration for large-scale semantic search (1000+ entities)",
    )

class EmbeddingsCacheConfig(BaseModel):
    """Embeddings cache configuration."""

    directory: str = Field(default="domains/.cache", description="Cache directory path")
    file: str = Field(default="embeddings.json", description="Cache file name")
    enabled: bool = Field(default=True, description="Enable caching")

class EmbeddingsConfig(BaseModel):
    """
    Embeddings configuration using PydanticAI unified interface.

    Supports multiple providers via PydanticAI (uses KnownEmbeddingModelName):
    - OpenAI: openai:* (requires OPENAI_API_KEY)
    - Google: google-gla:*, google-vertex:* (requires GOOGLE_API_KEY)
    - Cohere: cohere:* (requires CO_API_KEY)
    - Bedrock: bedrock:* (requires AWS credentials)
    - VoyageAI: voyageai:* (requires VOYAGE_API_KEY)
    - Custom models: Any string in 'provider:model' format

    API keys are read automatically from environment variables.
    See docs/ontology/embedding_api_keys.md for details.
    """

    model: Annotated[
        KnownEmbeddingModelName | str,  # Use PydanticAI's built-in types + allow custom
        Field(
            default="google-gla:gemini-embedding-001",  # Google's stable embedding model
            description="Embedding model (PydanticAI KnownEmbeddingModelName or custom string)",
            examples=[
                "gemini-embedding-001",  # Google's newer embedding model (may not be available in all regions)
                "openai:text-embedding-3-small",
                "openai:text-embedding-3-large",
                "cohere:embed-v4.0",
                "bedrock:amazon.titan-embed-text-v2:0",
                "voyageai:voyage-3.5",
            ],
        ),
    ]

    dimension: Annotated[
        int,
        Field(
            default=3072,
            gt=0,
            description="Embedding vector dimension (gemini-embedding-001: 3072, text-embedding-3-large: 1536, text-embedding-3-small: 1536)",
            examples=[384, 768, 1024, 1536, 3072],
        ),
    ]

    task_type: Annotated[
        Literal["RETRIEVAL_DOCUMENT", "RETRIEVAL_QUERY", "SEMANTIC_SIMILARITY", "CLASSIFICATION"],
        Field(
            default="RETRIEVAL_DOCUMENT",
            description="Task type for embeddings (used by some providers for optimization)",
        ),
    ]

    batch_size: Annotated[
        int,
        Field(
            default=100,
            gt=0,
            le=1000,
            description="Batch size for embedding generation (Google limit: 100 texts/request)",
        ),
    ]

    max_batch_size: Annotated[
        int,
        Field(
            default=100,
            gt=0,
            description="Maximum batch size (safety limit to prevent OOM errors)",
        ),
    ]

    cache: Annotated[
        EmbeddingsCacheConfig,
        Field(
            default_factory=EmbeddingsCacheConfig,
            description="Embedding cache configuration to avoid re-computing embeddings",
        ),
    ]

    concurrency: Annotated[
        int,
        Field(
            default=10,
            ge=1,
            le=50,
            description="Max concurrent API calls (async mode only)",
        ),
    ]

class CoreEntityTypeConfig(BaseModel):
    """Core entity type configuration."""

    name: str = Field(default="entity", description="Entity type name")
    fields: list[str] = Field(
        default=["id", "label", "aliases"], description="Field names for this entity type"
    )
    required_fields: list[str] = Field(default=["id", "label"], description="Required field names")

class CoreRelationshipTypeConfig(BaseModel):
    """Core relationship type configuration."""

    name: str = Field(description="Relationship type name")
    is_core: bool = Field(description="True if core relationship type")
    from_type: str = Field(description="Source entity type")
    to_type: str = Field(description="Target entity type")


class StructuralScaffoldConfig(BaseModel):
    """Configuration for the deterministic structural scaffold."""

    enabled: bool = Field(
        default=True,
        description=(
            "Enable the deterministic post-schema structural scaffold. "
            "When disabled, schema evolution relies only on extracted vocabulary "
            "and relationship evidence."
        ),
    )
    parent_map: dict[str, str | None] = Field(
        default_factory=lambda: {
            "Agent": None,
            "Organization": "Agent",
            "GovernmentOrganization": "Organization",
            "EducationalOrganization": "Organization",
            "MedicalOrganization": "Organization",
            "Corporation": "Organization",
            "TradeBody": "Organization",
            "TradeUnion": "Organization",
            "Person": "Agent",
            "Role": None,
            "Place": None,
            "AdministrativeArea": "Place",
            "Event": None,
            "Application": "Event",
            "Appointment": "Event",
            "Decision": "Event",
            "Payment": "Event",
            "Process": None,
            "Activity": None,
            "InformationEntity": None,
            "DocumentType": "InformationEntity",
            "Service": None,
        },
        description=(
            "Generic scaffold parent assignments keyed by local class name. "
            "Use only cross-domain structural anchors here."
        ),
    )
    suffix_parent_map: dict[str, str] = Field(
        default_factory=lambda: {
            "organization": "Organization",
            "organisation": "Organization",
            "person": "Person",
            "role": "Role",
            "place": "Place",
            "event": "Event",
            "process": "Process",
            "activity": "Activity",
            "document": "DocumentType",
            "identifier": "InformationEntity",
            "service": "Service",
        },
        description=(
            "Suffix-to-parent rules used by the structural scaffold. "
            "Keys are matched case-insensitively against the end of a class name."
        ),
    )


class ClassAlignmentRuleConfig(BaseModel):
    """Configurable mapping from a local class to an external vocabulary URI."""

    local_type: str = Field(
        min_length=1,
        description="Local ontology class name to align.",
    )
    target_uri: str = Field(
        min_length=1,
        description="Absolute target URI in the external vocabulary.",
    )
    predicate: Literal["equivalentClass", "subClassOf", "closeMatch"] = Field(
        default="closeMatch",
        description="RDF/OWL predicate used for the class alignment.",
    )


class ClassAlignmentConfig(BaseModel):
    """Optional export-time class alignments to external vocabularies."""

    enabled: bool = Field(
        default=False,
        description=(
            "Emit configured external class alignment triples during OWL/RDF export. "
            "These mappings do not affect extraction or schema evolution."
        ),
    )
    namespace_bindings: dict[str, str] = Field(
        default_factory=dict,
        description=(
            "Optional namespace prefix bindings for external vocabulary URIs, "
            "for example {'schema': 'https://schema.org/'}."
        ),
    )
    class_mappings: list[ClassAlignmentRuleConfig] = Field(
        default_factory=list,
        description="Configured class-level mappings to external vocabularies.",
    )


# Schema and Conflict Resolution Configuration
# ========================================================================
# Schema and Conflict Resolution Configuration
# ========================================================================


class SchemaEvolutionConfig(BaseModel):
    """Schema evolution configuration."""

    type_similarity_threshold: float = Field(
        default=0.75, ge=0.0, le=1.0, description="Type similarity threshold"
    )
    initial_version: str = Field(default="1.0", description="Initial schema version")
    version_increment: str = Field(default="patch", description="Version increment strategy")
    default_entity_type: str = Field(
        default="entity", description="Default entity type when missing"
    )
    core_entity_type: CoreEntityTypeConfig = Field(
        default_factory=CoreEntityTypeConfig, description="Core entity type definition"
    )
    core_relationship_types: list[CoreRelationshipTypeConfig] = Field(
        default_factory=lambda: [
            CoreRelationshipTypeConfig(
                name="is_a", is_core=True, from_type="entity", to_type="entity"
            ),
            CoreRelationshipTypeConfig(
                name="part_of", is_core=True, from_type="entity", to_type="entity"
            ),
            CoreRelationshipTypeConfig(
                name="requires", is_core=False, from_type="entity", to_type="entity"
            ),
            CoreRelationshipTypeConfig(
                name="depends_on", is_core=True, from_type="entity", to_type="entity"
            ),
            CoreRelationshipTypeConfig(
                name="related_to", is_core=True, from_type="entity", to_type="entity"
            ),
        ],
        description="Core relationship type definitions",
    )
    default_new_type_fields: list[str] = Field(
        default=["id", "label", "aliases", "description"],
        description="Default fields for new entity types",
    )
    default_new_type_required_fields: list[str] = Field(
        default=["id", "label"], description="Default required fields for new entity types"
    )
    structural_scaffold: StructuralScaffoldConfig = Field(
        default_factory=StructuralScaffoldConfig,
        description="Deterministic post-schema structural scaffold configuration.",
    )

    @field_validator("version_increment")
    @classmethod
    def validate_version_increment(cls, v: str) -> str:
        """Validate version increment strategy."""
        assert v is None or isinstance(v, str), "v must be a string or None"
        assert cls is not None, "cls parameter is required for classmethod"
        if v not in ("patch", "minor", "major"):
            raise ValueError(
                f"Invalid version_increment: {v}. Must be 'patch', 'minor', or 'major'"
            )
        return v

class ConflictResolutionConfig(BaseModel):
    """Conflict resolution configuration."""

    strategy: str = Field(default="higher_confidence", description="Resolution strategy")
    enabled: bool = Field(default=True, description="Enable conflict resolution")

    @field_validator("strategy")
    @classmethod
    def validate_strategy(cls, v: str) -> str:
        """Validate resolution strategy."""
        assert v is None or isinstance(v, str), "v must be a string or None"
        assert cls is not None, "cls parameter is required for classmethod"
        valid_strategies = ("higher_confidence", "most_recent", "more_sources")
        if v not in valid_strategies:
            raise ValueError(f"Invalid strategy: {v}. Must be one of {valid_strategies}")
        return v

class RelationshipProcessingConfig(BaseModel):
    """Configuration for relationship processing features."""

    auto_create_missing_entities: bool = Field(
        default=True,
        description=(
            "Automatically create missing entities referenced in relationships. "
            "When enabled, prevents relationship drops due to missing entities. "
            "Created entities have lower confidence and metadata marking them as auto-created."
        ),
    )

    auto_created_entity_confidence: float = Field(
        default=0.5,
        ge=0.0,
        le=1.0,
        description="Confidence score for auto-created entities (lower indicates synthetic origin)",
    )

    auto_created_entity_default_type: str = Field(
        default="entity",
        min_length=1,
        description="Entity type assigned to all auto-created entities",
    )
# Processing and Input Configuration
# ========================================================================
                                                                          

class BatchingConfig(BaseModel):
    """
    Batching configuration for LLM processing.

    Batching multiple chunks in a single LLM call improves throughput and reduces API costs.
    Batch sizes are dynamically adjusted based on:
    - Model token limits (max_tokens)
    - Input token ratio (how much of max_tokens is available for input)
    - Actual chunk sizes
    - Model-specific recommendations (Anthropic needs smaller batches due to timeout)

    Trade-offs:
    - Larger batches = fewer API calls, lower cost, higher throughput
    - Smaller batches = more granular error handling, less memory usage
    """

    chunks_per_batch: int = Field(
        default=50,
        gt=0,
        description=(
            "Initial chunks per batch hint (only used when max_tokens not set). "
            "Dynamically adjusted based on token limits. "
            "Recommended: 8-12 for Anthropic (timeout risk), 12-20 for Gemini (high throughput)"
        ),
    )
    min_batch_size: int = Field(
        default=1, gt=0, description="Minimum batch size (safety limit to ensure progress)"
    )
    chunk_separator: str = Field(
        default="\n\n---\n\n",
        description="Separator between chunks in a batch. Helps LLM distinguish chunk boundaries",
    )
    max_batch_text_length: int | None = Field(
        default=None,
        description=(
            "Maximum batch text length in characters (safety limit). "
            "Prevents extremely long batches that may cause API timeouts."
        ),
    )
    max_batch_size_anthropic: int = Field(
        default=12,
        gt=0,
        description=(
            "Maximum batch size for Anthropic models (safety limit to avoid timeout). "
            "Anthropic has 10-minute timeout. Recommended: 12 or lower."
        ),
    )
    input_token_ratio: float = Field(
        default=0.6,
        ge=0.1,
        le=0.9,
        description=(
            "Ratio of max_tokens allocated for input (0.6 = 60% input, 40% response). "
            "Higher ratio = more input text, less response space. "
            "Recommended: 0.6-0.7 for most models."
        ),
    )
    max_input_tokens: int | None = Field(
        default=None,
        gt=0,
        description=(
            "Explicit batch input token budget. When set, batching uses this value directly "
            "instead of deriving an input budget from llm.max_tokens."
        ),
    )
    min_batch_tokens: int = Field(
        default=100,
        gt=0,
        description=(
            "Minimum tokens reserved for batch text (safety limit). "
            "Ensures at least one chunk can be processed even with large prompts."
        ),
    )
    relationship_recovery_enabled: bool = Field(
        default=True,
        description=(
            "Run a focused relationship-only recovery pass when the primary extraction returns "
            "many concepts but no relationships."
        ),
    )
    relationship_recovery_min_concepts: int = Field(
        default=20,
        gt=0,
        description=(
            "Minimum number of extracted concepts required before the relationship recovery "
            "pass can trigger."
        ),
    )
    relationship_recovery_max_entities_in_prompt: int = Field(
        default=80,
        gt=0,
        description=(
            "Maximum number of known entities to include in the relationship recovery prompt. "
            "Keeps the follow-up pass focused and within context limits."
        ),
    )
    file_level_scaffold_enabled: bool = Field(
        default=False,
        description=(
            "Run a file-level schema-first extraction pass before chunk-level extraction and "
            "inject the resulting scaffold into chunk prompts."
        ),
    )
    file_level_scaffold_max_types: int = Field(
        default=12,
        gt=0,
        description="Maximum reusable concept types to keep in each file-level scaffold summary.",
    )
    file_level_scaffold_max_relationships: int = Field(
        default=12,
        gt=0,
        description="Maximum relationship families to keep in each file-level scaffold summary.",
    )
    file_level_scaffold_max_sources_in_prompt: int = Field(
        default=3,
        gt=0,
        description=(
            "Maximum per-source scaffold summaries to inject into a single chunk-level prompt."
        ),
    )

class InputValidationConfig(BaseModel):
    """Input validation configuration."""

    max_text_length: int | None = Field(default=None, description="Maximum input text length")
    max_shards: int | None = Field(default=None, description="Maximum number of input shards")
    min_shard_length: int = Field(default=1, ge=0, description="Minimum text length per shard")
    max_shard_length: int | None = Field(default=None, description="Maximum text length per shard")
    max_file_size_mb: float | None = Field(
        default=2.0,
        gt=0.0,
        description=(
            "Maximum input file size in megabytes (MB). Files exceeding this size will be skipped. "
            "Useful for preventing memory issues with very large files. "
            "Example: 10.0 for 10MB, 100.0 for 100MB, 0.5 for 500KB."
        ),
    )

class ExportConfig(BaseModel):
    """OWL/RDF export configuration."""

    enabled: bool = Field(default=True, description="Enable OWL/RDF export after extraction")
    mode: Literal["sync", "async"] = Field(
        default="sync",
        description=(
            "Export execution mode. 'sync' blocks until OWL/Turtle export completes; "
            "'async' saves schema/graph first and finishes OWL/Turtle export in a follow-on worker."
        ),
    )
    format: str = Field(default="turtle", description="Export format: 'turtle' or 'rdfxml'")
    filename: str = Field(default="ontology", description="Output file name (without extension)")
    status_filename: str = Field(
        default="export_status.json",
        description="Status artifact written next to outputs to track OWL/RDF export progress.",
    )
    base_uri: str = Field(
        default="http://example.org/ontology",
        description="Base URI for ontology namespace (e.g., 'http://example.org/ontology')",
    )
    entity_uri_suffix: str = Field(
        default="/entity#",
        description="URI suffix for entity namespace (appended to base_uri/{domain})",
    )
    relationship_uri_suffix: str = Field(
        default="/relationship#",
        description="URI suffix for relationship namespace (appended to base_uri/{domain})",
    )
    min_property_frequency: int = Field(
        default=1,
        description=(
            "Minimum number of entities a property key must appear on to be exported as "
            "owl:DatatypeProperty. Keys appearing on fewer entities are suppressed. "
            "Set to 2 to drop hapax-legomena properties."
        ),
    )
    class_alignments: ClassAlignmentConfig = Field(
        default_factory=ClassAlignmentConfig,
        description="Optional post-build class alignments to external vocabularies.",
    )

    @field_validator("format")
    @classmethod
    def validate_format(cls, v: str) -> str:
        """Validate export format."""
        assert v is None or isinstance(v, str), "v must be a string or None"
        assert cls is not None, "cls parameter is required for classmethod"
        valid_formats = ("turtle", "rdfxml")
        if v.lower() not in valid_formats:
            raise ValueError(f"Invalid export format: {v}. Must be one of {valid_formats}")
        return v.lower()
# Output and Feature Configuration
# ========================================================================
                                                                          

class OutputConfig(BaseModel):
    """Output configuration."""

    base_directory: str = Field(default="domains", description="Base output directory")
    append_domain_name: bool = Field(
        default=True,
        description="Append domain name and output to base directory (e.g., domains/{domain}/output/)",
    )
    schema_filename: str = Field(default="schema.json", description="Schema file name")
    graph_filename: str = Field(default="graph.json", description="Graph file name")
    embeddings_directory: str = Field(default="embeddings", description="Embeddings directory name")
    embeddings_filename: str = Field(default="embeddings.json", description="Embeddings file name")
    faiss_index_filename: str = Field(
        default="embeddings_index.faiss", description="FAISS index file name"
    )
    pretty_print: bool = Field(default=True, description="Pretty-print JSON output")
    include_metadata: bool = Field(default=True, description="Include metadata in output")
    compress_output: bool = Field(default=False, description="Compress large JSON files with gzip")
    entity_id_prefix: str = Field(default="entity_", description="Entity ID prefix")
    entity_id_format: str = Field(
        default="{prefix}{counter:06d}",
        description="Entity ID format string with {prefix} and {counter} placeholders",
    )
    relationship_id_prefix: str = Field(default="rel_", description="Relationship ID prefix")
    relationship_id_format: str = Field(
        default="{prefix}{counter:06d}",
        description="Relationship ID format string with {prefix} and {counter} placeholders",
    )
    timestamp_format: str = Field(
        default="%Y-%m-%dT%H:%M:%SZ", description="Timestamp format string for strftime"
    )
    type_aware_canonical_keys: bool = Field(
        default=False,
        description=(
            "Prefix canonical keys with entity type to prevent cross-type collisions. "
            "When True, keys become '{type}__{key}' (e.g., 'Disease__diabetes'). "
            "Default False preserves backward compatibility."
        ),
    )
    export: ExportConfig = Field(
        default_factory=ExportConfig, description="OWL/RDF export configuration"
    )
    deduplication_log_filename: str = Field(
        default="deduplication.jsonl",
        description="Deduplication log filename (JSONL format)",
    )
    deduplication_summary_filename: str = Field(
        default="deduplication_summary.json",
        description="Deduplication summary filename (JSON format)",
    )
    emit_deduplication_logs: bool = Field(
        default=True,
        description="Emit deduplication logs and summary",
    )
    emit_pipeline_stage_lists: bool = Field(
        default=True,
        description="Emit entity/relationship JSONL files at each pipeline stage (raw, processed, final)",
    )

    @field_validator("deduplication_log_filename", "deduplication_summary_filename")
    @classmethod
    def validate_filename_no_path_traversal(cls, v: str) -> str:
        """Validate that filename doesn't contain path separators (prevent path traversal)."""
        assert v is not None, "Filename must not be None"
        assert isinstance(v, str), "Filename must be a string"
        assert "/" not in v, f"Filename cannot contain forward slash (/): {v}"
        assert "\\" not in v, f"Filename cannot contain backslash (\\): {v}"
        return v

class TermExtractionConfig(BaseModel):
    enabled: bool = Field(
        default=False,
        description="Enable modular term extraction stage",
    )

class FeaturesConfig(BaseModel):
    """Feature flags configuration."""

    incremental_updates: bool = Field(default=True, description="Enable incremental updates")
    cross_session_deduplication: bool = Field(
        default=True, description="Enable cross-session deduplication"
    )
    schema_evolution: bool = Field(default=True, description="Enable schema evolution")
    conflict_resolution: bool = Field(default=True, description="Enable conflict resolution")
    faiss_enabled: bool = Field(default=True, description="Enable FAISS for large datasets")
    embedding_cache: bool = Field(default=True, description="Enable embedding caching")

class LimitsConfig(BaseModel):
    """Limits and thresholds configuration."""

    max_entities: int | None = Field(default=None, description="Maximum number of entities")
    max_relationships: int | None = Field(
        default=None, description="Maximum number of relationships"
    )
    max_entity_types: int | None = Field(default=None, description="Maximum number of entity types")
    max_relationship_types: int | None = Field(
        default=None, description="Maximum number of relationship types"
    )

class ErrorHandlingConfig(BaseModel):
    """Error handling configuration."""

    continue_on_error: bool = Field(
        default=True, description="Continue processing on non-critical errors"
    )
    max_errors: int | None = Field(default=None, description="Maximum errors to collect")
    collect_severities: list[str] = Field(
        default=["error", "warning", "info"], description="Error severity levels to collect"
    )

class LoggingConfig(BaseModel):
    """Logging configuration."""

    level: str = Field(default="INFO", description="Log level")
    format: str = Field(default="rich", description="Log format")
    show_progress: bool = Field(default=True, description="Show progress bars")
    log_llm_calls: bool = Field(default=False, description="Log LLM calls")
    log_deduplication: bool = Field(default=False, description="Log deduplication details")
    log_schema_evolution: bool = Field(default=True, description="Log schema evolution")

    @property
    def log_model_calls(self) -> bool:
        """Backward-compatible alias for log_llm_calls."""
        return self.log_llm_calls

    @log_model_calls.setter
    def log_model_calls(self, value: bool) -> None:
        self.log_llm_calls = value

    @field_validator("level")
    @classmethod
    def validate_level(cls, v: str) -> str:
        """Validate log level."""
        assert v is None or isinstance(v, str), "v must be a string or None"
        assert cls is not None, "cls parameter is required for classmethod"
        valid_levels = ("DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL")
        if v.upper() not in valid_levels:
            raise ValueError(f"Invalid log level: {v}. Must be one of {valid_levels}")
        return v.upper()

    @field_validator("format")
    @classmethod
    def validate_format(cls, v: str) -> str:
        """Validate log format."""
        assert v is None or isinstance(v, str), "v must be a string or None"
        assert cls is not None, "cls parameter is required for classmethod"
        if v not in ("rich", "json", "simple"):
            raise ValueError(f"Invalid log format: {v}. Must be 'rich', 'json', or 'simple'")
        return v

class PerformanceConfig(BaseModel):
    """Performance configuration."""

    llm_cache_enabled: bool = Field(default=False, description="Enable LLM response caching")
    embedding_cache_enabled: bool = Field(default=True, description="Enable embedding caching")
    normalization_cache_enabled: bool = Field(
        default=True, description="Enable normalization caching"
    )
    max_cache_size_mb: int | None = Field(default=None, description="Maximum cache size in MB")

    @property
    def response_cache_enabled(self) -> bool:
        """Backward-compatible alias for llm_cache_enabled."""
        return self.llm_cache_enabled

    @response_cache_enabled.setter
    def response_cache_enabled(self, value: bool) -> None:
        self.llm_cache_enabled = value

class MemoryConfig(BaseModel):
    """Memory management configuration."""

    max_usage_mb: int | None = Field(
        default=None,
        description=(
            "Maximum memory usage in MB. If None, uses 80% of available RAM. "
            "Raises MemoryError if estimated usage exceeds this limit."
        ),
    )
    safety_margin_mb: int = Field(
        default=2048,
        ge=0,
        description="Safety margin in MB to reserve (default: 2GB). Added to estimated usage.",
    )
    check_available: bool = Field(
        default=True,
        description="Check available memory before loading large files. Disable to skip checks.",
    )
    warn_threshold_mb: int | None = Field(
        default=None,
        description=(
            "Warning threshold in MB. If None, uses 70% of available RAM. "
            "Warns if estimated usage exceeds this threshold."
        ),
    )

class CheckpointConfig(BaseModel):
    """Checkpointing configuration for resumable extraction."""

    enabled: bool = Field(
        default=True,
        description="Enable/disable file-level checkpointing for resumable processing.",
    )
    checkpoint_filename: str = Field(
        default="processing_checkpoint.json",
        description="Name of checkpoint file stored in output_dir/checkpoints/",
    )
    flush_interval_batches: int = Field(
        default=50,
        ge=0,
        description="Flush to disk every N batches (0=disabled, flush only at end).",
    )
    flush_timeout_seconds: int = Field(
        default=600,
        ge=0,
        description="Force flush after N seconds of accumulation (0=disabled).",
    )
    persist_state: bool = Field(
        default=False,
        description="Enable full ExtractionState persistence at key pipeline stages (opt-in feature).",
    )
    auto_resume: bool = Field(
        default=True,
        description=(
            "Automatically resume from checkpoint if available. "
            "Set to False to always start fresh extraction (useful for debugging)."
        ),
    )
    state_checkpoint_stages: list[str] = Field(
        default=["extraction", "deduplication", "schema"],
        description=(
            "Pipeline stages to checkpoint state at. "
            "Valid stages: 'chunking', 'extraction', 'deduplication', 'relationships', 'schema'. "
            "Only used if persist_state=True."
        ),
    )
    max_state_checkpoints: int = Field(
        default=3,
        ge=1,
        description="Maximum number of state checkpoints to keep per stage (oldest removed first).",
    )

class SourceGroundingConfig(BaseModel):
    """Source grounding configuration for tracking entity/relationship sources."""

    enabled: bool = Field(
        default=True,
        description=(
            "Enable source grounding to track which source file each entity/relationship came from."
        ),
    )
    source_property_name: str = Field(
        default="sourceUrls",
        description="Property name to store source identifiers in entity/relationship properties.",
    )
    fallback_source_prefix: str = Field(
        default="text_input",
        description="Prefix for synthetic source IDs when processing text input (no file).",
    )
    merge_sources_on_deduplication: bool = Field(
        default=True,
        description=(
            "When merging duplicate entities, combine their source lists (comma-separated)."
        ),
    )
    validate_source_format: bool = Field(
        default=True,
        description="Validate source identifiers are non-empty strings before storing.",
    )
    max_source_length: int = Field(
        default=1000,
        gt=0,
        description=(
            "Maximum length for a single source identifier (prevents extremely long paths)."
        ),
    )

class ResearchConfig(BaseModel):
    """Web research configuration for domain exploration."""

    num_queries: int = Field(
        default=5, ge=1, le=20, description="Number of search queries to generate"
    )
    results_per_query: int = Field(
        default=10, ge=1, le=50, description="Web results to fetch per query"
    )
    max_fetches: int = Field(
        default=50, ge=1, le=500, description="Maximum total web pages to fetch"
    )
    allowed_domains: list[str] = Field(
        default_factory=list,
        description="Restrict searches to these domains (e.g., ['.edu', '.gov'])",
    )
    blocked_domains: list[str] = Field(
        default_factory=list,
        description="Block these domains from results (e.g., ['pinterest.com', 'facebook.com'])",
    )
    http_timeout: float = Field(
        default=30.0, ge=5.0, le=120.0, description="HTTP request timeout in seconds"
    )
    rate_limit_delay: float = Field(
        default=1.0, ge=0.0, le=10.0, description="Delay between search queries in seconds"
    )
    system_prompt_file: str | None = Field(
        default=None,
        description=(
            "Path to custom system prompt file for LLM query generation. "
            "If not set or file is empty, uses default prompt. "
            "Convention: {domain}/prompts/research_system_prompt.txt"
        ),
    )
    user_prompt_file: str | None = Field(
        default=None,
        description=(
            "Path to custom user prompt template file for LLM query generation. "
            "Use {domain} and {num_queries} placeholders in the file. "
            "If not set or file is empty, uses default template. "
            "Convention: {domain}/prompts/research_user_prompt.txt"
        ),
    )

                                  
# Naming Conventions Configuration
# ========================================================================
class NamingConventionsConfig(BaseModel):
    """
    Naming convention configuration for ontology output.

    Controls casing styles for entity types, relationship types, and properties.
    Note: Validators in models.py enforce UpperCamelCase for entities and
    lowerCamelCase for relationships/properties by default.
    """

    enabled: bool = Field(
        default=True,
        description="Enable naming convention enforcement",
    )
    entity_type_casing: Literal["UpperCamelCase", "snake_case", "lowerCamelCase"] = Field(
        default="UpperCamelCase",
        description="Casing style for entity types (e.g., 'MedicalConcept' vs 'medical_concept')",
    )
    relationship_type_casing: Literal["lowerCamelCase", "snake_case", "UpperCamelCase"] = Field(
        default="lowerCamelCase",
        description="Casing style for relationship types (e.g., 'isPartOf' vs 'is_part_of')",
    )
    property_casing: Literal["lowerCamelCase", "snake_case", "UpperCamelCase"] = Field(
        default="lowerCamelCase",
        description="Casing style for property keys (e.g., 'startDate' vs 'start_date')",
    )
    entity_label_casing: Literal["preserve", "UpperCamelCase", "snake_case", "lowerCamelCase"] = (
        Field(
            default="UpperCamelCase",
            description="Casing style for entity instance labels (e.g., 'Heart Disease' vs 'HeartDisease')",
        )
    )
    spelling_variant: Literal["US", "UK", "preserve"] = Field(
        default="preserve",
        description="Spelling variant for text (US: 'color', UK: 'colour', preserve: no conversion)",
    )
    entity_label_spelling_variant: Literal["US", "UK", "preserve"] = Field(
        default="preserve",
        description="Spelling variant for entity labels only (US: 'color', UK: 'colour', preserve: no conversion). Overrides spelling_variant for entity labels if set to non-preserve value.",
    )
    entity_iri_spelling_variant: Literal["US", "UK", "preserve"] = Field(
        default="US",
        description="Spelling variant for entity IRIs (US: 'organization', UK: 'organisation', preserve: no conversion). Ensures IRI stability aligned with standards like schema.org and FOAF.",
    )
    entity_label_language_tag: str | None = Field(
        default=None,
        description="BCP 47 language tag for rdfs:label/skos:prefLabel literals (e.g. 'en-GB', 'en-US'). If None, labels are untagged plain literals.",
    )

                          
class AlignmentCheckConfig(BaseModel):
    enabled: bool = Field(
        default=True,
        description="Run the graph.json/ontology.ttl alignment check after a turtle export.",
    )
    fail_on_misalignment: bool = Field(
        default=False,
        description="Exit non-zero when entities, properties or aliases fall below 100% aligned.",
    )


# Main Configuration Model
# ========================================================================
class OntologyConfig(BaseModel):
    """
    Complete ontology generator configuration.

    This is the root configuration object that contains all settings for the ontology engine.
    All fields have sensible defaults, so you can use OntologyConfig() without any arguments.

    Configuration Priority (highest to lowest):
    1. Domain YAML config ({domain}/config.yaml) - Highest priority
    2. Pydantic defaults (Field(default=...)) - Lowest priority

    Note: API keys (GOOGLE_API_KEY, ANTHROPIC_API_KEY, etc.) are read from
          environment variables by the LLM providers, not by this config system.

    Usage:
    - Basic: config = OntologyConfig()  # Uses all Pydantic defaults
    - With domain: config = OntologyConfigLoader.load_for_domain("travel")
      # Merges travel/config.yaml with Pydantic defaults
      # Merges travel/config.yaml with Pydantic defaults
    """

    llm: LLMConfig = Field(default_factory=LLMConfig)
    text_processing: TextProcessingConfig = Field(default_factory=TextProcessingConfig)
    deduplication: DeduplicationConfig = Field(default_factory=DeduplicationConfig)
    embeddings: EmbeddingsConfig = Field(default_factory=EmbeddingsConfig)  # type: ignore[arg-type]
    schema_evolution: SchemaEvolutionConfig = Field(default_factory=SchemaEvolutionConfig)
    conflict_resolution: ConflictResolutionConfig = Field(default_factory=ConflictResolutionConfig)
    batching: BatchingConfig = Field(default_factory=BatchingConfig)
    input_validation: InputValidationConfig = Field(default_factory=InputValidationConfig)
    output: OutputConfig = Field(default_factory=OutputConfig)
    alignment_check: AlignmentCheckConfig = Field(default_factory=AlignmentCheckConfig)
    features: FeaturesConfig = Field(default_factory=FeaturesConfig)
    limits: LimitsConfig = Field(default_factory=LimitsConfig)
    error_handling: ErrorHandlingConfig = Field(default_factory=ErrorHandlingConfig)
    logging: LoggingConfig = Field(default_factory=LoggingConfig)
    performance: PerformanceConfig = Field(default_factory=PerformanceConfig)
    memory: MemoryConfig = Field(default_factory=MemoryConfig)
    checkpointing: CheckpointConfig = Field(default_factory=CheckpointConfig)
    filesystem: FilesystemConfig = Field(default_factory=FilesystemConfig)
    naming_conventions: NamingConventionsConfig = Field(
        default_factory=NamingConventionsConfig,
        description="Naming convention configuration for casing styles",
    )
    source_grounding: SourceGroundingConfig = Field(
        default_factory=SourceGroundingConfig,
        description="Source grounding configuration for tracking entity/relationship sources.",
    )
    research: ResearchConfig = Field(
        default_factory=ResearchConfig,
        description="Web research configuration for domain exploration.",
    )
    relationship_processing: RelationshipProcessingConfig = Field(
        default_factory=RelationshipProcessingConfig,
        description="Relationship processing configuration (auto-creation of missing entities)",
    )
    domain: DomainConfig | None = Field(
        default=None,
        description="Domain-specific configuration (input/prompt path overrides)",
    )
    domain_name: str | None = Field(
        default=None,
        description="Domain identifier (set automatically by load_for_domain)",
    )
    batch_api_enabled: bool = Field(
        default=False,
        description="Enable batch API optimization for LLM calls (guard flag only - no logic yet)",
    )
    prompt_caching_enabled: bool = Field(
        default=False,
        description="Enable prompt caching optimization (guard flag only - no logic yet)",
    )
    parallel_files: int = Field(
        default=1,
        ge=1,
        description="Number of files to process in parallel (guard flag only - no logic yet)",
    )
    incremental_flush: bool = Field(
        default=False,
        description="Enable incremental flushing of results (guard flag only - no logic yet)",
    )
    upper_ontology_enabled: bool = Field(
        default=False,
        description=(
            "Enable LLM-based upper ontology refinement. A deterministic structural scaffold "
            "runs after schema evolution by default and is configurable under "
            "schema_evolution.structural_scaffold; when this flag is True an additional "
            "LLM pass refines parent assignments across the extracted vocabulary."
        ),
    )
    async_file_io: bool = Field(
        default=False,
        description="Enable asynchronous file I/O operations (guard flag only - no logic yet)",
    )
    bedrock_batch_s3_bucket: str = Field(
        default="",
        description="S3 bucket for Bedrock Batch Inference input/output",
    )
    bedrock_batch_s3_prefix: str = Field(
        default="toa-batch",
        description="S3 key prefix for batch jobs",
    )
    bedrock_batch_role_arn: str = Field(
        default="",
        description="IAM role ARN for Bedrock Batch Inference",
    )
    bedrock_batch_region: str = Field(
        default="",
        description="AWS region for batch (falls back to AWS_DEFAULT_REGION if empty)",
    )
    bedrock_batch_timeout_hours: int = Field(
        default=24,
        ge=1,
        description="Batch job timeout in hours",
    )
    bedrock_batch_max_records_per_job: int = Field(
        default=50_000,
        ge=1,
        description="Max records per Bedrock batch job",
    )
    _runtime_output_dir: str | None = PrivateAttr(default=None)
    term_extraction: TermExtractionConfig = Field(default_factory=TermExtractionConfig)

    @model_validator(mode='after')
    def validate_batch_config(self) -> Self:
        """Validate Bedrock batch configuration when batch_api_enabled is True."""
        if self.batch_api_enabled:
            if not self.bedrock_batch_s3_bucket:
                raise ValueError(
                    "bedrock_batch_s3_bucket must be set when batch_api_enabled=True"
                )
            if not self.bedrock_batch_role_arn:
                raise ValueError(
                    "bedrock_batch_role_arn must be set when batch_api_enabled=True"
                )
        return self

def deep_merge(default: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    """
    Deep merge two dictionaries (iterative implementation for NASA compliance).

    Override values take precedence over default values.
    Missing keys in override are filled from default.
    Nested dicts are iteratively merged.
    Lists are replaced (not merged).

    Args:
        default: Default configuration dictionary
        override: Override configuration dictionary

    Returns:
        Merged configuration dictionary

    Examples:
        >>> default = {"a": 1, "b": {"c": 2, "d": 3}}
        >>> override = {"b": {"c": 99}}
        >>> deep_merge(default, override)
        {"a": 1, "b": {"c": 99, "d": 3}}
    """
    assert default is not None, "default must not be None"
    assert override is not None, "override must not be None"
    assert isinstance(default, dict), "default must be a dictionary"
    assert isinstance(override, dict), "override must be a dictionary"

    result = default.copy()

    # Use stack-based iteration instead of recursion (NASA01 compliance)
    # Stack contains tuples of (target_dict, override_dict, path_for_debugging)
    # Use stack-based iteration instead of recursion (NASA01 compliance)
    # Stack contains tuples of (target_dict, override_dict, path_for_debugging)
    stack: list[tuple[dict[str, Any], dict[str, Any], str]] = [(result, override, "root")]

    while stack:
        target, source, path = stack.pop()

        for key, value in source.items():
            current_path = f"{path}.{key}"

            if key in target and isinstance(target[key], dict) and isinstance(value, dict):
                # Both are dicts - need to merge them
                # Push onto stack for processing
                # Both are dicts - need to merge them
                # Push onto stack for processing
                stack.append((target[key], value, current_path))
            else:
                                                 
                                                
                # Override value (or add new key)
                # Lists are replaced, not merged
                target[key] = value

    return result

class OntologyConfigLoader:
    """
    Configuration loader for ontology engine.

    This class provides static methods for loading configuration in different scenarios:
    - load(): Load with Pydantic defaults only
    - load_for_domain(): Load for a specific domain with YAML overrides

    Features:
    - Pydantic-based defaults (no external YAML required)
    - Domain-specific YAML overrides via deep merging
    - Comprehensive validation with clear error messages

    Architecture:
    1. Pydantic defaults are defined in Field(default=...) for each config class
    2. Domain YAML configs ({domain}/config.yaml) override defaults via deep merge
    3. All values are validated by Pydantic at instantiation time
    4. API keys are read from environment variables by LLM providers (not by this config)

    Examples:
        # Load with Pydantic defaults only
        # Load with Pydantic defaults only
        config = OntologyConfigLoader.load()

        # Load for specific domain (merges domain YAML with defaults)
        # Load for specific domain (merges domain YAML with defaults)
        config = OntologyConfigLoader.load_for_domain("travel")

        # Direct instantiation (same as load())
        # Direct instantiation (same as load())
        config = OntologyConfig()
    """

    @staticmethod
    def _load_config_file(config_path: Path, allow_empty: bool = False) -> dict[str, Any]:
        """
        Load and parse domain-specific config file (YAML).

        Args:
            config_path: Path to config file
            allow_empty: If True, allow empty config files (domain configs can be empty)

        Returns:
            Config dictionary

        Raises:
            ValueError: If config file is invalid or cannot be parsed
        """
        assert config_path is not None, "config_path parameter is required"
        assert isinstance(config_path, Path), "config_path must be a Path object"
        try:
            config_content = safe_read_file(config_path)
            data = yaml.safe_load(config_content)
        except yaml.YAMLError as e:
            raise ValueError(
                f"Failed to parse domain config file {config_path}: {e}\n"
                f"Check that the file is valid YAML."
            ) from e
        except (OSError, FileNotFoundError) as e:
            raise OSError(
                f"Failed to read domain config file {config_path}: {e}\n"
                f"Check file permissions and path."
            ) from e

                                                                                      
        # Handle None (empty file with only comments) - treat as empty dict if allowed
        if data is None:
            if allow_empty:
                return {}
            raise ValueError(
                f"Domain config file is empty\n"
                f"File: {config_path}\n"
                f"Add configuration overrides or delete the file to use defaults."
            )

        if not isinstance(data, dict):
            raise ValueError(
                f"Domain config file must contain a dictionary, got {type(data)}\n"
                f"File: {config_path}"
            )

        return data if data else {}

    @staticmethod
    def load() -> OntologyConfig:
        """
        Load and validate ontology configuration.

        Uses Pydantic defaults only. No external YAML file required.

        Returns:
            Validated OntologyConfig instance with Pydantic defaults

        Examples:
            >>> config = OntologyConfigLoader.load()
            >>> # Uses all Pydantic defaults from config.py
        """
        config = OntologyConfig()
        assert config is not None, "Config must not be None"
        assert isinstance(config, OntologyConfig), "Config must be OntologyConfig instance"
        return config

    @staticmethod
    def load_for_domain(domain: str) -> OntologyConfig:
        """
        Load configuration for a specific domain with deep merging.

        Merges:
        1. Pydantic model defaults (built-in sensible defaults)
        2. {domain}/config.yaml (domain-specific overrides, if exists)

        Args:
            domain: Domain identifier (folder name)

        Returns:
            Validated OntologyConfig instance with merged configuration

        Raises:
            FileNotFoundError: If domain folder doesn't exist
            ValueError: If config file is invalid or missing required parameters
            ValidationError: If config values don't match schema

        Examples:
            >>> config = OntologyConfigLoader.load_for_domain("travel")
            >>> # Uses travel/config.yaml overrides merged with Pydantic defaults
        """
        from pathlib import Path

        from taxonomy_ontology_accelerator.ontology_engine.utils.domain_resolver import (
            DomainResolver,
            sanitize_domain_name,
        )

        assert domain, "Domain must not be empty"
        assert isinstance(domain, str), "Domain must be a string"

        # Sanitize domain name first (security)
        # Sanitize domain name first (security)
        domain = sanitize_domain_name(domain)

                                       
        # Validate domain folder exists
        DomainResolver.validate_domain_folder(domain)

        # Step 1: Create base config from Pydantic defaults
        # Step 1: Create base config from Pydantic defaults
        base_config = OntologyConfig()

        # Step 2: Load domain-specific config (if exists)
        # Step 2: Load domain-specific config (if exists)
        domain_config_path = Path("domains") / domain / "config.yaml"

                                
        # Load and merge configs
        return OntologyConfigLoader._load_and_merge_domain_config(
            domain, domain_config_path, base_config
        )

    @staticmethod
    def _load_and_merge_domain_config(
        domain: str,
        domain_config_path: Path,
        base_config: OntologyConfig,
    ) -> OntologyConfig:
        """Load and merge domain-specific config with base config."""
        from taxonomy_ontology_accelerator.commons.io.fsspec_utils import get_default_filesystem

        fs = get_default_filesystem()

        assert domain, "Domain must not be empty"
        assert isinstance(base_config, OntologyConfig), "base_config must be an OntologyConfig"
        domain_config_dict: dict[str, Any] = {}

        if fs.exists(str(domain_config_path)):
            # Don't log here - logging happens in extractor.py after banner
            # Don't log here - logging happens in extractor.py after banner
            try:
                domain_config_dict = OntologyConfigLoader._load_config_file(
                    domain_config_path, allow_empty=True
                )
            except ValueError as e:
                # Parsing error - should fail
                # Parsing error - should fail
                raise ValueError(f"Invalid YAML in domain config {domain_config_path}: {e}") from e
            except OSError as e:
                                                          
                # File exists but can't read - should fail
                raise OSError(f"Cannot read domain config {domain_config_path}: {e}") from e

        # If no domain config exists or it's empty, just use base config
        # If no domain config exists or it's empty, just use base config
        if not domain_config_dict:
                                        
            # Set domain_name and return
            base_config.domain_name = domain
            return base_config

        # Step 3: Convert base config to dict for merging
        # Step 3: Convert base config to dict for merging
        base_config_dict = base_config.model_dump(mode="json", exclude_none=False)

                                                            
        # Step 4: Deep merge configs (domain overrides base)
        merged_config_dict = deep_merge(base_config_dict, domain_config_dict)

        # Step 5: Add domain-specific config if present in domain config
        # Step 5: Add domain-specific config if present in domain config
        if "domain" in domain_config_dict:
                                                                                  
            # Domain config can have a 'domain' section for input/prompt overrides
            merged_config_dict["domain"] = domain_config_dict["domain"]

        # Step 6: Set domain_name
        # Step 6: Set domain_name
        merged_config_dict["domain_name"] = domain

                                     
        # Step 7: Validate and return
        try:
            return OntologyConfig(**merged_config_dict)
        except ValidationError as e:
            config_ref = domain_config_path if fs.exists(str(domain_config_path)) else "base config"
            raise ValueError(
                f"Invalid configuration for domain '{domain}':\n{e}\nCheck {config_ref}"
            ) from e
