"""Default prompts for ontology extraction engine."""

FILE_LEVEL_SCAFFOLD_PROMPT = """
# File-Level Scaffold Extraction

Extract only a provisional schema-first scaffold from the full file context.

Priorities:
- Reusable classes and subclass families
- Reusable relationship families
- Broad-to-specific ontology structure

Deprioritize:
- Repeating many route/page-specific individuals
- Purely narrative details
- Page/container artefacts

Output rules:
- Reuse candidate classes when several concepts clearly belong to the same reusable family
- Prefer relation families like `requires`, `appliesTo`, `issuedBy`, `permits`, `prohibits`
  over endpoint-qualified variants
- Emit only the concepts and relationships needed to form a compact scaffold
- Keep the output grounded in the text; do not invent domain concepts not supported by the file
"""

OWL_CONSTRAINT_EXTRACTION = """
## OWL Constraints Extraction (Advanced)

When extracting entities and relationships, also identify OWL constraints from the text:

### Property Characteristics (for relationships):

Add to `characteristics` field when the characteristic genuinely holds for the relationship type:

- **Functional**: Each subject has at most one object for this property
  - Example: "Each certificate has exactly one issuer" → Functional
  - Example: "Each person has one birth country" → Functional

- **InverseFunctional**: Each object has at most one subject for this property
  - Example: "Each unique ID identifies at most one entity" → InverseFunctional

- **Transitive**: If A→B and B→C, then A→C
  - Example: "locatedIn" — if X is in Y and Y is in Z, X is in Z → Transitive
  - Example: "partOf" is transitive

- **Symmetric**: If A→B then B→A
  - Example: "relatedTo", "marriedTo" → Symmetric

- **Asymmetric**: If A→B then NOT B→A
  - Example: "requires", "replacedBy", "parentOf" → Asymmetric

- **Irreflexive**: Nothing is related to itself via this property
  - Example: "requires", "replacedBy" — a thing cannot replace itself → Irreflexive

- **Reflexive**: Every entity is related to itself via this property (rare — use with care)

### Inverse Relationships (for relationships):

Add `inverse_of` when a meaningful inverse exists:
- "requires" → inverse_of: "isRequiredBy"
- "replacedBy" → inverse_of: "replaces"
- "issuedBy" → inverse_of: "issues"
- "partOf" → inverse_of: "hasPart"
- "locatedIn" → inverse_of: "contains"
- DO NOT use auxiliary verb prefix — prefer "issuedBy" not "isIssuedBy"

### Cardinality and Value Constraints (for entity types, added to `restrictions` field):

Supported restriction_type values:

- **someValuesFrom**: Entity must have at least one value from class X
  - Example: "Every contract requires at least one signatory" →
    {"property": "requires", "restriction_type": "someValuesFrom", "on_class": "Person"}

- **allValuesFrom**: All values for this property must be from class X
  - Example: "A report can only be issued by a GovernmentDepartment" →
    {"property": "issuedBy", "restriction_type": "allValuesFrom", "on_class": "GovernmentDepartment"}

- **hasValue**: Entity must have this specific individual as a value

- **minCardinality**: Entity must have at least N values for this property
  - Example: "A company must have at least 1 director" → minCardinality=1

- **maxCardinality**: Entity must have at most N values for this property
  - Example: "A person can have at most 1 spouse" → maxCardinality=1

- **cardinality**: Entity must have exactly N values
  - Example: "Every person has exactly 2 biological parents" → cardinality=2

- **Qualified variants** (use on_class for target class):
  - minQualifiedCardinality, maxQualifiedCardinality, qualifiedCardinality

**How to capture these:**

1. For relationships, add to `characteristics` field: `["Functional", "Asymmetric", "Irreflexive"]`
2. For relationships, add `inverse_of` field if inverse is meaningful
3. For entities, add to `restrictions` field as dict:
   ```json
   {
     "property": "requires",
     "restriction_type": "someValuesFrom",
     "on_class": "Document"
   }
   ```
- The `property` in every restriction MUST exactly match a relationship type you emit in
  this extraction output.
- Use class or `concept_type` names in restriction class positions such as `on_class` or
  `value` for `someValuesFrom` / `allValuesFrom`.
- Do NOT put a named individual label, page title, or document instance label in a
  restriction class position.
- Do NOT invent restriction-only properties such as `hasFee`, `hasDocument`, or
  `hasCondition` when a reusable relationship type like `requires`, `appliesTo`,
  `hasRequirement`, or `hasTemporalConstraint` already expresses the link.
- If you use an inverse property in a restriction, that inverse must also appear in the
  relationship vocabulary via `inverse_of`.

### Class Hierarchy via is_a Relationships:

To express that one concept type is a subtype of another, emit an `is_a` relationship
between representative instances. The pipeline's schema evolver infers the class hierarchy
from the concept_types of the source (child) and target (parent):

  Example: {"type": "is_a", "source_label": "savings account", "target_label": "bank account"}
  → If savings_account has concept_type "SavingsAccount" and bank_account has concept_type
    "BankAccount", the schema evolver emits: SavingsAccount rdfs:subClassOf BankAccount

Multiple superclasses (multiple inheritance): emit multiple `is_a` relationships from the same entity.
  Example: A ResearchArticle is_a Publication AND is_a AcademicWork → emit both is_a relationships.

Hierarchy quality rules:
- Do NOT emit `is_a` when the source and target would have the same `concept_type`.
- same-type `is_a` links create flat or meaningless hierarchies.
- Emit `is_a` only when the child is genuinely more specific than the parent and their
  `concept_type` values are different.
- Substitution test: only emit `is_a` if the statement "Every X is a Y" would be true,
  where X is the child and Y is the parent. If you are unsure about direction, do NOT emit it.
- Do NOT use `is_a` merely to state that an individual belongs to its own concept_type.
  The entity's `concept_type` already carries that typing; use `is_a` only for class hierarchy.
- The representative entities used for `is_a` must actually exemplify the class being linked.
  Do NOT use a guide page, form page, service page, or document container as a stand-in for
  a broader class unless the text explicitly models it that way.
- Do NOT treat a page title, URL, heading, or navigation label as a domain concept unless
  the text is genuinely defining a reusable concept rather than merely naming content.

Ontological grouping — permitted inference:
When you identify multiple extracted entities whose `concept_type` values clearly form natural
subtypes of the same abstract category, you SHOULD emit an abstract grouping entity with that
parent `concept_type` and connect the concrete types to it via `is_a`. This is ontological
inference, not hallucination — it is expected and required for a well-formed ontology.

  Example: If you have extracted entities with concept_types "SafetyInspection",
  "QualityInspection", and "ComplianceInspection", you SHOULD:
  1. Create an abstract entity with concept_type "Inspection" (e.g., label: "inspection")
  2. Emit is_a relationships: safety_inspection is_a inspection, quality_inspection is_a
     inspection, compliance_inspection is_a inspection

  Common groupings to look for (shared suffixes, semantic families):
  - Multiple XInspection, YInspection → group under Inspection
  - Multiple XDocument, YDocument → group under Document
  - Multiple XPolicy, YPolicy → group under Policy
  - Multiple XFee, YFee → group under Fee
  - Semantically related types with a clear common parent

Restriction integrity rules:
- Use `property` names that match relationship types present in this extraction output
- Use `on_class` values that match concept_type values present in this extraction output
- If a referenced property or class is missing from this extraction, do not emit that restriction

Only extract constraints that are explicitly stated or clearly implied by the domain text.

### CRITICAL: restrictions[] vs Relationship Triples

**restrictions[] is for type-level (class) axioms only.**
Use `restrictions[]` ONLY when the range target is a class name (a concept_type), not a specific
named individual that already appears in your extraction output.

If BOTH the source entity AND the target entity appear as named individuals in your extraction,
you MUST express the link as a relationship triple (in the relationships section) — NOT as a
restriction.

Examples:
❌ WRONG — ScaleupRoute.restrictions: [{property:"requires", restriction_type:"someValuesFrom",
           on_class:"ApplicationForm"}] when ApplicationForm is a named individual in the output.
✅ RIGHT  — emit a relationship: {from_: "scaleup route", to: "application form", type: "requires"}

Emitting a restriction instead of a relationship triple when both endpoints are named individuals
will result in ZERO relationships in the graph. Always prefer relationship triples when the
target is a specific named individual.
"""

DEFAULT_ONTOLOGY_PROMPT = (
    """# Ontology Extraction System

Extract structured knowledge from text as entities, relationships, and properties. This is a domain-agnostic system that works across any domain.

## Core Principles

1. **Zero Information Loss**: Capture ALL information mentioned in the text - every attribute, specification, condition, and detail must be preserved in properties
2. **Precision**: Extract only meaningful, trackable entities - not every word or generic term
3. **Connectivity**: Build a well-linked graph with minimal orphaned entities (< 15% target)
4. **Accuracy**: Extract ONLY what is explicitly stated in the text - NO hallucination, NO inference of entities not directly mentioned
   - If text says "damage to infrastructure", do NOT extract "Public Infrastructure" as an entity
   - Only extract entities that are clearly named, defined, or discussed in the text
   - Do NOT generalize passing mentions into standalone entities
5. **Source Grounding**: Every entity and relationship must include source attribution
6. **OWL Constraints**: Extract property characteristics and cardinality constraints when mentioned (see OWL Constraints section below)

---

"""
    + OWL_CONSTRAINT_EXTRACTION
    + """

---

## Ontology Design Principles

Apply these principles when making extraction decisions. They improve the quality and
reusability of the resulting OWL ontology.

### Concept Type Decisions

The `concept_type` field maps directly to an OWL Class. Choose types that are:
- **Specific and meaningful** — not generic placeholders. NEVER use: `entity`, `thing`,
  `object`, `item`, `concept`, `resource`, `node`, `element`, `misc`, `other`, `unknown`
- **Singular UpperCamelCase**: `Organization`, `ServiceRoute`, `ApplicationFee`
- **Consistent across chunks**: once you assign `Organization` to an entity of this kind,
  use the exact same string for all similar entities across the entire text
- **Reused, not invented**: prefer reusing an existing type over creating a new near-synonym
- **Anchored to established vocabulary where applicable** — for universal concepts,
  prefer type names matching widely-used vocabularies: `Organization` (schema.org/FOAF),
  `Person` (schema.org/FOAF), `Document` (schema.org), `Place` (schema.org) — improves
  interoperability without requiring full namespace alignment

#### Concept Type Anti-Patterns — DO NOT create these:

- **Role-based types**: `SeniorEmployee`, `LeadSurgeon`, `RegisteredPatient`
  → INSTEAD: use `Person` (or `Organisation`) and capture the role in properties or via
  an `is_a` relationship to a `Role` entity.

- **Instance-qualified types**: `CommercialLoan`, `ResidentialProperty`, `PedestrianBridge`
  → INSTEAD: use `Loan`, `Property`, `Bridge` and distinguish via properties.
  If a structural subtype is warranted, emit an `is_a` relationship to express it.

- **Compound entity-attribute types**: `MonthlyPaymentAmount`, `SubmissionDeadlineDate`
  → INSTEAD: use `Payment` / `Deadline` etc. and store the qualifying detail as a property.

- **OWL infrastructure terms**: `Individual`, `Class`, `Thing`
  → NEVER use as concept_type. Assign a meaningful domain type instead.

A good test: "Would an ontology engineer define this as a distinct OWL class, or is it
an instance of an existing class with specific property values?" If the latter, use the
existing class.

- Do NOT create an individual whose label is just the class name unless the text provides
  instance-specific facts that make it a real domain instance rather than a schema exemplar.
- Do NOT emit an abstract grouping class as a standalone named entity merely to attach
  descriptions, aliases, or source references. Put those facts on the class and keep the
  graph layer for real domain instances.

### Hierarchy First

- Prefer a layered class system over a flat list of unrelated top-level types.
- If several extracted concepts could share a broader reusable parent, introduce or reuse that
  parent and connect the specific concepts to it via `is_a` before inventing more relationship
  types.
- If you extract many concepts but zero relationships, the output is probably under-connected.
  Re-read the text and emit the explicit or strongly implied relationships linking those
  concepts before returning.
- Do NOT leave many named entities typed directly as a very broad class when a narrower reusable
  class is clearly supported by the text.
- If several entities would otherwise all be direct members of `Requirement`, `InformationEntity`,
  `Service`, `Organization`, or `Place`,
  first introduce or reuse the narrower shared class they exemplify, then type the entities under
  that narrower class.
- If you find yourself using a generic range like `entity`, that usually means the class
  hierarchy is underspecified. Reuse or introduce a broader class such as `Place`,
  `Organization`, `DocumentType`, `Activity`, `Event`, or `Service` when the text supports it.
- Avoid ambiguous standalone classes like `Concept`, `Object`, `Item`, or `Thing`; choose the
  smallest meaningful reusable abstraction instead.

### Data Properties vs Object Properties

Prefer creating a **typed entity** linked via a **relationship** over storing a value as
a flat data property, when the value:
- Could be referenced by multiple other entities
- Has its own meaningful attributes
- Is a named concept in the domain (a fee, a requirement, a document type)

PREFER:
  ApplicationFee [entity, concept_type: "Fee"]
    amount: "£319"
  planning_application --[requires]--> application_fee

AVOID:
  planning_application.applicationFee: "£319"  ← loses the Fee entity's identity and reusability

Data properties remain appropriate for simple scalar values: URLs, boolean flags,
duration strings, free-text descriptions that are not entities.

### Generic Object Properties

Prefer generic, reusable relationship types whose scope is narrowed by class restrictions,
not by embedding the class name in the property name:

  PREFER: `requires` (used for Service→Document, Application→EligibilityRequirement, etc.)
  AVOID:  `requiresDocument`, `requiresEligibilityRequirement`
  Do NOT create both `permits` and `permitsActivity` when class restrictions can express
  the difference more cleanly.
  If the text suggests only an endpoint-qualified verb such as `permitsApplication`,
  `providesService`, or `requiresDocument`, emit the reusable base predicate
  (`permits`, `provides`, `requires`) unless the longer form has genuinely different semantics.

Express the class constraint formally via `restrictions[]` on the entity.

### Multiple Inheritance

A concept can have more than one supertype. Emit multiple `is_a` relationships from the
same entity to express this. Example: a ResearchArticle is both a Publication and an
AcademicWork — emit is_a relationships to both.

### Axiom Placement

Place shared constraints at the most general applicable type so subclasses inherit them.
Do not repeat the same restriction on every subclass if it can be placed on the parent.

### Property Naming

- Relationship types: lowerCamelCase, no redundant auxiliary verbs
  USE: `issuedBy`, `requires`, `locatedIn`
  AVOID: `isIssuedBy`, `isRequiredBy`, `isLocatedIn`
- Property keys: lowerCamelCase
- concept_type: UpperCamelCase, singular

---

## Sequential Extraction Process

### STEP 0: Source Identification (MANDATORY)

**Action:**
- Locate `SOURCE_URLS: <identifier>` markers in the input text
- If multiple sources exist, track which entities/relationships come from which source
- If no source marker found, use `"unknown_source"` as fallback
- **CRITICAL**: Include `source_urls` in properties of EVERY entity and relationship

**Output:**
- Source identifier string to be used in all `properties.source_urls` fields

---

### STEP 1: Extract All Entities with Properties

**FIRST**: Extract ALL entities from the input text along with their properties. Do NOT extract relationships yet.

**CRITICAL REQUIREMENTS:**
- You MUST extract EVERY entity mentioned in the text that meets the entity criteria
- You MUST capture ALL properties for each entity - do not skip details
- You MUST scan the ENTIRE text multiple times to ensure nothing is missed
- Incomplete extraction is NOT acceptable - be thorough and comprehensive

#### What is an Entity?

An entity is a **distinct, trackable concept** that is **explicitly mentioned or clearly defined** in the text and meets ALL of these criteria:
- Has a **specific identity** (proper noun, named thing, or well-defined concept that is actually discussed in the text)
- Represents something that can be **referenced independently** in relationships
- Carries **meaningful information** beyond generic descriptors
- Can be **categorized** into a meaningful type
- **CRITICAL**: Is actually discussed, named, or defined in the text - NOT just mentioned in passing or as part of another concept

#### Entity Examples from Different Domains (EXTRACT):

**Medical Domain:**
- Named things: "John Smith" (person), "Mayo Clinic" (organization)
- Specific concepts: "Type 2 diabetes" (condition), "MRI scan" (procedure), "Aspirin" (medication)
- Well-defined categories: "Cardiac surgery" (procedure type), "FDA approval" (regulatory status)

**Legal Domain:**
- Named things: "Supreme Court" (organization), "California" (location)
- Specific concepts: "Copyright law" (regulation), "Patent application" (process), "Contract breach" (legal concept)
- Well-defined categories: "Trial procedure" (process), "Legal requirement" (requirement type)

**Technical Domain:**
- Named things: "Microsoft Corporation" (organization), "Python" (technology)
- Specific concepts: "API endpoint" (technical concept), "Database schema" (structure), "Authentication protocol" (process)
- Well-defined categories: "Software framework" (technology type), "Security standard" (standard type)

**Business Domain:**
- Named things: "Amazon" (organization), "New York Stock Exchange" (organization)
- Specific concepts: "Supply chain" (process), "Market analysis" (activity), "Revenue model" (business concept)
- Well-defined categories: "Business process" (process type), "Financial metric" (metric type)

**General Patterns:**
- Organizations, agencies, institutions
- Locations (countries, regions, cities, facilities)
- People (when specifically named)
- Products, services, technologies
- Processes, procedures, methods
- Regulations, laws, standards
- Documents, certificates, permits
- Events, activities, concepts

#### NOT Entities (DO NOT EXTRACT):

- Generic descriptors: "good", "important", "many", "several", "various"
- Pure attribute values: "6 months" (this is a property, not an entity - extract the thing it describes)
- Vague references: "it", "they", "this", "that", "these"
- Common adjectives: "large", "small", "fast", "slow" (unless they represent named concepts)
- Generic verbs: "manage", "process", "handle" (unless they represent named processes)
- Abstract qualities without identity: "quality", "efficiency" (unless they're trackable concepts)
- **Infrastructure Context**: Do NOT extract concepts about the data processing pipeline, semantic extraction, embedding vectors, graph databases, or this extraction mechanics (e.g. "embedding vector chunk", "pipeline stage"). Only extract domain concepts.
- **Passing mentions**: If something is only mentioned as part of another concept (e.g., "damage to infrastructure" where infrastructure is not the topic), do NOT extract it as a standalone entity
- **Inferred concepts**: Do NOT extract concepts that you think are relevant but are not actually discussed in the text

#### Entity Extraction Process:

1. **Scan systematically**: Read the entire text comprehensively:
   - All sentences and paragraphs
   - All headers and subheaders (often contain key entity names)
   - All lists (bulleted, numbered, comma-separated, "including X, Y, Z")
   - All tables and structured data (extract entities from table cells)
   - All footnotes, captions, and annotations
   - All metadata and references

2. **Identify candidates**: Look for and mark:
   - All proper nouns (capitalized words/phrases that represent specific entities)
   - All named concepts (specific, identifiable concepts with clear meaning)
   - All items in lists (when text lists items, extract each item if it meets entity criteria)
   - All organizations, agencies, institutions mentioned
   - All locations (countries, regions, cities, areas, facilities)
   - All documents, certificates, permits, requirements mentioned
   - Entities mentioned in headers, tables, or structured formats

3. **Filter carefully**: Apply the entity criteria - is it trackable? Does it have identity? Is it a meaningful concept?

4. **Extract comprehensively**: For each valid entity, capture:
   - Normalized label (lowercase, expanded abbreviations)
   - Appropriate concept_type (domain-agnostic type)
   - Clear description (1-2 sentences explaining what it is)
   - ALL aliases and variations mentioned in text
   - ALL properties and attributes mentioned about this entity (see Property Extraction below)

#### Property Extraction for Entities - ZERO INFORMATION LOSS:

**MANDATORY**: For EACH entity, you MUST follow this systematic approach and extract ALL properties:

1. **Identify ALL mentions**: Find EVERY occurrence of the entity (by name, alias, abbreviation, or reference) in:
   - Every sentence and paragraph
   - Every header and subheader
   - Every table cell and structured data
   - Every footnote, caption, and annotation
   - Every list and enumeration

2. **Scan context systematically**: For EACH mention, read:
   - The sentence containing the mention
   - Adjacent sentences (before and after)
   - The entire paragraph
   - Related sections or headers

3. **Extract ALL details**: From EACH context, extract EVERY detail mentioned about the entity - do not skip anything

4. **Cross-reference entire text**: After finding all mentions, scan the ENTIRE text again to find any information about this entity that might appear in different sections, headers, footnotes, or tables

5. **Aggregate distributed information**: If information about the same entity appears in multiple places (even far apart), combine ALL details into the entity's properties

6. **Verify completeness**: After extraction, verify that ALL information about the entity from across the ENTIRE text is captured - missing details is NOT acceptable

**What to Extract as Properties:**
Look for and capture ALL of the following when mentioned about an entity:

- **Numeric values**: Any numbers mentioned (amounts, counts, percentages, distances, phone numbers, years, dates, quantities, measurements, sizes, capacities)
- **Temporal information**: Any dates, timeframes, durations, deadlines, frequencies, time periods mentioned (specific dates, months, years, "within X days", "before Y", "after Z")
- **Contact information**: Phone numbers, helpline numbers, emergency numbers, email addresses, contact details, website URLs
- **Status information**: Open/closed status, active/inactive state, availability, banned/prohibited status, operational status
- **Conditions and exceptions**: Special cases, exemptions, conditional requirements, "except when" clauses, "except for" patterns
- **Requirements and specifications**: Entry requirements, document requirements, criteria, standards, restrictions, qualifications
- **Qualitative attributes**: Status, condition, state, category, classification, type, level, grade, rating
- **Contextual information**: Location, jurisdiction, scope, applicability, context, domain, area

**Property Key Naming**: Use clear, descriptive property keys (e.g., `validity_period` not `valid`, `phone_number` not `phone`, `training_hours_required` not `hours`). Property values should preserve the original information format from the text.

**CRITICAL PRINCIPLE**: If the text provides ANY information about an entity (numbers, dates, status, requirements, etc.), you MUST capture it in properties. Missing properties is a FAILURE. Some entities may have minimal information in the text - that's acceptable ONLY if you've verified the text truly has no more information. But if information is mentioned ANYWHERE in the text, it MUST be captured.

#### Entity Structure:

```json
{
  "label": "normalized_name",           // lowercase, expanded abbreviations, no punctuation
  "concept_type": "entity_type",        // domain-appropriate type (e.g., "location", "organization", "process")
  "description": "clear explanation",   // 1-2 sentences defining what this entity is
  "aliases": ["abbrev", "alt_name"],   // ALL name variations, abbreviations, alternative forms
  "properties": {
    "source_urls": "source_id",        // MANDATORY - from STEP 0
    "attribute1": "value1",             // EVERY attribute, specification, detail mentioned
    "attribute2": "value2"              // Zero information loss - capture everything
  },
  "restrictions": [                     // OPTIONAL - OWL cardinality/value constraints
    {
      "property": "relationship_type",
      "restriction_type": "cardinality",
      "value": 2
    }
  ],
  "confidence": 0.95                    // 0.9-1.0: explicit mention, 0.7-0.8: clearly implied
}
```

#### Normalization Rules:

- Convert labels to lowercase
- Expand abbreviations only when the full form is clear from context: "API" → "application programming interface", "USA" → "united states"
- Remove punctuation from labels
- Use consistent naming conventions
- Merge obvious duplicates (same entity with different capitalization/spacing)
- For `concept_type`, prefer meaningful domain terms and avoid placeholder types like "Entity", "Thing", "Object", "Concept", "Unknown", "Error", "Misc"
- If a type is uncertain, reuse the nearest meaningful existing type instead of inventing placeholder types

#### Abbreviation Mapping:

When encountering abbreviated forms alongside full forms, link them correctly:

✓ Link (same entity):
  - "NATO" ↔ "north atlantic treaty organization" (canonical abbreviation)
  - "NYC" ↔ "new york city" (well-known abbreviation)
  - "Dr Smith" ↔ "Doctor Smith" (title abbreviation)

✗ Don't link (different entities):
  - "Entity0" ↔ "Entity1" (distinct IDs, not abbreviations)
  - "Paris Hotel" ↔ "Paris" (related but separate entities)
  - "FastPass" ↔ "Fast Pass System" (variant name, context-dependent)

Only merge when the abbreviated form is clearly the same entity as the full form.

**CRITICAL**: Complete STEP 1 fully before moving to STEP 2. Extract ALL entities with ALL their properties first.

---

### STEP 2: Establish Relationships Between Entities

**ONLY AFTER** all entities have been extracted in STEP 1, parse the entire input text again to establish relationships between the extracted entities along with their relationship properties.

**CRITICAL REQUIREMENTS:**
- You MUST extract relationships for ALL pairs of entities that co-occur or are related
- You MUST be aggressive in finding connections - most co-occurring entities have relationships
- You MUST capture ALL relationship properties - do not skip contextual details
- Orphan rate MUST be below 15% - if higher, you are missing relationships

#### What is a Relationship?

A relationship is a **meaningful connection** between two entities where:
- Both entities exist in your extracted entity list from STEP 1
- The connection is **stated explicitly** or **clearly implied** from context
- The relationship can be **described** with a specific verb or phrase

**"Clearly Implied"**: A relationship is clearly implied if entities are mentioned together in a way that suggests connection (same sentence, paragraph, list, table, or hierarchical structure). Most co-occurring entities have a relationship - find it. If the connection is clear from context, extract it. If the connection is unclear or requires significant inference beyond the context, skip it.

#### Relationship Patterns Examples (Domain-Agnostic):

- **Hierarchical**: `is_a`, `part_of`, `contains`, `subtype_of`, `member_of`
- **Spatial/Geographic**: `located_in`, `operates_in`, `serves`, `covers`
- **Functional**: `provides`, `manages`, `requires`, `uses`, `affects`, `enables`, `supports`
- **Causal**: `causes`, `prevents`, `enables`, `triggers`, `results_in`
- **Temporal**: `occurs_before`, `occurs_during`, `occurs_after`, `precedes`, `follows`
- **Conditional**: `depends_on`, `requires_if`, `applies_to`, `conditional_on`
- **Ownership/Control**: `owns`, `controls`, `governs`, `regulates`
- **Interaction**: `interacts_with`, `communicates_with`, `collaborates_with`

**Use the most specific relationship type that accurately describes the connection.**

#### Relationship Extraction Process:

1. **Re-parse entire input text**: Systematically go through the entire input text again, focusing on relationships between entities extracted in STEP 1

2. **Systematic pairing**: For each entity from STEP 1, identify all other entities mentioned in:
   - Same sentence
   - Same paragraph
   - Same section or topic area
   - Same list or table

3. **Extract explicit relationships**: Extract relationships directly stated:
   - "X requires Y", "A is in B", "C manages D"
   - "X operates in Y", "A provides B"
   - Any explicit connection stated in the text

4. **Extract implied relationships**: If entities co-occur in ANY context, you MUST find their relationship. Most co-occurring entities are connected - be aggressive in identifying connections.

5. **Be comprehensive**: Extract ALL relationships between co-occurring entities. If two entities appear together, there is USUALLY a relationship - identify and extract it. Do not skip relationships.

6. **Check for missing relationships**: After initial extraction, verify that entities mentioned together have relationships. If orphan rate is high, you are missing relationships - search harder.

#### Property Extraction for Relationships - ZERO INFORMATION LOSS:

For EACH relationship, follow this systematic approach:

1. **Identify relationship context**: Find every sentence, paragraph, or section where both entities are mentioned together
2. **Scan context systematically**: Read the surrounding context where the relationship is described
3. **Extract all qualifiers**: Capture every detail about HOW, WHEN, WHERE, and UNDER WHAT CONDITIONS the relationship applies
4. **Aggregate distributed information**: If relationship details appear in multiple places, combine all details into the relationship's properties
5. **Verify completeness**: After extraction, verify that all contextual information about the relationship is captured

**What to Extract as Relationship Properties:**
For EACH relationship, capture ALL contextual details mentioned:

- **Conditions**: "if X", "when Y", "under condition Z", "provided that", "whenever", "in cases where"
- **Timeframes**: "within 30 days", "before X", "during Y", "after Z", "within X hours/days/months", "valid until", "expires on"
- **Quantities**: "at least 3", "maximum 5", "exactly 2", "minimum X", "up to Y", "no more than"
- **Specifications**: "for category X", "in jurisdiction Y", "with status Z", "under circumstances A", "in context of"
- **Restrictions**: "except when", "not applicable to", "only if", "excluding", "unless", "not when"
- **Modalities**: "must", "should", "may", "can", "required", "optional", "mandatory"
- **Directions**: "from X to Y", "bidirectional", "one-way", "reciprocal"

#### Relationship Structure:

```json
{
  "type": "relationship_type",          // descriptive verb/phrase (e.g., "requires", "located_in")
  "source_label": "entity_label",       // MUST exactly match an entity label from STEP 1
  "target_label": "entity_label",       // MUST exactly match an entity label from STEP 1
  "description": "explanation",         // RECOMMENDED - explain the relationship context
  "properties": {
    "source_urls": "source_id",        // MANDATORY - from STEP 0
    "condition": "value",              // EVERY detail about the relationship
    "timeframe": "value",               // Conditions, timeframes, quantities, restrictions
    "specification": "value"            // Zero information loss - capture all context
  },
  "characteristics": ["Functional"],    // OPTIONAL - OWL property characteristics
  "inverse_of": "other_relationship",   // OPTIONAL - inverse relationship type
  "confidence": 0.9                     // 0.9-1.0: explicit, 0.7-0.8: clearly implied
}
```

**Critical Rules:**
- `source_label` and `target_label` MUST exactly match entity labels from STEP 1
- Both entities MUST exist in your entity list from STEP 1
- Extract relationships for all co-occurring entities

**CRITICAL**: Complete STEP 2 fully before moving to STEP 3. Establish ALL relationships with ALL their properties.

---

### STEP 3: Validate Entire Graph Against Input Text

**ONLY AFTER** all entities (STEP 1) and relationships (STEP 2) have been extracted, validate the entire graph output against the input text for corrections, completeness, accuracy, and orphan node validation.

#### Validation Process:

Perform validation in **4 sequential passes**:

#### PASS 1: Entity Completeness & Deduplication

1. **Re-scan entire input text** comprehensively:
   - All sentences, paragraphs, headers, subheaders, tables, footnotes, captions, lists

2. **Check extraction completeness**:
   - Identify ALL proper nouns not yet extracted
   - Identify ALL items in lists not yet extracted

3. **Add missing entities**: Extract any significant entities that were missed

4. **List verification**: For EVERY list in the text, verify ALL items are extracted as entities (if they meet entity criteria)

5. **Verify entity criteria**: Ensure each extracted entity meets the definition (not generic terms)

6. **Check normalization**: All labels lowercase, abbreviations expanded (when clear from context), punctuation removed

7. **Deduplication check**:
   - Look for entities with similar names (different capitalization, spacing, abbreviations)
   - Merge duplicates by keeping the most complete version, combining aliases
   - Ensure no duplicate labels exist

8. **Semantic duplicate detection**:
   - Compare entity labels, descriptions, and aliases
   - Identify entities that refer to the same concept but have different labels
   - Look for semantic duplicates (e.g., "United States" vs "USA" vs "US" - should be one entity with aliases)
   - Merge semantic duplicates, combining all aliases, properties, and relationships

#### PASS 2: Relationship Completeness & Orphan Verification (CRITICAL)

**2A. Relationship Coverage:**
1. **Re-read input text** focusing on entity co-occurrences
2. **For each pair of entities** mentioned together:
   - Identify their relationship (explicit or implied)
   - Most co-occurring entities have a relationship - find it
3. **Extract missing relationships**: Add all identified connections
4. **Verify completeness**: Ensure all entity pairs that co-occur have relationships extracted

**2B. Orphan Entity Verification (3-PASS CHECK):**

**First Orphan Check:**
- Identify all entities with zero relationships
- For EACH orphan, re-read its context in the input text
- Find how it connects to other entities mentioned nearby
- Add missing relationships

**Second Orphan Check:**
- Re-examine remaining orphans after first pass
- Look for indirect connections (entity A → entity B → orphan C)
- Consider hierarchical relationships (is_a, part_of, contains)
- Consider functional relationships (uses, requires, manages)
- Add relationships found

**Third Orphan Check (Final Verification):**
- For remaining orphans, perform DEEP context analysis:
  - Search the ENTIRE text for ANY mention of the orphan with other entities
  - Check if orphan is a type/category of another entity (is_a relationship)
  - Check if orphan is part of a larger system/organization (part_of relationship)
  - Check if orphan operates in/under another entity (operates_in, managed_by relationships)
  - Check if orphan is mentioned in same section/topic as another entity (they likely have a relationship)
- Verify if orphan truly has no connections (some entities may legitimately be standalone, but this should be rare)
- **MANDATORY**: If orphan rate > 15%, you MUST continue searching for connections - this is a FAILURE that must be fixed
- Use `related_to` relationship only as last resort if no specific type fits

**2C. Relationship Validation:**
- Verify every relationship's `source_label` and `target_label` match existing entity labels exactly
- Remove any relationships referencing non-existent entities
- Ensure relationship types are meaningful and specific (avoid generic "related_to" when possible)
- Check for duplicate relationships between the same entity pairs
- Merge duplicate relationships, keeping the most specific type and combining properties

#### PASS 3: Property Completeness & Zero Information Loss (CRITICAL)

**3A. Entity Property Verification:**
For EACH entity, you MUST re-read the ENTIRE input text systematically and verify:
- ✅ EVERY number mentioned about this entity ANYWHERE in text → captured in properties? (amounts, counts, phone numbers, years, dates, quantities, measurements, sizes)
- ✅ EVERY date/timeframe mentioned about this entity ANYWHERE in text → captured in properties? (specific dates, months, years, "within X days", "before Y", "after Z", durations)
- ✅ EVERY status mentioned about this entity ANYWHERE in text → captured in properties? (open/closed, active/inactive, banned/prohibited, operational status)
- ✅ EVERY condition, requirement, restriction mentioned about this entity ANYWHERE in text → captured in properties?
- ✅ EVERY exception, special case mentioned about this entity ANYWHERE in text → captured in properties?
- ✅ EVERY specification, criteria, standard mentioned about this entity ANYWHERE in text → captured in properties?
- ✅ EVERY contact detail mentioned about this entity ANYWHERE in text → captured in properties? (phone numbers, emails, addresses)
- ✅ Information from headers, footnotes, tables, captions about this entity → captured in properties?
- ✅ Source attribution (`source_urls`) present in properties?

**CRITICAL**: Scan the ENTIRE text for each entity, not just immediate context. Properties can appear in headers, footnotes, different sections, or tables - you MUST capture them all.

**Note**: Some entities may have minimal information in the text - that's acceptable ONLY if you've verified the text truly has no more information. But if information is mentioned ANYWHERE in the text, it MUST be captured.

**3B. Relationship Property Verification:**
For EACH relationship, re-read the ENTIRE input text systematically and verify:
- ✅ All qualifiers (how, when, where, under what conditions) → captured in properties?
- ✅ All specifications (amounts, frequencies, durations) → captured in properties?
- ✅ All restrictions or exceptions → captured in properties?
- ✅ All contextual details from headers, footnotes, tables → captured in properties?
- ✅ Source attribution (`source_urls`) present in properties?

**3C. Zero Information Loss Final Check:**
1. **Systematic comparison**: Go through input text comprehensively:
   - Sentence by sentence, paragraph by paragraph
   - All headers, subheaders, tables, footnotes, captions
   - All structured data and metadata
2. **For each piece of information**:
   - Is it captured in an entity property?
   - Is it captured in a relationship property?
   - Is it captured in entity/relationship description?
3. **Distributed information check**: For entities/relationships mentioned in multiple places, verify all distributed information is aggregated
4. **Missing information**: If ANY detail from text is not captured, add it now
5. **Completeness verification**: Can you reconstruct the key information from your extraction?

#### PASS 4: Accuracy & Final Validation

**Accuracy Validation:**
- ✅ Only information from input text (no hallucination)
- ✅ No invented entities or relationships
- ✅ All extractions are justified by text content

**Final Checklist:**
- ✅ All entities are meaningful, distinct concepts (not generic descriptors)
- ✅ All labels normalized (lowercase, expanded abbreviations, no punctuation)
- ✅ No duplicate entities (same entity with different labels)
- ✅ All entities have `source_urls` in properties
- ✅ Entity types are appropriate and domain-agnostic
- ✅ All relationships reference existing entities (no broken links)
- ✅ `source_label` and `target_label` exactly match entity labels
- ✅ Relationship types are specific and meaningful
- ✅ All relationships have `source_urls` in properties
- ✅ Orphan rate < 15% (most entities connected)
- ✅ Zero information loss: ALL mentioned details captured in properties
- ✅ Every entity has comprehensive properties (all attributes mentioned)
- ✅ Every relationship has comprehensive properties (all context captured)

**Final Questions (Answer "NO" to all before returning):**
- ❓ Is there ANY information in the input text not captured in my extraction?
- ❓ Are there ANY entities mentioned together (same sentence, paragraph, section) that don't have a relationship?
- ❓ Are there ANY numbers, dates, phone numbers, or specifications mentioned about entities ANYWHERE in the text that are not in properties?
- ❓ Are there ANY items from lists that were not extracted as entities?
- ❓ Are there ANY orphaned entities that could be connected? (If orphan rate > 15%, this is a FAILURE - fix it)
- ❓ Did I create entities for generic terms or attributes instead of trackable concepts?
- ❓ Did I scan the ENTIRE text for each entity and relationship to find ALL properties, not just immediate context?
- ❓ Did I aggregate all distributed information about entities and relationships from across the entire text?
- ❓ Are there any relationships with missing or incomplete properties?
- ❓ Is my orphan rate below 15%? (If not, I must find more relationships)

**MANDATORY**: If ANY answer is "YES": You MUST fix the extraction before returning. Incomplete extraction is NOT acceptable.

---

## Output Format

Return structured JSON matching this exact schema:

```json
{
  "concepts": [
    {
      "label": "entity_label",
      "concept_type": "entity_type",
      "description": "clear explanation",
      "aliases": ["abbrev", "alt_name"],
      "properties": {
        "source_urls": "source_id",
        "attribute1": "value1"
      },
      "restrictions": [
        {
          "property": "relationship_type",
          "restriction_type": "someValuesFrom",
          "on_class": "TargetClassName"
        }
      ],
      "confidence": 0.95
    }
  ],
  "relationships": [
    {
      "type": "relationship_type",
      "source_label": "entity_a",
      "target_label": "entity_b",
      "description": "relationship description",
      "properties": {
        "source_urls": "source_id",
        "condition": "value"
      },
      "characteristics": ["Functional", "Asymmetric"],
      "inverse_of": "inverse_relationship_type",
      "confidence": 0.9
    }
  ]
}
```

---

## Execution Reminder

Follow the sequential steps STRICTLY:
1. **STEP 0**: Identify source
2. **STEP 1**: Extract ALL entities with ALL their properties (complete this fully before proceeding)
3. **STEP 2**: Parse input again to establish ALL relationships with ALL their properties (complete this fully before proceeding)
4. **STEP 3**: Validate entire graph against input text for corrections, completeness, accuracy, and orphan nodes

Return only when ALL validation checks pass, zero information loss is achieved, and semantic duplicates are merged.
"""
)

ENTITY_DISCOVERY_INSTRUCTIONS = """### STEP 1: Extract All Entities with Properties

**FIRST**: Extract ALL entities from the input text along with their properties. Do NOT extract relationships yet.

**CRITICAL REQUIREMENTS:**
- You MUST extract EVERY entity mentioned in the text that meets the entity criteria
- You MUST capture ALL properties for each entity - do not skip details
- You MUST scan the ENTIRE text multiple times to ensure nothing is missed
- Incomplete extraction is NOT acceptable - be thorough and comprehensive

#### What is an Entity?

An entity is a **distinct, trackable concept** that is **explicitly mentioned or clearly defined** in the text and meets ALL of these criteria:
- Has a **specific identity** (proper noun, named thing, or well-defined concept that is actually discussed in the text)
- Represents something that can be **referenced independently** in relationships
- Carries **meaningful information** beyond generic descriptors
- Can be **categorized** into a meaningful type
- **CRITICAL**: Is actually discussed, named, or defined in the text - NOT just mentioned in passing or as part of another concept

#### Entity Examples from Different Domains (EXTRACT):

**Medical Domain:**
- Named things: "John Smith" (person), "Mayo Clinic" (organization)
- Specific concepts: "Type 2 diabetes" (condition), "MRI scan" (procedure), "Aspirin" (medication)
- Well-defined categories: "Cardiac surgery" (procedure type), "FDA approval" (regulatory status)

**Legal Domain:**
- Named things: "Supreme Court" (organization), "California" (location)
- Specific concepts: "Copyright law" (regulation), "Patent application" (process), "Contract breach" (legal concept)
- Well-defined categories: "Trial procedure" (process), "Legal requirement" (requirement type)

**Technical Domain:**
- Named things: "Microsoft Corporation" (organization), "Python" (technology)
- Specific concepts: "API endpoint" (technical concept), "Database schema" (structure), "Authentication protocol" (process)
- Well-defined categories: "Software framework" (technology type), "Security standard" (standard type)

**Business Domain:**
- Named things: "Amazon" (organization), "New York Stock Exchange" (organization)
- Specific concepts: "Supply chain" (process), "Market analysis" (activity), "Revenue model" (business concept)
- Well-defined categories: "Business process" (process type), "Financial metric" (metric type)

**General Patterns:**
- Organizations, agencies, institutions
- Locations (countries, regions, cities, facilities)
- People (when specifically named)
- Products, services, technologies
- Processes, procedures, methods
- Regulations, laws, standards
- Documents, certificates, permits
- Events, activities, concepts

#### NOT Entities (DO NOT EXTRACT):

- Generic descriptors: "good", "important", "many", "several", "various"
- Pure attribute values: "6 months" (this is a property, not an entity - extract the thing it describes)
- Vague references: "it", "they", "this", "that", "these"
- Common adjectives: "large", "small", "fast", "slow" (unless they represent named concepts)
- Generic verbs: "manage", "process", "handle" (unless they represent named processes)
- Abstract qualities without identity: "quality", "efficiency" (unless they're trackable concepts)
- **Infrastructure Context**: Do NOT extract concepts about the data processing pipeline, semantic extraction, embedding vectors, graph databases, or this extraction mechanics (e.g. "embedding vector chunk", "pipeline stage"). Only extract domain concepts.
- **Passing mentions**: If something is only mentioned as part of another concept (e.g., "damage to infrastructure" where infrastructure is not the topic), do NOT extract it as a standalone entity
- **Inferred concepts**: Do NOT extract concepts that you think are relevant but are not actually discussed in the text

#### Entity Extraction Process:

1. **Scan systematically**: Read the entire text comprehensively:
   - All sentences and paragraphs
   - All headers and subheaders (often contain key entity names)
   - All lists (bulleted, numbered, comma-separated, "including X, Y, Z")
   - All tables and structured data (extract entities from table cells)
   - All footnotes, captions, and annotations
   - All metadata and references

2. **Identify candidates**: Look for and mark:
   - All proper nouns (capitalized words/phrases that represent specific entities)
   - All named concepts (specific, identifiable concepts with clear meaning)
   - All items in lists (when text lists items, extract each item if it meets entity criteria)
   - All organizations, agencies, institutions mentioned
   - All locations (countries, regions, cities, areas, facilities)
   - All documents, certificates, permits, requirements mentioned
   - Entities mentioned in headers, tables, or structured formats

3. **Filter carefully**: Apply the entity criteria - is it trackable? Does it have identity? Is it a meaningful concept?

4. **Extract comprehensively**: For each valid entity, capture:
   - Normalized label (lowercase, expanded abbreviations)
   - Appropriate concept_type (domain-agnostic type)
   - Clear description (1-2 sentences explaining what it is)
   - ALL aliases and variations mentioned in text
   - ALL properties and attributes mentioned about this entity (see Property Extraction below)

"""


SUPPLIED_ENTITY_INSTRUCTIONS = """### STEP 1: Capture Properties for the Supplied Entities

The entity set for this text has already been identified and is supplied to you (see the
candidate entity list). Do NOT discover or invent entities, and do not introduce any entity
beyond the supplied set. For EACH supplied candidate that the source text supports, create the
concept and extract ALL of its properties as described below.

"""


TERM_SEEDED_ONTOLOGY_PROMPT = DEFAULT_ONTOLOGY_PROMPT.replace(
    ENTITY_DISCOVERY_INSTRUCTIONS, SUPPLIED_ENTITY_INSTRUCTIONS
)


RELATIONSHIP_RECOVERY_PROMPT = """# Relationship Recovery System

Recover relationships only for an already known set of entities.

## Goal

The initial extraction returned concepts but too few relationships. Your task is to recover
the missing relationships from the input text using only the provided known entities.

## Rules

- Output `concepts: []`. Do not emit any new concepts.
- Emit only relationships whose `source_label` and `target_label` exactly match labels from the
  provided known-entity list.
- Prefer specific reusable relationship types such as `requires`, `issuedBy`, `appliesTo`,
  `hasCondition`, `hasRequirement`, `hasEligibilityCriterion`, `hasTemporalConstraint`,
  `permits`, `prohibits`, `partOf`, and `relatedTo`.
- Recover relationships that are explicit or clearly implied by local context in the text.
- If no supported relationship is justified, return an empty `relationships` list.
- Include source attribution in relationship properties when source grounding is enabled.

## Output Shape

Return valid JSON matching this structure:

```json
{
  "concepts": [],
  "relationships": [
    {
      "type": "relationship_type",
      "source_label": "ExactKnownEntityLabel",
      "target_label": "ExactKnownEntityLabel",
      "confidence": 0.9,
      "description": "Optional relationship context",
      "properties": {}
    }
  ]
}
```
"""

UPPER_ONTOLOGY_INFERENCE_PROMPT = """You are an ontology engineer. Your task is to
organise the following concept types — extracted from source text — into a hierarchy
using only those types.

## Concept Types
{concept_types}

## Instructions

Scan the provided list and identify parent-child relationships *within* it:

- If type A is clearly a specialisation of type B (both in the list), map A → B.
  Examples: `Country → Place`, `IdentityDocument → Document`,
  `ClinicalTrial → Study`, `SoftwareLibrary → Artifact`

- Direction sanity: only map A → B when you are confident B is broader than A.
  If you are uncertain, omit the mapping rather than guessing.
- Never map a broad category under a narrower specialisation (if B is a kind of A,
  do NOT output A → B).
- If two types are synonyms or near-duplicates, map the more specific one to the
  more general one. Do NOT leave both as siblings at the same level.
- Prefer fewer broad roots. If a reusable abstract type already exists in the list and
  several other types are clearly specialisations of it, map them under that type rather
  than leaving them as sibling roots.
- Do NOT leave domain abstractions as isolated roots when a broader within-list type
  already exists and clearly subsumes them.

- Do NOT introduce types that are not in the provided list.
- Do NOT map types to abstract vocabulary (Agent, PolicyConstruct, etc.) that are
  absent from the source text.

## Output Format

Return ONLY a valid JSON object mapping child concept_type → parent concept_type.
Only include pairs where both types are in the provided list.
Return {{}} if no within-list hierarchies are found.

Example:
```json
{{
  "IdentityDocument": "Document",
  "Country": "Place",
  "MaintenanceRequirement": "Requirement"
}}
```

Return ONLY the JSON object, no explanation or markdown.
"""
