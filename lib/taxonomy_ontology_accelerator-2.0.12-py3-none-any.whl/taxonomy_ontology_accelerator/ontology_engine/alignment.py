from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from difflib import SequenceMatcher
from pathlib import Path

from rdflib import OWL, RDF, Graph as RDFGraph
from rdflib.namespace import SKOS
from rdflib.term import URIRef

from taxonomy_ontology_accelerator.commons.io.file_utils import join_path, safe_write_file
from taxonomy_ontology_accelerator.commons.io.fsspec_utils import get_default_filesystem
from taxonomy_ontology_accelerator.ontology_engine.core.models import OntologyGraph

logger = logging.getLogger(__name__)

FUZZY_THRESHOLD = 0.85
MAX_LISTED_ITEMS = 20
_DIMENSIONS = ("entities", "properties", "aliases")
ALIGNMENT_REPORT_FILENAME = "alignment_report.json"


@dataclass
class Match:
    graph_name: str
    ontology_name: str
    confidence: float


@dataclass
class DimensionAlignment:
    exact: list[Match] = field(default_factory=list)
    surface: list[Match] = field(default_factory=list)
    missing: list[str] = field(default_factory=list)
    extras: list[str] = field(default_factory=list)

    @property
    def aligned_pct(self) -> float:
        total = len(self.exact) + len(self.surface) + len(self.missing) + len(self.extras)
        return len(self.exact) / total * 100 if total else 100.0


@dataclass
class AlignmentReport:
    entities: DimensionAlignment
    properties: DimensionAlignment
    aliases: DimensionAlignment

    @property
    def fully_aligned(self) -> bool:
        return all(
            dimension.aligned_pct == 100.0
            for dimension in (self.entities, self.properties, self.aliases)
        )


def _local_name(uri: URIRef) -> str:
    text = str(uri)
    for separator in ("#", "/"):
        if separator in text:
            return text[text.rfind(separator) + 1 :]
    return text


def _align(graph_names: list[str], ontology_names: list[str]) -> DimensionAlignment:
    exact: list[Match] = []
    surface: list[Match] = []
    unmatched_graph = list(graph_names)
    unmatched_ontology = list(ontology_names)

    for name in list(unmatched_graph):
        for candidate in list(unmatched_ontology):
            if name.casefold() == candidate.casefold():
                exact.append(Match(name, candidate, 1.0))
                unmatched_graph.remove(name)
                unmatched_ontology.remove(candidate)
                break

    for name in list(unmatched_graph):
        best_score = 0.0
        best_candidate: str | None = None
        for candidate in unmatched_ontology:
            score = SequenceMatcher(None, name.casefold(), candidate.casefold()).ratio()
            if score > best_score:
                best_score = score
                best_candidate = candidate
        if best_candidate is not None and best_score > FUZZY_THRESHOLD:
            surface.append(Match(name, best_candidate, best_score))
            unmatched_graph.remove(name)
            unmatched_ontology.remove(best_candidate)

    return DimensionAlignment(
        exact=exact,
        surface=surface,
        missing=unmatched_graph,
        extras=unmatched_ontology,
    )


def _alias_name(alias: object) -> str:
    name = getattr(alias, "name", None)
    return name if isinstance(name, str) else str(alias)


def _literal_values(ontology: RDFGraph, predicate: URIRef) -> list[str]:
    return [str(obj) for _, obj in ontology.subject_objects(predicate)]


def _typed_local_names(ontology: RDFGraph, rdf_type: URIRef) -> list[str]:
    names: set[str] = set()
    for subject in ontology.subjects(RDF.type, rdf_type):
        if isinstance(subject, URIRef):
            names.add(_local_name(subject))
    return sorted(names)


def compare_graph_and_ontology(
    graph: OntologyGraph,
    ontology: RDFGraph,
    declared_relationship_types: list[str] | None = None,
) -> AlignmentReport:
    entity_labels = [entity.label for entity in graph.entities]
    alias_names = [
        _alias_name(alias)
        for entity in graph.entities
        for alias in (entity.aliases or [])
    ]
    relationship_types = (
        declared_relationship_types
        if declared_relationship_types is not None
        else sorted(
            {relationship.type for relationship in graph.relationships if relationship.type}
        )
    )

    return AlignmentReport(
        entities=_align(entity_labels, _literal_values(ontology, SKOS.prefLabel)),
        properties=_align(
            relationship_types, _typed_local_names(ontology, OWL.ObjectProperty)
        ),
        aliases=_align(alias_names, _literal_values(ontology, SKOS.altLabel)),
    )


def align_files(graph_path: str | Path, ontology_path: str | Path) -> AlignmentReport:
    graph = OntologyGraph(**json.loads(Path(graph_path).read_text(encoding="utf-8")))
    ontology = RDFGraph()
    ontology.parse(str(ontology_path), format="turtle")
    return compare_graph_and_ontology(graph, ontology)


def report_to_dict(report: AlignmentReport) -> dict:
    out: dict = {"fully_aligned": report.fully_aligned}
    for name in _DIMENSIONS:
        dimension = getattr(report, name)
        out[name] = {
            "aligned_pct": round(dimension.aligned_pct, 1),
            "exact": len(dimension.exact),
            "surface": [
                {
                    "graph": match.graph_name,
                    "ontology": match.ontology_name,
                    "confidence": round(match.confidence, 4),
                }
                for match in dimension.surface
            ],
            "missing": dimension.missing,
            "extras": dimension.extras,
        }
    return out


def _format_items(items: list[str], limit: int = MAX_LISTED_ITEMS) -> str:
    shown = ", ".join(items[:limit])
    if len(items) > limit:
        return f"{shown} (+{len(items) - limit} more)"
    return shown


def format_report(report: AlignmentReport) -> str:
    lines = ["Alignment (graph.json <-> ontology.ttl)"]
    for label, name in (
        ("Entities", "entities"),
        ("Properties", "properties"),
        ("Aliases", "aliases"),
    ):
        dimension = getattr(report, name)
        lines.append(
            f"  {label:11s} aligned={dimension.aligned_pct:6.1f}%  "
            f"exact={len(dimension.exact)} surface={len(dimension.surface)} "
            f"missing={len(dimension.missing)} extras={len(dimension.extras)}"
        )
        for match in dimension.surface:
            lines.append(
                f"    surface: {match.graph_name} <-> {match.ontology_name} "
                f"({match.confidence:.2f})"
            )
        if dimension.missing:
            lines.append(f"    in graph.json only: {_format_items(dimension.missing)}")
        if dimension.extras:
            lines.append(f"    in ontology.ttl only: {_format_items(dimension.extras)}")
    return "\n".join(lines)


def _declared_relationship_types(schema_path, fs) -> list[str] | None:
    if not fs.exists(str(schema_path)):
        return None
    schema = json.loads(fs.cat_file(str(schema_path)))
    return sorted((schema.get("relationship_types") or {}).keys())


def run_pipeline_alignment(output_dir, config, fs) -> None:
    if not config.alignment_check.enabled or config.output.export.format != "turtle":
        return
    if fs is None:
        fs = get_default_filesystem()
    graph_path = join_path(output_dir, config.output.graph_filename)
    ontology_path = join_path(output_dir, f"{config.output.export.filename}.ttl")
    schema_path = join_path(output_dir, config.output.schema_filename)
    if not (fs.exists(str(graph_path)) and fs.exists(str(ontology_path))):
        logger.info("Alignment check skipped: graph.json or ontology.ttl not found")
        return
    try:
        graph = OntologyGraph(**json.loads(fs.cat_file(str(graph_path))))
        ontology = RDFGraph()
        ontology.parse(data=fs.cat_file(str(ontology_path)), format="turtle")
        declared = _declared_relationship_types(schema_path, fs)
        report = compare_graph_and_ontology(graph, ontology, declared)
    except Exception as error:
        logger.warning("Alignment check skipped: %s", error)
        return
    safe_write_file(
        join_path(output_dir, ALIGNMENT_REPORT_FILENAME),
        json.dumps(report_to_dict(report), indent=2),
        fs=fs,
    )
    logger.info("Ontology alignment report written:\n%s", format_report(report))
