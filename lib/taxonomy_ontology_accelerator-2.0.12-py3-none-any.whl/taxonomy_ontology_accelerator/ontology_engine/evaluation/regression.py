"""Regression comparison helpers for generated ontology outputs."""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any

from rdflib import Graph, URIRef
from rdflib.namespace import OWL, RDF, RDFS


@dataclass(frozen=True)
class MetricThreshold:
    """Threshold rule for one ontology harness metric."""

    metric: str
    minimum_ratio: float | None = None
    maximum_drop: float | None = None

    def threshold_value(self, baseline_value: float) -> float:
        if self.minimum_ratio is not None:
            return baseline_value * self.minimum_ratio
        if self.maximum_drop is not None:
            return max(0.0, baseline_value - self.maximum_drop)
        return baseline_value


@dataclass(frozen=True)
class RegressionReportContext:
    """Metadata needed to describe an ontology regression comparison."""

    domain: str
    deployment_version: str
    baseline_run_id: str
    baseline_output_uri: str
    baseline_uri: str
    candidate_run_id: str
    candidate_output_uri: str
    candidate_uri: str
    baseline_promoted_at: str | None = None
    baseline_notes: str | None = None


DEFAULT_REGRESSION_THRESHOLDS = (
    MetricThreshold("subclass_hierarchy_count", minimum_ratio=0.8),
    MetricThreshold("property_domain_count", minimum_ratio=0.8),
    MetricThreshold("property_range_count", minimum_ratio=0.8),
    MetricThreshold("relationship_density", minimum_ratio=0.8),
    MetricThreshold("attribute_richness", minimum_ratio=0.8),
    MetricThreshold("max_inheritance_depth", maximum_drop=1.0),
)

_METRIC_ALIASES = {
    "class_count": "class_count",
    "object_properties_count": "object_property_count",
    "object_property_count": "object_property_count",
    "data_properties_count": "data_property_count",
    "data_property_count": "data_property_count",
    "subclass_hierarchies": "subclass_hierarchy_count",
    "subclass_hierarchy_count": "subclass_hierarchy_count",
    "property_domains": "property_domain_count",
    "property_domain_count": "property_domain_count",
    "property_ranges": "property_range_count",
    "property_range_count": "property_range_count",
    "disjointness": "disjointness_count",
    "disjointness_count": "disjointness_count",
    "inverse_properties": "inverse_property_count",
    "inverse_property_count": "inverse_property_count",
    "cardinality_restriction": "cardinality_restriction_count",
    "cardinality_restriction_count": "cardinality_restriction_count",
    "equivalent_classes": "equivalent_class_count",
    "equivalent_class_count": "equivalent_class_count",
    "relationships_density": "relationship_density",
    "relationship_density": "relationship_density",
    "attribute_richness": "attribute_richness",
    "max_inheritance_depth": "max_inheritance_depth",
}


def _normalise_key(key: str) -> str | None:
    candidate = re.sub(r"[^a-z0-9]+", "_", key.strip().lower()).strip("_")
    return _METRIC_ALIASES.get(candidate)


def _numeric_value(value: Any) -> float | None:
    if value is None:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def normalise_metric_row(row: dict[str, Any]) -> dict[str, float]:
    """Convert CSV headings or canonical metric keys into numeric harness keys."""
    metrics: dict[str, float] = {}
    for key, value in row.items():
        metric = _normalise_key(key)
        numeric_value = _numeric_value(value)
        if metric is None or numeric_value is None:
            continue
        metrics[metric] = numeric_value
    return metrics


def _compute_max_depth(classes: set[URIRef], parents: dict[URIRef, set[URIRef]]) -> int:
    memo: dict[URIRef, int] = {}

    def depth(class_uri: URIRef) -> int:
        if class_uri in memo:
            return memo[class_uri]
        class_parents = parents.get(class_uri, set())
        memo[class_uri] = 0 if not class_parents else 1 + max(depth(parent) for parent in class_parents)
        return memo[class_uri]

    return max((depth(class_uri) for class_uri in classes), default=0)


def build_ontology_metrics_from_turtle(turtle_content: str | bytes) -> dict[str, float]:
    """Extract the regression metric set from Turtle ontology content."""
    if isinstance(turtle_content, bytes):
        turtle_content = turtle_content.decode("utf-8")

    graph = Graph()
    graph.parse(data=turtle_content, format="turtle")

    classes = set(graph.subjects(RDF.type, OWL.Class))
    classes.discard(OWL.Thing)
    object_properties = set(graph.subjects(RDF.type, OWL.ObjectProperty))
    data_properties = set(graph.subjects(RDF.type, OWL.DatatypeProperty))
    subclass_links = {
        (subject, obj)
        for subject, obj in graph.subject_objects(RDFS.subClassOf)
        if subject in classes and obj in classes
    }
    parents: dict[URIRef, set[URIRef]] = {class_uri: set() for class_uri in classes}
    for subject, obj in subclass_links:
        parents[subject].add(obj)

    class_count = float(len(classes))
    object_property_count = float(len(object_properties))
    data_property_count = float(len(data_properties))

    return {
        "class_count": class_count,
        "object_property_count": object_property_count,
        "data_property_count": data_property_count,
        "subclass_hierarchy_count": float(len(subclass_links)),
        "property_domain_count": float(len(set(graph.subjects(RDFS.domain)))),
        "property_range_count": float(len(set(graph.subjects(RDFS.range)))),
        "disjointness_count": float(len(set(graph.subjects(OWL.disjointWith)))),
        "inverse_property_count": float(len(set(graph.subjects(OWL.inverseOf)))),
        "cardinality_restriction_count": float(
            len(set(graph.subjects(OWL.maxCardinality)))
            + len(set(graph.subjects(OWL.minCardinality)))
        ),
        "equivalent_class_count": float(len(set(graph.subjects(OWL.equivalentClass)))),
        "relationship_density": object_property_count / class_count if class_count else 0.0,
        "attribute_richness": data_property_count / class_count if class_count else 0.0,
        "max_inheritance_depth": float(_compute_max_depth(classes, parents)),
    }


def compare_ontology_metrics(
    baseline: dict[str, Any],
    candidate: dict[str, Any],
    *,
    context: RegressionReportContext,
    thresholds: tuple[MetricThreshold, ...] = DEFAULT_REGRESSION_THRESHOLDS,
) -> dict[str, Any]:
    """Compare candidate metrics against an accepted baseline and return a JSON-ready report."""
    baseline_metrics = normalise_metric_row(baseline)
    candidate_metrics = normalise_metric_row(candidate)
    checks = []

    for threshold in thresholds:
        baseline_value = baseline_metrics.get(threshold.metric)
        candidate_value = candidate_metrics.get(threshold.metric)
        threshold_value = (
            threshold.threshold_value(baseline_value)
            if baseline_value is not None and candidate_value is not None
            else None
        )
        passed = (
            candidate_value >= threshold_value
            if candidate_value is not None and threshold_value is not None
            else False
        )
        checks.append(
            {
                "metric": threshold.metric,
                "baseline_value": baseline_value,
                "candidate_value": candidate_value,
                "threshold": threshold_value,
                "passed": passed,
            }
        )

    failed_metrics = [check["metric"] for check in checks if not check["passed"]]
    return {
        "passed": not failed_metrics,
        "domain": context.domain,
        "deployment_version": context.deployment_version,
        "baseline": {
            "run_id": context.baseline_run_id,
            "output_uri": context.baseline_output_uri,
            "ontology_uri": context.baseline_uri,
            "promoted_at": context.baseline_promoted_at,
            "notes": context.baseline_notes,
            "metrics": baseline_metrics,
        },
        "candidate": {
            "run_id": context.candidate_run_id,
            "output_uri": context.candidate_output_uri,
            "ontology_uri": context.candidate_uri,
            "metrics": candidate_metrics,
        },
        "checks": checks,
        "failed_metrics": failed_metrics,
    }
