"""Utilities for fast structural assessment of exported ontologies."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from rdflib import Graph, Literal, URIRef
from rdflib.namespace import OWL, RDF, RDFS

if TYPE_CHECKING:
    from pathlib import Path


@dataclass(frozen=True)
class OntologyShapeScorecard:
    """Compact shape metrics for an exported ontology."""

    class_count: int
    subclass_link_count: int
    root_class_count: int
    max_hierarchy_depth: int
    named_individual_count: int
    object_property_count: int
    class_individual_overlap_count: int
    restriction_count: int
    inverse_property_count: int
    functional_property_count: int
    disjoint_declaration_count: int
    domain_range_coverage_pct: float
    data_property_count: int
    typed_literal_count: int
    artifact_literal_count: int
    typo_literal_count: int


@dataclass(frozen=True)
class OntologyConvergenceScore:
    """Reference-informed quality score for ontology convergence toward the north star."""

    structural_pct: float
    semantic_pct: float
    overall_pct: float


def _normalize_patterns(patterns: list[str] | None) -> list[str]:
    """Normalize optional literal-match patterns."""
    if not patterns:
        return []
    return [pattern.strip().lower() for pattern in patterns if pattern and pattern.strip()]


def _compute_max_depth(classes: set[URIRef], parents: dict[URIRef, set[URIRef]]) -> int:
    """Compute the maximum subclass depth across classes."""
    memo: dict[URIRef, int] = {}

    def _depth(node: URIRef) -> int:
        if node in memo:
            return memo[node]
        node_parents = parents.get(node, set())
        memo[node] = 0 if not node_parents else 1 + max(_depth(parent) for parent in node_parents)
        return memo[node]

    return max((_depth(class_uri) for class_uri in classes), default=0)


def _clamp_score(value: float) -> float:
    """Clamp a score into the inclusive [0, 1] range."""
    return max(0.0, min(1.0, value))


def _safe_ratio(value: float, target: float) -> float:
    """Return a bounded ratio score where meeting the target yields 1.0."""
    if target <= 0:
        return 1.0
    return _clamp_score(value / target)


def build_shape_scorecard(
    ontology_path: str | Path,
    *,
    artifact_patterns: list[str] | None = None,
    typo_patterns: list[str] | None = None,
) -> OntologyShapeScorecard:
    """Build a lightweight structural scorecard from an OWL/Turtle export."""
    graph = Graph()
    graph.parse(str(ontology_path))

    classes = set(graph.subjects(RDF.type, OWL.Class))
    classes.discard(OWL.Thing)
    subclass_links = {
        (subject, obj)
        for subject, obj in graph.subject_objects(RDFS.subClassOf)
        if subject in classes and obj in classes
    }
    parents: dict[URIRef, set[URIRef]] = {class_uri: set() for class_uri in classes}
    for subject, obj in subclass_links:
        parents[subject].add(obj)

    roots = {class_uri for class_uri in classes if not parents[class_uri]}
    named_individuals = set(graph.subjects(RDF.type, OWL.NamedIndividual))
    object_properties = set(graph.subjects(RDF.type, OWL.ObjectProperty))
    data_properties = set(graph.subjects(RDF.type, OWL.DatatypeProperty))
    overlaps = classes & named_individuals
    restrictions = set(graph.subjects(RDF.type, OWL.Restriction))
    inverse_properties = set(graph.subject_objects(OWL.inverseOf))
    functional_properties = set(graph.subjects(RDF.type, OWL.FunctionalProperty))
    disjoint_declarations = set(graph.subject_objects(OWL.disjointWith))
    all_disjoint_classes = set(graph.subjects(RDF.type, OWL.AllDisjointClasses))
    object_properties_with_domain_and_range = {
        prop
        for prop in object_properties
        if any(graph.objects(prop, RDFS.domain)) and any(graph.objects(prop, RDFS.range))
    }
    domain_range_coverage_pct = (
        (len(object_properties_with_domain_and_range) / len(object_properties)) * 100.0
        if object_properties
        else 0.0
    )
    typed_literal_count = sum(
        1
        for _, _, obj in graph
        if isinstance(obj, Literal) and obj.datatype is not None
    )

    literal_values = [str(obj).lower() for _, _, obj in graph if isinstance(obj, Literal)]
    artifact_terms = _normalize_patterns(artifact_patterns)
    typo_terms = _normalize_patterns(typo_patterns)

    artifact_literal_count = sum(
        sum(text.count(pattern) for pattern in artifact_terms) for text in literal_values
    )
    typo_literal_count = sum(
        sum(text.count(pattern) for pattern in typo_terms) for text in literal_values
    )

    return OntologyShapeScorecard(
        class_count=len(classes),
        subclass_link_count=len(subclass_links),
        root_class_count=len(roots),
        max_hierarchy_depth=_compute_max_depth(classes, parents),
        named_individual_count=len(named_individuals),
        object_property_count=len(object_properties),
        class_individual_overlap_count=len(overlaps),
        restriction_count=len(restrictions),
        inverse_property_count=len(inverse_properties),
        functional_property_count=len(functional_properties),
        disjoint_declaration_count=len(disjoint_declarations) + len(all_disjoint_classes),
        domain_range_coverage_pct=domain_range_coverage_pct,
        data_property_count=len(data_properties),
        typed_literal_count=typed_literal_count,
        artifact_literal_count=artifact_literal_count,
        typo_literal_count=typo_literal_count,
    )


def build_convergence_score(
    ontology_path: str | Path,
    reference_path: str | Path,
    *,
    artifact_patterns: list[str] | None = None,
    typo_patterns: list[str] | None = None,
) -> OntologyConvergenceScore:
    """Build a reference-informed semantic/structural convergence score.

    This score is intentionally not an exact ontology-overlap metric. It uses the
    reference ontology to calibrate targets for structural and semantic quality while
    still rewarding generic ontology hygiene over raw count matching.
    """
    candidate = build_shape_scorecard(
        ontology_path,
        artifact_patterns=artifact_patterns,
        typo_patterns=typo_patterns,
    )
    reference = build_shape_scorecard(
        reference_path,
        artifact_patterns=artifact_patterns,
        typo_patterns=typo_patterns,
    )

    subclass_density = candidate.subclass_link_count / max(candidate.class_count, 1)
    reference_subclass_density = reference.subclass_link_count / max(reference.class_count, 1)
    object_property_ratio = candidate.object_property_count / max(candidate.class_count, 1)

    target_depth = max(1.0, float(min(reference.max_hierarchy_depth, 4)))
    target_subclass_density = max(0.75, min(reference_subclass_density, 1.25))
    target_domain_range = max(85.0, min(reference.domain_range_coverage_pct, 95.0))
    target_restriction_density = max(
        0.1,
        min(reference.restriction_count / max(reference.class_count, 1), 0.75),
    )
    target_inverse_count = max(1.0, min(float(reference.inverse_property_count), 4.0))
    max_root_ratio = max(0.25, (reference.root_class_count / max(reference.class_count, 1)) * 1.5)

    root_ratio = candidate.root_class_count / max(candidate.class_count, 1)
    if root_ratio <= max_root_ratio:
        root_score = 1.0
    else:
        root_score = _clamp_score(1.0 - ((root_ratio - max_root_ratio) / max_root_ratio))

    overlap_score = 1.0 if candidate.class_individual_overlap_count == 0 else _clamp_score(
        1.0 - (candidate.class_individual_overlap_count / max(candidate.class_count, 1))
    )
    label_hygiene_score = 1.0 if (
        candidate.artifact_literal_count == 0 and candidate.typo_literal_count == 0
    ) else 0.0
    property_balance_score = 1.0 if object_property_ratio <= 1.2 else _clamp_score(1.2 / object_property_ratio)

    structural_score = (
        _safe_ratio(float(candidate.max_hierarchy_depth), target_depth) * 0.30
        + _safe_ratio(subclass_density, target_subclass_density) * 0.25
        + root_score * 0.15
        + overlap_score * 0.15
        + property_balance_score * 0.10
        + label_hygiene_score * 0.05
    )

    restriction_density = candidate.restriction_count / max(candidate.class_count, 1)
    semantic_score = (
        _safe_ratio(candidate.domain_range_coverage_pct, target_domain_range) * 0.45
        + _safe_ratio(restriction_density, target_restriction_density) * 0.30
        + _safe_ratio(float(candidate.inverse_property_count), target_inverse_count) * 0.15
        + overlap_score * 0.10
    )

    overall_score = structural_score * 0.55 + semantic_score * 0.45

    return OntologyConvergenceScore(
        structural_pct=structural_score * 100.0,
        semantic_pct=semantic_score * 100.0,
        overall_pct=overall_score * 100.0,
    )
