"""
LLM prompt loader for ontology engine.

Default prompt is embedded in code for simplicity.
Domain-specific prompts can be loaded from files.
"""

from pathlib import Path

from fsspec import AbstractFileSystem

from taxonomy_ontology_accelerator.commons.io.file_utils import safe_read_file
from taxonomy_ontology_accelerator.commons.io.fsspec_utils import safe_read_file_fsspec
from taxonomy_ontology_accelerator.commons.utils.logger import get_logger
from taxonomy_ontology_accelerator.ontology_engine.prompts import DEFAULT_ONTOLOGY_PROMPT

logger = get_logger()


# ========================================================================
# Prompt Loader Class
# ========================================================================


class PromptLoader:
    """
    Loader for LLM prompt with strict validation.

    Loads the fixed generic ontology extraction prompt and builds final prompts
    by appending domain-specific instructions and input text.
    """

    @staticmethod
    def _load_prompt_file(prompt_path: Path | str, fs: AbstractFileSystem | None = None) -> str:
        """
        Load prompt from file.

        Args:
            prompt_path: Path to prompt file
            fs: Optional filesystem instance (defaults to local filesystem)

        Returns:
            Prompt string

        Raises:
            IOError: If prompt file cannot be read
            ValueError: If prompt file is empty
        """
        assert prompt_path is not None, "Prompt path must not be None"
        assert isinstance(prompt_path, Path | str), "Prompt path must be a Path or string"

        logger.debug("Loading ontology LLM prompt...")
        logger.debug(f"LLM prompt path: {prompt_path}")

        try:
            if fs is not None:
                prompt = safe_read_file_fsspec(str(prompt_path), fs=fs)
            else:
                prompt = safe_read_file(prompt_path)  # Read prompt file
        except (OSError, FileNotFoundError) as e:  # Handle file I/O errors
            msg = (
                f"Failed to read ontology LLM prompt {prompt_path}: {e}\n"
                f"Check file permissions and path."
            )
            raise OSError(msg) from e

        if not prompt or not prompt.strip():  # Check for empty file
            raise ValueError(
                f"Ontology LLM prompt file is empty\nFile: {prompt_path}\nAdd prompt content."
            )

        # Prompt loaded successfully (logged by stage_timer in extractor)
        return prompt

    @staticmethod
    def load_prompt(use_cache: bool = True, fs: AbstractFileSystem | None = None) -> str:
        """
        Load generic LLM prompt.

        Uses embedded default prompt from code.
        Can be overridden with ONTOLOGY_PROMPT_PATH environment variable.

        Args:
            use_cache: Ignored (kept for API compatibility)
            fs: Optional filesystem instance for dependency injection (defaults to local filesystem)

        Returns:
            Generic prompt string

        Raises:
            FileNotFoundError: If custom prompt file specified but doesn't exist
            IOError: If custom prompt file cannot be read
        """
        import os

        assert use_cache is not None, "use_cache must not be None"
        assert isinstance(use_cache, bool), "use_cache must be a boolean"

        env_path_str = os.getenv("ONTOLOGY_PROMPT_PATH")
        if env_path_str:
            if fs is not None:
                prompt_path = env_path_str
            else:
                from taxonomy_ontology_accelerator.commons.io.file_utils import normalize_path

                prompt_path = normalize_path(env_path_str)
            logger.debug(f"Loading custom prompt from: {prompt_path}")
            return PromptLoader._load_prompt_file(prompt_path, fs=fs)

        logger.debug("Using default ontology prompt from code")
        return DEFAULT_ONTOLOGY_PROMPT

    @staticmethod
    def _inject_source_annotations(batch_chunks: list[str], chunk_sources: list[str]) -> str:
        """
        Inject source annotations into chunks for source grounding.

        Args:
            batch_chunks: List of text chunks
            chunk_sources: List of source identifiers

        Returns:
            Annotated text with source metadata
        """
        assert batch_chunks is not None, "Batch chunks must not be None"
        assert chunk_sources is not None, "Chunk sources must not be None"

        source_annotated_chunks: list[str] = []
        for chunk_idx, chunk in enumerate(batch_chunks):
            source_id = (
                chunk_sources[chunk_idx]
                if chunk_idx < len(chunk_sources)
                else f"unknown_source_{chunk_idx}"
            )
            source_annotated_chunks.append(
                f"SOURCE_URLS: {source_id}\nCHUNK_INDEX: {chunk_idx}\n{chunk}"
            )
        return "\n\n---DOCUMENT_SEPARATOR---\n\n".join(source_annotated_chunks)

    @staticmethod
    def build_prompt(
        generic_prompt: str,
        domain_prompt: str | None = None,
        input_text: str | None = None,
        chunk_sources: list[str] | None = None,
        batch_chunks: list[str] | None = None,
        source_grounding_enabled: bool = False,
        include_instructions: bool = True,
        context_text: str | None = None,
    ) -> str:
        """
        Build final prompt by combining generic prompt with domain prompt and input text.
        Optionally injects source identifiers for source grounding.

        Args:
            generic_prompt: Generic ontology extraction prompt (fixed)
            domain_prompt: Optional domain-specific prompt (appended if provided)
            input_text: Input text to extract from (appended at the end)
            chunk_sources: Optional list of source identifiers for each chunk in batch
            batch_chunks: Optional list of individual chunks (used when injecting sources)
            source_grounding_enabled: Whether source grounding is enabled
            include_instructions: Whether to embed generic/domain instructions in the user prompt
            context_text: Optional dynamic context to prepend before input text

        Returns:
            Final prompt string

        Raises:
            ValueError: If input_text is not provided
        """
        assert generic_prompt is not None, "Generic prompt must not be None"
        assert isinstance(generic_prompt, str), "Generic prompt must be a string"

        if input_text is None:
            msg = (
                "input_text is required to build the prompt.\n"
                "The prompt must include the text content to extract from."
            )
            raise ValueError(msg)

        final_prompt = ""

        if include_instructions:
            final_prompt = generic_prompt.strip()

            if domain_prompt:
                final_prompt += "\n\n## Domain-Specific Instructions\n\n"
                final_prompt += domain_prompt.strip()

        if context_text and context_text.strip():
            if final_prompt:
                final_prompt += "\n\n"
            final_prompt += "## Batch Context\n\n"
            final_prompt += context_text.strip()

        if final_prompt:
            final_prompt += "\n\n"
        final_prompt += "## Input Text\n\n"

        if source_grounding_enabled and chunk_sources and batch_chunks:
            final_prompt += PromptLoader._inject_source_annotations(batch_chunks, chunk_sources)
        else:
            final_prompt += input_text

        return final_prompt

    @staticmethod
    def load_and_build(
        domain_prompt: str | None = None,
        input_text: str | None = None,
    ) -> str:
        """
        Load generic prompt and build final prompt in one call.

        Args:
            domain_prompt: Optional domain-specific prompt
            input_text: Input text to extract from (required)

        Returns:
            Final prompt string

        Raises:
            FileNotFoundError: If prompt file doesn't exist
            ValueError: If input_text is not provided
        """
        assert input_text is None or isinstance(input_text, str), (
            "input_text must be string or None"
        )
        assert domain_prompt is None or isinstance(domain_prompt, str), (
            "domain_prompt must be string or None"
        )

        generic_prompt = PromptLoader.load_prompt()
        return PromptLoader.build_prompt(
            generic_prompt, domain_prompt=domain_prompt, input_text=input_text
        )
