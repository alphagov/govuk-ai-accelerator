"""
File locking utilities for concurrent access protection.

Supports both synchronous (``with FileLock(...)``) and asynchronous
(``async with FileLock(...)``) context-manager usage.  The async path
uses ``asyncio.sleep`` so it never blocks the event loop.
"""

import asyncio
import contextlib
import sys
from pathlib import Path
from types import TracebackType
from typing import TextIO

import fsspec

from taxonomy_ontology_accelerator.commons.utils.logger import get_logger

logger = get_logger()

_lock_available: bool
_lock_type: str | None

if sys.platform == "win32":
    try:
        import msvcrt  # noqa: F401  # pyright: ignore[reportUnusedImport]

        _lock_available = True
        _lock_type = "windows"
    except ImportError:
        _lock_available = False
        _lock_type = None
else:
    try:
        import fcntl  # noqa: F401  # pyright: ignore[reportUnusedImport]

        _lock_available = True
        _lock_type = "unix"
    except ImportError:
        _lock_available = False
        _lock_type = None

# Backwards compatibility aliases for tests
# Backwards compatibility aliases for tests
_LOCK_AVAILABLE = _lock_available
_LOCK_TYPE = _lock_type

class FileLock:
    """
    Context manager for file locking.

    Provides exclusive lock on a file to prevent concurrent writes.
    Falls back gracefully if locking is not available.

    Supports both sync (``with``) and async (``async with``) usage.
    """

    file_path: Path
    max_retries: int
    retry_delay: float
    lock_file: TextIO | None
    locked: bool
    lock_path: Path | None
    fs: fsspec.AbstractFileSystem

    def __init__(self, file_path: Path, max_retries: int = 3, retry_delay: float = 0.1):
        """
        Initialize file lock.

        Args:
            file_path: Path to file to lock
            max_retries: Maximum number of retry attempts
            retry_delay: Delay between retries in seconds
        """
        assert isinstance(file_path, Path), "file_path must be a Path object"
        assert max_retries > 0, "max_retries must be positive"
        assert retry_delay > 0, "retry_delay must be positive"

        self.file_path = file_path
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self.lock_file = None
        self.locked = False
        self.lock_path = None
        self.fs = fsspec.filesystem("file")

    def _acquire_lock(self, lock_file: TextIO) -> None:
        """Acquire platform-specific lock on file handle."""
        assert lock_file is not None, "lock_file must not be None"
        assert _LOCK_TYPE in ("windows", "unix"), f"Invalid lock type: {_LOCK_TYPE}"

        if _LOCK_TYPE == "windows":
            import msvcrt

            msvcrt.locking(lock_file.fileno(), msvcrt.LK_LOCK, 1)
        else:
            import fcntl

            fcntl.flock(lock_file.fileno(), fcntl.LOCK_EX)

    def _handle_lock_retry(self, attempt: int, error: OSError) -> float:
        """Handle lock retry with exponential backoff. Returns delay in seconds."""
        assert attempt >= 0, "attempt must be non-negative"
        assert attempt < self.max_retries, "attempt must be less than max_retries"

        delay = self.retry_delay * pow(2.0, attempt)

        if attempt < self.max_retries - 1:
            msg = (
                f"Failed to acquire lock on {self.file_path} "
                f"(attempt {attempt + 1}/{self.max_retries}): {error}. "
                f"Retrying in {delay:.2f}s..."
            )
            logger.debug(msg)
        else:
            msg = (
                f"Failed to acquire lock on {self.file_path} "
                f"after {self.max_retries} attempts: {error}. "
                f"Proceeding without lock (may cause corruption with concurrent access)."
            )
            logger.error(msg)

        return delay

    def __enter__(self) -> "FileLock":
        """Acquire file lock with retry mechanism."""
        assert self.lock_file is None, "Lock already acquired"
        assert not self.locked, "Lock state inconsistent"

        if not _lock_available:
            msg = (
                f"File locking not available on this platform. "
                f"Concurrent writes to {self.file_path} may cause corruption."
            )
            logger.warning(msg)
            return self

        self.lock_path = self.file_path.with_suffix(self.file_path.suffix + ".lock")

        for attempt in range(self.max_retries):
            try:
                fs = fsspec.filesystem("file")
                self.lock_file = fs.open(str(self.lock_path), "a", encoding="utf-8")
                self._acquire_lock(self.lock_file)
                self.locked = True

                if attempt > 0:
                    logger.debug(f"Acquired lock on {self.file_path} after {attempt + 1} attempts")
                else:
                    logger.debug(f"Acquired lock on {self.file_path}")
                return self

            except OSError as e:
                if self.lock_file:
                    with contextlib.suppress(Exception):
                        self.lock_file.close()
                    self.lock_file = None

                _delay = self._handle_lock_retry(attempt, e)              
                                                            
                                                                                    

        return self

    def _release_lock(self, lock_file: TextIO) -> None:
        """Release platform-specific lock on file handle."""
        assert lock_file is not None, "lock_file must not be None"
        assert _LOCK_TYPE in ("windows", "unix"), f"Invalid lock type: {_LOCK_TYPE}"

        if _LOCK_TYPE == "windows":
            import msvcrt

            msvcrt.locking(lock_file.fileno(), msvcrt.LK_UNLCK, 1)
        else:
            import fcntl

            fcntl.flock(lock_file.fileno(), fcntl.LOCK_UN)

    def __exit__(
        self,
        _exc_type: type[BaseException] | None,
        _exc_val: BaseException | None,
        _exc_tb: TracebackType | None,
    ) -> None:
        """Release file lock."""
        assert not (self.locked and self.lock_file is None), (
            "Lock state inconsistent: locked but no file handle"
        )
        assert not (not self.locked and self.lock_file is not None), (
            "Lock state inconsistent: file handle but not locked"
        )

        if self.lock_file and self.locked:
            try:
                self._release_lock(self.lock_file)
                logger.debug(f"Released lock on {self.file_path}")
            except Exception as e:
                logger.error(f"Error releasing lock on {self.file_path}: {e}")
            finally:
                with contextlib.suppress(Exception):
                    self.lock_file.close()
                self.lock_file = None
                self.locked = False

                if self.lock_path and self.fs.exists(str(self.lock_path)):
                    try:
                        if self.fs.size(str(self.lock_path)) == 0:
                            self.fs.rm(str(self.lock_path))
                            logger.debug(f"Cleaned up lock file: {self.lock_path}")
                    except OSError:
                        pass

                                                                        
                                   
                                                                        

    async def __aenter__(self) -> "FileLock":
        """Acquire file lock asynchronously with retry mechanism."""
        assert self.lock_file is None, "Lock already acquired"
        assert not self.locked, "Lock state inconsistent"

        if not _lock_available:
            msg = (
                f"File locking not available on this platform. "
                f"Concurrent writes to {self.file_path} may cause corruption."
            )
            logger.warning(msg)
            return self

        self.lock_path = self.file_path.with_suffix(self.file_path.suffix + ".lock")

        for attempt in range(self.max_retries):
            try:
                fs = fsspec.filesystem("file")
                self.lock_file = fs.open(str(self.lock_path), "a", encoding="utf-8")
                self._acquire_lock(self.lock_file)
                self.locked = True

                if attempt > 0:
                    logger.debug(f"Acquired lock on {self.file_path} after {attempt + 1} attempts")
                else:
                    logger.debug(f"Acquired lock on {self.file_path}")
                return self

            except OSError as e:
                if self.lock_file:
                    with contextlib.suppress(Exception):
                        self.lock_file.close()
                    self.lock_file = None

                delay = self._handle_lock_retry(attempt, e)
                if attempt < self.max_retries - 1:
                    await asyncio.sleep(delay)

        return self

    async def __aexit__(
        self,
        _exc_type: type[BaseException] | None,
        _exc_val: BaseException | None,
        _exc_tb: TracebackType | None,
    ) -> None:
        """Release file lock (async path delegates to sync release)."""
        self.__exit__(_exc_type, _exc_val, _exc_tb)
