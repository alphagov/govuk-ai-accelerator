"""
Utility to convert schema metadata to graph format for visualization and Neo4j upload.

This module provides functions to convert OntologySchema to a graph structure
that can be visualized in the UI or uploaded to Neo4j.
"""

from typing import Any, cast

from taxonomy_ontology_accelerator.ontology_engine.core.models import (
    EntityTypeDefinition,
    OntologySchema,
    RelationshipTypeDefinition,
)


def _create_entities_from_types(
    entity_types: dict[str, EntityTypeDefinition],
) -> list[dict[str, Any]]:  # pyright: ignore[reportExplicitAny]
    """Create entity list from entity type definitions."""
    assert isinstance(entity_types, dict), "Entity types must be a dict"

    entities: list[dict[str, Any]] = []  # pyright: ignore[reportExplicitAny]
    for type_name, type_def in entity_types.items():
        entity: dict[str, Any] = cast(  # pyright: ignore[reportExplicitAny]
            "dict[str, Any]",  # pyright: ignore[reportExplicitAny]
            {
                "id": f"entity_type_{type_name}",
                "canonical_key": type_name,
                "label": type_name,
                "type": "EntityType",
                "description": f"Entity type: {type_name}",
                "aliases": [],
                "properties": {
                    "fields": type_def.fields or [],
                    "required_fields": type_def.required_fields or [],
                    "is_core": type_name == "entity" or type_def.parent_type is None,
                },
                "metadata": {
                    "created_at": type_def.created_at,
                    "parent_type": type_def.parent_type,
                },
            },
        )
        entities.append(entity)

    assert isinstance(entities, list), "Entities must be a list"
    return entities


def _create_hierarchy_relationships(
    entity_types: dict[str, EntityTypeDefinition],
) -> list[dict[str, Any]]:  # pyright: ignore[reportExplicitAny]
    """Create EXTENDS relationships from entity type hierarchy."""
    assert isinstance(entity_types, dict), "Entity types must be a dict"

    relationships: list[dict[str, Any]] = []  # pyright: ignore[reportExplicitAny]
    for type_name, type_def in entity_types.items():
        parent_type = type_def.parent_type
        if parent_type and parent_type in entity_types:
            rel = {
                "id": f"extends_{parent_type}_{type_name}",
                "from_": f"entity_type_{parent_type}",
                "to": f"entity_type_{type_name}",
                "type": "EXTENDS",
                "description": f"{type_name} extends {parent_type}",
                "properties": {},
                "metadata": {
                    "link_type": "hierarchy",
                },
            }
            relationships.append(rel)

    assert isinstance(relationships, list), "Relationships must be a list"
    return relationships


def _create_relationship_type_edges(
    entity_types: dict[str, EntityTypeDefinition],
    relationship_types: dict[str, RelationshipTypeDefinition],
) -> list[dict[str, Any]]:  # pyright: ignore[reportExplicitAny]
    """Create edges from relationship type definitions."""
    assert isinstance(entity_types, dict), "Entity types must be a dict"
    assert isinstance(relationship_types, dict), "Relationship types must be a dict"

    relationships: list[dict[str, Any]] = []  # pyright: ignore[reportExplicitAny]
    for rel_type_name, rel_def in relationship_types.items():
        from_type = rel_def.from_type or "entity"
        to_type = rel_def.to_type or "entity"

        if from_type in entity_types and to_type in entity_types:
            rel = {
                "id": f"rel_def_{rel_type_name}_{from_type}_{to_type}",
                "from_": f"entity_type_{from_type}",
                "to": f"entity_type_{to_type}",
                "type": rel_type_name,
                "description": f"Relationship type {rel_type_name} from {from_type} to {to_type}",
                "properties": {
                    "is_core": rel_def.is_core or False,
                },
                "metadata": {
                    "link_type": "relationship",
                    "created_at": rel_def.created_at,
                },
            }
            relationships.append(rel)

    assert isinstance(relationships, list), "Relationships must be a list"
    return relationships


def schema_to_graph(schema: OntologySchema) -> dict[str, Any]:  # pyright: ignore[reportExplicitAny]
    """
    Convert OntologySchema to graph.json format.

    Creates a graph representation where:
    - Entity types become nodes (EntityType)
    - parent_type relationships become "EXTENDS" edges
    - Relationship type definitions become edges between entity types

    Args:
        schema: OntologySchema instance

    Returns:
        Graph JSON data with entities and relationships in graph.json format
    """
    assert schema is not None, "Schema must not be None"
    assert schema.domain is not None, "Schema domain must not be None"

    entity_types = schema.entity_types or {}
    relationship_types = schema.relationship_types or {}

    entities = _create_entities_from_types(entity_types)
    hierarchy_rels = _create_hierarchy_relationships(entity_types)
    rel_type_edges = _create_relationship_type_edges(entity_types, relationship_types)

    relationships = hierarchy_rels + rel_type_edges

    result = {
        "domain": schema.domain,
        "schema_version": schema.version,
        "entities": entities,
        "relationships": relationships,
    }

    assert "entities" in result, "Result must contain entities key"
    assert "relationships" in result, "Result must contain relationships key"
    assert isinstance(result["entities"], list), "Entities must be a list"
    assert isinstance(result["relationships"], list), "Relationships must be a list"

    return result
