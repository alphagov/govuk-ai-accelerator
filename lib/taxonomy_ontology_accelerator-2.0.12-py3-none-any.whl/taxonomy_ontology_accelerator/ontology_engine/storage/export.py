"""
OWL/RDF export module for ontology engine.

Exports ontology schema and graph to OWL/RDF formats (Turtle and RDF/XML).

Architecture:
- Reads schema.json and graph.json (or accepts Pydantic models)
- Maps entity types → OWL Classes
- Maps relationship types → OWL ObjectProperties
- Maps entities → OWL Individuals
- Maps relationships → OWL Property Assertions
- Exports metadata using reification (for relationship metadata)
- Supports Turtle (.ttl) and RDF/XML (.owl) formats

Namespace Conventions:
- Base: http://example.org/ontology/{domain}/#
- Entity: http://example.org/ontology/{domain}/entity#
- Relationship: http://example.org/ontology/{domain}/relationship#
"""
import csv
import io
import json
import re
import tempfile
import time
from collections import Counter
from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path
from typing import Any

from pydantic import ValidationError

from taxonomy_ontology_accelerator.commons.io.file_utils import safe_read_file, safe_write_file
from taxonomy_ontology_accelerator.commons.io.fsspec_utils import get_default_filesystem
from taxonomy_ontology_accelerator.commons.utils.logger import get_logger
from taxonomy_ontology_accelerator.ontology_engine.config.config import (
    ClassAlignmentRuleConfig,
    OntologyConfig,
)
from taxonomy_ontology_accelerator.ontology_engine.core.models import (
    Entity,
    OntologyGraph,
    OntologySchema,
    RestrictionType,
    apply_type_casing,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.text_normalization import (
    split_identifier_words,
)

logger = get_logger()

# ========================================================================
# Try to import rdflib (optional dependency)
try:
    from rdflib import BNode, Graph, Literal, Namespace, URIRef
    from rdflib.namespace import OWL, RDF, RDFS, SKOS, XSD

    RDFLIB_AVAILABLE = True
except ImportError:
    RDFLIB_AVAILABLE = False
    logger.warning("rdflib not available - OWL/RDF export will not work")

# Dublin Core Terms namespace
# Dublin Core Terms namespace
DCTERMS = Namespace("http://purl.org/dc/terms/") if RDFLIB_AVAILABLE else None

_NOISY_PARENT_TYPE_NAMES = frozenset(
    {
        "entity",
        "thing",
        "object",
        "item",
        "concept",
        "resource",
        "node",
        "element",
        "misc",
        "other",
        "unknown",
        "error",
        "errors",
        "exception",
    }
)

_SKIP_EXPORT_TYPES = {"entity", "thing", "object", "item", "concept", "resource",
                      "node", "element", "misc", "other", "unknown", "error"}


@dataclass
class _ExportBuildContext:
    """Per-export caches and derived lookups for graph assembly."""

    schema_obj: OntologySchema
    graph_obj: OntologyGraph
    namespaces: dict[str, Any]
    ontology_config: OntologyConfig | None
    correction_vocabulary: set[str]
    entity_label_casing: str
    entity_iri_spelling_variant: str
    entity_label_language_tag: str | None
    relationship_type_casing: str
    allowed_props: set[str] | None
    object_property_conflict_keys: set[str]
    class_uri_cache: dict[str, Any] = field(default_factory=dict)
    relationship_uri_cache: dict[str, Any] = field(default_factory=dict)
    property_uri_cache: dict[str, Any] = field(default_factory=dict)
    normalized_text_cache: dict[tuple[str, bool], str] = field(default_factory=dict)
    property_conflict_key_cache: dict[str, frozenset[str]] = field(default_factory=dict)
    converted_property_key_cache: dict[str, str] = field(default_factory=dict)
    schema_proxy_type_match_keys: dict[str, frozenset[str]] = field(default_factory=dict)
    schema_type_depths: dict[str, int] = field(default_factory=dict)
    ancestor_cache: dict[tuple[str, str], bool] = field(default_factory=dict)
    entity_proxy_type_cache: dict[str, str | None] = field(default_factory=dict)
    entity_id_to_uri: dict[str, Any] = field(default_factory=dict)
    entity_id_to_entity: dict[str, Entity] = field(default_factory=dict)


def _build_export_context(
    schema_obj: OntologySchema,
    graph_obj: OntologyGraph,
    namespaces: dict[str, Any],
    ontology_config: OntologyConfig | None,
) -> _ExportBuildContext:
    """Build per-export derived lookups once before entering hot loops."""
    correction_vocabulary = _build_export_correction_vocabulary(
        schema_obj,
        graph_obj,
        ontology_config,
    )
    entity_label_casing = _get_entity_label_casing(ontology_config)
    entity_iri_spelling_variant = "preserve"
    entity_label_language_tag = None
    relationship_type_casing = "lowerCamelCase"
    if ontology_config and ontology_config.naming_conventions:
        entity_iri_spelling_variant = ontology_config.naming_conventions.entity_iri_spelling_variant
        entity_label_language_tag = ontology_config.naming_conventions.entity_label_language_tag
        relationship_type_casing = ontology_config.naming_conventions.relationship_type_casing

    prop_counts = Counter(
        key
        for entity in graph_obj.entities
        if not _resolve_schema_proxy_type(entity, schema_obj)
        for key in (entity.properties or {})
        if key not in _SKIP_ENTITY_PROPERTY_KEYS
    )
    min_freq = 1
    if ontology_config and ontology_config.output and ontology_config.output.export:
        min_freq = getattr(ontology_config.output.export, "min_property_frequency", 1)
    allowed_props = {key for key, count in prop_counts.items() if count >= min_freq} if min_freq > 1 else None
    object_property_conflict_keys = _build_object_property_conflict_keys(
        schema_obj,
        relationship_type_casing,
    )

    context = _ExportBuildContext(
        schema_obj=schema_obj,
        graph_obj=graph_obj,
        namespaces=namespaces,
        ontology_config=ontology_config,
        correction_vocabulary=correction_vocabulary,
        entity_label_casing=entity_label_casing,
        entity_iri_spelling_variant=entity_iri_spelling_variant,
        entity_label_language_tag=entity_label_language_tag,
        relationship_type_casing=relationship_type_casing,
        allowed_props=allowed_props,
        object_property_conflict_keys=object_property_conflict_keys,
        entity_id_to_entity={entity.id: entity for entity in graph_obj.entities},
    )

    context.schema_proxy_type_match_keys = {
        type_name: _build_schema_proxy_match_keys(type_name)
        for type_name in schema_obj.entity_types
        if type_name.strip().lower() not in _SKIP_EXPORT_TYPES
    }
    context.schema_type_depths = {
        type_name: _schema_type_depth(type_name, schema_obj)
        for type_name in schema_obj.entity_types
    }
    context.class_uri_cache = {
        type_name: (
            URIRef(type_def.uri)
            if type_def.uri
            else namespaces["base_ns"][_sanitize_uri_component(type_name)]
        )
        for type_name, type_def in schema_obj.entity_types.items()
    }
    return context


def _normalize_export_literal_text_cached(
    text: str,
    export_context: _ExportBuildContext,
    *,
    use_entity_label_variant: bool = False,
) -> str:
    """Memoize exported literal normalization for repeated labels and text values."""
    cache_key = (text, use_entity_label_variant)
    cached = export_context.normalized_text_cache.get(cache_key)
    if cached is not None:
        return cached

    normalized = _normalize_export_literal_text(
        text,
        export_context.ontology_config,
        correction_vocabulary=export_context.correction_vocabulary,
        use_entity_label_variant=use_entity_label_variant,
    )
    export_context.normalized_text_cache[cache_key] = normalized
    return normalized


def _get_class_uri(type_name: str, export_context: _ExportBuildContext):
    """Return a cached URI for a schema class name."""
    if type_name not in export_context.class_uri_cache:
        export_context.class_uri_cache[type_name] = export_context.namespaces["base_ns"][
            _sanitize_uri_component(type_name)
        ]
    return export_context.class_uri_cache[type_name]


def _get_relationship_uri(rel_name_for_uri: str, export_context: _ExportBuildContext):
    """Return a cached URI for a relationship/property name."""
    if rel_name_for_uri not in export_context.relationship_uri_cache:
        export_context.relationship_uri_cache[rel_name_for_uri] = export_context.namespaces["base_ns"][
            _sanitize_uri_component(rel_name_for_uri)
        ]
    return export_context.relationship_uri_cache[rel_name_for_uri]


def _get_property_uri(prop_name: str, export_context: _ExportBuildContext):
    """Return a cached URI for an entity property key."""
    if prop_name not in export_context.property_uri_cache:
        export_context.property_uri_cache[prop_name] = export_context.namespaces["base_ns"][
            _sanitize_uri_component(prop_name)
        ]
    return export_context.property_uri_cache[prop_name]


def _get_property_conflict_keys_cached(
    text: str,
    export_context: _ExportBuildContext,
) -> frozenset[str]:
    """Return cached conflict keys for a property string."""
    cached = export_context.property_conflict_key_cache.get(text)
    if cached is not None:
        return cached
    cached = _build_property_conflict_keys(text)
    export_context.property_conflict_key_cache[text] = cached
    return cached


@lru_cache(maxsize=65536)
def _sanitize_uri_component(component: str) -> str:
    """
    Sanitize string for use in URI (replace invalid characters).

    Args:
        component: String to sanitize

    Returns:
        Sanitized string safe for URI use
    """
    assert component is not None, "component parameter is required"
    assert isinstance(component, str), "component must be a string"
    # Replace spaces and special characters with underscores
    # Keep alphanumeric, underscores, and hyphens
    # Replace spaces and special characters with underscores
    # Keep alphanumeric, underscores, and hyphens
    import re

    # Replace invalid URI characters with underscore
    sanitized = re.sub(r"[^a-zA-Z0-9_-]", "_", component)
    # Remove consecutive underscores
    # Remove consecutive underscores
    sanitized = re.sub(r"_+", "_", sanitized)
    # Remove leading/trailing underscores
    # Remove leading/trailing underscores
    return sanitized.strip("_")


@lru_cache(maxsize=65536)
def _apply_naming_convention_to_uri(component: str, casing: str) -> str:
    """
    Apply naming convention casing to a URI component.

    This ensures URIs match the configured naming conventions for OWL validation.

    Args:
        component: The URI component (e.g., canonical_key, relationship type)
        casing: The casing style ('UpperCamelCase', 'lowerCamelCase', 'snake_case', 'preserve')

    Returns:
        URI component with naming convention applied
    """
    assert component is not None, "component parameter is required"
    assert isinstance(component, str), "component must be a string"
    assert casing in ("UpperCamelCase", "lowerCamelCase", "snake_case", "preserve"), (
        f"Invalid casing: {casing}"
    )

    if casing == "preserve":
        return component

    # Apply casing transformation
    # Apply casing transformation
    if casing in ("UpperCamelCase", "lowerCamelCase"):
        # Use the type casing function for URI components
        return apply_type_casing(component, casing)
    if casing == "snake_case":
        # Already in snake_case from canonical_key generation
        # Already in snake_case from canonical_key generation
        return component
    return component


def _load_schema_for_export(schema: OntologySchema | Path) -> OntologySchema:
    """
    Load schema from Path or return directly if already OntologySchema.

    Args:
        schema: OntologySchema Pydantic model or Path to schema.json file

    Returns:
        Loaded OntologySchema object

    Raises:
        FileNotFoundError: If schema file doesn't exist
        ValueError: If schema file is invalid JSON or doesn't match schema
    """
    assert schema is not None, "schema parameter is required"
    assert isinstance(schema, OntologySchema | Path), "schema must be OntologySchema or Path"
    try:
        if isinstance(schema, Path):
            fs = get_default_filesystem()
            if not fs.exists(str(schema)):
                raise FileNotFoundError(f"Schema file not found: {schema}")
            schema_data = json.loads(safe_read_file(schema))
            schema_obj = OntologySchema(**schema_data)
            logger.debug(f"Loaded schema from file: {schema}")
            return schema_obj
        logger.debug("Using provided schema object")
        return schema
    except (json.JSONDecodeError, ValidationError) as e:
        raise ValueError(f"Failed to load/parse schema: {e}") from e
    except OSError as e:
        raise FileNotFoundError(f"Failed to read schema file: {e}") from e


def _load_graph_for_export(graph: OntologyGraph | Path) -> OntologyGraph:
    """
    Load graph from Path or return directly if already OntologyGraph.

    Args:
        graph: OntologyGraph Pydantic model or Path to graph.json file

    Returns:
        Loaded OntologyGraph object

    Raises:
        FileNotFoundError: If graph file doesn't exist
        ValueError: If graph file is invalid JSON or doesn't match schema
    """
    assert graph is not None, "graph parameter is required"
    assert isinstance(graph, OntologyGraph | Path), "graph must be OntologyGraph or Path"
    try:
        if isinstance(graph, Path):
            fs = get_default_filesystem()
            if not fs.exists(str(graph)):
                raise FileNotFoundError(f"Graph file not found: {graph}")
            graph_data = json.loads(safe_read_file(graph))
            graph_obj = OntologyGraph(**graph_data)
            logger.debug(f"Loaded graph from file: {graph}")
            return graph_obj
        logger.debug("Using provided graph object")
        return graph
    except (json.JSONDecodeError, ValidationError) as e:
        raise ValueError(f"Failed to load/parse graph: {e}") from e
    except OSError as e:
        raise FileNotFoundError(f"Failed to read graph file: {e}") from e


def _validate_export_domains(
    schema_obj: OntologySchema, graph_obj: OntologyGraph
) -> tuple[str, str]:
    """
    Validate that schema and graph domains match.

    Args:
        schema_obj: The loaded schema object
        graph_obj: The loaded graph object

    Returns:
        Tuple of (domain, sanitized_domain)

    Raises:
        ValueError: If domains don't match after sanitization
    """
    assert schema_obj is not None, "schema_obj parameter is required"
    assert graph_obj is not None, "graph_obj parameter is required"
    schema_domain_sanitized = _sanitize_uri_component(schema_obj.domain)
    graph_domain_sanitized = _sanitize_uri_component(graph_obj.domain)

    if schema_domain_sanitized != graph_domain_sanitized:
        error_msg = (
            f"Domain mismatch: schema has '{schema_obj.domain}', graph has '{graph_obj.domain}'"
        )
        logger.error(error_msg)
        raise ValueError(error_msg)

    return schema_obj.domain, _sanitize_uri_component(schema_obj.domain)


def _create_rdf_namespaces(sanitized_domain: str, export_config=None) -> dict:
    """
    Create RDF namespaces for the ontology export.

    Args:
        sanitized_domain: Sanitized domain name for URI construction
        export_config: Optional ExportConfig with configurable base_uri

    Returns:
        Dictionary containing namespace objects and property URIs
    """
    assert sanitized_domain is not None, "sanitized_domain parameter is required"
    assert isinstance(sanitized_domain, str), "sanitized_domain must be a string"

    base_uri = "http://example.org/ontology"
    rel_suffix = "/relationship#"

    if export_config is not None:
        base_uri = export_config.base_uri
        rel_suffix = export_config.relationship_uri_suffix

    base_ns = Namespace(f"{base_uri}/{sanitized_domain}/#")
    entity_ns = base_ns
    rel_ns = Namespace(f"{base_uri}/{sanitized_domain}{rel_suffix}")

    return {
        "base_ns": base_ns,
        "entity_ns": entity_ns,
        "rel_ns": rel_ns,
        "confidence_prop": base_ns["confidence"],
        "extracted_at_prop": base_ns["extractedAt"],
    }


def _bind_rdf_namespaces(g, namespaces: dict) -> None:
    """
    Bind namespaces to the RDF graph.

    Args:
        g: RDF Graph object
        namespaces: Dictionary containing namespace objects
    """
    assert g is not None, "g (RDF Graph) parameter is required"
    assert namespaces is not None, "namespaces parameter is required"
    g.bind("", namespaces["base_ns"])
    g.bind("rel", namespaces["rel_ns"])
    g.bind("rdf", RDF)
    g.bind("rdfs", RDFS)
    g.bind("owl", OWL)
    g.bind("xsd", XSD)
    g.bind("skos", SKOS)
    if DCTERMS is not None:
        g.bind("dcterms", DCTERMS)


def _bind_configured_alignment_namespaces(g, ontology_config: OntologyConfig | None) -> None:
    """Bind optional external vocabulary namespaces used by class alignments."""
    assert g is not None, "g (RDF Graph) parameter is required"

    if (
        ontology_config is None
        or ontology_config.output is None
        or ontology_config.output.export is None
    ):
        return

    class_alignments = ontology_config.output.export.class_alignments
    if not class_alignments.enabled:
        return

    for prefix, uri in class_alignments.namespace_bindings.items():
        if not prefix or not uri:
            continue
        g.bind(prefix, Namespace(uri))


def _add_ontology_declaration(
    g,
    domain: str,
    schema_obj: OntologySchema,
    ontology_config: OntologyConfig | None = None,
) -> None:
    """
    Add ontology declaration, Dublin Core metadata, and owl:imports to RDF graph.

    Args:
        g: RDF Graph object
        domain: Domain name
        schema_obj: Schema object containing version info
    """
    assert g is not None, "g (RDF Graph) parameter is required"
    assert domain is not None, "domain parameter is required"
    ontology_uri = URIRef("")
    label_language_tag = _get_export_label_language_tag(ontology_config)
    g.add((ontology_uri, RDF.type, OWL.Ontology))
    g.add(
        (
            ontology_uri,
            RDFS.label,
            _build_label_literal(f"{domain.title()} Ontology", label_language_tag),
        )
    )
    g.add((ontology_uri, OWL.versionInfo, Literal(schema_obj.version)))
    g.add((ontology_uri, OWL.imports, URIRef(str(SKOS))))

    # Dublin Core metadata (DCTERMS is only available when rdflib is installed)
    # Dublin Core metadata (DCTERMS is only available when rdflib is installed)
    assert DCTERMS is not None, "DCTERMS namespace requires rdflib"
    g.add((ontology_uri, DCTERMS.title, Literal(f"{domain.title()} Ontology")))
    g.add((ontology_uri, DCTERMS.description, Literal(f"Ontology for the {domain} domain")))
    g.add((ontology_uri, DCTERMS.created, Literal(schema_obj.last_updated, datatype=XSD.dateTime)))

def _add_graph_metadata(g, graph_obj: OntologyGraph, namespaces: dict) -> None:
    """
    Add graph-level metadata (extracted_at timestamp) to RDF graph.

    Args:
        g: RDF Graph object
        graph_obj: Graph object containing metadata
        namespaces: Dictionary containing namespace objects
    """
    assert g is not None, "g (RDF Graph) parameter is required"
    assert namespaces is not None, "namespaces parameter is required"
    if not graph_obj.extracted_at:
        return

    ontology_uri = URIRef("")
    extracted_at_prop = namespaces["extracted_at_prop"]
    g.add(
        (
            ontology_uri,
            extracted_at_prop,
            Literal(graph_obj.extracted_at, datatype=XSD.dateTime),
        )
    )


def _add_normalization_rules(g, schema_obj: OntologySchema, namespaces: dict) -> None:
    """
    Add normalization rules as ontology annotations.

    Args:
        g: RDF Graph object
        schema_obj: Schema object containing normalization rules
        namespaces: Dictionary containing namespace objects
    """
    assert g is not None, "g (RDF Graph) parameter is required"
    assert namespaces is not None, "namespaces parameter is required"
    if not schema_obj.normalization_rules:
        return

    ontology_uri = URIRef("")
    base_ns = namespaces["base_ns"]

    for key, value in schema_obj.normalization_rules.items():
        if isinstance(value, str | int | float | bool):
            norm_prop_uri = base_ns[f"normalization_{key}"]
            g.add((ontology_uri, norm_prop_uri, Literal(value)))


def _add_schema_history(g, schema_obj: OntologySchema, namespaces: dict) -> None:
    """
    Add schema history as version annotations.

    Args:
        g: RDF Graph object
        schema_obj: Schema object containing history
        namespaces: Dictionary containing namespace objects
    """
    assert g is not None, "g (RDF Graph) parameter is required"
    assert namespaces is not None, "namespaces parameter is required"
    if not schema_obj.history:
        return

    ontology_uri = URIRef("")
    extracted_at_prop = namespaces["extracted_at_prop"]

    for history_entry in schema_obj.history:
        if not isinstance(history_entry, dict):
            continue

        version = history_entry.get("version")
        if not version:
            continue

        g.add((ontology_uri, OWL.versionInfo, Literal(version)))

        timestamp = history_entry.get("timestamp")
        if timestamp:
            g.add(
                (
                    ontology_uri,
                    extracted_at_prop,
                    Literal(timestamp, datatype=XSD.dateTime),
                )
            )

        changes = history_entry.get("changes", [])
        if changes:
            changes_str = "; ".join(changes)
            g.add(
                (
                    ontology_uri,
                    RDFS.comment,
                    Literal(f"Version {version}: {changes_str}"),
                )
            )


def _add_restriction_value(g, restriction_node, restriction, base_ns) -> None:
    """Add restriction value based on restriction type."""
    assert g is not None, "g parameter is required"
    assert restriction is not None, "restriction parameter is required"

    rtype = restriction.restriction_type
    if rtype == RestrictionType.SOME_VALUES_FROM:
        filler = restriction.value or restriction.on_class
        value_uri = base_ns[_sanitize_uri_component(str(filler))]
        g.add((restriction_node, OWL.someValuesFrom, value_uri))
    elif rtype == RestrictionType.ALL_VALUES_FROM:
        filler = restriction.value or restriction.on_class
        value_uri = base_ns[_sanitize_uri_component(str(filler))]
        g.add((restriction_node, OWL.allValuesFrom, value_uri))
    elif rtype == RestrictionType.HAS_VALUE:
        g.add((restriction_node, OWL.hasValue, Literal(restriction.value)))
    elif rtype in (RestrictionType.MIN_CARDINALITY, RestrictionType.MIN_QUALIFIED_CARDINALITY):
        g.add(
            (
                restriction_node,
                OWL.minCardinality,
                Literal(int(restriction.value), datatype=XSD.nonNegativeInteger),
            )
        )
    elif rtype in (RestrictionType.MAX_CARDINALITY, RestrictionType.MAX_QUALIFIED_CARDINALITY):
        g.add(
            (
                restriction_node,
                OWL.maxCardinality,
                Literal(int(restriction.value), datatype=XSD.nonNegativeInteger),
            )
        )
    elif rtype in (RestrictionType.EXACT_CARDINALITY, RestrictionType.EXACT_QUALIFIED_CARDINALITY):
        g.add(
            (
                restriction_node,
                OWL.cardinality,
                Literal(int(restriction.value), datatype=XSD.nonNegativeInteger),
            )
        )


def _export_owl_restriction(g, class_uri, restriction, base_ns) -> None:
    """Export a single OWL restriction as an anonymous restriction class."""
    assert g is not None, "g parameter is required"
    assert restriction is not None, "restriction parameter is required"

    if restriction.restriction_type in (
        RestrictionType.SOME_VALUES_FROM,
        RestrictionType.ALL_VALUES_FROM,
    ) and not (restriction.value or restriction.on_class):
        return


    restriction_node = BNode()
    g.add((restriction_node, RDF.type, OWL.Restriction))

    sanitized_prop = _sanitize_uri_component(restriction.property)
    g.add((restriction_node, OWL.onProperty, base_ns[sanitized_prop]))

    _add_restriction_value(g, restriction_node, restriction, base_ns)

    if restriction.on_class and restriction.restriction_type in (
        RestrictionType.MIN_QUALIFIED_CARDINALITY,
        RestrictionType.MAX_QUALIFIED_CARDINALITY,
        RestrictionType.EXACT_QUALIFIED_CARDINALITY,
    ):
        on_class_uri = base_ns[_sanitize_uri_component(restriction.on_class)]
        g.add((restriction_node, OWL.onClass, on_class_uri))

    g.add((class_uri, RDFS.subClassOf, restriction_node))


def _declare_annotation_properties(
    g,
    namespaces: dict,
    ontology_config: OntologyConfig | None = None,
) -> None:
    """
    Declare annotation properties used in the ontology export.

    Declares 'confidence' and 'extractedAt' as owl:AnnotationProperty
    with appropriate rdfs:range so OWL reasoners can interpret them.

    Args:
        g: RDF Graph object
        namespaces: Dictionary containing namespace objects
    """
    assert g is not None, "g parameter is required"
    assert namespaces is not None, "namespaces parameter is required"
    label_language_tag = _get_export_label_language_tag(ontology_config)

    confidence_prop = namespaces["confidence_prop"]
    g.add((confidence_prop, RDF.type, OWL.AnnotationProperty))
    g.add((confidence_prop, RDFS.label, _build_label_literal("confidence", label_language_tag)))
    g.add((confidence_prop, RDFS.range, XSD.float))

    extracted_at_prop = namespaces["extracted_at_prop"]
    g.add((extracted_at_prop, RDF.type, OWL.AnnotationProperty))
    g.add(
        (
            extracted_at_prop,
            RDFS.label,
            _build_label_literal("extractedAt", label_language_tag),
        )
    )
    g.add((extracted_at_prop, RDFS.range, XSD.dateTime))


def _build_rdf_list(g, items: list) -> "BNode":
    """
    Build an RDF collection (list) from a list of RDF terms.

    Args:
        g: RDF Graph object
        items: List of URIRef or Literal items

    Returns:
        BNode representing the head of the RDF list
    """
    assert g is not None, "g parameter is required"
    assert items is not None, "items parameter is required"
    assert len(items) > 0, "items must be a non-empty list"

    head = BNode()
    current = head
    for i, item in enumerate(items):
        g.add((current, RDF.first, item))
        if i < len(items) - 1:
            next_node = BNode()
            g.add((current, RDF.rest, next_node))
            current = next_node
        else:
            g.add((current, RDF.rest, RDF.nil))
    return head


def _export_class_expression(g, class_uri, class_expr, base_ns) -> None:
    """
    Export an OWL class expression (unionOf, intersectionOf, complementOf).

    Args:
        g: RDF Graph object
        class_uri: URI of the class to attach expression to
        class_expr: ClassExpression object
        base_ns: Base namespace
    """
    assert g is not None, "g parameter is required"
    assert class_expr is not None, "class_expr parameter is required"

    if not class_expr.classes:
        return

    expr_type = class_expr.expression_type.lower()
    class_uris = [base_ns[_sanitize_uri_component(c)] for c in class_expr.classes]

    if expr_type == "complementof" and len(class_uris) == 1:
        complement_node = BNode()
        g.add((complement_node, RDF.type, OWL.Class))
        g.add((complement_node, OWL.complementOf, class_uris[0]))
        g.add((class_uri, OWL.equivalentClass, complement_node))
    elif (
        expr_type in ("unionof", "intersectionof")
        and len(class_uris) >= _MIN_CLASSES_FOR_EXPRESSION
    ):
        rdf_list = _build_rdf_list(g, class_uris)
        expr_node = BNode()
        g.add((expr_node, RDF.type, OWL.Class))
        owl_prop = OWL.unionOf if expr_type == "unionof" else OWL.intersectionOf
        g.add((expr_node, owl_prop, rdf_list))
        g.add((class_uri, OWL.equivalentClass, expr_node))


# Built-in fields that should not be exported as DatatypeProperty
_BUILTIN_ENTITY_FIELDS = {"id", "label", "aliases", "description"}

# Minimum number of classes for union/intersection expressions
# Minimum number of classes for union/intersection expressions
_MIN_CLASSES_FOR_EXPRESSION = 2

# Minimum number of properties for a property chain
# Minimum number of properties for a property chain
_MIN_PROPERTIES_FOR_CHAIN = 2


def _export_entity_type_fields(g, class_uri, type_def, base_ns) -> None:
    """Export entity type fields as DatatypeProperty (skip built-ins)."""
    assert g is not None, "g parameter is required"
    assert type_def is not None, "type_def parameter is required"

    if not type_def.fields:
        return

    for field_name in type_def.fields:
        if field_name in _BUILTIN_ENTITY_FIELDS:
            continue
        field_uri = base_ns[_sanitize_uri_component(field_name)]
        g.add((field_uri, RDF.type, OWL.DatatypeProperty))
        g.add((field_uri, RDFS.domain, class_uri))
        g.add((field_uri, RDFS.range, XSD.string))


def _export_entity_type_axioms(g, class_uri, type_def, base_ns) -> None:
    """Export entity type axioms (equivalent_classes, disjoint_with, class_expression)."""
    assert g is not None, "g parameter is required"
    assert type_def is not None, "type_def parameter is required"

    for equiv_class in type_def.equivalent_classes:
        g.add((class_uri, OWL.equivalentClass, base_ns[_sanitize_uri_component(equiv_class)]))

    for disjoint_class in type_def.disjoint_with:
        g.add((class_uri, OWL.disjointWith, base_ns[_sanitize_uri_component(disjoint_class)]))

    if type_def.class_expression:
        _export_class_expression(g, class_uri, type_def.class_expression, base_ns)


_CLASS_ALIGNMENT_PREDICATES = {
    "equivalentClass": OWL.equivalentClass,
    "subClassOf": RDFS.subClassOf,
    "closeMatch": SKOS.closeMatch,
}


def _iter_configured_class_alignments(
    ontology_config: OntologyConfig | None,
) -> list[ClassAlignmentRuleConfig]:
    """Return validated export-time class alignment mappings."""
    if (
        ontology_config is None
        or ontology_config.output is None
        or ontology_config.output.export is None
    ):
        return []

    class_alignments = ontology_config.output.export.class_alignments
    if not class_alignments.enabled:
        return []

    validated_mappings: list[ClassAlignmentRuleConfig] = []
    for mapping in class_alignments.class_mappings:
        if isinstance(mapping, ClassAlignmentRuleConfig):
            validated_mappings.append(mapping)
            continue
        try:
            validated_mappings.append(ClassAlignmentRuleConfig.model_validate(mapping))
        except ValidationError:
            logger.warning(f"Skipping invalid class alignment mapping: {mapping!r}")
    return validated_mappings


def _export_class_alignments(
    g,
    schema_obj: OntologySchema,
    namespaces: dict,
    ontology_config: OntologyConfig | None,
    export_context: _ExportBuildContext | None = None,
) -> None:
    """Export configured mappings from local classes to external vocabularies."""
    assert g is not None, "g (RDF Graph) parameter is required"
    assert schema_obj is not None, "schema_obj parameter is required"
    assert namespaces is not None, "namespaces parameter is required"

    for mapping in _iter_configured_class_alignments(ontology_config):
        local_type = mapping.local_type.strip()
        if local_type not in schema_obj.entity_types:
            continue
        if local_type.lower() in _SKIP_EXPORT_TYPES:
            continue

        type_def = schema_obj.entity_types[local_type]
        class_uri = (
            _get_class_uri(local_type, export_context)
            if export_context is not None
            else (
                URIRef(type_def.uri)
                if type_def.uri
                else namespaces["base_ns"][_sanitize_uri_component(local_type)]
            )
        )
        predicate_uri = _CLASS_ALIGNMENT_PREDICATES.get(mapping.predicate)
        if predicate_uri is None:
            continue
        g.add((class_uri, predicate_uri, URIRef(mapping.target_uri)))


def _export_entity_types(
    g,
    schema_obj: OntologySchema,
    namespaces: dict,
    ontology_config: OntologyConfig | None = None,
    export_context: _ExportBuildContext | None = None,
) -> None:
    """Export entity types to OWL Classes with DatatypeProperty declarations."""
    assert g is not None, "g (RDF Graph) parameter is required"
    assert schema_obj is not None, "schema_obj parameter is required"
    base_ns = namespaces["base_ns"]
    label_language_tag = _get_export_label_language_tag(ontology_config)

    for type_name, type_def in schema_obj.entity_types.items():
        if type_name.strip().lower() in _SKIP_EXPORT_TYPES:
            continue
        class_uri = (
            _get_class_uri(type_name, export_context)
            if export_context is not None
            else (
                URIRef(type_def.uri)
                if type_def.uri
                else base_ns[_sanitize_uri_component(type_name)]
            )
        )

        g.add((class_uri, RDF.type, OWL.Class))
        type_label = (
            _normalize_export_literal_text_cached(type_name, export_context)
            if export_context is not None
            else _normalize_export_literal_text(type_name, ontology_config)
        )
        label_language_tag = (
            export_context.entity_label_language_tag
            if export_context is not None
            else _get_export_label_language_tag(ontology_config)
        )
        g.add((class_uri, RDFS.label, _build_label_literal(type_label, label_language_tag)))

        if type_def.parent_type:
            parent_name = type_def.parent_type.strip()
            parent_lower = parent_name.lower()
            if parent_lower not in _NOISY_PARENT_TYPE_NAMES and not re.fullmatch(r"error\d+", parent_lower):
                parent_uri = (
                    _get_class_uri(parent_name, export_context)
                    if export_context is not None
                    else base_ns[_sanitize_uri_component(parent_name)]
                )
                g.add((class_uri, RDFS.subClassOf, parent_uri))

        _export_entity_type_fields(g, class_uri, type_def, base_ns)

        for restriction in type_def.restrictions:
            _export_owl_restriction(g, class_uri, restriction, base_ns)

        _export_entity_type_axioms(g, class_uri, type_def, base_ns)


_OWL_CHARACTERISTIC_MAPPING = {
    "Functional": OWL.FunctionalProperty,
    "InverseFunctional": OWL.InverseFunctionalProperty,
    "Transitive": OWL.TransitiveProperty,
    "Symmetric": OWL.SymmetricProperty,
    "Asymmetric": OWL.AsymmetricProperty,
    "Reflexive": OWL.ReflexiveProperty,
    "Irreflexive": OWL.IrreflexiveProperty,
}


def _export_property_characteristics(g, prop_uri, rel_def) -> None:
    """Export OWL property characteristics (Functional, Transitive, etc.)."""
    assert g is not None, "g parameter is required"
    assert rel_def is not None, "rel_def parameter is required"

    for characteristic in rel_def.characteristics:
        char_value = (
            characteristic.value if hasattr(characteristic, "value") else str(characteristic)
        )
        owl_class = _OWL_CHARACTERISTIC_MAPPING.get(char_value)
        if owl_class:
            g.add((prop_uri, RDF.type, owl_class))


def _export_property_axioms(g, prop_uri, rel_def, base_ns) -> None:
    """Export property axioms (inverse, sub_property, equivalent, chain, disjoint)."""
    assert g is not None, "g parameter is required"
    assert rel_def is not None, "rel_def parameter is required"

    if rel_def.inverse_of:
        g.add((prop_uri, OWL.inverseOf, base_ns[_sanitize_uri_component(rel_def.inverse_of)]))

    if rel_def.sub_property_of:
        g.add(
            (
                prop_uri,
                RDFS.subPropertyOf,
                base_ns[_sanitize_uri_component(rel_def.sub_property_of)],
            )
        )

    for equiv_prop in rel_def.equivalent_properties:
        g.add((prop_uri, OWL.equivalentProperty, base_ns[_sanitize_uri_component(equiv_prop)]))

    if (
        rel_def.property_chain
        and len(rel_def.property_chain.properties) >= _MIN_PROPERTIES_FOR_CHAIN
    ):
        chain_uris = [
            base_ns[_sanitize_uri_component(p)] for p in rel_def.property_chain.properties
        ]
        g.add((prop_uri, OWL.propertyChainAxiom, _build_rdf_list(g, chain_uris)))

    for disjoint_prop in rel_def.disjoint_with:
        g.add((prop_uri, OWL.propertyDisjointWith, base_ns[_sanitize_uri_component(disjoint_prop)]))


def _export_relationship_types(
    g,
    schema_obj: OntologySchema,
    namespaces: dict,
    ontology_config: OntologyConfig | None = None,
    export_context: _ExportBuildContext | None = None,
) -> None:
    """Export relationship types to OWL ObjectProperties."""
    assert g is not None, "g (RDF Graph) parameter is required"
    assert schema_obj is not None, "schema_obj parameter is required"
    base_ns = namespaces["base_ns"]
    label_language_tag = _get_export_label_language_tag(ontology_config)

    # Get naming convention for relationship types (used for URIs)
    # Get naming convention for relationship types (used for URIs)
    relationship_type_casing = "lowerCamelCase"
    if ontology_config and ontology_config.naming_conventions.enabled:
        relationship_type_casing = ontology_config.naming_conventions.relationship_type_casing

    for rel_name, rel_def in schema_obj.relationship_types.items():
        # Apply naming convention to relationship type for URI
        rel_name_for_uri = _apply_naming_convention_to_uri(rel_name, relationship_type_casing)
        prop_uri = (
            _get_relationship_uri(rel_name_for_uri, export_context)
            if export_context is not None
            else base_ns[_sanitize_uri_component(rel_name_for_uri)]
        )

        g.add((prop_uri, RDF.type, OWL.ObjectProperty))
        rel_label = (
            _normalize_export_literal_text_cached(rel_name_for_uri, export_context)
            if export_context is not None
            else _normalize_export_literal_text(rel_name_for_uri, ontology_config)
        )
        label_language_tag = (
            export_context.entity_label_language_tag
            if export_context is not None
            else _get_export_label_language_tag(ontology_config)
        )
        g.add((prop_uri, RDFS.label, _build_label_literal(rel_label, label_language_tag)))

        if rel_def.from_type and rel_def.from_type.strip().lower() not in _SKIP_EXPORT_TYPES:
            domain_uri = (
                _get_class_uri(rel_def.from_type, export_context)
                if export_context is not None
                else base_ns[_sanitize_uri_component(rel_def.from_type)]
            )
            g.add((prop_uri, RDFS.domain, domain_uri))

        if rel_def.to_type and rel_def.to_type.strip().lower() not in _SKIP_EXPORT_TYPES:
            range_uri = (
                _get_class_uri(rel_def.to_type, export_context)
                if export_context is not None
                else base_ns[_sanitize_uri_component(rel_def.to_type)]
            )
            g.add((prop_uri, RDFS.range, range_uri))

        if rel_def.direction:
            direction_text = f"Direction: {rel_def.direction}"
            direction_comment = (
                _normalize_export_literal_text_cached(direction_text, export_context)
                if export_context is not None
                else _normalize_export_literal_text(
                    direction_text,
                    ontology_config,
                )
            )
            g.add((prop_uri, RDFS.comment, Literal(direction_comment)))

        _export_property_characteristics(g, prop_uri, rel_def)
        _export_property_axioms(g, prop_uri, rel_def, base_ns)


def _build_entity_id_mappings(
    graph_obj: OntologyGraph,
    schema_obj: OntologySchema,
    namespaces: dict,
    entity_label_casing: str,
    entity_iri_spelling_variant: str = "preserve",
    export_context: _ExportBuildContext | None = None,
) -> tuple[dict[str, URIRef], dict[str, Entity]]:
    """
    Build entity ID to URI and entity mappings.

    Uses naming policy to choose URI components while keeping ID mapping stable.

    Args:
        graph_obj: Graph object containing entities

    Returns:
        Tuple of (entity_id_to_uri, entity_id_to_entity) dictionaries
    """
    assert graph_obj is not None, "graph_obj parameter is required"
    assert schema_obj is not None, "schema_obj parameter is required"
    assert namespaces is not None, "namespaces parameter is required"
    assert hasattr(graph_obj, "entities"), "graph_obj must have entities attribute"
    assert entity_label_casing in (
        "preserve",
        "UpperCamelCase",
        "lowerCamelCase",
        "snake_case",
    ), f"Invalid casing: {entity_label_casing}"
    entity_id_to_uri: dict[str, URIRef] = {}
    entity_id_to_entity: dict[str, Entity] = (
        dict(export_context.entity_id_to_entity) if export_context is not None else {}
    )
    class_uri_components = {
        _sanitize_uri_component(type_name)
        for type_name in schema_obj.entity_types
    }

    preferred_components_by_id: dict[str, str] = {}
    full_components_by_id: dict[str, str] = {}

    for entity in graph_obj.entities:
        entity_id_to_entity[entity.id] = entity
        proxy_type = _resolve_schema_proxy_type(
            entity,
            schema_obj,
            export_context=export_context,
        )
        if proxy_type is not None:
            if export_context is not None:
                entity_id_to_uri[entity.id] = _get_class_uri(proxy_type, export_context)
            else:
                entity_id_to_uri[entity.id] = namespaces["base_ns"][_sanitize_uri_component(proxy_type)]
            continue

        full_component = _sanitize_uri_component(
            _get_entity_uri_component(
                entity,
                entity_label_casing,
                entity_iri_spelling_variant,
            )
        )
        suffix_key = _extract_type_aware_canonical_key_suffix(entity, schema_obj)
        if suffix_key:
            preferred_component = _sanitize_uri_component(
                _build_entity_uri_component_from_key(
                    suffix_key,
                    entity_label_casing,
                    entity_iri_spelling_variant,
                )
            )
        else:
            preferred_component = full_component

        preferred_components_by_id[entity.id] = preferred_component
        full_components_by_id[entity.id] = full_component

    assigned_components: set[str] = set()
    for entity in graph_obj.entities:
        if entity.id in entity_id_to_uri:
            continue

        preferred_component = preferred_components_by_id[entity.id]
        full_component = full_components_by_id[entity.id]
        candidate_components: list[str] = []
        if preferred_component:
            candidate_components.append(preferred_component)
            candidate_components.append(_sanitize_uri_component(f"{preferred_component}Instance"))
            candidate_components.append(_sanitize_uri_component(f"{preferred_component}Entity"))
        if full_component:
            candidate_components.append(full_component)
            candidate_components.append(_sanitize_uri_component(f"{full_component}Instance"))
            candidate_components.append(_sanitize_uri_component(f"{full_component}Entity"))

        chosen_component: str | None = None
        seen_candidates: set[str] = set()
        for candidate in candidate_components:
            if not candidate or candidate in seen_candidates:
                continue
            seen_candidates.add(candidate)
            if candidate in class_uri_components or candidate in assigned_components:
                continue
            chosen_component = candidate
            break

        if chosen_component is None:
            fallback_base = full_component or preferred_component or "Entity"
            chosen_component = fallback_base
            suffix = 2
            while chosen_component in class_uri_components or chosen_component in assigned_components:
                chosen_component = _sanitize_uri_component(f"{fallback_base}{suffix}")
                suffix += 1

        entity_id_to_uri[entity.id] = namespaces["entity_ns"][chosen_component]
        assigned_components.add(chosen_component)

    if export_context is not None:
        export_context.entity_id_to_uri = entity_id_to_uri
        export_context.entity_id_to_entity = entity_id_to_entity

    return entity_id_to_uri, entity_id_to_entity


# Property keys that must not become data properties (Fix B + Fix F)
_SKIP_ENTITY_PROPERTY_KEYS = {
    "restrictions", "_restrictions",   # Fix B: restriction string literals
    "sourceUrls",                      # Fix F: source grounding metadata
    "description",                     # Fix F: duplicates rdfs:comment
    "foundOn",                         # Fix F: extraction provenance metadata
}

_AGGREGATED_TEXT_PROPERTY_KEYS = frozenset(
    {
        "context",
        "consequence",
        "condition",
        "conditions",
        "detail",
        "details",
        "example",
        "examples",
        "guidance",
        "note",
        "notes",
        "rationale",
        "summary",
    }
)


@lru_cache(maxsize=65536)
def _build_property_conflict_keys(text: str) -> frozenset[str]:
    """Build separator-insensitive keys for property conflict detection."""
    assert text is not None, "text parameter is required"
    from taxonomy_ontology_accelerator.ontology_engine.utils.spelling_variants import (
        convert_spelling_compound,
    )

    variants = {
        text,
        convert_spelling_compound(text, "US"),
        convert_spelling_compound(text, "UK"),
    }
    return frozenset(
        re.sub(r"[^a-z0-9]+", "", split_identifier_words(variant).lower())
        for variant in variants
        if variant
    )


@lru_cache(maxsize=65536)
def _build_entity_uri_component_from_key(
    canonical_key: str,
    entity_label_casing: str,
    entity_iri_spelling_variant: str = "preserve",
) -> str:
    """Build a URI component from a canonical key under the configured spelling policy."""
    assert canonical_key is not None, "canonical_key parameter is required"
    assert entity_label_casing in (
        "preserve",
        "UpperCamelCase",
        "lowerCamelCase",
        "snake_case",
    ), f"Invalid casing: {entity_label_casing}"

    from taxonomy_ontology_accelerator.ontology_engine.utils.spelling_variants import (
        convert_spelling_compound,
    )

    if entity_iri_spelling_variant != "preserve":
        canonical_spaced = canonical_key.replace("_", " ")
        source_text = convert_spelling_compound(canonical_spaced, entity_iri_spelling_variant)
    else:
        source_text = canonical_key
    return _apply_naming_convention_to_uri(source_text, entity_label_casing)


def _extract_type_aware_canonical_key_suffix(
    entity: Entity,
    schema_obj: OntologySchema | None = None,
) -> str | None:
    """Return the label portion of a type-aware canonical key like `type__label` when safe."""
    assert entity is not None, "entity parameter is required"

    if "__" not in entity.canonical_key:
        return None

    prefix, suffix = entity.canonical_key.split("__", 1)
    if not suffix:
        return None

    normalized_prefix = re.sub(r"[^a-z0-9]+", "", split_identifier_words(prefix).lower())
    normalized_type = re.sub(r"[^a-z0-9]+", "", split_identifier_words(entity.type).lower())
    normalized_type_candidates = {normalized_type}
    if schema_obj is not None:
        current = entity.type
        visited: set[str] = set()
        while current and current not in visited and current in schema_obj.entity_types:
            visited.add(current)
            normalized_type_candidates.add(
                re.sub(r"[^a-z0-9]+", "", split_identifier_words(current).lower())
            )
            current = schema_obj.entity_types[current].parent_type

    if not normalized_prefix or normalized_prefix not in normalized_type_candidates:
        return None

    return suffix


def _build_object_property_conflict_keys(
    schema_obj: OntologySchema,
    relationship_type_casing: str,
) -> set[str]:
    """Build normalized keys for all known object properties."""
    assert schema_obj is not None, "schema_obj parameter is required"
    assert relationship_type_casing is not None, "relationship_type_casing parameter is required"

    conflict_keys: set[str] = set()
    for rel_name in schema_obj.relationship_types:
        rel_name_for_uri = _apply_naming_convention_to_uri(rel_name, relationship_type_casing)
        conflict_keys.update(_build_property_conflict_keys(rel_name))
        conflict_keys.update(_build_property_conflict_keys(rel_name_for_uri))
    return conflict_keys


def _merge_text_annotation_values(values: list[object]) -> str | None:
    """Collapse repeated annotation-style text values into a single readable literal."""
    assert values is not None, "values parameter is required"

    merged_values: list[str] = []
    for item in values:
        if item is None:
            continue
        text = str(item).strip()
        if text and text not in merged_values:
            merged_values.append(text)
    if not merged_values:
        return None
    return "\n".join(merged_values)


def _add_entity_properties(
    g,
    entity_uri,
    entity,
    namespaces: dict,
    allowed_props=None,
    entity_iri_spelling_variant: str = "preserve",
    object_property_conflict_keys: set[str] | None = None,
    export_context: _ExportBuildContext | None = None,
) -> None:
    """
    Add dynamic properties from entity.properties to RDF graph.

    Also declares each property as owl:DatatypeProperty if not already declared.

    Args:
        g: RDF Graph object
        entity_uri: URI of the entity
        entity: Entity object
        namespaces: Dictionary containing namespace objects
        allowed_props: Optional set of property keys to include (Fix C frequency filter)
        entity_iri_spelling_variant: Spelling variant for property key IRIs
    """
    assert g is not None, "g (RDF Graph) parameter is required"
    assert namespaces is not None, "namespaces parameter is required"
    from taxonomy_ontology_accelerator.ontology_engine.utils.spelling_variants import (
        convert_spelling_compound,
    )
    base_ns = namespaces["base_ns"]

    for key, value in entity.properties.items():
        if key in _SKIP_ENTITY_PROPERTY_KEYS:  # Fix B: skip restriction string literals
            continue
        if allowed_props is not None and key not in allowed_props:  # Fix C: frequency filter
            continue

        if export_context is not None:
            converted_key = export_context.converted_property_key_cache.get(key)
            if converted_key is None:
                converted_key = (
                    convert_spelling_compound(key, entity_iri_spelling_variant)
                    if entity_iri_spelling_variant != "preserve"
                    else key
                )
                export_context.converted_property_key_cache[key] = converted_key
        else:
            converted_key = (
                convert_spelling_compound(key, entity_iri_spelling_variant)
                if entity_iri_spelling_variant != "preserve"
                else key
            )

        if object_property_conflict_keys is not None:
            if export_context is not None:
                conflict_keys = _get_property_conflict_keys_cached(
                    key,
                    export_context,
                ) | _get_property_conflict_keys_cached(
                    converted_key,
                    export_context,
                )
            else:
                conflict_keys = _build_property_conflict_keys(key) | _build_property_conflict_keys(
                    converted_key
                )
            if conflict_keys & object_property_conflict_keys:
                continue

        if export_context is not None:
            prop_uri = _get_property_uri(converted_key, export_context)
        else:
            sanitized_prop = _sanitize_uri_component(converted_key)
            prop_uri = base_ns[sanitized_prop]

        # Issue 2b: Declare as DatatypeProperty
        g.add((prop_uri, RDF.type, OWL.DatatypeProperty))

        # Collapse annotation-style text lists into a single literal for readability.
        if isinstance(value, list):
            if key in _AGGREGATED_TEXT_PROPERTY_KEYS:
                merged_text = _merge_text_annotation_values(value)
                if merged_text is not None:
                    g.add((entity_uri, prop_uri, Literal(merged_text)))
                continue
            for item in value:
                if item is not None:
                    g.add((entity_uri, prop_uri, Literal(str(item))))
            continue

        if isinstance(value, bool):
            g.add((entity_uri, prop_uri, Literal(value, datatype=XSD.boolean)))
        elif isinstance(value, int | float):
            g.add((entity_uri, prop_uri, Literal(value)))
        else:
            g.add((entity_uri, prop_uri, Literal(_make_path_relative(str(value)))))


def _add_entity_metadata(g, entity_uri, entity, namespaces: dict) -> None:
    """
    Add metadata (confidence, timestamps) to entity.

    Args:
        g: RDF Graph object
        entity_uri: URI of the entity
        entity: Entity object
        namespaces: Dictionary containing namespace objects
    """
    assert g is not None, "g (RDF Graph) parameter is required"
    assert namespaces is not None, "namespaces parameter is required"
    if not entity.metadata:
        return

    confidence_prop = namespaces["confidence_prop"]
    extracted_at_prop = namespaces["extracted_at_prop"]

    confidence = entity.metadata.get("confidence")
    if confidence is not None:
        g.add((entity_uri, confidence_prop, Literal(float(confidence))))

    timestamp = entity.metadata.get("last_updated") or entity.metadata.get("first_seen")
    if timestamp:
        g.add((entity_uri, extracted_at_prop, Literal(timestamp, datatype=XSD.dateTime)))


def _get_entity_label_casing(ontology_config: OntologyConfig | None) -> str:
    """Extract entity label casing from config."""
    result = "preserve"
    if ontology_config and ontology_config.naming_conventions.enabled:
        result = ontology_config.naming_conventions.entity_label_casing
    assert result in ("preserve", "UpperCamelCase", "lowerCamelCase", "snake_case"), (
        f"Invalid casing: {result}"
    )
    assert isinstance(result, str), "Result must be a string"
    return result


def _get_export_label_language_tag(ontology_config: OntologyConfig | None) -> str | None:
    """Return the configured language tag for RDF label literals when enabled."""
    if ontology_config is None or not ontology_config.naming_conventions.enabled:
        return None
    return ontology_config.naming_conventions.entity_label_language_tag


def _build_label_literal(text: str, language_tag: str | None):
    """Build an RDF literal for label-like fields with an optional lang tag."""
    assert text is not None, "text parameter is required"
    return Literal(text, lang=language_tag) if language_tag else Literal(text)


def _get_export_spelling_variant(
    ontology_config: OntologyConfig | None,
    *,
    use_entity_label_variant: bool = False,
) -> str:
    """Return the configured spelling variant for exported human-visible text."""
    if ontology_config is None or not ontology_config.naming_conventions.enabled:
        return "preserve"

    naming = ontology_config.naming_conventions
    if use_entity_label_variant and naming.entity_label_spelling_variant != "preserve":
        return naming.entity_label_spelling_variant
    return naming.spelling_variant


def _normalize_export_literal_text(
    text: str,
    ontology_config: OntologyConfig | None,
    *,
    correction_vocabulary: set[str] | None = None,
    use_entity_label_variant: bool = False,
) -> str:
    """Normalize exported human-visible text under the configured spelling policy."""
    assert text is not None, "text parameter is required"

    spelling_variant = _get_export_spelling_variant(
        ontology_config,
        use_entity_label_variant=use_entity_label_variant,
    )
    normalized = text
    if spelling_variant != "preserve" and text:
        from taxonomy_ontology_accelerator.ontology_engine.utils.spelling_variants import (
            convert_spelling,
            convert_spelling_compound,
        )

        if "_" in text or "-" in text or re.search(r"[a-z0-9][A-Z]", text):
            normalized = convert_spelling_compound(text, spelling_variant)
        else:
            assumed_source_variant = "UK" if spelling_variant == "US" else "US"
            normalized = convert_spelling(
                text,
                from_variant=assumed_source_variant,
                to_variant=spelling_variant,
            )
            normalized = convert_spelling_compound(normalized, spelling_variant)

    if ontology_config is None or not correction_vocabulary:
        return normalized

    from taxonomy_ontology_accelerator.ontology_engine.utils.text_normalization import (
        correct_text_against_vocabulary,
    )

    return correct_text_against_vocabulary(normalized, correction_vocabulary, ontology_config)


def _build_export_correction_vocabulary(
    schema_obj: OntologySchema,
    graph_obj: OntologyGraph,
    ontology_config: OntologyConfig | None,
) -> set[str]:
    """Build a conservative vocabulary for export-time typo correction."""
    assert schema_obj is not None, "schema_obj parameter is required"
    assert graph_obj is not None, "graph_obj parameter is required"

    vocabulary: set[str] = set()
    for type_name in schema_obj.entity_types:
        vocabulary.update(split_identifier_words(type_name).replace("_", " ").split())
    for rel_name in schema_obj.relationship_types:
        vocabulary.update(split_identifier_words(rel_name).replace("_", " ").split())
    for entity in graph_obj.entities:
        vocabulary.update(split_identifier_words(entity.label).replace("_", " ").split())

    spelling_variant = _get_export_spelling_variant(ontology_config, use_entity_label_variant=True)
    if spelling_variant != "preserve":
        from taxonomy_ontology_accelerator.ontology_engine.utils.spelling_variants import (
            convert_spelling_compound,
        )

        expanded = set(vocabulary)
        for token in list(vocabulary):
            expanded.add(convert_spelling_compound(token, spelling_variant))
        vocabulary = expanded

    return {token.lower() for token in vocabulary if token and token.isalpha()}


def _get_entity_uri_component(entity, entity_label_casing: str, entity_iri_spelling_variant: str = "preserve") -> str:
    assert entity is not None, "entity parameter is required"
    assert entity_label_casing in (
        "preserve",
        "UpperCamelCase",
        "lowerCamelCase",
        "snake_case",
    ), f"Invalid casing: {entity_label_casing}"
    if entity_iri_spelling_variant != "preserve":
        return _build_entity_uri_component_from_key(
            entity.canonical_key,
            entity_label_casing,
            entity_iri_spelling_variant,
        )

    source_text = entity.canonical_key
    if entity_label_casing in ("UpperCamelCase", "lowerCamelCase") and entity.label:
        source_text = entity.label
    return _apply_naming_convention_to_uri(source_text, entity_label_casing)


@lru_cache(maxsize=65536)
def _build_schema_proxy_match_key(text: str) -> str:
    """Build a separator-insensitive key for detecting schema-proxy entities."""
    assert text is not None, "text parameter is required"
    return re.sub(r"[^a-z0-9]+", "", split_identifier_words(text).lower())


@lru_cache(maxsize=65536)
def _build_schema_proxy_match_keys(text: str) -> frozenset[str]:
    """Build spelling-tolerant match keys for schema-proxy detection."""
    assert text is not None, "text parameter is required"
    from taxonomy_ontology_accelerator.ontology_engine.utils.spelling_variants import (
        convert_spelling_compound,
    )

    variants = {
        text,
        convert_spelling_compound(text, "US"),
        convert_spelling_compound(text, "UK"),
    }
    return frozenset(_build_schema_proxy_match_key(variant) for variant in variants if variant)


def _schema_type_depth(type_name: str, schema_obj: OntologySchema) -> int:
    """Compute simple inheritance depth for a schema type."""
    assert type_name is not None, "type_name parameter is required"
    assert schema_obj is not None, "schema_obj parameter is required"

    depth = 0
    current = type_name
    visited: set[str] = set()
    while current in schema_obj.entity_types and current not in visited:
        visited.add(current)
        parent = schema_obj.entity_types[current].parent_type
        if not parent or parent not in schema_obj.entity_types:
            break
        depth += 1
        current = parent
    return depth


def _type_is_same_or_ancestor(
    ancestor_type: str,
    descendant_type: str,
    schema_obj: OntologySchema,
    export_context: _ExportBuildContext | None = None,
) -> bool:
    """Return True when ancestor_type is the same as or an ancestor of descendant_type."""
    assert ancestor_type is not None, "ancestor_type parameter is required"
    assert descendant_type is not None, "descendant_type parameter is required"
    assert schema_obj is not None, "schema_obj parameter is required"

    if export_context is not None:
        cache_key = (ancestor_type, descendant_type)
        cached = export_context.ancestor_cache.get(cache_key)
        if cached is not None:
            return cached

    current = descendant_type
    visited: set[str] = set()
    while current and current not in visited and current in schema_obj.entity_types:
        if current == ancestor_type:
            if export_context is not None:
                export_context.ancestor_cache[(ancestor_type, descendant_type)] = True
            return True
        visited.add(current)
        current = schema_obj.entity_types[current].parent_type
    if export_context is not None:
        export_context.ancestor_cache[(ancestor_type, descendant_type)] = False
    return False


def _resolve_schema_proxy_type(
    entity: Entity,
    schema_obj: OntologySchema,
    export_context: _ExportBuildContext | None = None,
) -> str | None:
    """Return the schema class mirrored by an entity label, if any."""
    assert entity is not None, "entity parameter is required"
    assert schema_obj is not None, "schema_obj parameter is required"

    if export_context is not None and entity.id in export_context.entity_proxy_type_cache:
        return export_context.entity_proxy_type_cache[entity.id]

    entity_match_keys = _build_schema_proxy_match_keys(entity.label)
    if export_context is not None:
        candidate_types = [
            type_name
            for type_name, match_keys in export_context.schema_proxy_type_match_keys.items()
            if match_keys & entity_match_keys
        ]
    else:
        candidate_types = [
            type_name
            for type_name in schema_obj.entity_types
            if type_name.strip().lower() not in _SKIP_EXPORT_TYPES
            and _build_schema_proxy_match_keys(type_name) & entity_match_keys
        ]
    if not candidate_types:
        if export_context is not None:
            export_context.entity_proxy_type_cache[entity.id] = None
        return None

    if entity.type not in schema_obj.entity_types:
        if export_context is not None:
            export_context.entity_proxy_type_cache[entity.id] = None
        return None

    compatible_candidates = [
        type_name
        for type_name in candidate_types
        if _type_is_same_or_ancestor(
            entity.type,
            type_name,
            schema_obj,
            export_context=export_context,
        )
    ]
    if not compatible_candidates:
        exact_label_match_keys = _build_schema_proxy_match_keys(entity.label)
        exact_label_candidates = [
            type_name
            for type_name in candidate_types
            if _build_schema_proxy_match_keys(type_name) & exact_label_match_keys
        ]
        if not exact_label_candidates:
            if export_context is not None:
                export_context.entity_proxy_type_cache[entity.id] = None
            return None
        entity_type_depth = (
            export_context.schema_type_depths.get(entity.type, _schema_type_depth(entity.type, schema_obj))
            if export_context is not None
            else _schema_type_depth(entity.type, schema_obj)
        )
        if entity_type_depth > 1:
            if export_context is not None:
                export_context.entity_proxy_type_cache[entity.id] = None
            return None
        resolved = max(
            exact_label_candidates,
            key=(
                lambda type_name: export_context.schema_type_depths.get(
                    type_name,
                    _schema_type_depth(type_name, schema_obj),
                )
                if export_context is not None
                else _schema_type_depth(type_name, schema_obj)
            ),
        )
        if export_context is not None:
            export_context.entity_proxy_type_cache[entity.id] = resolved
        return resolved

    resolved = max(
        compatible_candidates,
        key=(
            lambda type_name: export_context.schema_type_depths.get(
                type_name,
                _schema_type_depth(type_name, schema_obj),
            )
            if export_context is not None
            else _schema_type_depth(type_name, schema_obj)
        ),
    )
    if export_context is not None:
        export_context.entity_proxy_type_cache[entity.id] = resolved
    return resolved


def _is_schema_proxy_entity(
    entity: Entity,
    schema_obj: OntologySchema,
    export_context: _ExportBuildContext | None = None,
) -> bool:
    """Return True when an entity only mirrors a schema type label."""
    assert entity is not None, "entity parameter is required"
    assert schema_obj is not None, "schema_obj parameter is required"

    return _resolve_schema_proxy_type(
        entity,
        schema_obj,
        export_context=export_context,
    ) is not None


def _get_entity_uri(
    entity: Entity,
    schema_obj: OntologySchema,
    namespaces: dict,
    entity_label_casing: str,
    entity_iri_spelling_variant: str = "preserve",
    export_context: _ExportBuildContext | None = None,
) -> URIRef:
    """Resolve the RDF URI for an entity, reusing class URIs for schema proxies."""
    assert entity is not None, "entity parameter is required"
    assert schema_obj is not None, "schema_obj parameter is required"
    assert namespaces is not None, "namespaces parameter is required"

    base_ns = namespaces["base_ns"]
    entity_ns = namespaces["entity_ns"]
    proxy_type = _resolve_schema_proxy_type(
        entity,
        schema_obj,
        export_context=export_context,
    )
    if proxy_type is not None:
        if export_context is not None:
            return _get_class_uri(proxy_type, export_context)
        return base_ns[_sanitize_uri_component(proxy_type)]

    canonical_key_for_uri = _get_entity_uri_component(
        entity,
        entity_label_casing,
        entity_iri_spelling_variant,
    )
    sanitized_key = _sanitize_uri_component(canonical_key_for_uri)
    return entity_ns[sanitized_key]


def _export_single_entity(
    g,
    entity,
    namespaces: dict,
    entity_label_casing: str,
    entity_iri_spelling_variant="preserve",
    entity_label_language_tag=None,
    allowed_props=None,
    schema_obj: OntologySchema | None = None,
    ontology_config: OntologyConfig | None = None,
    correction_vocabulary: set[str] | None = None,
    entity_id_to_uri: dict[str, URIRef] | None = None,
    object_property_conflict_keys: set[str] | None = None,
    export_context: _ExportBuildContext | None = None,
) -> None:
    """Export a single entity to OWL Individual."""
    assert g is not None, "g (RDF Graph) parameter is required"
    assert entity is not None, "entity parameter is required"
    base_ns = namespaces["base_ns"]
    entity_ns = namespaces["entity_ns"]

    if entity_id_to_uri is not None and entity.id in entity_id_to_uri:
        entity_uri = entity_id_to_uri[entity.id]
        if schema_obj is not None:
            proxy_type = _resolve_schema_proxy_type(
                entity,
                schema_obj,
                export_context=export_context,
            )
            proxy_class_uri = (
                _get_class_uri(proxy_type, export_context)
                if proxy_type is not None and export_context is not None
                else namespaces["base_ns"][_sanitize_uri_component(proxy_type)]
                if proxy_type is not None
                else None
            )
            is_schema_proxy = proxy_class_uri is not None and entity_uri == proxy_class_uri
        else:
            is_schema_proxy = False
    elif schema_obj is not None:
        entity_uri = _get_entity_uri(
            entity,
            schema_obj,
            namespaces,
            entity_label_casing,
            entity_iri_spelling_variant,
            export_context=export_context,
        )
        proxy_type = _resolve_schema_proxy_type(
            entity,
            schema_obj,
            export_context=export_context,
        )
        proxy_class_uri = (
            _get_class_uri(proxy_type, export_context)
            if proxy_type is not None and export_context is not None
            else namespaces["base_ns"][_sanitize_uri_component(proxy_type)]
            if proxy_type is not None
            else None
        )
        is_schema_proxy = proxy_class_uri is not None and entity_uri == proxy_class_uri
    else:
        canonical_key_for_uri = _get_entity_uri_component(
            entity,
            entity_label_casing,
            entity_iri_spelling_variant,
        )
        entity_uri = base_ns[_sanitize_uri_component(canonical_key_for_uri)]
        is_schema_proxy = False

    entity_type_value = str(entity.type).strip().lower()
    if is_schema_proxy:
        pass
    elif entity_type_value == "class":
        g.add((entity_uri, RDF.type, OWL.Class))
    elif entity_type_value == "individual":
        g.add((entity_uri, RDF.type, OWL.NamedIndividual))
        g.add((entity_uri, RDF.type, OWL.Thing))
    else:
        if entity_type_value in _SKIP_EXPORT_TYPES:
            g.add((entity_uri, RDF.type, OWL.NamedIndividual))
        else:
            if export_context is not None:
                entity_type_uri = _get_class_uri(entity.type, export_context)
            else:
                sanitized_type = _sanitize_uri_component(entity.type)
                entity_type_uri = base_ns[sanitized_type]
            g.add((entity_uri, RDF.type, OWL.NamedIndividual))
            g.add((entity_uri, RDF.type, entity_type_uri))

    normalized_label = (
        _normalize_export_literal_text_cached(
            entity.label,
            export_context,
            use_entity_label_variant=True,
        )
        if export_context is not None
        else _normalize_export_literal_text(
            entity.label,
            ontology_config,
            correction_vocabulary=correction_vocabulary,
            use_entity_label_variant=True,
        )
    )
    label_literal = _build_label_literal(normalized_label, entity_label_language_tag)
    if not is_schema_proxy:
        g.add((entity_uri, RDFS.label, label_literal))
    g.add((entity_uri, SKOS.prefLabel, label_literal))

    if entity.description:
        normalized_description = (
            _normalize_export_literal_text_cached(entity.description, export_context)
            if export_context is not None
            else _normalize_export_literal_text(
                entity.description,
                ontology_config,
                correction_vocabulary=correction_vocabulary,
            )
        )
        g.add((entity_uri, RDFS.comment, Literal(normalized_description)))

    for alias in entity.alias_names:
        normalized_alias = (
            _normalize_export_literal_text_cached(
                alias,
                export_context,
                use_entity_label_variant=True,
            )
            if export_context is not None
            else _normalize_export_literal_text(
                alias,
                ontology_config,
                correction_vocabulary=correction_vocabulary,
                use_entity_label_variant=True,
            )
        )
        alias_literal = _build_label_literal(normalized_alias, entity_label_language_tag)
        g.add((entity_uri, SKOS.altLabel, alias_literal))

    if is_schema_proxy:
        return

    _add_entity_properties(
        g,
        entity_uri,
        entity,
        namespaces,
        allowed_props,
        entity_iri_spelling_variant=entity_iri_spelling_variant,
        object_property_conflict_keys=object_property_conflict_keys,
        export_context=export_context,
    )
    _add_entity_metadata(g, entity_uri, entity, namespaces)

    # owl:sameAs for merged entities
    # owl:sameAs for merged entities
    merged_from = entity.metadata.get("merged_from")
    if merged_from and isinstance(merged_from, list):
        for merged_entry in merged_from:
            if isinstance(merged_entry, dict):
                merged_id = merged_entry.get("entity_id") or merged_entry.get("id")
                if merged_id:
                    merged_uri = (
                        entity_id_to_uri.get(str(merged_id))
                        if entity_id_to_uri is not None
                        else None
                    )
                    if merged_uri is None:
                        if ontology_config and ontology_config.naming_conventions.enabled:
                            nc = ontology_config.naming_conventions
                            legacy_component = _build_entity_uri_component_from_key(
                                str(merged_id),
                                nc.entity_label_casing,
                                nc.entity_iri_spelling_variant,
                            )
                        else:
                            legacy_component = _sanitize_uri_component(str(merged_id))
                        merged_uri = entity_ns[_sanitize_uri_component(legacy_component)]
                    g.add((entity_uri, OWL.sameAs, merged_uri))


def _export_entities(
    g,
    graph_obj: OntologyGraph,
    schema_obj: OntologySchema,
    namespaces: dict,
    ontology_config: OntologyConfig | None = None,
    correction_vocabulary: set[str] | None = None,
    entity_id_to_uri: dict[str, URIRef] | None = None,
    export_context: _ExportBuildContext | None = None,
) -> None:
    """
    Export entities to OWL Individuals.

    Args:
        g: RDF Graph object
        graph_obj: Graph object containing entities
        namespaces: Dictionary containing namespace objects
        ontology_config: Optional config for applying naming conventions to URIs
    """
    assert g is not None, "g (RDF Graph) parameter is required"
    assert graph_obj is not None, "graph_obj parameter is required"
    assert schema_obj is not None, "schema_obj parameter is required"

    if export_context is not None:
        entity_label_casing = export_context.entity_label_casing
        entity_iri_spelling_variant = export_context.entity_iri_spelling_variant
        entity_label_language_tag = export_context.entity_label_language_tag
        allowed_props = export_context.allowed_props
        object_property_conflict_keys = export_context.object_property_conflict_keys
        correction_vocabulary = export_context.correction_vocabulary
    else:
        entity_label_casing = _get_entity_label_casing(ontology_config)
        entity_iri_spelling_variant = "preserve"
        entity_label_language_tag = None
        relationship_type_casing = "lowerCamelCase"
        if ontology_config and ontology_config.naming_conventions:
            entity_iri_spelling_variant = ontology_config.naming_conventions.entity_iri_spelling_variant
            entity_label_language_tag = ontology_config.naming_conventions.entity_label_language_tag
            relationship_type_casing = ontology_config.naming_conventions.relationship_type_casing

        prop_counts = Counter(
            key
            for entity in graph_obj.entities
            if not _is_schema_proxy_entity(entity, schema_obj)
            for key in (entity.properties or {})
            if key not in _SKIP_ENTITY_PROPERTY_KEYS
        )
        min_freq = 1
        if ontology_config and ontology_config.output and ontology_config.output.export:
            min_freq = getattr(ontology_config.output.export, "min_property_frequency", 1)
        allowed_props = (
            {key for key, count in prop_counts.items() if count >= min_freq}
            if min_freq > 1
            else None
        )
        object_property_conflict_keys = _build_object_property_conflict_keys(
            schema_obj,
            relationship_type_casing,
        )

    for entity in graph_obj.entities:
        _export_single_entity(
            g,
            entity,
            namespaces,
            entity_label_casing,
            entity_iri_spelling_variant,
            entity_label_language_tag,
            allowed_props,
            schema_obj=schema_obj,
            ontology_config=ontology_config,
            correction_vocabulary=correction_vocabulary,
            entity_id_to_uri=entity_id_to_uri,
            object_property_conflict_keys=object_property_conflict_keys,
            export_context=export_context,
        )

def _build_relationship_uris(
    rel,
    subject_uri: URIRef,
    object_uri: URIRef,
    namespaces: dict,
    relationship_type_casing: str,
    export_context: _ExportBuildContext | None = None,
) -> tuple:
    """Build URIs for relationship export with naming conventions applied."""
    assert rel is not None, "rel parameter is required"
    assert subject_uri is not None, "subject_uri parameter is required"

    base_ns = namespaces["base_ns"]
    rel_type_for_uri = _apply_naming_convention_to_uri(rel.type, relationship_type_casing)

    predicate_uri = (
        _get_relationship_uri(rel_type_for_uri, export_context)
        if export_context is not None
        else base_ns[_sanitize_uri_component(rel_type_for_uri)]
    )

    return subject_uri, predicate_uri, object_uri


def _is_taxonomic_relationship_type(rel_type: str) -> bool:
    """Return True when a relationship type expresses type hierarchy."""
    assert rel_type is not None, "rel_type parameter is required"

    normalized = rel_type.lower().replace("_", "").replace("-", "")
    return normalized in {"isa", "subclassof", "typeof", "kindof"}


def _source_is_ancestor_of_target(
    source_class_name: str,
    target_class_name: str,
    schema: OntologySchema,
) -> bool:
    """Return True if source is already an ancestor of target in the schema hierarchy.

    Used to detect when an IS_A relationship would write a rdfs:subClassOf triple
    that contradicts the schema's established parent_type hierarchy.
    """
    assert source_class_name is not None, "source_class_name parameter is required"
    assert target_class_name is not None, "target_class_name parameter is required"
    assert schema is not None, "schema parameter is required"

    current = target_class_name
    visited: set[str] = set()
    while current and current in schema.entity_types:
        if current == source_class_name:
            return True
        if current in visited:
            break  # cycle protection
        visited.add(current)
        current = schema.entity_types[current].parent_type
    return False


def _restriction_exists(
    g,
    class_uri: URIRef,
    property_uri: URIRef,
    filler_uri: URIRef,
) -> bool:
    """Return True when an equivalent someValuesFrom restriction already exists."""
    assert g is not None, "g (RDF Graph) parameter is required"
    assert class_uri is not None, "class_uri parameter is required"
    assert property_uri is not None, "property_uri parameter is required"
    assert filler_uri is not None, "filler_uri parameter is required"

    for candidate in g.objects(class_uri, RDFS.subClassOf):
        if (
            (candidate, RDF.type, OWL.Restriction) in g
            and (candidate, OWL.onProperty, property_uri) in g
            and (candidate, OWL.someValuesFrom, filler_uri) in g
        ):
            return True
    return False


def _export_schema_proxy_relationship_as_restriction(
    g,
    rel,
    predicate_uri: URIRef,
    source_entity: Entity,
    target_entity: Entity,
    schema_obj: OntologySchema,
    namespaces: dict,
    export_context: _ExportBuildContext | None = None,
) -> bool:
    """Lift relationships involving schema-proxy endpoints into class restrictions."""
    assert g is not None, "g (RDF Graph) parameter is required"
    assert rel is not None, "rel parameter is required"
    assert predicate_uri is not None, "predicate_uri parameter is required"
    assert source_entity is not None, "source_entity parameter is required"
    assert target_entity is not None, "target_entity parameter is required"
    assert schema_obj is not None, "schema_obj parameter is required"
    assert namespaces is not None, "namespaces parameter is required"

    base_ns = namespaces["base_ns"]
    source_proxy_type = _resolve_schema_proxy_type(
        source_entity,
        schema_obj,
        export_context=export_context,
    )
    target_proxy_type = _resolve_schema_proxy_type(
        target_entity,
        schema_obj,
        export_context=export_context,
    )

    source_class_name = source_proxy_type or source_entity.type
    target_class_name = target_proxy_type or target_entity.type
    if (
        source_class_name not in schema_obj.entity_types
        or target_class_name not in schema_obj.entity_types
    ):
        return False

    source_class_uri = (
        _get_class_uri(source_class_name, export_context)
        if export_context is not None
        else base_ns[_sanitize_uri_component(source_class_name)]
    )
    target_class_uri = (
        _get_class_uri(target_class_name, export_context)
        if export_context is not None
        else base_ns[_sanitize_uri_component(target_class_name)]
    )

    if _is_taxonomic_relationship_type(rel.type):
        if source_class_uri != target_class_uri:
            if _source_is_ancestor_of_target(source_class_name, target_class_name, schema_obj):
                logger.debug(
                    f"Skipping inverted taxonomic triple "
                    f"'{source_class_name}' subClassOf '{target_class_name}': "
                    "source is already an ancestor of target in schema"
                )
                return False
            g.add((source_class_uri, RDFS.subClassOf, target_class_uri))
        return True

    if _restriction_exists(g, source_class_uri, predicate_uri, target_class_uri):
        return True

    restriction_node = BNode()
    g.add((restriction_node, RDF.type, OWL.Restriction))
    g.add((restriction_node, OWL.onProperty, predicate_uri))
    g.add((restriction_node, OWL.someValuesFrom, target_class_uri))
    g.add((source_class_uri, RDFS.subClassOf, restriction_node))
    return True


def _export_single_relationship(
    g,
    rel,
    entity_id_to_uri: dict[str, URIRef],
    namespaces: dict,
    entity_id_to_entity: dict[str, Entity] | None = None,
    schema_obj: OntologySchema | None = None,
    relationship_type_casing: str = "lowerCamelCase",
    export_context: _ExportBuildContext | None = None,
) -> bool:
    """Export a single relationship to RDF graph."""
    assert g is not None, "g (RDF Graph) parameter is required"
    assert rel is not None, "rel parameter is required"
    subject_uri = entity_id_to_uri.get(rel.from_)
    object_uri = entity_id_to_uri.get(rel.to)

    if not subject_uri or not object_uri:
        missing_entity = "from" if not subject_uri else "to"
        missing_id = rel.from_ if not subject_uri else rel.to
        logger.error(
            f"Relationship '{rel.id}' skipped: {missing_entity} entity "
            f"not found (ID: '{missing_id}', type: {rel.type})"
        )
        return False

    subject_uri, predicate_uri, object_uri = _build_relationship_uris(
        rel,
        subject_uri,
        object_uri,
        namespaces,
        relationship_type_casing,
        export_context=export_context,
    )

    if entity_id_to_entity is not None and schema_obj is not None:
        source_entity = entity_id_to_entity.get(rel.from_)
        target_entity = entity_id_to_entity.get(rel.to)
        if (
            source_entity is not None
            and target_entity is not None
            and (
                _is_schema_proxy_entity(source_entity, schema_obj, export_context=export_context)
                or _is_schema_proxy_entity(
                    target_entity,
                    schema_obj,
                    export_context=export_context,
                )
            )
        ):
            return _export_schema_proxy_relationship_as_restriction(
                g,
                rel,
                predicate_uri,
                source_entity,
                target_entity,
                schema_obj,
                namespaces,
                export_context=export_context,
            )

    if subject_uri == object_uri and _is_taxonomic_relationship_type(rel.type):
        logger.debug(
            f"Relationship '{rel.id}' skipped: redundant taxonomic self-loop after URI resolution"
        )
        return False

    if (
        _is_taxonomic_relationship_type(rel.type)
        and (subject_uri, RDF.type, OWL.Class) in g
        and (object_uri, RDF.type, OWL.Class) in g
    ):
        if entity_id_to_entity is not None and schema_obj is not None:
            source_entity = entity_id_to_entity.get(rel.from_)
            target_entity = entity_id_to_entity.get(rel.to)
            if (
                source_entity is not None
                and target_entity is not None
                and _source_is_ancestor_of_target(
                    source_entity.type, target_entity.type, schema_obj
                )
            ):
                logger.debug(
                    f"Skipping inverted taxonomic triple "
                    f"'{source_entity.type}' subClassOf '{target_entity.type}': "
                    "source is already an ancestor of target in schema"
                )
                return False
        g.add((subject_uri, RDFS.subClassOf, object_uri))
        return True

    if _is_taxonomic_relationship_type(rel.type):
        logger.debug(
            f"Relationship '{rel.id}' skipped: taxonomic links only export when both endpoints resolve to classes"
        )
        return False

    g.add((subject_uri, predicate_uri, object_uri))

    _add_relationship_properties(g, subject_uri, rel, namespaces)
    return True


def _export_reified_relationship(
    g, rel, subject_uri, predicate_uri, object_uri, namespaces: dict
) -> None:
    """
    Export relationship with reification for metadata attachment.

    Args:
        g: RDF Graph object
        rel: Relationship object
        subject_uri: Subject entity URI
        predicate_uri: Relationship type URI
        object_uri: Object entity URI
        namespaces: Dictionary containing namespace objects including property URIs
    """
    assert g is not None, "g (RDF Graph) parameter is required"
    assert namespaces is not None, "namespaces parameter is required"
    confidence_prop = namespaces["confidence_prop"]
    extracted_at_prop = namespaces["extracted_at_prop"]
    statement_uri = URIRef(f"rel:{rel.id}")

    g.add((statement_uri, RDF.type, RDF.Statement))
    g.add((statement_uri, RDF.subject, subject_uri))
    g.add((statement_uri, RDF.predicate, predicate_uri))
    g.add((statement_uri, RDF.object, object_uri))

    if rel.metadata.get("confidence") is not None:
        g.add((statement_uri, confidence_prop, Literal(float(rel.metadata["confidence"]))))

    if rel.metadata.get("timestamp"):
        g.add(
            (
                statement_uri,
                extracted_at_prop,
                Literal(rel.metadata["timestamp"], datatype=XSD.dateTime),
            )
        )

    g.add((subject_uri, predicate_uri, object_uri))


def _add_relationship_properties(g, subject_uri, rel, namespaces: dict) -> None:
    """
    Add relationship properties to RDF graph.

    Args:
        g: RDF Graph object
        subject_uri: Subject entity URI
        rel: Relationship object
        namespaces: Dictionary containing namespace objects
    """
    assert g is not None, "g (RDF Graph) parameter is required"
    assert namespaces is not None, "namespaces parameter is required"
    base_ns = namespaces["base_ns"]

    for key, value in rel.properties.items():
        sanitized_prop = _sanitize_uri_component(key)
        prop_uri = base_ns[sanitized_prop]

        if isinstance(value, int | float):
            g.add((subject_uri, prop_uri, Literal(value)))
        elif isinstance(value, bool):
            g.add((subject_uri, prop_uri, Literal(value, datatype=XSD.boolean)))
        else:
            g.add((subject_uri, prop_uri, Literal(str(value))))


def _export_relationships(
    g,
    graph_obj: OntologyGraph,
    entity_id_to_uri: dict[str, URIRef],
    entity_id_to_entity: dict[str, Entity],
    schema_obj: OntologySchema,
    namespaces: dict,
    ontology_config: OntologyConfig | None = None,
    export_context: _ExportBuildContext | None = None,
) -> None:
    """
    Export relationships to OWL Property Assertions.

    Each relationship becomes a property assertion with optional
    reification for metadata (confidence, timestamp).

    Args:
        g: RDF Graph object
        graph_obj: Graph object containing relationships
        entity_id_to_key: Mapping of entity ID to canonical key
        namespaces: Dictionary containing namespace objects
        ontology_config: Optional config for applying naming conventions to URIs
    """
    assert g is not None, "g (RDF Graph) parameter is required"
    assert graph_obj is not None, "graph_obj parameter is required"
    assert schema_obj is not None, "schema_obj parameter is required"

    # Get naming conventions
    relationship_type_casing = (
        export_context.relationship_type_casing
        if export_context is not None
        else "lowerCamelCase"
    )
    if (
        export_context is None
        and ontology_config
        and ontology_config.naming_conventions.enabled
    ):
        relationship_type_casing = ontology_config.naming_conventions.relationship_type_casing

    for rel in graph_obj.relationships:
        _export_single_relationship(
            g,
            rel,
            entity_id_to_uri,
            namespaces,
            entity_id_to_entity=entity_id_to_entity,
            schema_obj=schema_obj,
            relationship_type_casing=relationship_type_casing,
            export_context=export_context,
        )


def _serialize_rdf_graph(
    g,
    output_path: Path | str,
    format: str,
    entity_count: int,
    relationship_count: int,
    fs=None,
    export_metrics: dict[str, float] | None = None,
) -> Path | str:
    """
    Serialize RDF graph to file in specified format.

    Args:
        g: RDF Graph object
        output_path: Path for output file
        format: Output format ("turtle" or "rdfxml")
        entity_count: Number of entities exported
        relationship_count: Number of relationships exported
        fs: Optional filesystem instance (defaults to local filesystem)

    Returns:
        Path to generated file

    Raises:
        ValueError: If format is not supported
        OSError: If file cannot be written
    """
    assert g is not None, "g (RDF Graph) parameter is required"
    assert output_path is not None, "output_path parameter is required"

    from taxonomy_ontology_accelerator.commons.io.fsspec_utils import get_default_filesystem

    if fs is None:
        fs = get_default_filesystem()

    output_path_str = str(output_path)
    if isinstance(output_path, str):
        parent_dir = output_path.rsplit("/", 1)[0] if "/" in output_path else "."
    else:
        parent_dir = str(output_path.parent)

    try:
        fs.makedirs(parent_dir, exist_ok=True)
    except OSError as e:
        raise OSError(f"Failed to create output directory: {e}") from e

    def _protocol_name(filesystem: Any) -> str:
        protocol = getattr(filesystem, "protocol", "file")
        if isinstance(protocol, (tuple, list)):
            return str(protocol[0])
        return str(protocol)

    def _is_local_output(filesystem: Any, path_str: str) -> bool:
        protocol = _protocol_name(filesystem)
        if path_str.startswith(("s3://", "gs://", "gcs://", "az://", "hdfs://")):
            return False
        return protocol in {"file", "local"}

    def _serialize_to_local_path(destination: Path, rdflib_format: str) -> None:
        g.serialize(destination=str(destination), format=rdflib_format)

    try:
        if format == "turtle":
            rdflib_format = "turtle"
            export_label = "Turtle"
            extension = ".ttl"
        elif format == "rdfxml":
            rdflib_format = "xml"
            export_label = "RDF/XML"
            extension = ".owl"
        else:
            error_msg = f"Unsupported format: {format}. Supported: 'turtle', 'rdfxml'"
            logger.error(error_msg)
            raise ValueError(error_msg)

        local_output = _is_local_output(fs, output_path_str)
        serialize_started = time.perf_counter()

        if local_output:
            _serialize_to_local_path(Path(output_path_str), rdflib_format)
            serialization_seconds = time.perf_counter() - serialize_started
            upload_seconds = 0.0
        else:
            logger.info(
                f"[OWL Export] Staging serialized {export_label} locally before upload to "
                f"{_protocol_name(fs)} output"
            )
            with tempfile.TemporaryDirectory(prefix="toa-owl-export-") as tmp_dir:
                staged_output = Path(tmp_dir) / f"ontology{extension}"
                _serialize_to_local_path(staged_output, rdflib_format)
                serialization_seconds = time.perf_counter() - serialize_started

                upload_started = time.perf_counter()
                if hasattr(fs, "put"):
                    fs.put(str(staged_output), output_path_str)
                else:
                    safe_write_file(output_path_str, staged_output.read_text(encoding="utf-8"), fs=fs)
                upload_seconds = time.perf_counter() - upload_started

        if export_metrics is not None:
            export_metrics["serialization_seconds"] = serialization_seconds
            export_metrics["upload_seconds"] = upload_seconds

        logger.info(f"[OWL Export] Serialization completed in {serialization_seconds:.2f}s")
        if not local_output:
            logger.info(f"[OWL Export] Upload completed in {upload_seconds:.2f}s")

        logger.save(f"Exported ontology to {export_label} format: {output_path}")

        logger.debug(f"Exported {entity_count} entities and {relationship_count} relationships")
        return output_path
    except ValueError:
        raise
    except Exception as e:
        logger.error(f"Failed to serialize ontology to {format} format: {e}")
        raise OSError(f"Failed to write export file: {e}") from e


def _add_all_ontology_metadata(
    g,
    domain: str,
    schema_obj,
    graph_obj,
    namespaces: dict,
    ontology_config: OntologyConfig | None = None,
) -> None:
    """Add all ontology metadata to the RDF graph."""
    assert g is not None, "g parameter is required"
    assert namespaces is not None, "namespaces parameter is required"

    _add_ontology_declaration(g, domain, schema_obj, ontology_config)
    _add_graph_metadata(g, graph_obj, namespaces)
    _add_normalization_rules(g, schema_obj, namespaces)
    _add_schema_history(g, schema_obj, namespaces)


def _export_all_data(
    g,
    schema_obj,
    graph_obj,
    namespaces: dict,
    ontology_config: OntologyConfig | None = None,
    export_metrics: dict[str, float] | None = None,
) -> None:
    """Export all schema types, entities, and relationships."""
    assert g is not None, "g parameter is required"
    assert schema_obj is not None, "schema_obj parameter is required"

    export_context = _build_export_context(
        schema_obj,
        graph_obj,
        namespaces,
        ontology_config,
    )

    schema_types_started = time.perf_counter()
    _export_entity_types(
        g,
        schema_obj,
        namespaces,
        ontology_config,
        export_context=export_context,
    )
    _export_class_alignments(
        g,
        schema_obj,
        namespaces,
        ontology_config,
        export_context=export_context,
    )
    schema_type_export_seconds = time.perf_counter() - schema_types_started

    relationship_types_started = time.perf_counter()
    _export_relationship_types(
        g,
        schema_obj,
        namespaces,
        ontology_config,
        export_context=export_context,
    )
    relationship_type_export_seconds = time.perf_counter() - relationship_types_started

    entity_mapping_started = time.perf_counter()
    entity_id_to_uri, entity_id_to_entity = _build_entity_id_mappings(
        graph_obj,
        schema_obj,
        namespaces,
        export_context.entity_label_casing,
        export_context.entity_iri_spelling_variant,
        export_context=export_context,
    )
    entity_mapping_seconds = time.perf_counter() - entity_mapping_started

    entity_export_started = time.perf_counter()
    _export_entities(
        g,
        graph_obj,
        schema_obj,
        namespaces,
        ontology_config,
        correction_vocabulary=export_context.correction_vocabulary,
        entity_id_to_uri=entity_id_to_uri,
        export_context=export_context,
    )
    entity_export_seconds = time.perf_counter() - entity_export_started

    relationship_export_started = time.perf_counter()
    _export_relationships(
        g,
        graph_obj,
        entity_id_to_uri,
        entity_id_to_entity,
        schema_obj,
        namespaces,
        ontology_config,
        export_context=export_context,
    )
    relationship_export_seconds = time.perf_counter() - relationship_export_started

    if export_metrics is not None:
        export_metrics["schema_type_export_seconds"] = schema_type_export_seconds
        export_metrics["relationship_type_export_seconds"] = relationship_type_export_seconds
        export_metrics["entity_mapping_seconds"] = entity_mapping_seconds
        export_metrics["entity_export_seconds"] = entity_export_seconds
        export_metrics["relationship_export_seconds"] = relationship_export_seconds
    logger.info(
        "[OWL Export] Graph assembly breakdown | "
        f"schema/types={schema_type_export_seconds:.2f}s | "
        f"relationship_types={relationship_type_export_seconds:.2f}s | "
        f"entity_mapping={entity_mapping_seconds:.2f}s | "
        f"entities={entity_export_seconds:.2f}s | "
        f"relationships={relationship_export_seconds:.2f}s"
    )


def export_to_owl_rdf(  # noqa: PLR0913
    schema: OntologySchema | Path,
    graph: OntologyGraph | Path,
    output_path: Path | str,
    format: str = "turtle",
    export_config=None,
    fs=None,
    ontology_config: OntologyConfig | None = None,
    export_metrics: dict[str, float] | None = None,
) -> Path | str:
    """
    Export ontology to OWL/RDF format.

    Args:
        schema: OntologySchema or Path to schema.json
        graph: OntologyGraph or Path to graph.json
        output_path: Path for output file (.ttl or .owl)
        format: Output format ("turtle" or "rdfxml")
        export_config: Optional ExportConfig with configurable base_uri
        fs: Optional filesystem instance (defaults to local filesystem)

    Returns:
        Path to generated OWL/RDF file
    """
    assert schema is not None, "schema parameter is required"
    assert output_path is not None, "output_path parameter is required"

    if not RDFLIB_AVAILABLE:
        raise ImportError("rdflib is required for OWL/RDF export. pip install rdflib")

    if fs is None:
        fs = get_default_filesystem()

    schema_obj = _load_schema_for_export(schema)
    graph_obj = _load_graph_for_export(graph)
    domain, sanitized_domain = _validate_export_domains(schema_obj, graph_obj)

    logger.info(f"Starting OWL/RDF export | Domain: {domain} | Format: {format}")

    graph_started = time.perf_counter()
    g = Graph()  # pyright: ignore[reportPossiblyUnboundVariable]
    namespaces = _create_rdf_namespaces(sanitized_domain, export_config)
    _bind_rdf_namespaces(g, namespaces)
    _bind_configured_alignment_namespaces(g, ontology_config)
    _declare_annotation_properties(g, namespaces, ontology_config)

    _add_all_ontology_metadata(g, domain, schema_obj, graph_obj, namespaces, ontology_config)
    _export_all_data(
        g,
        schema_obj,
        graph_obj,
        namespaces,
        ontology_config,
        export_metrics=export_metrics,
    )
    graph_assembly_seconds = time.perf_counter() - graph_started
    if export_metrics is not None:
        export_metrics["graph_assembly_seconds"] = graph_assembly_seconds
    logger.info(f"[OWL Export] Graph assembly completed in {graph_assembly_seconds:.2f}s")

    output_path = _serialize_rdf_graph(
        g,
        output_path,
        format,
        len(graph_obj.entities),
        len(graph_obj.relationships),
        fs=fs,
        export_metrics=export_metrics,
    )

    owl_ontology_metrics = _extract_ontology_metrics_from_graph(g)

    owl_ontology_metrics_output_path = str(Path(output_path).parents[2]) + '/output/owl_ontology_metrics.csv'

    if owl_ontology_metrics_output_path.startswith("s3:/"):
        owl_ontology_metrics_output_path = owl_ontology_metrics_output_path.replace("s3:/", "s3://", 1)

    logger.info(f"Writing ontology metrics to {owl_ontology_metrics_output_path}")

    run_id = Path(output_path).parents[1].name

    _write_ontology_metrics_to_csv(fs, owl_ontology_metrics_output_path, owl_ontology_metrics, run_id)

    return output_path

@dataclass
class OntologyMetrics:
    class_count: int
    object_properties_count: int
    data_properties_count: int
    data_properties_count: int
    subclass_hierarchies: int
    property_domains: int
    property_ranges: int
    disjointness: int
    inverse_properties: int
    cardinality_restriction: int
    equivalent_classes: int
    relationships_density: float | str
    attribute_richness: float | str
    max_inheritance_depth: int |str

def _write_ontology_metrics_to_csv(fs, output_path: Path | str, ontology_metrics: OntologyMetrics, run_id):

    if not hasattr(fs, "open"):
        logger.debug("Skipping ontology metrics CSV write: filesystem does not support open()")
        return

    output_path_parent = str(Path(output_path).parent)

    if output_path_parent.startswith("s3:/"):
        output_path_parent = output_path_parent.replace("s3:/", "s3://", 1)

    fs.makedirs(output_path_parent, exist_ok=True)

    metrics_file_exists = hasattr(fs, "exists") and fs.exists(output_path)

    logger.info(f"Metrics file exists: {metrics_file_exists}")

    fieldnames = ['Run ID',
                  'Class Count',
                  'Object Properties Count',
                  'Data Properties Count',
                  'Subclass Hierarchies',
                  'Property Domains',
                  'Property Ranges',
                  'Disjointness',
                  'Inverse Properties',
                  'Cardinality Restriction',
                  'Equivalent Classes',
                  'Relationships Density',
                  'Attribute Richness',
                  'Max Inheritance Depth']

    if metrics_file_exists:
        with fs.open(output_path) as f:
            binary_content = f.read()
            text_content = binary_content.decode('utf-8')
            csv_file = io.StringIO(text_content)

            csv_file.seek(0, io.SEEK_END)

            writer = csv.DictWriter(csv_file, fieldnames=fieldnames)

            writer.writerow({'Run ID': run_id,
                             'Class Count': ontology_metrics.class_count,
                             'Object Properties Count': ontology_metrics.object_properties_count,
                             'Data Properties Count': ontology_metrics.data_properties_count,
                             'Subclass Hierarchies': ontology_metrics.subclass_hierarchies,
                             'Property Domains': ontology_metrics.property_domains,
                             'Property Ranges': ontology_metrics.property_ranges,
                             'Disjointness': ontology_metrics.disjointness,
                             'Inverse Properties': ontology_metrics.inverse_properties,
                             'Cardinality Restriction': ontology_metrics.cardinality_restriction,
                             'Equivalent Classes': ontology_metrics.equivalent_classes,
                             'Relationships Density': ontology_metrics.relationships_density,
                             'Attribute Richness': ontology_metrics.attribute_richness,
                             'Max Inheritance Depth': ontology_metrics.max_inheritance_depth})

            csv_file = csv_file.getvalue()
    else:
        csv_file = io.StringIO()
        writer = csv.DictWriter(csv_file, fieldnames=fieldnames)

        writer.writeheader()
        writer.writerow({'Run ID': run_id,
                         'Class Count': ontology_metrics.class_count,
                         'Object Properties Count': ontology_metrics.object_properties_count,
                         'Data Properties Count': ontology_metrics.data_properties_count,
                         'Subclass Hierarchies': ontology_metrics.subclass_hierarchies,
                         'Property Domains': ontology_metrics.property_domains,
                         'Property Ranges': ontology_metrics.property_ranges,
                         'Disjointness': ontology_metrics.disjointness,
                         'Inverse Properties': ontology_metrics.inverse_properties,
                         'Cardinality Restriction': ontology_metrics.cardinality_restriction,
                         'Equivalent Classes': ontology_metrics.equivalent_classes,
                         'Relationships Density': ontology_metrics.relationships_density,
                         'Attribute Richness': ontology_metrics.attribute_richness,
                         'Max Inheritance Depth': ontology_metrics.max_inheritance_depth})

        csv_file = csv_file.getvalue()

    with fs.open(output_path, "w", encoding="utf-8") as f:
        f.write(csv_file)

def _extract_ontology_metrics_from_graph(g) -> OntologyMetrics:

    class_count = len(list(g.subjects(RDF.type, OWL.Class)))
    object_properties_count = len(list(g.subjects(RDF.type, OWL.ObjectProperty)))
    data_properties_count = len(list(g.subjects(RDF.type, OWL.DatatypeProperty)))
    subclass_hierarchies = len(list(g.subjects(RDFS.subClassOf)))
    property_domains = len(list(g.subjects(RDFS.domain)))
    property_ranges = len(list(g.subjects(RDFS.range)))

    disjointness = len(list(g.subjects(OWL.disjointWith)))
    inverse_properties = len(list(g.subjects(OWL.inverseOf)))
    cardinality_restriction = len(list(g.subjects(OWL.maxCardinality))) + len(list(g.subjects(OWL.minCardinality)))
    equivalent_classes = len(list(g.subjects(OWL.equivalentClass)))

    max_depth_query = """
                PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
                PREFIX owl: <http://www.w3.org/2002/07/owl#> 

                SELECT ?class (COUNT(?ancestor) AS ?depth)
                WHERE {
                  ?class a owl:Class .
                  ?class rdfs:subClassOf+ ?ancestor .
                  ?ancestor a owl:Class .
                }
                GROUP BY ?class
                ORDER BY DESC(?depth)
                LIMIT 1
                """

    max_inheritance_depth_query_results = list(g.query(max_depth_query))

    if len(max_inheritance_depth_query_results) > 0:
        max_inheritance_depth = int(max_inheritance_depth_query_results[0]["depth"])
    else :
        max_inheritance_depth = "error: query was not successful"

    if class_count == 0:
        relationships_density = "error: class count is zero"
    else:
        relationships_density = object_properties_count / class_count

    if class_count == 0:
        attribute_richness = "error: class count is zero"
    else:
        attribute_richness = data_properties_count / class_count

    logger.info(f"[OWL Export] Class Count: {class_count}, "
                f"Object Properties Count: {object_properties_count}, "
                f"Data Properties Count: {data_properties_count}, "
                f"Subclass Hierarchies: {subclass_hierarchies},"
                f"Property Domains: {property_domains}, "
                f"Property Ranges: {property_ranges}, "
                f"Disjointness: {disjointness}, "
                f"Inverse Properties: {inverse_properties}, "
                f"Cardinality Restriction: {cardinality_restriction}, "
                f"Equivalent Classes: {equivalent_classes}, "
                f"Relationships Density: {relationships_density}, "
                f"Attribute Richness: {attribute_richness}, "
                f"Max Inheritance Depth: {max_inheritance_depth}")

    return OntologyMetrics(class_count,
                           object_properties_count,
                           data_properties_count,
                           subclass_hierarchies,
                           property_domains,
                           property_ranges,
                           disjointness,
                           inverse_properties,
                           cardinality_restriction,
                           equivalent_classes,
                           relationships_density,
                           attribute_richness,
                           max_inheritance_depth)

def export_to_owl_rdf_from_files(
    schema_path: Path,
    graph_path: Path,
    output_path: Path,
    format: str = "turtle",
) -> Path:
    """
    Convenience function to export from file paths.

    Args:
        schema_path: Path to schema.json file
        graph_path: Path to graph.json file
        output_path: Path for output file (.ttl or .owl)
        format: Output format ("turtle" or "rdfxml")

    Returns:
        Path to generated OWL/RDF file
    """
    assert schema_path is not None, "schema_path parameter is required"
    assert graph_path is not None, "graph_path parameter is required"
    return export_to_owl_rdf(schema_path, graph_path, output_path, format)


def _make_path_relative(value: str) -> str:
    """Convert absolute filesystem paths to CWD-relative, handling comma-separated lists."""
    import os
    cwd = Path.cwd()

    def _relativize(p: str) -> str:
        p = p.strip()
        try:
            if os.path.isabs(p):
                return str(Path(p).relative_to(cwd))
        except ValueError:
            pass
        return p

    if "," in value:
        return ", ".join(_relativize(part) for part in value.split(","))
    return _relativize(value)
