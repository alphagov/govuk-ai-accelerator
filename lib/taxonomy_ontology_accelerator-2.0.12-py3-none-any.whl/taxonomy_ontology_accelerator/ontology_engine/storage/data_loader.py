"""
Data loading functions for ontology extraction.

Handles loading existing schema, graph, and embeddings for incremental updates.
"""

import json
import uuid
from pathlib import Path

from pydantic import BaseModel, Field, ValidationError

                                                                      
# Try to import ijson for streaming JSON parsing (optional dependency)
try:
    import ijson  # type: ignore[import-not-found]

    IJSON_AVAILABLE = True
except ImportError:
    ijson = None  # type: ignore[assignment]
    IJSON_AVAILABLE = False

from taxonomy_ontology_accelerator.commons.errors import ErrorCollector
from taxonomy_ontology_accelerator.commons.utils.logger import get_logger
from taxonomy_ontology_accelerator.ontology_engine.config.config import OntologyConfig
from taxonomy_ontology_accelerator.ontology_engine.core.models import (
    Entity,
    OntologyGraph,
    OntologySchema,
    Relationship,
)
from taxonomy_ontology_accelerator.ontology_engine.processing.embeddings import load_embeddings
from taxonomy_ontology_accelerator.ontology_engine.processing.validation import validate_ontology
from taxonomy_ontology_accelerator.ontology_engine.utils.error_helpers import (
    check_max_errors,
    should_collect_error,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.memory_utils import (
    check_memory_available,
    estimate_graph_memory,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.text_normalization import normalize_text

logger = get_logger()

# File size thresholds for logging and streaming decisions (in MB)
# File size thresholds for logging and streaming decisions (in MB)
LARGE_GRAPH_WARNING_THRESHOLD_MB = 500
STREAMING_THRESHOLD_MB = 50
LARGE_EMBEDDINGS_WARNING_THRESHOLD_MB = 100
MAX_FALLBACK_ID_ATTEMPTS = 100  # Maximum attempts for fallback ID generation

def _stream_json_array(graph_path: str, array_name: str, chunk_size: int = 10000, fs=None) -> list:
    """Stream parse a JSON array from file."""
    assert ijson is not None, "ijson must be available to call this function"
    assert graph_path is not None, "graph_path parameter is required"

    from taxonomy_ontology_accelerator.commons.io.fsspec_utils import get_default_filesystem

    if fs is None:
        fs = get_default_filesystem()

    result = []
    with fs.open(graph_path, "rb") as f:
        parser = ijson.items(f, f"{array_name}.item")
        for idx, item in enumerate(parser, 1):
            result.append(item)
            if idx % chunk_size == 0:
                logger.debug(f"Streaming: loaded {idx} {array_name}")
    return result

def _parse_graph_metadata(graph_path: str, fs=None) -> tuple[str, str]:
    """Parse domain and schema_version from graph file."""
    assert ijson is not None, "ijson must be available to call this function"
    assert graph_path is not None, "graph_path parameter is required"

    from taxonomy_ontology_accelerator.commons.io.fsspec_utils import get_default_filesystem

    if fs is None:
        fs = get_default_filesystem()

    domain, schema_version = "", ""
    with fs.open(graph_path, "rb") as f:
        parser = ijson.parse(f)
        for prefix, event, value in parser:
            if prefix == "domain" and event == "string":
                domain = value
            elif prefix == "schema_version" and event == "string":
                schema_version = value
            if domain and schema_version:
                break
    return domain, schema_version

def _load_graph_streaming(
    graph_path: str,
    config: OntologyConfig,
    error_collector: ErrorCollector,
    fs=None,
) -> dict | None:
    """
    Load graph JSON using streaming parser for large files (>50MB).

    Uses ijson to parse JSON incrementally, reducing memory usage.
    Falls back to standard JSON loading if streaming fails or ijson unavailable.
    """
    assert graph_path is not None, "graph_path parameter is required"
    assert config is not None, "config parameter is required"
    if not IJSON_AVAILABLE:
        logger.debug(
            "ijson not available (install with: pip install ijson), using standard loading"
        )
        return None

    try:
        entities = _stream_json_array(graph_path, "entities", fs=fs)
        relationships = _stream_json_array(graph_path, "relationships", fs=fs)
        domain, schema_version = _parse_graph_metadata(graph_path, fs=fs)

        logger.load(
            f"Streaming load complete | Entities: {len(entities):,} | Relationships: {len(relationships):,}"
        )
        return {
            "domain": domain,
            "schema_version": schema_version,
            "entities": entities,
            "relationships": relationships,
        }

    except Exception as e:
        logger.warning(f"Streaming JSON load failed: {e}. Falling back to standard loading.")
        if should_collect_error("warning", config):
            check_max_errors(
                error_collector,
                config,
                "config_error",
                f"Streaming graph load failed: {e}",
            )
            error_collector.add_config_error(
                f"Streaming graph load failed: {e}",
                config_path=str(graph_path),
            )
        return None

class ExistingData(BaseModel):
    """Container for existing ontology data loaded from files."""

    model_config = {"arbitrary_types_allowed": True}

    ontology_schema: OntologySchema | None = None
    graph: OntologyGraph | None = None
    embeddings: dict[str, list[float]] = Field(default_factory=dict)
    entity_map: dict[str, str] = Field(default_factory=dict)
    entity_ids: set[str] = Field(default_factory=set)
    relationships: set[tuple[str, str, str]] = Field(default_factory=set)

def _collect_warning(
    msg: str, config: OntologyConfig, error_collector: ErrorCollector, path: str
) -> None:
    """Collect a warning error if configured."""
    assert msg is not None, "msg parameter is required"
    assert config is not None, "config parameter is required"
    if should_collect_error("warning", config):
        check_max_errors(error_collector, config, "config_error", msg)
        error_collector.add_config_error(msg, config_path=path)

def _load_schema_file(
    schema_path: str, config: OntologyConfig, error_collector: ErrorCollector, fs=None
) -> OntologySchema | None:
    """
    Load ontology schema from a JSON file.

    Handles JSON parsing errors and file I/O errors gracefully,
    logging warnings rather than raising exceptions since schema
    loading is optional for incremental updates.

    Args:
        schema_path: Path to schema.json file
        config: Ontology configuration
        error_collector: Collector for non-fatal errors
        fs: Optional filesystem instance (defaults to local filesystem)

    Returns:
        OntologySchema if successfully loaded, None if file doesn't
        exist or loading fails
    """
    assert schema_path is not None, "schema_path parameter is required"
    assert config is not None, "config parameter is required"

    from taxonomy_ontology_accelerator.commons.io.fsspec_utils import get_default_filesystem

    if fs is None:
        fs = get_default_filesystem()

    if not fs.exists(schema_path):
        return None

    try:
        with fs.open(schema_path, "r", encoding="utf-8") as f:
            schema_data = json.load(f)
        schema = OntologySchema(**schema_data)
        logger.load(f"Loaded existing schema | Version: {schema.version}")
        return schema
    except (json.JSONDecodeError, ValidationError) as e:
        _collect_warning(
            f"Failed to load existing schema: {e}", config, error_collector, str(schema_path)
        )
        logger.warning(f"Failed to load existing schema from {schema_path}: {e}")
    except OSError as e:
        _collect_warning(
            f"Failed to read schema file: {e}", config, error_collector, str(schema_path)
        )
        logger.warning(f"Failed to read existing schema file {schema_path}: {e}")
    return None

def _get_graph_size_info(graph_path: str, fs=None) -> tuple[float, bool]:
    """
    Get graph file size and compression status.

    Args:
        graph_path: Path to the graph file
        fs: Optional filesystem instance (defaults to local filesystem)

    Returns:
        Tuple of (size_in_mb, is_compressed)
    """
    assert graph_path is not None, "graph_path parameter is required"
    assert isinstance(graph_path, str), "graph_path must be a string"

    from taxonomy_ontology_accelerator.commons.io.fsspec_utils import get_default_filesystem

    if fs is None:
        fs = get_default_filesystem()

    is_compressed = graph_path.endswith(".gz")
    try:
        info = fs.info(graph_path)
        graph_size_mb = info.get("size", 0) / (1024 * 1024)
        return graph_size_mb, is_compressed
    except OSError:
        return 0.0, is_compressed

def _check_graph_memory(graph_size_mb: float, config: OntologyConfig) -> None:
    """
    Check memory availability and warn for large files.

    Args:
        graph_size_mb: Graph file size in MB
        config: Ontology configuration
    """
    assert isinstance(graph_size_mb, float | int), "graph_size_mb must be numeric"
    assert config is not None, "config parameter is required"
    if config.memory.check_available and graph_size_mb > 0:
        estimated_memory = estimate_graph_memory(graph_size_mb)
        check_memory_available(estimated_memory, config, "graph")

    if graph_size_mb > LARGE_GRAPH_WARNING_THRESHOLD_MB:
        logger.warning(
            f"Graph file is very large ({graph_size_mb:.1f}MB). "
            f"This may cause memory issues. Consider splitting or using streaming."
        )

def _should_use_streaming(
    graph_size_mb: float, is_compressed: bool, config: OntologyConfig
) -> bool:
    """
    Determine if streaming loading should be used.

    Args:
        graph_size_mb: Graph file size in MB
        is_compressed: Whether file is compressed
        config: Ontology configuration

    Returns:
        True if streaming should be used
    """
    assert isinstance(graph_size_mb, float | int), "graph_size_mb must be numeric"
    assert config is not None, "config parameter is required"
    return (
        IJSON_AVAILABLE
        and not is_compressed
        and graph_size_mb > STREAMING_THRESHOLD_MB
        and config.memory.check_available
    )

def _load_graph_from_file(
    graph_path: str,
    config: OntologyConfig,
    error_collector: ErrorCollector,
    use_streaming: bool,
    graph_size_mb: float,
    fs=None,
) -> OntologyGraph | None:
    """
    Load graph data from file using streaming or standard loading.

    Args:
        graph_path: Path to graph file
        config: Ontology configuration
        error_collector: Error collector
        use_streaming: Whether to use streaming parser
        graph_size_mb: Graph file size in MB
        fs: Optional filesystem instance (defaults to local filesystem)

    Returns:
        Loaded OntologyGraph or None if loading fails
    """
    assert graph_path is not None, "graph_path parameter is required"
    assert config is not None, "config parameter is required"
    from taxonomy_ontology_accelerator.commons.io.file_utils import safe_read_file

    if use_streaming:
        logger.load(f"Loading large graph ({graph_size_mb:.1f}MB) with streaming parser")
        existing_graph_data = _load_graph_streaming(graph_path, config, error_collector, fs=fs)
        if existing_graph_data:
            return OntologyGraph(**existing_graph_data)
        logger.load("Falling back to standard JSON loading")

    existing_graph_data = json.loads(safe_read_file(graph_path, fs=fs))
    return OntologyGraph(**existing_graph_data)

def _try_fallback_id(
    rel_id: str, seen_ids: set[str], counter: int, attempts: int
) -> tuple[str, int, str]:
    """Try generating fallback ID when primary method fails."""
    assert rel_id is not None, "rel_id parameter is required"
    assert seen_ids is not None, "seen_ids parameter is required"

    fallback_id = f"{rel_id}_fixed_{counter}"
    fallback_attempts = 0
    while fallback_id in seen_ids and fallback_attempts < MAX_FALLBACK_ID_ATTEMPTS:
        counter += 1
        fallback_id = f"{rel_id}_fixed_{counter}"
        fallback_attempts += 1

    if fallback_id in seen_ids:
        fallback_id = f"rel_fixed_{uuid.uuid4().hex[:8]}"
        msg = f"Used UUID fallback for {rel_id} after {attempts}+{fallback_attempts} attempts"
    else:
        msg = f"Fixed duplicate ID: {rel_id} -> {fallback_id} (after {attempts} attempts)"
    return fallback_id, counter, msg

def _generate_unique_relationship_id(
    rel_id: str, seen_ids: set[str], counter: int, num_rels: int, config: OntologyConfig
) -> tuple[str, int, str | None]:
    """Generate a unique relationship ID for a duplicate."""
    assert rel_id is not None, "rel_id parameter is required"
    assert config is not None, "config parameter is required"
    from taxonomy_ontology_accelerator.ontology_engine.utils.id_generation import (
        generate_relationship_id,
    )

    max_attempts = num_rels * 2
    new_id = generate_relationship_id(counter, config)
    attempts = 0

    while new_id in seen_ids and attempts < max_attempts:
        counter += 1
        new_id = generate_relationship_id(counter, config)
        attempts += 1

    if new_id not in seen_ids:
        return new_id, counter, None

    fallback_id, counter, msg = _try_fallback_id(rel_id, seen_ids, counter, attempts)
    return fallback_id, counter, msg

def _create_fixed_relationship(rel: Relationship, new_id: str) -> Relationship:
    """Create a new relationship with a fixed ID."""
    assert rel is not None, "rel parameter is required"
    assert new_id is not None, "new_id parameter is required"
    return Relationship(
        id=new_id,
        type=rel.type,
        to=rel.to,
        properties=rel.properties,
        metadata=rel.metadata,
        **{"from": rel.from_},
    )

def _populate_entity_maps(
    data: ExistingData, config: OntologyConfig, error_collector: ErrorCollector
) -> None:
    """
    Populate entity_map and entity_ids from loaded graph entities.

    Creates a lookup map from normalized label to entity ID for efficient
    entity matching during extraction. Also detects and removes duplicate
    entity IDs (data corruption).

    Args:
        data: ExistingData object to update
        config: Ontology configuration for text normalization
        error_collector: Error collector for duplicate ID warnings
    """
    assert data is not None, "data parameter is required"
    assert config is not None, "config parameter is required"
    assert data.graph is not None, "graph must be loaded"
    assert error_collector is not None, "error_collector parameter is required"

    normalization_cache: dict[str, str] = {}
    seen_ids: set[str] = set()
    deduplicated_entities: list[Entity] = []

    for entity in data.graph.entities:
        # Check for duplicate entity IDs (data corruption)
        # Check for duplicate entity IDs (data corruption)
        if entity.id in seen_ids:
            error_collector.add_error(
                "data_integrity",
                f"Duplicate entity ID '{entity.id}' found in graph, skipping duplicate",
            )
            continue

        seen_ids.add(entity.id)
        deduplicated_entities.append(entity)
        data.entity_ids.add(entity.id)

        # Add to entity_map (normalized label → entity ID)
        # Add to entity_map (normalized label → entity ID)
        normalized = normalize_text(entity.label, config, cache=normalization_cache)
        if normalized in data.entity_map and data.entity_map[normalized] != entity.id:
            logger.debug(
                f"Normalized label '{normalized}' maps to both "
                f"'{data.entity_map[normalized]}' and '{entity.id}', keeping first"
            )
        else:
            data.entity_map[normalized] = entity.id

        # Add aliases to entity_map (skip if already mapped)
        # Add aliases to entity_map (skip if already mapped)
        _add_aliases_to_entity_map(entity, data, normalization_cache, config)

                                                                          
    # Update graph with deduplicated entities if any duplicates were found
    if len(deduplicated_entities) < len(data.graph.entities):
        data.graph.entities = deduplicated_entities

def _add_aliases_to_entity_map(
    entity: Entity,
    data: ExistingData,
    normalization_cache: dict[str, str],
    config: OntologyConfig,
) -> None:
    """Register an entity's aliases in the entity_map for lookup during extraction."""
    assert entity is not None, "entity parameter is required"
    assert data is not None, "data parameter is required"
    if not entity.aliases:
        return
    for alias in entity.alias_names:
        if alias:
            normalized_alias = normalize_text(alias, config, cache=normalization_cache)
            if normalized_alias not in data.entity_map:
                data.entity_map[normalized_alias] = entity.id
            else:
                logger.debug(
                    f"Alias '{alias}' (normalized: '{normalized_alias}') for entity "
                    f"'{entity.id}' already mapped to '{data.entity_map[normalized_alias]}', skipping"
                )

def _fix_duplicate_relationship_ids(
    data: ExistingData, graph_path: str, config: OntologyConfig, error_collector: ErrorCollector
) -> None:
    """Regenerate IDs for duplicate relationships."""
    assert data is not None, "data parameter is required"
    assert config is not None, "config parameter is required"
    if data.graph is None:
        return

    from taxonomy_ontology_accelerator.ontology_engine.utils.id_generation import (
        find_max_id_counter,
    )

    seen_ids: set[str] = set()
    fixed_rels: list[Relationship] = []
    rel_ids = [rel.id for rel in data.graph.relationships]
    max_c = find_max_id_counter(rel_ids, config.output.relationship_id_prefix)
    counter = max_c + 1 if max_c >= 0 else 0
    num_rels = len(data.graph.relationships)

    for rel in data.graph.relationships:
        if rel.id in seen_ids:
            new_id, counter, err = _generate_unique_relationship_id(
                rel.id, seen_ids, counter, num_rels, config
            )
            if err:
                logger.warning(err)
                if should_collect_error("warning", config):
                    check_max_errors(error_collector, config, "config_error", err)
                    error_collector.add_config_error(err, config_path=str(graph_path))
            fixed_rels.append(_create_fixed_relationship(rel, new_id))
            seen_ids.add(new_id)
        else:
            seen_ids.add(rel.id)
            fixed_rels.append(rel)

    data.graph.relationships = fixed_rels
    data.relationships = {(r.from_, r.to, r.type) for r in fixed_rels}

def _handle_graph_load_error(
    e: Exception,
    graph_path: str,
    config: OntologyConfig,
    error_collector: ErrorCollector,
    is_read_error: bool = False,
) -> None:
    """Handle errors during graph file loading."""
    assert config is not None, "config parameter is required"
    assert error_collector is not None, "error_collector parameter is required"

    error_type = "read" if is_read_error else "load"
    msg = f"Failed to {error_type} existing graph file: {e}"
    if should_collect_error("warning", config):
        check_max_errors(error_collector, config, "config_error", msg)
        error_collector.add_config_error(msg, config_path=str(graph_path))
    logger.warning(f"Failed to {error_type} graph from {graph_path}: {e}")

def _load_graph_file(
    data: ExistingData,
    graph_path: str,
    config: OntologyConfig,
    error_collector: ErrorCollector,
    fs=None,
) -> None:
    """Load and process graph file with deduplication."""
    assert data is not None, "data parameter is required"
    assert config is not None, "config parameter is required"

    from taxonomy_ontology_accelerator.commons.io.fsspec_utils import get_default_filesystem

    if fs is None:
        fs = get_default_filesystem()

    if not fs.exists(graph_path):
        return

    try:
        graph_size_mb, is_compressed = _get_graph_size_info(graph_path, fs=fs)
        _check_graph_memory(graph_size_mb, config)
        use_streaming = _should_use_streaming(graph_size_mb, is_compressed, config)
        data.graph = _load_graph_from_file(
            graph_path, config, error_collector, use_streaming, graph_size_mb, fs=fs
        )

        if data.graph:
            logger.load(
                f"Loaded graph | Entities: {len(data.graph.entities):,} | Rels: {len(data.graph.relationships):,}"
            )
            # Entity deduplication removed - handled by extraction_pipeline pre-merge
            # This eliminates conflicting deduplication strategies
            # Entity deduplication removed - handled by extraction_pipeline pre-merge
            # This eliminates conflicting deduplication strategies
            _populate_entity_maps(data, config, error_collector)
            _fix_duplicate_relationship_ids(data, graph_path, config, error_collector)

    except (json.JSONDecodeError, ValidationError) as e:
        _handle_graph_load_error(e, graph_path, config, error_collector)
    except OSError as e:
        _handle_graph_load_error(e, graph_path, config, error_collector, is_read_error=True)

def _load_embeddings_file(
    data: ExistingData,
    embeddings_path: str,
    config: OntologyConfig,
    fs=None,
) -> None:
    """
    Load embeddings file with size warnings.

    Args:
        data: ExistingData object to update
        embeddings_path: Path to embeddings file
        config: Ontology configuration
        fs: Optional filesystem instance (defaults to local filesystem)
    """
    assert data is not None, "data parameter is required"
    assert config is not None, "config parameter is required"

    from taxonomy_ontology_accelerator.commons.io.fsspec_utils import get_default_filesystem

    if fs is None:
        fs = get_default_filesystem()

    if not fs.exists(embeddings_path):
        return

    existing_embeddings = load_embeddings(config, embeddings_path, fs=fs)
    data.embeddings = existing_embeddings
    logger.load(f"Loaded {len(data.embeddings):,} existing embeddings")

    try:
        info = fs.info(embeddings_path)
        embeddings_size_mb = info.get("size", 0) / (1024 * 1024)
        if embeddings_size_mb > LARGE_EMBEDDINGS_WARNING_THRESHOLD_MB:
            logger.warning(
                f"Embeddings file is large ({embeddings_size_mb:.1f}MB). "
                f"Consider using FAISS index for better memory efficiency."
            )
    except OSError:
        pass

def _filter_unknown_type_errors(errors: list[str]) -> tuple[list[str], list[str]]:
    """
    Separate unknown type errors from real validation errors.

    Returns:
        Tuple of (unknown_type_errors, real_errors)
    """
    assert errors is not None, "errors parameter is required"
    assert isinstance(errors, list), "errors must be a list"

    unknown_type_errors = [
        e
        for e in errors
        if "unknown entity types" in e.lower() or "unknown relationship types" in e.lower()
    ]
    real_errors = [e for e in errors if e not in unknown_type_errors]
    return unknown_type_errors, real_errors

def _log_and_collect_real_errors(
    real_errors: list[str],
    config: OntologyConfig,
    error_collector: ErrorCollector,
) -> None:
    """Log and collect real validation errors (non-type-related)."""
    assert real_errors is not None, "real_errors parameter is required"
    assert config is not None, "config parameter is required"
    assert error_collector is not None, "error_collector parameter is required"

    logger.warning(f"Validation found {len(real_errors)} data integrity issue(s) in existing data")
    for error in real_errors:
        logger.warning(f"  • {error}")

                         
    # Collect real errors
    if should_collect_error("warning", config):
        for error in real_errors:
            error_collector.add_error(
                error_type="validation_warning",
                message=f"Existing data validation issue: {error}",
                severity="warning",
            )

def _log_validation_warnings_for_loaded_data(warnings: list[str]) -> None:
    """Log validation warnings for loaded data."""
    assert warnings is not None, "warnings parameter is required"
    assert len(warnings) > 0, "warnings list must not be empty"

    logger.debug(f"Validation found {len(warnings)} warning(s) in existing data")
    for i, warning in enumerate(warnings, 1):
        logger.debug(f"  [{i}] {warning}")

def _validate_loaded_data(
    data: ExistingData,
    config: OntologyConfig,
    error_collector: ErrorCollector,
) -> None:
    """
    Validate loaded schema and graph data.

    Args:
        data: ExistingData object to validate
        config: Ontology configuration
        error_collector: Error collector
    """
    assert data is not None, "data parameter is required"
    assert config is not None, "config parameter is required"
    if data.ontology_schema is None or data.graph is None:
        return

    validation_errors, validation_warnings = validate_ontology(data.ontology_schema, data.graph)

    # During incremental extraction, it's expected that existing data may have types
    # not yet in the schema (schema evolution happens at end of job).
    # Only log non-type-related errors as they indicate real data integrity issues.
    # During incremental extraction, it's expected that existing data may have types
    # not yet in the schema (schema evolution happens at end of job).
    # Only log non-type-related errors as they indicate real data integrity issues.
    if validation_errors:
        _unknown_type_errors, real_errors = _filter_unknown_type_errors(validation_errors)
        if real_errors:
            _log_and_collect_real_errors(real_errors, config, error_collector)
        # Unknown type errors are silently ignored (expected during incremental extraction)
        # Unknown type errors are silently ignored (expected during incremental extraction)

    if validation_warnings:
        _log_validation_warnings_for_loaded_data(validation_warnings)

def load_existing_data(
    output_dir: Path | str,
    config: OntologyConfig,
    error_collector: ErrorCollector,
    validate: bool = True,
    fs=None,
) -> ExistingData:
    """
    Load existing schema, graph, and embeddings for incremental updates.

    Args:
        output_dir: Output directory containing existing files
        config: Ontology configuration
        error_collector: Error collector for non-failing errors
        validate: Whether to validate loaded data (default True)
        fs: Optional filesystem instance (defaults to local filesystem)

    Returns:
        ExistingData object containing all loaded data
    """
    assert output_dir is not None, "output_dir parameter is required"
    assert config is not None, "config parameter is required"

    from taxonomy_ontology_accelerator.commons.io.fsspec_utils import get_default_filesystem

    if fs is None:
        fs = get_default_filesystem()

    if not config.features.incremental_updates:
        return ExistingData()

    data = ExistingData()
    output_dir_str = str(output_dir)
    schema_path = f"{output_dir_str}/{config.output.schema_filename}"
    graph_path = f"{output_dir_str}/{config.output.graph_filename}"
    embeddings_path = (
        f"{output_dir_str}/{config.output.embeddings_directory}/{config.output.embeddings_filename}"
    )

    # Load schema, graph, and embeddings
    # Load schema, graph, and embeddings
    data.ontology_schema = _load_schema_file(schema_path, config, error_collector, fs=fs)
    _load_graph_file(data, graph_path, config, error_collector, fs=fs)
    _load_embeddings_file(data, embeddings_path, config, fs=fs)

                                         
    # Validate existing data if requested
    if validate:
        _validate_loaded_data(data, config, error_collector)

    return data
