"""
Checkpoint Manager for Resumable Ontology Extraction

Implements file-level checkpointing for resumable processing:
- Tracks files (not chunks) for simplicity and reliability
- Two-state system: completed_files and failed_files
- Persists using fsspec (supports local and cloud storage)
- Enables resuming from interruption point and retrying failed files
- Files are marked as completed only after successful storage to graph.json
"""

import contextlib
import json
import threading
import time
from pathlib import Path
from typing import Any

from fsspec import AbstractFileSystem

from taxonomy_ontology_accelerator.commons.io.fsspec_utils import get_default_filesystem
from taxonomy_ontology_accelerator.commons.utils.logger import get_logger
from taxonomy_ontology_accelerator.ontology_engine.storage.file_locking import FileLock

logger = get_logger()

# OS path length limits (POSIX standard)
PATH_MAX = 2048  # Maximum total path length
NAME_MAX = 255  # Maximum length for individual path component (file/directory name)

def _validate_path_length(path_str: str) -> bool:
    """Validate total path length doesn't exceed PATH_MAX."""
    assert path_str is not None, "path_str parameter is required"
    assert isinstance(path_str, str), "path_str must be a string"
    if len(path_str) > PATH_MAX:
        logger.warning(
            f"File path exceeds maximum length ({len(path_str)} > {PATH_MAX}): {path_str[:100]}..."
        )
        return False
    return True

def _validate_component_lengths(path_str: str) -> bool:
    """Validate individual path components don't exceed NAME_MAX."""
    assert path_str is not None, "path_str parameter is required"
    assert isinstance(path_str, str), "path_str must be a string"
    components = path_str.replace("\\", "/").split("/")
    for component in components:
        if component and len(component) > NAME_MAX:
            logger.warning(
                f"Path component exceeds maximum length ({len(component)} > {NAME_MAX}): {component[:50]}..."
            )
            return False
    return True

def _normalize_file_path(file_path: str | Path | None) -> str | None:
    """
    Normalize file path for consistent checkpoint tracking.

    Validates path length limits and converts to string form.
    For cloud paths (s3://, gs://, etc.), returns unchanged string.
    For local paths, returns absolute path string.

    Args:
        file_path: File path to normalize

    Returns:
        Normalized absolute path string, or None if invalid
    """
    assert logger is not None, "logger must be available"
    assert PATH_MAX > 0, "PATH_MAX must be positive"
    if not file_path:
        return None

    path_str = str(file_path)
    if not _validate_path_length(path_str) or not _validate_component_lengths(path_str):
        return None

    try:
        from taxonomy_ontology_accelerator.commons.io.file_utils import normalize_path

        path = normalize_path(file_path)
        normalized_str = str(path)

        if not _validate_path_length(normalized_str):
            return None

        return normalized_str
    except (OSError, ValueError) as e:
        logger.warning(f"Failed to normalize file path '{file_path}': {e}")
        return None

def _write_checkpoint_file_atomic(checkpoint_path: str, data: dict, fs: AbstractFileSystem) -> None:
    """Write checkpoint data atomically using temp file and rename."""
    assert checkpoint_path is not None, "checkpoint_path parameter is required"
    assert isinstance(data, dict), "data must be a dictionary"
    assert fs is not None, "fs parameter is required"

    temp_path = checkpoint_path + ".tmp"

                                                
    # Use file locking only for local filesystem
    use_lock = isinstance(fs, type(get_default_filesystem()))

    lock_context = FileLock(Path(checkpoint_path)) if use_lock else contextlib.nullcontext()

    with lock_context:
        try:
            with fs.open(temp_path, "w", encoding="utf-8") as f:
                f.write(json.dumps(data, indent=2))
            fs.mv(temp_path, checkpoint_path, overwrite=True)
        except OSError:
            if fs.exists(temp_path):
                with contextlib.suppress(OSError):
                    fs.rm(temp_path)
            raise

def _prepare_checkpoint_data(completed_files: set[str], failed_files: set[str]) -> dict:
    """Prepare checkpoint data dictionary for saving."""
    assert completed_files is not None, "completed_files parameter is required"
    assert failed_files is not None, "failed_files parameter is required"

    return {
        "completed_files": sorted(completed_files),
        "failed_files": sorted(failed_files),
        "last_updated": time.time(),
    }

class CheckpointManager:
    """
    File-level checkpoint manager for resumable ontology extraction.

    Tracks file-level processing state:
    - completed_files: Files successfully processed and stored to graph.json
    - failed_files: Files that failed during processing (will be retried)

    Simple structure: only tracks files, not chunks.
    """

    def __init__(
        self,
        output_dir: Path | str,
        checkpoint_filename: str = "processing_checkpoint.json",
        enabled: bool = True,
        clear_first: bool = False,
        fs: AbstractFileSystem | None = None,
    ):
        """
        Initialize checkpoint manager.

        Args:
            output_dir: Output directory for ontology extraction
            checkpoint_filename: Name of checkpoint file
            enabled: Enable/disable checkpointing
            clear_first: If True, clear existing checkpoint before loading
            fs: Optional filesystem instance (defaults to local filesystem)
        """
        assert output_dir is not None, "output_dir parameter is required"
        assert isinstance(checkpoint_filename, str), "checkpoint_filename must be a string"
        self.enabled = enabled
        self.fs = fs if fs is not None else get_default_filesystem()
        self.output_dir = str(output_dir)
        self.checkpoint_dir = f"{self.output_dir}/checkpoints"
        self.checkpoint_path = f"{self.checkpoint_dir}/{checkpoint_filename}"

        # In-memory tracking (file-level) - Simple 2-state system
        self.completed_files: set[str] = set()  # File paths successfully processed
        self.failed_files: set[str] = set()  # File paths that failed (will retry)
        self._state_lock = threading.RLock()

        if not self.enabled:
            logger.debug("Checkpointing disabled")
            return

        # Ensure checkpoint directory exists
        # Ensure checkpoint directory exists
        self.fs.makedirs(self.checkpoint_dir, exist_ok=True)

                                             
        # Clear checkpoint first if requested
        if clear_first:
            self._clear_checkpoint_only()
            logger.data("Cleared existing checkpoint - starting fresh extraction")
                                                               
        # Load existing checkpoint (only if not clearing first)
        elif self.enabled:
            self._load_checkpoint()

    def _normalize_path_list(self, paths: list) -> set[str]:
        """Normalize and validate a list of file paths."""
        assert paths is not None, "paths parameter is required"
        assert isinstance(paths, list), "paths must be a list"
        result: set[str] = set()
        for path in paths:
            if not isinstance(path, str):
                logger.warning(f"Invalid checkpoint entry (not a string): {path}")
                continue
            normalized = _normalize_file_path(path)
            if normalized:
                result.add(normalized)
        return result

    def _load_checkpoint(self) -> None:
        """Load checkpoint from filesystem."""
        assert self.checkpoint_path is not None, "checkpoint_path must be set"
        assert isinstance(self.enabled, bool), "enabled must be a boolean"
        if not self.enabled or not self.fs.exists(self.checkpoint_path):
            if self.enabled:
                logger.debug("No existing checkpoint found - starting fresh")
            return

                                                    
        # Use file locking only for local filesystem
        use_lock = isinstance(self.fs, type(get_default_filesystem()))
        lock_context = (
            FileLock(Path(self.checkpoint_path)) if use_lock else contextlib.nullcontext()
        )

        try:
            with lock_context:
                info = self.fs.info(self.checkpoint_path)
                if info.get("size", 0) == 0:
                    logger.warning("Checkpoint file is empty - starting fresh")
                    self.completed_files, self.failed_files = set(), set()
                    return

                with self.fs.open(self.checkpoint_path, "r", encoding="utf-8") as f:
                    content = f.read()

                if not content.strip():
                    logger.warning("Checkpoint file contains only whitespace - starting fresh")
                    self.completed_files, self.failed_files = set(), set()
                    return

                data = json.loads(content)
                if not isinstance(data, dict):
                    raise ValueError(f"Checkpoint data is not a dict: {type(data)}")

                self.completed_files = self._normalize_path_list(data.get("completed_files", []))
                self.failed_files = self._normalize_path_list(data.get("failed_files", []))

                logger.info(
                    f"Loaded checkpoint: {len(self.completed_files)} completed files, "
                    f"{len(self.failed_files)} failed files"
                )
        except (json.JSONDecodeError, KeyError, OSError, ValueError) as e:
            logger.warning(f"Failed to load checkpoint: {e}. Starting fresh.")
            self.completed_files, self.failed_files = set(), set()

    def _save_checkpoint(self) -> None:
        """Save checkpoint to filesystem with retry and error handling."""
        assert self.checkpoint_path is not None, "checkpoint_path must be set"
        assert isinstance(self.enabled, bool), "enabled must be a boolean"
        if not self.enabled:
            return

        max_retries = 3
        retry_delay = 0.1

        for attempt in range(max_retries):
            try:
                self.fs.makedirs(self.checkpoint_dir, exist_ok=True)
                data = _prepare_checkpoint_data(self.completed_files, self.failed_files)
                _write_checkpoint_file_atomic(self.checkpoint_path, data, self.fs)
                logger.debug(
                    f"Checkpoint saved: {len(self.completed_files)} completed, "
                    f"{len(self.failed_files)} failed"
                )
                return  # Success

            except OSError as e:
                if attempt < max_retries - 1:
                    delay = retry_delay * (2**attempt)
                    logger.warning(
                        f"Failed to save checkpoint (attempt {attempt + 1}/{max_retries}): {e}. "
                        f"Retrying in {delay:.2f}s..."
                    )
                    time.sleep(delay)
                else:
                    logger.error(f"Failed to save checkpoint after {max_retries} attempts: {e}")

    def is_file_completed(self, file_path: str) -> bool:
        """Check if file has been completed."""
        assert isinstance(self.enabled, bool), "enabled must be a boolean"
        assert self.completed_files is not None, "completed_files must be initialized"
        if not self.enabled or not file_path:
            return False
        normalized = _normalize_file_path(file_path)
        if normalized is None:
            return False
        with self._state_lock:
            return normalized in self.completed_files

    def is_file_failed(self, file_path: str) -> bool:
        """Check if file has previously failed."""
        assert isinstance(self.enabled, bool), "enabled must be a boolean"
        assert self.failed_files is not None, "failed_files must be initialized"
        if not self.enabled or not file_path:
            return False
        normalized = _normalize_file_path(file_path)
        if normalized is None:
            return False
        with self._state_lock:
            return normalized in self.failed_files

    def remove_from_failed(self, file_path: str) -> bool:
        """
        Remove file from failed_files set (for successful retries).

        Args:
            file_path: File path to remove from failed files

        Returns:
            True if file was in failed_files and removed, False otherwise
        """
        assert self.failed_files is not None, "failed_files must be initialized"
        assert isinstance(self.enabled, bool), "enabled must be a boolean"
        if not self.enabled:
            return False

        normalized = _normalize_file_path(file_path)
        if not normalized:
            return False
        with self._state_lock:
            was_in_failed = normalized in self.failed_files
            if was_in_failed:
                self.failed_files.discard(normalized)
                self._save_checkpoint()
        return was_in_failed

    def mark_file_completed(self, file_path: str) -> None:
        """
        Mark file as completed (fully processed and stored to graph.json).

        Args:
            file_path: File path to mark as completed
        """
        assert self.completed_files is not None, "completed_files must be initialized"
        assert isinstance(self.enabled, bool), "enabled must be a boolean"
        if not self.enabled:
            return

        normalized = _normalize_file_path(file_path)
        if not normalized:
            logger.warning(f"Cannot mark file as completed - invalid path: {file_path}")
            return

        with self._state_lock:
            was_in_failed = normalized in self.failed_files
            was_already_completed = normalized in self.completed_files
        # Idempotent operation - safe to call multiple times
            self.completed_files.add(normalized)
            self.failed_files.discard(normalized)

            self._save_checkpoint()

        if was_in_failed:
            logger.success(f"✓ File completed (recovered from previous failure): {normalized}")
        elif not was_already_completed:
            logger.debug(f"✓ File completed: {normalized}")

    def mark_file_failed(self, file_path: str) -> None:
        """
        Mark file as failed (will be retried on next run).

        Args:
            file_path: File path to mark as failed
        """
        assert self.failed_files is not None, "failed_files must be initialized"
        assert isinstance(self.enabled, bool), "enabled must be a boolean"
        if not self.enabled:
            return

        normalized = _normalize_file_path(file_path)
        if not normalized:
            logger.warning(f"Cannot mark file as failed - invalid path: {file_path}")
            return

        with self._state_lock:
            was_in_completed = normalized in self.completed_files
            self.failed_files.add(normalized)
            self.completed_files.discard(normalized)
        # Idempotent operation - safe to call multiple times
            self._save_checkpoint()

        if was_in_completed:
            logger.warning(f"Marked file as failed (was previously completed): {normalized}")
        else:
            logger.debug(f"Marked file as failed: {normalized}")

    def mark_files_batch(self, completed_files: list[str], failed_files: list[str]) -> None:
        assert isinstance(self.enabled, bool), "enabled must be a boolean"
        if not self.enabled:
            return

        with self._state_lock:
            for file_path in completed_files:
                normalized = _normalize_file_path(file_path)
                if normalized:
                    self.completed_files.add(normalized)
                    self.failed_files.discard(normalized)

            for file_path in failed_files:
                normalized = _normalize_file_path(file_path)
                if normalized:
                    self.failed_files.add(normalized)
                    self.completed_files.discard(normalized)

            self._save_checkpoint()

    def filter_unprocessed_files(self, files: list[str]) -> list[str]:
        """
        Filter out files that have already been completed, include failed files for retry.

        This method implements the core resumability logic:
        - Completed files are excluded (already processed successfully)
        - Failed files are included for retry (will be reprocessed)
        - New files are included for processing

        Args:
            files: List of all files to be processed (can be empty or contain None/invalid paths)

        Returns:
            List of files that need processing (failed files + new files)
        """
        assert files is not None, "files parameter is required"
        assert isinstance(files, list), "files must be a list"
        if not self.enabled:
            # Return normalized files even if checkpointing is disabled
            # Return normalized files even if checkpointing is disabled
            return [n for f in files if (n := _normalize_file_path(f)) is not None]

        if not files:
            return []

                                                
        # Normalize and filter out invalid paths
        normalized_files = []
        for f in files:
            if not f:
                logger.warning("Skipping empty/None file path in filter_unprocessed_files")
                continue
            normalized = _normalize_file_path(f)
            if normalized:
                normalized_files.append(normalized)
            else:
                logger.warning(f"Skipping invalid file path: {f}")

        # Only exclude completed files - include failed files for retry
        # Only exclude completed files - include failed files for retry
        unprocessed = [f for f in normalized_files if not self.is_file_completed(f)]

                                                  
        # Remove duplicates while preserving order
        seen = set()
        result = []
        for f in unprocessed:
            if f not in seen:
                seen.add(f)
                result.append(f)
        unprocessed = result

        if len(unprocessed) != len(normalized_files):
            completed_count = len([f for f in normalized_files if self.is_file_completed(f)])
            failed_count = len([f for f in normalized_files if self.is_file_failed(f)])
            logger.info(
                f"🔄 RESUMABILITY: {len(unprocessed)}/{len(normalized_files)} files remaining to process"
            )
            logger.info(
                f"🔄 RESUMABILITY: {completed_count} files already completed, {failed_count} files failed (will retry)"
            )

        return unprocessed

    def get_resume_info(self) -> dict[str, Any]:
        """Get resume information."""
        assert isinstance(self.enabled, bool), "enabled must be a boolean"
        assert self.completed_files is not None, "completed_files must be initialized"
        return {
            "enabled": self.enabled,
            "completed_files": len(self.completed_files),
            "failed_files": len(self.failed_files),
            "can_resume": len(self.completed_files) > 0 or len(self.failed_files) > 0,
        }

    def log_checkpoint_summary(self, operation: str) -> None:
        """
        Log summary of checkpoint state changes.

        Args:
            operation: Description of the operation that triggered this summary
        """
        assert operation is not None, "operation parameter is required"
        assert isinstance(self.enabled, bool), "enabled must be a boolean"
        if not self.enabled:
            return

        completed_count = len(self.completed_files)
        failed_count = len(self.failed_files)

        logger.data(
            f"CHECKPOINT {operation} | Completed: {completed_count} | Failed: {failed_count}"
        )

    def _clear_checkpoint_only(self) -> None:
        """Clear checkpoint file without logging (internal use)."""
        assert self.checkpoint_path is not None, "checkpoint_path must be set"
        assert isinstance(self.enabled, bool), "enabled must be a boolean"
        if not self.enabled:
            return

        # Use file locking only for local filesystem
        # Use file locking only for local filesystem
        use_lock = isinstance(self.fs, type(get_default_filesystem()))
        lock_context = (
            FileLock(Path(self.checkpoint_path)) if use_lock else contextlib.nullcontext()
        )

        try:
            if self.fs.exists(self.checkpoint_path):
                with lock_context:
                    self.fs.rm(self.checkpoint_path)
                                                  
            # Also clean up temp file if it exists
            temp_path = self.checkpoint_path + ".tmp"
            if self.fs.exists(temp_path):
                with contextlib.suppress(OSError):
                    self.fs.rm(temp_path)
        except OSError as e:
            logger.error(f"Failed to clear checkpoint: {e}")

    def clear_checkpoint(self) -> None:
        """
        Clear all checkpoints.

        When checkpointing is disabled, this is a no-op and does not clear
        in-memory state. When enabled, clears both the checkpoint file and
        in-memory tracking (completed_files and failed_files).
        """
        assert self.checkpoint_path is not None, "checkpoint_path must be set"
        assert isinstance(self.enabled, bool), "enabled must be a boolean"
        if not self.enabled:
            # When disabled, checkpointing operations are no-ops
            # Don't clear in-memory state to match expected behavior
            return

        # Use file locking only for local filesystem
        # Use file locking only for local filesystem
        use_lock = isinstance(self.fs, type(get_default_filesystem()))
        lock_context = (
            FileLock(Path(self.checkpoint_path)) if use_lock else contextlib.nullcontext()
        )

        try:
            if self.fs.exists(self.checkpoint_path):
                with lock_context:
                    self.fs.rm(self.checkpoint_path)
                                                  
            # Also clean up temp file if it exists
            temp_path = self.checkpoint_path + ".tmp"
            if self.fs.exists(temp_path):
                with contextlib.suppress(OSError):
                    self.fs.rm(temp_path)

            self.completed_files.clear()
            self.failed_files.clear()
            logger.data("Checkpoint cleared successfully")
        except OSError as e:
            logger.error(f"Failed to clear checkpoint: {e}")
            # Still clear in-memory state even if file deletion fails
            # Still clear in-memory state even if file deletion fails
            self.completed_files.clear()
            self.failed_files.clear()
