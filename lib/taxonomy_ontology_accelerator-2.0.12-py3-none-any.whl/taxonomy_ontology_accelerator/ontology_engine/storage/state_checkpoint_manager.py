"""
State Checkpoint Manager for Resumable Pipeline Execution

Implements full ExtractionState persistence at key pipeline stages:
- Saves complete state (entities, embeddings, relationships) to JSON
- Enables resume from mid-pipeline failures (after expensive LLM extraction)
- Tracks checkpoint versions for compatibility
- Automatic cleanup of old checkpoints
"""

import contextlib
import gzip
import hashlib
import json
import time
import warnings
from pathlib import Path
from typing import Any

from fsspec import AbstractFileSystem
from fsspec.implementations.local import LocalFileSystem

from taxonomy_ontology_accelerator.commons.io.fsspec_utils import get_default_filesystem
from taxonomy_ontology_accelerator.commons.utils.logger import get_logger
from taxonomy_ontology_accelerator.ontology_engine.core.extraction_pipeline import (
    ExtractionState,
)
from taxonomy_ontology_accelerator.ontology_engine.storage.file_locking import FileLock

logger = get_logger()

# Version identifier for state checkpoint format
CHECKPOINT_VERSION = "1.0"

# Minimum parts required in checkpoint filename (stage and timestamp)
MIN_FILENAME_PARTS = 2


def _compute_checksum(state_dict: dict) -> str:
    """
    Compute SHA256 checksum of state data.

    Args:
        state_dict: State dictionary to compute checksum for

    Returns:
        SHA256 checksum hex string
    """
    assert state_dict is not None, "state_dict must not be None"
    assert isinstance(state_dict, dict), "state_dict must be a dict"
    state_json = json.dumps(state_dict, sort_keys=True)
    return hashlib.sha256(state_json.encode()).hexdigest()


def _get_checkpoint_filename(stage: str) -> str:
    """Generate checkpoint filename for a stage with gzip compression."""
    assert stage is not None, "stage must not be None"
    assert isinstance(stage, str), "stage must be a string"
    timestamp = int(time.time() * 1000)  # Use milliseconds for uniqueness
    return f"state_checkpoint_{stage}_{timestamp}.json.gz"


def _parse_checkpoint_filename(filename: str) -> tuple[str, int] | None:
    """
    Parse checkpoint filename to extract stage and timestamp.

    Supports both compressed (.json.gz) and uncompressed (.json) formats
    for backward compatibility.
    """
    assert filename is not None, "filename must not be None"
    assert isinstance(filename, str), "filename must be a string"

    if not filename.startswith("state_checkpoint_"):
        return None

    # Support both .json.gz (new) and .json (old) formats
    if filename.endswith(".json.gz"):
        base = filename[17:-8]  # Remove "state_checkpoint_" prefix and ".json.gz" suffix
    elif filename.endswith(".json"):
        base = filename[17:-5]  # Remove "state_checkpoint_" prefix and ".json" suffix
    else:
        return None

    parts = base.split("_")
    if len(parts) < MIN_FILENAME_PARTS:
        return None

    try:
        timestamp = int(parts[-1])
        stage = "_".join(parts[:-1])
        return stage, timestamp
    except ValueError:
        return None


class StateCheckpointManager:
    """
    Manager for full ExtractionState persistence at pipeline stages.

    Saves complete state (entities, embeddings, relationships, etc.) to enable
    resuming from mid-pipeline failures, especially after expensive LLM extraction.
    """

    def __init__(
        self,
        output_dir: Path | str,
        enabled: bool = False,
        checkpoint_stages: list[str] | None = None,
        max_checkpoints: int = 3,
        fs: AbstractFileSystem | None = None,
    ):
        """
        Initialize state checkpoint manager.

        Args:
            output_dir: Output directory for ontology extraction
            enabled: Enable/disable state persistence (opt-in)
            checkpoint_stages: Which stages to checkpoint (default: all)
            max_checkpoints: Maximum checkpoints to keep per stage
            fs: Optional filesystem instance (defaults to local)
        """
        assert output_dir is not None, "output_dir must not be None"
        assert isinstance(enabled, bool), "enabled must be a boolean"

        self.enabled = enabled
        self.fs = fs if fs is not None else get_default_filesystem()
        self.output_dir = str(output_dir)
        self.checkpoint_dir = f"{self.output_dir}/checkpoints"
        self.checkpoint_stages = set(checkpoint_stages or [])
        self.max_checkpoints = max_checkpoints

        if self.enabled:
            self.fs.makedirs(self.checkpoint_dir, exist_ok=True)
            logger.debug(f"State checkpoint manager initialized (stages: {self.checkpoint_stages})")

    def should_checkpoint_stage(self, stage: str) -> bool:
        """Check if a stage should be checkpointed."""
        assert stage is not None, "stage must not be None"
        assert isinstance(stage, str), "stage must be a string"

        if not self.enabled:
            return False
        return not self.checkpoint_stages or stage in self.checkpoint_stages

    def _validate_checkpoint_data(
        self,
        checkpoint_data: dict,
        expected_domain: str | None = None,
    ) -> tuple[bool, str]:
        """
        Validate checkpoint integrity.

        Args:
            checkpoint_data: Checkpoint data dictionary
            expected_domain: Expected domain name (optional)

        Returns:
            Tuple of (is_valid, error_message)
        """
        assert checkpoint_data is not None, "checkpoint_data must not be None"
        assert isinstance(checkpoint_data, dict), "checkpoint_data must be a dict"

        # 1. Version check
        version = checkpoint_data.get("version")
        if version != CHECKPOINT_VERSION:
            return False, f"Version mismatch: expected {CHECKPOINT_VERSION}, got {version}"

        # 2. Domain matching
        if expected_domain:
            actual_domain = checkpoint_data.get("domain")
            if actual_domain != expected_domain:
                return (
                    False,
                    f"Domain mismatch: expected {expected_domain}, got {actual_domain}",
                )

        # 3. Structure validation
        state_dict = checkpoint_data.get("state")
        if not state_dict or not isinstance(state_dict, dict):
            return False, "Invalid state structure: missing or invalid state field"

        # 4. Checksum validation
        stored_checksum = checkpoint_data.get("checksum")
        if stored_checksum:
            computed = _compute_checksum(state_dict)
            if stored_checksum != computed:
                return False, "Checksum mismatch: data may be corrupted"

        return True, ""

    def save_state_checkpoint(self, state: ExtractionState, stage: str) -> None:
        """
        Save ExtractionState to checkpoint file.

        Args:
            state: ExtractionState to save
            stage: Pipeline stage name (e.g., "extraction", "deduplication")
        """
        assert state is not None, "state must not be None"
        assert stage is not None, "stage must not be None"

        if not self.enabled or not self.should_checkpoint_stage(stage):
            return

        try:
            checkpoint_path = f"{self.checkpoint_dir}/{_get_checkpoint_filename(stage)}"

            # Serialize state with metadata
            # Fields excluded via Field(exclude=True) metadata in ExtractionState
            state_dict = state.model_dump(
                mode="json",
                exclude_none=False,
            )

            checkpoint_data = {
                "version": CHECKPOINT_VERSION,
                "stage": stage,
                "timestamp": time.time(),
                "domain": state.domain,
                "checksum": _compute_checksum(state_dict),
                "state": state_dict,
            }

            # Write atomically with gzip compression
            temp_path = checkpoint_path + ".tmp"
            use_lock = isinstance(self.fs, LocalFileSystem)
            lock_context = FileLock(Path(checkpoint_path)) if use_lock else contextlib.nullcontext()

            with lock_context:
                json_str = json.dumps(checkpoint_data, indent=2)
                compressed_bytes: bytes = gzip.compress(json_str.encode("utf-8"))
                with self.fs.open(temp_path, "wb") as f:
                    bytes_written: int = f.write(compressed_bytes)  # type: ignore[assignment]
                    assert bytes_written > 0, "Failed to write checkpoint data"
                self.fs.mv(temp_path, checkpoint_path, overwrite=True)

            logger.info(f"💾 Saved state checkpoint: {stage}")

            # Cleanup old checkpoints
            self._cleanup_old_checkpoints(stage)

        except Exception as e:
            logger.warning(f"Failed to save state checkpoint for {stage}: {e}")

    def _load_checkpoint_data(self, checkpoint_path: str) -> dict[str, Any] | None:
        """Load and decompress checkpoint data from file."""
        assert checkpoint_path is not None, "checkpoint_path must not be None"
        assert isinstance(checkpoint_path, str), "checkpoint_path must be a string"

        use_lock = isinstance(self.fs, LocalFileSystem)
        lock_context = FileLock(Path(checkpoint_path)) if use_lock else contextlib.nullcontext()

        with lock_context:
            # Support both compressed (.json.gz) and uncompressed (.json) formats
            if checkpoint_path.endswith(".gz"):
                with self.fs.open(checkpoint_path, "rb") as f:
                    data = f.read()
                    assert isinstance(data, bytes), "Expected bytes from binary file read"
                    compressed_bytes: bytes = data
                    json_bytes: bytes = gzip.decompress(compressed_bytes)
                    json_str = json_bytes.decode("utf-8")
                    return json.loads(json_str)
            else:
                # Backward compatibility: uncompressed .json files (deprecated)
                warnings.warn(
                    f"Loading uncompressed checkpoint format (.json) from {Path(checkpoint_path).name}. "
                    "This format is deprecated and will be removed in v3.0. "
                    "Future checkpoints will use compressed format (.json.gz).",
                    DeprecationWarning,
                    stacklevel=2,
                )
                with self.fs.open(checkpoint_path, "r", encoding="utf-8") as f:
                    return json.load(f)

    def _restore_state_from_data(
        self, checkpoint_data: dict[str, Any], stage: str
    ) -> ExtractionState | None:
        """Restore ExtractionState from checkpoint data."""
        assert checkpoint_data is not None, "checkpoint_data must not be None"
        assert stage is not None, "stage must not be None"

        state_dict = checkpoint_data.get("state")
        if not state_dict:
            logger.warning(f"Invalid checkpoint data for {stage}")
            return None

        state = ExtractionState(**state_dict)
        logger.success(f"🔄 Restored state checkpoint: {stage}")
        return state

    def load_state_checkpoint(
        self, stage: str, domain: str | None = None
    ) -> ExtractionState | None:
        """
        Load most recent state checkpoint for a stage.

        Args:
            stage: Pipeline stage name
            domain: Expected domain name for validation (optional)

        Returns:
            ExtractionState if checkpoint exists and valid, None otherwise
        """
        assert stage is not None, "stage must not be None"
        assert isinstance(stage, str), "stage must be a string"

        if not self.enabled:
            return None

        checkpoint_path = self._get_latest_checkpoint_path(stage)
        if not checkpoint_path:
            return None

        try:
            checkpoint_data = self._load_checkpoint_data(checkpoint_path)
            if not checkpoint_data:
                return None

            # Validate checkpoint
            is_valid, error = self._validate_checkpoint_data(checkpoint_data, domain)
            if not is_valid:
                logger.warning(f"Checkpoint validation failed: {error}. Starting fresh extraction.")
                return None

            return self._restore_state_from_data(checkpoint_data, stage)

        except Exception as e:
            logger.warning(f"Failed to load state checkpoint for {stage}: {e}")
            return None

    def _list_checkpoints_for_stage(self, stage: str | None = None) -> list[tuple[str, int, str]]:
        """
        List checkpoints, optionally filtered by stage.

        Args:
            stage: Optional stage name to filter by. If None, returns all checkpoints.

        Returns:
            List of (file_path, timestamp, stage) tuples sorted by timestamp (newest first)
        """
        assert self.checkpoint_dir is not None, "checkpoint_dir must be set"
        assert stage is None or isinstance(stage, str), "stage must be None or a string"

        if not self.fs.exists(self.checkpoint_dir):
            return []

        try:
            files = self.fs.ls(self.checkpoint_dir, detail=False)
            checkpoints = []

            for file_path in files:
                filename = Path(file_path).name
                parsed = _parse_checkpoint_filename(filename)
                if parsed:
                    parsed_stage, timestamp = parsed
                    if stage is None or parsed_stage == stage:
                        checkpoints.append((file_path, timestamp, parsed_stage))

            # Sort by timestamp (newest first)
            checkpoints.sort(key=lambda x: x[1], reverse=True)
            return checkpoints

        except Exception as e:
            logger.warning(f"Failed to list checkpoints: {e}")
            return []

    def get_latest_checkpoint_info(self) -> dict[str, Any] | None:
        """
        Get information about the most recent checkpoint across all stages.

        Returns:
            Dict with stage, timestamp, and path, or None if no checkpoints exist
        """
        assert self.checkpoint_dir is not None, "checkpoint_dir must be set"
        assert isinstance(self.enabled, bool), "enabled must be a boolean"

        if not self.enabled:
            return None

        checkpoints = self._list_checkpoints_for_stage(stage=None)
        if not checkpoints:
            return None

        latest = checkpoints[0]  # Already sorted newest first
        return {
            "stage": latest[2],
            "timestamp": latest[1],
            "path": latest[0],
        }

    def _get_latest_checkpoint_path(self, stage: str) -> str | None:
        """Get path to most recent checkpoint for a stage."""
        assert stage is not None, "stage must not be None"
        assert isinstance(stage, str), "stage must be a string"

        checkpoints = self._list_checkpoints_for_stage(stage)
        if not checkpoints:
            return None

        return checkpoints[0][0]  # Return path of newest checkpoint

    def _cleanup_old_checkpoints(self, stage: str) -> None:
        """Remove old checkpoints for a stage, keeping only max_checkpoints."""
        assert stage is not None, "stage must not be None"
        assert isinstance(stage, str), "stage must be a string"

        checkpoints = self._list_checkpoints_for_stage(stage)
        if len(checkpoints) <= self.max_checkpoints:
            return

        # Remove excess old checkpoints (keep max_checkpoints newest)
        to_remove = checkpoints[self.max_checkpoints :]

        for file_path, _, _ in to_remove:
            try:
                self.fs.rm(file_path)
                logger.debug(f"Removed old checkpoint: {Path(file_path).name}")
            except OSError as e:
                logger.warning(f"Failed to remove checkpoint {Path(file_path).name}: {e}")

    def clear_all_checkpoints(self) -> None:
        """Remove all state checkpoints."""
        assert self.checkpoint_dir is not None, "checkpoint_dir must be set"
        assert isinstance(self.enabled, bool), "enabled must be a boolean"

        if not self.enabled or not self.fs.exists(self.checkpoint_dir):
            return

        try:
            checkpoints = self._list_checkpoints_for_stage(stage=None)

            for file_path, _, _ in checkpoints:
                try:
                    self.fs.rm(file_path)
                except OSError as e:
                    logger.warning(f"Failed to remove checkpoint {Path(file_path).name}: {e}")

            logger.data("Cleared all state checkpoints")

        except Exception as e:
            logger.error(f"Failed to clear state checkpoints: {e}")
