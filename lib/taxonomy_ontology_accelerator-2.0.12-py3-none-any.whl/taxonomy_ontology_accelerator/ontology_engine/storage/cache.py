"""
Caching utilities for ontology engine.

Implements LRU (Least Recently Used) eviction for LLM response cache
to improve cache hit rates for frequently used prompts.

Thread-safe: All cache operations are protected by locks to ensure
safe concurrent access in multi-threaded/async environments.
"""

import hashlib
import json
import threading
import time
from collections.abc import Callable
from pathlib import Path
from typing import Any

from taxonomy_ontology_accelerator.commons.utils.logger import get_logger

logger = get_logger()


# ========================================================================
# Module-level Caches (Thread-safe)
# ========================================================================

# Thread locks for cache operations
_prompt_cache_lock = threading.Lock()
_llm_cache_lock = threading.Lock()

_prompt_cache: tuple[str, float] | None = None
# LLM cache with LRU eviction: dict[key] = (response, access_time)
# Access time used for LRU eviction (most recently used items kept)
# Order list maintains LRU order (oldest first) for efficient eviction
_llm_cache: dict[str, tuple[Any, float]] = {}  # pyright: ignore[reportExplicitAny]
_llm_cache_order: list[str] = []  # Maintains access order (oldest first) for LRU eviction
_llm_cache_size_bytes: int = 0


# ========================================================================
# File Utilities
# ========================================================================


def get_file_mtime(file_path: str | Path, fs=None) -> float:
    """
    Get file modification time.

    Args:
        file_path: Path to file
        fs: Optional filesystem instance (defaults to local filesystem)

    Returns:
        Modification time as float (0.0 if file doesn't exist)
    """
    assert file_path is not None, "File path must not be None"
    assert isinstance(file_path, str | Path), "File path must be a string or Path object"

    from taxonomy_ontology_accelerator.commons.io.fsspec_utils import get_default_filesystem

    if fs is None:
        fs = get_default_filesystem()

    file_path_str = str(file_path)

    try:
        info = fs.info(file_path_str)
        return info.get("mtime", 0.0)
    except OSError:
        return 0.0


# ========================================================================
# Prompt Caching
# ========================================================================


def get_prompt_cached(prompt_path: str | Path, loader_func: Callable[[], str], fs=None) -> str:
    """
    Load prompt with caching based on file modification time.

    Thread-safe: Uses lock to protect cache access.

    Args:
        prompt_path: Path to prompt file
        loader_func: Function to load prompt (PromptLoader.load_prompt)
        fs: Optional filesystem instance (defaults to local filesystem)

    Returns:
        Cached or freshly loaded prompt string
    """
    assert prompt_path is not None, "Prompt path must not be None"
    assert loader_func is not None, "Loader function must not be None"

    global _prompt_cache

    current_mtime = get_file_mtime(prompt_path, fs=fs)  # Get current file modification time

    # Double-checked locking pattern to avoid race condition
    # First check (fast path - outside lock for performance)
    if _prompt_cache is not None:
        cached_prompt, cached_mtime = _prompt_cache
        if cached_mtime == current_mtime:  # File unchanged, use cache
            logger.debug(f"Using cached prompt from {prompt_path}")
            return cached_prompt

    # Second check and load (inside lock) - prevents duplicate loads
    with _prompt_cache_lock:  # Thread-safe cache access
        # Re-check cache and mtime (another thread may have loaded it)
        current_mtime = get_file_mtime(prompt_path, fs=fs)  # Re-check mtime inside lock
        if _prompt_cache is not None:
            cached_prompt, cached_mtime = _prompt_cache
            if cached_mtime == current_mtime:  # Another thread loaded it
                logger.debug(f"Using prompt loaded by another thread from {prompt_path}")
                return cached_prompt

        # Need to load prompt (inside lock to prevent duplicate loads)
        # Prompt loading is fast, so loading inside lock is acceptable
        # and happens infrequently (only on file modification)
        prompt = loader_func()  # Load prompt from file

        # Update cache (inside lock)
        _prompt_cache = (prompt, current_mtime)  # Update cache with new prompt and mtime
        return prompt


# ========================================================================
# LLM Response Caching
# ========================================================================


def get_llm_cache_key(prompt: str) -> str:
    """
    Generate cache key for LLM prompt.

    Args:
        prompt: LLM prompt text

    Returns:
        Cache key (hex digest)
    """
    assert prompt is not None, "Prompt must not be None"
    assert isinstance(prompt, str), "Prompt must be a string"

    return hashlib.md5(prompt.encode()).hexdigest()


def get_cached_llm_response(prompt: str) -> Any | None:  # pyright: ignore[reportExplicitAny]
    """
    Get cached LLM response if available.

    Updates access time and order for LRU eviction (most recently used items kept).
    Thread-safe: Uses lock to protect cache access.

    Args:
        prompt: LLM prompt text

    Returns:
        Cached response or None if not found
    """
    assert prompt is not None, "Prompt must not be None"
    assert isinstance(prompt, str), "Prompt must be a string"

    global _llm_cache_order

    cache_key = get_llm_cache_key(prompt)

    with _llm_cache_lock:  # Thread-safe cache access
        cached_entry = _llm_cache.get(cache_key)
        if cached_entry is not None:
            # Update access time and move to end (mark as recently used)
            response, _ = cached_entry
            _llm_cache[cache_key] = (response, time.time())
            # Move to end of order list (most recently used)
            if cache_key in _llm_cache_order:
                _llm_cache_order.remove(cache_key)
            _llm_cache_order.append(cache_key)
            return response
        return None


def get_cached_response(prompt: str) -> Any | None:  # pyright: ignore[reportExplicitAny]
    """Backward-compatible alias for get_cached_llm_response."""
    return get_cached_llm_response(prompt)


def _calculate_entry_size(cache_key: str, response: Any) -> int:  # pyright: ignore[reportExplicitAny]
    """Calculate size of cache entry in bytes."""
    assert cache_key is not None, "Cache key must not be None"
    assert isinstance(cache_key, str), "Cache key must be a string"

    try:
        response_bytes = len(json.dumps(response, default=str).encode("utf-8"))
        return len(cache_key) + response_bytes
    except Exception as e:
        logger.debug(f"Failed to calculate response size: {e}. Using fallback size.")
        return 1024  # Fallback size (1KB estimate)


def _initialize_cache_size() -> int:
    """Calculate total cache size from existing entries."""
    assert isinstance(_llm_cache, dict), "LLM cache must be a dict"
    assert isinstance(_llm_cache_order, list), "LLM cache order must be a list"

    if len(_llm_cache) == 0:
        return 0

    total_size = 0
    for key, (value, _) in _llm_cache.items():
        total_size += _calculate_entry_size(key, value)
    return total_size


def _evict_lru_entries(max_size_bytes: int, new_entry_size: int) -> None:
    """Evict least recently used entries to make space."""
    global _llm_cache_size_bytes, _llm_cache_order

    assert max_size_bytes > 0, "Max size must be positive"
    assert new_entry_size >= 0, "New entry size must be non-negative"
    assert isinstance(_llm_cache_order, list), "LLM cache order must be a list"

    while _llm_cache_size_bytes + new_entry_size > max_size_bytes and _llm_cache_order:
        eviction_count = max(1, len(_llm_cache_order) // 10)
        keys_to_remove = _llm_cache_order[:eviction_count]

        for key in keys_to_remove:
            removed_value, _ = _llm_cache.get(key, (None, None))
            if removed_value is not None:
                removed_size = _calculate_entry_size(key, removed_value)
            else:
                removed_size = 1024

            _llm_cache_size_bytes = max(0, _llm_cache_size_bytes - removed_size)
            _ = _llm_cache.pop(key, None)

        # O(n) optimization: rebuild list once instead of calling remove() in loop
        keys_to_remove_set = set(keys_to_remove)
        _llm_cache_order = [k for k in _llm_cache_order if k not in keys_to_remove_set]

        estimated_size_mb = _llm_cache_size_bytes / (1024 * 1024)
        evict_msg = (
            f"LLM cache size limit reached, evicted {len(keys_to_remove)} LRU entries "
            f"(estimated {estimated_size_mb:.2f}MB remaining)"
        )
        logger.debug(evict_msg)


def cache_llm_response(
    prompt: str,
    response: Any,  # pyright: ignore[reportExplicitAny]
    max_cache_size_mb: int | None = None,
) -> None:
    """
    Cache LLM response with LRU eviction.

    Uses Least Recently Used (LRU) eviction strategy: when cache is full,
    removes least recently accessed items first, keeping frequently used prompts.
    Thread-safe: Uses lock to protect cache access.

    Args:
        prompt: LLM prompt text
        response: LLM response to cache
        max_cache_size_mb: Maximum cache size in MB (None = no limit)
    """
    assert prompt is not None, "Prompt must not be None"
    assert isinstance(prompt, str), "Prompt must be a string"

    global _llm_cache_size_bytes, _llm_cache_order

    cache_key = get_llm_cache_key(prompt)
    current_time = time.time()
    new_entry_size = _calculate_entry_size(cache_key, response)

    with _llm_cache_lock:
        if max_cache_size_mb is not None:
            max_size_bytes = max_cache_size_mb * 1024 * 1024

            if _llm_cache_size_bytes == 0 and len(_llm_cache) > 0:
                _llm_cache_size_bytes = _initialize_cache_size()

            _evict_lru_entries(max_size_bytes, new_entry_size)

        if cache_key in _llm_cache_order:
            _llm_cache_order.remove(cache_key)

        _llm_cache[cache_key] = (response, current_time)
        _llm_cache_order.append(cache_key)
        _llm_cache_size_bytes += new_entry_size
        logger.debug(f"Cached LLM response for prompt (key: {cache_key[:8]}...)")


def cache_response(
    prompt: str,
    response: Any,  # pyright: ignore[reportExplicitAny]
    max_cache_size_mb: int | None = None,
) -> None:
    """Backward-compatible alias for cache_llm_response."""
    cache_llm_response(prompt, response, max_cache_size_mb=max_cache_size_mb)


# ========================================================================
# Cache Management
# ========================================================================


def clear_caches() -> None:
    """
    Clear all caches (useful for testing or memory management).

    Resets all module-level caches including prompt and LLM response caches.
    Thread-safe: Uses locks to protect cache access.
    """
    global _prompt_cache, _llm_cache, _llm_cache_order, _llm_cache_size_bytes
    assert isinstance(_llm_cache, dict), "_llm_cache must be a dict"
    assert isinstance(_llm_cache_order, list), "_llm_cache_order must be a list"

    assert isinstance(_llm_cache, dict), "LLM cache must be a dict"

    with _prompt_cache_lock:
        _prompt_cache = None

    with _llm_cache_lock:
        _llm_cache.clear()
        _llm_cache_order.clear()
        _llm_cache_size_bytes = 0

    logger.debug("All caches cleared")
