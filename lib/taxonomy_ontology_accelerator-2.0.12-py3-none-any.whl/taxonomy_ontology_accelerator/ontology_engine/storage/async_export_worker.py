"""
Detached OWL/RDF export worker.

Loads a local job payload, exports Turtle/RDF from saved schema+graph snapshots,
and updates the run-local export status artifact as work progresses.
"""

import json
import shutil
import sys
import time
from pathlib import Path

from taxonomy_ontology_accelerator.commons.io.file_utils import safe_write_json
from taxonomy_ontology_accelerator.commons.io.fsspec_utils import (
    get_default_filesystem,
    get_filesystem_from_config,
)
from taxonomy_ontology_accelerator.commons.utils.logger import get_logger
from taxonomy_ontology_accelerator.ontology_engine.config.config import OntologyConfig
from taxonomy_ontology_accelerator.ontology_engine.storage.export import export_to_owl_rdf
from taxonomy_ontology_accelerator.ontology_engine.utils.id_generation import (
    get_current_timestamp,
)

logger = get_logger()

_CLOUD_PROTOCOLS = ("s3", "gs", "gcs", "az", "hdfs")


def _resolve_output_filesystem(output_path: str, config: OntologyConfig):
    """Resolve the filesystem for the final export artifact."""
    for protocol in _CLOUD_PROTOCOLS:
        if output_path.startswith(f"{protocol}://") or output_path.startswith(f"{protocol}::"):
            if getattr(config.filesystem, "protocol", "local") == protocol:
                return get_filesystem_from_config(protocol, config.filesystem.options or {})
            return get_filesystem_from_config(protocol, {})
    return get_default_filesystem()


def _write_status(status_path: str, fs, payload: dict[str, object]) -> None:
    """Best-effort status writer for async export jobs."""
    try:
        safe_write_json(status_path, payload, fs=fs, pretty=True)
    except Exception as status_error:
        logger.warning(f"[OWL Export] Failed to update async export status: {status_error}")


def run_export_job(job_path: Path) -> int:
    """Execute a queued OWL/RDF export job from a JSON payload."""
    job = json.loads(job_path.read_text(encoding="utf-8"))
    config = OntologyConfig.model_validate(job["ontology_config"])
    output_path = str(job["output_path"])
    status_path = str(job["status_path"])
    output_fs = _resolve_output_filesystem(output_path, config)
    export_metrics: dict[str, float] = {}
    working_dir = Path(str(job["working_dir"]))

    _write_status(
        status_path,
        output_fs,
        {
            "status": "running",
            "mode": "async",
            "format": job["format"],
            "output_path": output_path,
            "schema_path": str(job["schema_path"]),
            "graph_path": str(job["graph_path"]),
            "queued_at": job.get("queued_at"),
            "started_at": get_current_timestamp(config),
        },
    )

    try:
        started = time.perf_counter()
        export_to_owl_rdf(
            schema=Path(str(job["schema_snapshot"])),
            graph=Path(str(job["graph_snapshot"])),
            output_path=output_path,
            format=str(job["format"]),
            export_config=config.output.export,
            fs=output_fs,
            ontology_config=config,
            export_metrics=export_metrics,
        )
        total_seconds = time.perf_counter() - started
        _write_status(
            status_path,
            output_fs,
            {
                "status": "completed",
                "mode": "async",
                "format": job["format"],
                "output_path": output_path,
                "schema_path": str(job["schema_path"]),
                "graph_path": str(job["graph_path"]),
                "queued_at": job.get("queued_at"),
                "completed_at": get_current_timestamp(config),
                "timings": export_metrics,
                "total_seconds": total_seconds,
            },
        )
        return 0
    except Exception as export_error:
        logger.error(f"[OWL Export] Async export worker failed: {export_error}", exc_info=True)
        _write_status(
            status_path,
            output_fs,
            {
                "status": "failed",
                "mode": "async",
                "format": job["format"],
                "output_path": output_path,
                "schema_path": str(job["schema_path"]),
                "graph_path": str(job["graph_path"]),
                "queued_at": job.get("queued_at"),
                "failed_at": get_current_timestamp(config),
                "error": str(export_error),
            },
        )
        return 1
    finally:
        shutil.rmtree(working_dir, ignore_errors=True)


def main(argv: list[str]) -> int:
    """Command-line entrypoint for async OWL/RDF export jobs."""
    if len(argv) != 1:
        print("Usage: python -m taxonomy_ontology_accelerator.ontology_engine.storage.async_export_worker <job.json>")
        return 2
    return run_export_job(Path(argv[0]))


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
