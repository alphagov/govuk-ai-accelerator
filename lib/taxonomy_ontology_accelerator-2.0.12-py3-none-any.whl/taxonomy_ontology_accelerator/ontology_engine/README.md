# 🔮 Ontology Engine

> **AI-powered knowledge graph extraction from unstructured text**

The Ontology Engine extracts entities, relationships, and semantic structures from text documents to build comprehensive knowledge graphs (ontologies). It uses Large Language Models (LLMs) for intelligent extraction and supports incremental updates, deduplication, and OWL/RDF export.

---

## 📖 Overview

### What does this engine do?

The Ontology Engine transforms unstructured text into structured knowledge graphs by:

1. **Extracting Entities**: Identifying people, places, concepts, organizations, and other named entities
2. **Building Relationships**: Discovering how entities relate to each other
3. **Creating Schemas**: Automatically generating type definitions for entities and relationships
4. **Deduplicating**: Merging duplicate entities using exact and semantic matching
5. **Evolving**: Incrementally updating existing ontologies with new information

### Why does this engine exist?

Manual ontology creation is:

- **Time-consuming**: Subject matter experts spend weeks building ontologies
- **Error-prone**: Human inconsistencies lead to quality issues
- **Difficult to scale**: Hard to process thousands of documents manually

The Ontology Engine automates this process while maintaining high quality through LLM-powered extraction and validation.

---

## 🎯 Responsibilities

### Inputs

| Input Type | Description | Format |
|------------|-------------|--------|
| **Input Files** | Documents to process (required) | `.txt`, `.md`, `.json`, `.html`, `.xml`, `.yaml` |
| **Domain Prompt** | Domain-specific extraction instructions | Text file |
| **Configuration** | Engine settings | YAML config files |
| **Existing Ontology** | Previous graph for incremental updates | JSON files |

### Outputs

| Output Type | Description | Format |
|-------------|-------------|--------|
| **Schema** | Type definitions for entities and relationships | `schema.json` |
| **Graph** | Entities and relationships | `graph.json` |
| **Embeddings** | Semantic vectors for deduplication | `embeddings.json` |
| **OWL/RDF Export** | Standard ontology format | `.owl` or `.ttl` |

### Key Capabilities

- ✅ Multi-file batch processing
- ✅ Incremental ontology updates
- ✅ Exact + semantic deduplication
- ✅ Schema evolution (auto-creates new types)
- ✅ Conflict resolution for contradictory relationships
- ✅ Checkpoint/resume for large jobs
- ✅ OWL/RDF export for interoperability
- ✅ Configurable LLM providers (Anthropic, OpenAI, Google Gemini, and more)
- ✅ Source grounding (tracks which source file each entity/relationship came from)

---

## 🏗️ Architecture & Flow

### Processing Pipeline

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         ONTOLOGY EXTRACTION PIPELINE                    │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  INPUT                                                                  │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐                     │
│  │ Text Files  │  │   Domain    │  │   Config    │                     │
│  │ (.txt, .md) │  │   Prompt    │  │   (.yaml)   │                     │
│  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘                     │
│         │                │                │                             │
│         ▼                ▼                ▼                             │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │ STAGE 1: Load & Validate                                        │   │
│  │ • Load configuration                                            │   │
│  │ • Validate inputs                                               │   │
│  │ • Load existing ontology (if incremental)                       │   │
│  └──────────────────────────────┬──────────────────────────────────┘   │
│                                 │                                       │
│                                 ▼                                       │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │ STAGE 2: Text Chunking                                          │   │
│  │ • Split large documents into processable chunks                 │   │
│  │ • Respect token limits for LLM calls                           │   │
│  └──────────────────────────────┬──────────────────────────────────┘   │
│                                 │                                       │
│                                 ▼                                       │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │ STAGE 3: LLM Extraction                                         │   │
│  │ • Send chunks to LLM with extraction prompt                     │   │
│  │ • Parse structured output (entities + relationships)            │   │
│  │ • Batch processing with retries                                 │   │
│  └──────────────────────────────┬──────────────────────────────────┘   │
│                                 │                                       │
│                                 ▼                                       │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │ STAGE 4: Deduplication                                          │   │
│  │ • Exact match deduplication (same label)                        │   │
│  │ • Semantic deduplication (embedding similarity)                 │   │
│  │ • Merge entities, preserve metadata                             │   │
│  └──────────────────────────────┬──────────────────────────────────┘   │
│                                 │                                       │
│                                 ▼                                       │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │ STAGE 5: Relationship Building                                   │   │
│  │ • Validate entity references                                    │   │
│  │ • Build relationship objects                                    │   │
│  │ • Resolve conflicts                                             │   │
│  └──────────────────────────────┬──────────────────────────────────┘   │
│                                 │                                       │
│                                 ▼                                       │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │ STAGE 6: Schema Evolution                                       │   │
│  │ • Create new entity types if needed                             │   │
│  │ • Create new relationship types if needed                       │   │
│  │ • Version schema                                                │   │
│  └──────────────────────────────┬──────────────────────────────────┘   │
│                                 │                                       │
│                                 ▼                                       │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │ STAGE 7: Merge & Export                                         │   │
│  │ • Merge with existing ontology (if incremental)                │   │
│  │ • Validate final graph                                          │   │
│  │ • Save schema.json, graph.json                                  │   │
│  │ • Export OWL/RDF (if enabled)                                   │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
│  OUTPUT                                                                 │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐   │
│  │ schema.json │  │ graph.json  │  │ embeddings  │  │  .owl/.ttl  │   │
│  │ (types)     │  │ (entities)  │  │   .json     │  │  (export)   │   │
│  └─────────────┘  └─────────────┘  └─────────────┘  └─────────────┘   │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

### Module Structure

```
ontology_engine/
├── __init__.py              # Public API exports
├── cli.py                   # Command-line interface (Typer)
├── cli_helpers.py           # CLI helper functions
├── config/
│   └── config.py            # Configuration loader
├── core/
│   ├── extractor.py         # Main extraction pipeline (entry point)
│   ├── llm_processor.py     # LLM batch processing
│   └── models.py            # Pydantic data models
├── processing/
│   ├── conflict_resolution.py   # Relationship conflict handling
│   ├── embeddings.py            # Embedding generation & similarity
│   ├── entity_processor.py      # Entity normalization & deduplication
│   ├── merge_validator.py       # Post-merge validation
│   ├── relationship_builder.py  # Relationship construction
│   ├── schema_evolver.py        # Schema type evolution
│   ├── text_processor.py        # Text chunking
│   └── validation.py            # Ontology validation
├── storage/
│   ├── cache.py                 # LLM response caching
│   ├── checkpoint_manager.py    # Resume support
│   ├── data_loader.py           # Load existing ontologies
│   ├── export.py                # OWL/RDF export
│   ├── file_locking.py          # Concurrent access protection
│   └── prompt_loader.py         # Prompt file loading
└── utils/
    ├── batch_optimizer.py       # Batch size optimization
    ├── id_generation.py         # Entity/relationship IDs
    ├── text_normalization.py    # Text cleaning
    └── versioning.py            # Schema versioning
```

### Interaction with Other Components

```
┌─────────────────────────────────────────────────────────────────────┐
│                     ONTOLOGY ENGINE INTERACTIONS                    │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ┌─────────────────┐                    ┌─────────────────┐        │
│  │  INPUT SOURCES  │                    │ EXTERNAL APIs   │        │
│  │  • Text files   │                    │ • Anthropic LLM │        │
│  │  • Config YAML  │                    │ • Google AI     │        │
│  │  • Prompts      │                    │   (embeddings)  │        │
│  └────────┬────────┘                    └────────┬────────┘        │
│           │                                      │                  │
│           ▼                                      ▼                  │
│  ┌────────────────────────────────────────────────────────────┐    │
│  │                    ONTOLOGY ENGINE                         │    │
│  │                                                            │    │
│  │  extract_ontology() ──────────────────────────────────┐   │    │
│  │       │                                               │   │    │
│  │       ▼                                               │   │    │
│  │  ┌──────────────┐  ┌──────────────┐  ┌────────────┐  │   │    │
│  │  │   Commons    │  │   Storage    │  │ Processing │  │   │    │
│  │  │  • Logging   │  │  • Caching   │  │ • Entities │  │   │    │
│  │  │  • Errors    │  │  • Export    │  │ • Relations│  │   │    │
│  │  │  • File I/O  │  │  • Locking   │  │ • Schema   │  │   │    │
│  │  └──────────────┘  └──────────────┘  └────────────┘  │   │    │
│  │                                                       │   │    │
│  └───────────────────────────────────────────────────────┘   │    │
│                              │                                │    │
│                              ▼                                │    │
│  ┌─────────────────────────────────────────────────────┐     │    │
│  │                    OUTPUTS                          │     │    │
│  │  • graph.json → Ontology Visualization UI           │     │    │
│  │  • schema.json → Schema comparison tools            │     │    │
│  │  • .owl/.ttl → External ontology tools (Protégé)    │     │    │
│  │  • Neo4j upload (via scripts/upload_to_neo4j.py)    │     │    │
│  └─────────────────────────────────────────────────────┘     │    │
│                                                               │    │
└───────────────────────────────────────────────────────────────┘    │
                                                                      │
┌─────────────────────────────────────────────────────────────────────┘
│
▼
┌─────────────────────────────────────────────────────────────────────┐
│                     DOWNSTREAM CONSUMERS                            │
│  • Ontology Visualization UI (scripts/ontology_visualization/)      │
│  • Tagging Engine (auto-tag content with extracted entities)        │
│  • Neo4j Graph Database (knowledge graph querying)                  │
│  • External Tools (Protégé, GraphDB via OWL/RDF)                   │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 🛠️ Setup & Installation

### Prerequisites

- Python 3.11+
- `uv` package manager ([installation guide](https://github.com/astral-sh/uv))
- Anthropic API key (for LLM extraction)
- Google API key (for embeddings)

### Installation

```bash
# Install uv if not already installed
curl -LsSf https://astral.sh/uv/install.sh | sh

# From the project root
cd Taxonomy-Ontology-Accelerator

# Install all dependencies
uv sync
```

### Environment Variables

```bash
# Choose one LLM provider API key (based on your model in config)
export GOOGLE_API_KEY="your-google-api-key"        # For Gemini models
export ANTHROPIC_API_KEY="your-anthropic-api-key"  # For Anthropic models
export OPENAI_API_KEY="your-openai-api-key"        # For OpenAI models

# Optional: AWS Bedrock (alternative to direct API)
# Minimum: Region (required)
export AWS_DEFAULT_REGION="us-east-1"
# Credentials (required for API calls, boto3 reads from env vars or ~/.aws/credentials)
export AWS_ACCESS_KEY_ID="your-aws-access-key"
export AWS_SECRET_ACCESS_KEY="your-aws-secret-key"
```

---

## 🚀 How to Run

### Convention-Over-Configuration

The Ontology Engine uses a simple, intuitive folder structure. Create a domain folder:

```
travel/                      # Domain name
├── input/                   # Input files (REQUIRED)
│   ├── advisory1.txt
│   ├── advisory2.txt
│   └── ...
├── prompts/                 # Domain prompts (OPTIONAL)
│   └── prompt.txt           # Or extraction_prompt.txt, llm_prompt.txt
└── config.yaml              # Domain config (OPTIONAL)
```

**Resolution Priority:**

1. **Input**: `{domain}/input/` → `domain.input` in config → error
2. **Prompt**: `{domain}/prompts/*.txt` → `domain.prompt` in config → code default
3. **Config**: `{domain}/config.yaml` merged with Pydantic defaults (in config.py)

### CLI Commands (Recommended)

The Ontology Engine provides a command-line interface for easy usage.

> **Note:** Use `uv run toa` during development, or just `toa` after installation.

#### 1. Extract Ontology

Extract entities and relationships from text files:

```bash
# Convention-based (auto-discovers input/ and prompts/)
uv run toa ontology extract --domain travel

# With custom config file
uv run toa ontology extract --domain travel --config custom_config.yaml
```

**Note:** All configuration (model, incremental mode, paths) is now done via:

- **Pydantic defaults**: Built into `config.py` (no YAML file needed)
- **Domain overrides**: `{domain}/config.yaml` (optional)

API keys (GOOGLE_API_KEY, ANTHROPIC_API_KEY, etc.) use environment variables.

#### 2. Export to OWL/RDF

Export the ontology to standard OWL/RDF formats:

```bash
# Export to Turtle format (default)
uv run toa ontology export --domain travel

# Export to XML format
uv run toa ontology export --domain travel --format rdfxml

# Custom output directory
uv run toa ontology export --domain travel --output ./exports/
```

#### 3. View Ontology Info

Display statistics about an extracted ontology:

```bash
uv run toa ontology info --domain travel
```

#### 4. Visualize Ontology

Visualize the ontology graph in an interactive browser interface:

```bash
# Start visualization server (opens browser automatically)
uv run toa ontology visualize --domain travel

# Use custom port
uv run toa ontology visualize --domain travel --port 9000

# Export standalone HTML file (portable, works offline)
uv run toa ontology visualize --domain travel --export ./visualization.html

# Start server without auto-opening browser
uv run toa ontology visualize --domain travel --no-open
```

#### CLI Options Reference

**Extract Command:**

| Option | Short | Description |
|--------|-------|-------------|
| `--domain` | `-d` | Domain name (required) |
| `--config` | `-c` | Path to config file (overrides code default) |

**Export Command:**

| Option | Short | Description |
|--------|-------|-------------|
| `--domain` | `-d` | Domain name (required) |
| `--format` | `-f` | Export format: 'turtle' or 'rdfxml' (default: turtle) |
| `--output` | `-o` | Output directory for ontology files |
| `--schema` | | Path to schema.json (auto-detected if not provided) |
| `--graph` | | Path to graph.json (auto-detected if not provided) |

**Info Command:**

| Option | Short | Description |
|--------|-------|-------------|
| `--domain` | `-d` | Domain name (required) |
| `--output` | `-o` | Output directory containing ontology files |

**Visualize Command:**

| Option | Short | Description |
|--------|-------|-------------|
| `--domain` | `-d` | Domain name (required) |
| `--output` | `-o` | Output directory containing ontology files |
| `--port` | `-p` | Port for local server (default: 8080) |
| `--export` | `-e` | Export standalone HTML file instead of serving |
| `--no-open` | | Don't automatically open browser |

---

### Python API (Advanced)

For programmatic usage and integration into applications:

#### Basic Usage (Python API)

```python
import asyncio
from taxonomy_ontology_accelerator.ontology_engine import extract_ontology

# Simple: Just provide domain name (uses convention)
async def main():
    result = await extract_ontology(domain="travel")

    print(f"Extracted {len(result.graph.entities)} entities")
    print(f"Found {len(result.graph.relationships)} relationships")
    print(f"Output: {result.graph_path}")

asyncio.run(main())
```

**What happens:**

1. Looks for `travel/input/` folder (required)
2. Looks for `travel/prompts/*.txt` (optional, uses code default if missing)
3. Loads `travel/config.yaml` merged with Pydantic defaults (optional)
4. Outputs to `domains/{domain}/output/travel/`

#### Domain Folder Structure

```
travel/                      # Your domain folder
├── input/                   # REQUIRED: Input files
│   ├── advisory1.txt
│   └── advisory2.txt
├── prompts/                 # OPTIONAL: Domain-specific prompts
│   └── prompt.txt
└── config.yaml              # OPTIONAL: Domain config overrides
```

#### Domain Config Example (travel/config.yaml)

```yaml
# Override code defaults for this domain
llm:
  model: "gemini-2.5-pro"
  temperature: 0.1

# Explicit paths (overrides convention)
domain:
  input: "path/to/custom/input.txt"      # Override {domain}/input/
  prompt: "path/to/custom/prompt.txt"    # Override {domain}/prompts/

# Any other config overrides...
deduplication:
  semantic_threshold: 0.90
```

### Supported LLM Providers

All pydantic-ai providers are supported via auto-inference:

| Provider | Model Format | API Key Required |
|----------|-------------|------------------|
| **Gemini** | `gemini-2.5-pro` | `GOOGLE_API_KEY` |
| **Anthropic** | `anthropic:claude-sonnet-4` | `ANTHROPIC_API_KEY` |
| **OpenAI** | `openai:gpt-4o` | `OPENAI_API_KEY` |
| **Groq** | `groq:llama-3-70b` | `GROQ_API_KEY` |
| **Cohere** | `cohere:command-r-plus` | `COHERE_API_KEY` |
| **Mistral** | `mistral:mistral-large` | `MISTRAL_API_KEY` |

**Usage:** Set the model in `config.yaml` and the appropriate API key, OR override at runtime using the `model` parameter.

### Override Model via Config

You can override the configured model for a specific domain by setting it in `{domain}/config.yaml`:

```yaml
# travel/config.yaml
llm:
  model: "openai:gpt-4o"  # Use OpenAI GPT-4o for this domain
```

```yaml
# healthcare/config.yaml
llm:
  model: "gemini-2.5-pro"  # Use Gemini for this domain
```

```yaml
# finance/config.yaml
llm:
  model: "anthropic:claude-sonnet-4-20250514"  # Use Claude for this domain
```

Then simply run:

```python
import asyncio
from taxonomy_ontology_accelerator.ontology_engine import extract_ontology

result = asyncio.run(extract_ontology(domain="travel"))
```

**Supported model formats:**

- Anthropic: `anthropic:claude-sonnet-4-20250514`, `anthropic:claude-3-5-sonnet-20241022`
- Gemini: `gemini-2.5-pro`, `gemini-2.0-flash-exp`
- OpenAI: `openai:gpt-4o`, `openai:gpt-4-turbo`, `openai:gpt-4`, `openai:gpt-3.5-turbo`

### Use AWS Bedrock (Optional)

Use AWS Bedrock for Claude models (alternative to direct Anthropic API):

**Prerequisites:**

```bash
# 1. Install boto3
uv sync --extra bedrock

# 2. AWS region (REQUIRED)
export AWS_DEFAULT_REGION="us-east-1"

# 3. AWS credentials (REQUIRED for API calls)
export AWS_ACCESS_KEY_ID="your-key"
export AWS_SECRET_ACCESS_KEY="your-secret"
```

**Usage:** Enable in `{domain}/config.yaml`:

```yaml
# travel/config.yaml
llm:
  model: "anthropic:claude-sonnet-4-20250514"
  aws_bedrock_enabled: true
```

Then run:

```python
import asyncio
from taxonomy_ontology_accelerator.ontology_engine import extract_ontology

result = asyncio.run(extract_ontology(domain="travel"))
```

**Note:** Bedrock only supports Anthropic Claude models.

### Export to OWL/RDF

Enable in config or use the export function directly:

```python
from taxonomy_ontology_accelerator.ontology_engine import export_to_owl_rdf_from_files

export_to_owl_rdf_from_files(
    schema_path="domains/{domain}/output/travel/schema.json",
    graph_path="domains/{domain}/output/travel/graph.json",
    output_path="domains/{domain}/output/travel/ontology.owl",
    format="rdfxml"  # or "turtle"
)
```

---

## ⚙️ Configuration

### Configuration File Location

The engine uses `Pydantic defaults (config.py)` for all settings.

### Key Configuration Options

```yaml
# LLM Configuration
llm:
  model: "anthropic:claude-sonnet-4-20250514"  # or "openai:gpt-4o", "gemini-2.5-pro"
  retries: 3
  max_tokens: 8000
  temperature: 0.0

# Source Grounding
source_grounding:
  enabled: true  # Track which source file each entity/relationship came from
  source_property_name: "source_urls"  # Property name to store source identifiers
  merge_sources_on_deduplication: true  # Merge sources when entities are deduplicated

# Output Settings
output:
  base_directory: "domains/{domain}/output"
  schema_filename: "schema.json"
  graph_filename: "graph.json"
  embeddings_directory: "embeddings"
  embeddings_filename: "embeddings.json"
  pretty_print: true
  compress_output: false
  export:
    enabled: true
    format: "turtle"  # or "rdfxml"
    filename: "ontology"

# Processing Settings
processing:
  chunk_size: 4000  # Characters per chunk
  batch_size: 5     # Chunks per LLM call

# Deduplication
deduplication:
  semantic_threshold: 0.85  # Similarity threshold

# Checkpointing (resume support)
checkpointing:
  enabled: true
  checkpoint_filename: "checkpoint.json"

# Limits (safety guards)
limits:
  max_entities: 10000
  max_relationships: 50000
```

### Environment Variables

| Variable | Purpose | Default |
|----------|---------|---------|
| `ANTHROPIC_API_KEY` | LLM API access (Anthropic models) | Required for Anthropic |
| `OPENAI_API_KEY` | LLM API access (OpenAI models) | Required for OpenAI |
| `GOOGLE_API_KEY` | Embeddings API / Gemini models | Required |

---

## ❗ Common Issues & Troubleshooting

### Issue: "API_KEY not set" (ANTHROPIC_API_KEY, OPENAI_API_KEY, etc.)

**Solution:** Set the appropriate environment variable for your chosen model:

```bash
# For Anthropic models
export ANTHROPIC_API_KEY="your-anthropic-key"

# For OpenAI models
export OPENAI_API_KEY="your-openai-key"

# For Gemini models
export GOOGLE_API_KEY="your-google-key"
```

### Issue: "Rate limit exceeded"

**Solution:** Reduce batch size in config or add delays:

```yaml
processing:
  batch_size: 3  # Reduce from default
  delay_between_batches: 1.0  # Seconds
```

### Issue: "Out of memory"

**Solution:** Process fewer files at once or reduce chunk size:

```yaml
processing:
  chunk_size: 2000  # Smaller chunks
limits:
  max_entities: 5000
```

### Issue: "Duplicate entities not merging"

**Solution:** Lower the semantic similarity threshold:

```yaml
deduplication:
  semantic_threshold: 0.80  # Lower threshold = more merging
```

### Issue: "OWL export fails"

**Solution:** Ensure `rdflib` is installed (it should be included in the project dependencies). If not:

```bash
uv add rdflib
```

---

## 👥 Who Should Use This Module

| Role | Use Case |
|------|----------|
| **Data Engineers** | Build automated ontology extraction pipelines |
| **Knowledge Engineers** | Bootstrap ontologies from document collections |
| **ML Engineers** | Generate training data for NER/RE models |
| **Research Scientists** | Extract structured knowledge from papers |
| **Technical Architects** | Design domain models from requirements docs |

---

## 📊 Output Examples

### Entity Example (from graph.json)

```json
{
  "id": "ENT_001",
  "canonical_key": "london",
  "label": "London",
  "type": "city",
  "description": "Capital city of the United Kingdom",
  "aliases": ["Greater London", "London, UK"],
  "properties": {
    "population": "8.9 million",
    "country": "United Kingdom",
    "source_urls": "travel_guide.txt"
  },
  "metadata": {
    "confidence": 0.95,
    "first_seen": "2024-01-15T10:30:00Z",
    "last_updated": "2024-01-15T10:30:00Z"
  }
}
```

### Relationship Example (from graph.json)

```json
{
  "id": "REL_001",
  "from_": "ENT_001",
  "to": "ENT_002",
  "type": "IS_CAPITAL_OF",
  "properties": {
    "since": "1066",
    "source_urls": "travel_guide.txt"
  },
  "metadata": {
    "confidence": 0.98
  }
}
```

### Schema Example (from schema.json)

```json
{
  "domain": "geography",
  "version": "1.0.3",
  "entity_types": [
    {
      "name": "city",
      "description": "A large human settlement",
      "properties": ["population", "country", "coordinates"]
    }
  ],
  "relationship_types": [
    {
      "name": "IS_CAPITAL_OF",
      "description": "City is the capital of a country",
      "from_types": ["city"],
      "to_types": ["country"]
    }
  ]
}
```

---

## 🔗 Related Documentation

- [Main README](../../README.md) - Project overview
- [Complete RUNBOOK](../../docs/ontology/RUNBOOK.md) - Comprehensive usage guide
- [Ontology Visualization UI](../../scripts/ontology_visualization/README.md) - Visualize outputs
- [Configuration File](config/config.py) - Full config options (Pydantic defaults)
