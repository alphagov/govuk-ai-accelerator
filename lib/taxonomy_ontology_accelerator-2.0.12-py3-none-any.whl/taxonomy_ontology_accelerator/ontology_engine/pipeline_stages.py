"""
Public API for ontology extraction pipeline stages.

This module exposes all 17 internal stages of ontology extraction as individual
callable functions. Each stage function operates on an ExtractionState object,
which flows through the pipeline carrying intermediate data.

Usage:
    from taxonomy_ontology_accelerator import (
        ExtractionState,
        load_configuration,
        load_input_content,
        chunk_input_text,
        run_llm_extraction,
        deduplicate_entities,
    )

    # Manual state management
    state = ExtractionState(domain="travel", incremental=False)
    state.input_path = Path("data.txt")

    # Run stages individually
    load_configuration(state)
    load_input_content(state.input_path, state)
    chunk_input_text(state)
    # ... etc

Stage Groups:
    Configuration: load_configuration, validate_input_parameters, load_domain_prompt,
                   load_input_content, setup_output_directory, load_existing_data
    Extraction: chunk_input_text, create_extraction_agent, run_llm_extraction
    Processing: deduplicate_entities, build_relationships, evolve_schema, resolve_conflicts
    Finalization: merge_with_existing, merge_relationships, build_and_validate,
                  save_output, export_owl, finalize_metadata
"""

import json
import logging
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pydantic_ai import Agent

    from taxonomy_ontology_accelerator.ontology_engine.core.models import ExtractionResult

from taxonomy_ontology_accelerator.ontology_engine.core.extraction_finalize import (
    build_and_validate_graph,
    export_to_owl_format,
    finalize_extraction_output,
    merge_and_deduplicate_relationships,
    merge_with_existing_graph,
    save_schema_and_graph,
)
from taxonomy_ontology_accelerator.ontology_engine.core.extraction_pipeline import (
    ExtractionState,
    load_existing_ontology_data,
)
from taxonomy_ontology_accelerator.ontology_engine.core.extraction_pipeline import (
    load_configuration as _load_configuration,
)
from taxonomy_ontology_accelerator.ontology_engine.core.extraction_pipeline import (
    load_domain_prompt as _load_domain_prompt,
)
from taxonomy_ontology_accelerator.ontology_engine.core.extraction_pipeline import (
    load_input_content as _load_input_content,
)
from taxonomy_ontology_accelerator.ontology_engine.core.extraction_pipeline import (
    setup_output_directory as _setup_output_directory,
)
from taxonomy_ontology_accelerator.ontology_engine.core.extraction_pipeline import (
    validate_input_parameters as _validate_input_parameters,
)
from taxonomy_ontology_accelerator.ontology_engine.core.extraction_stages import (
    build_entity_relationships as _build_entity_relationships,
)
from taxonomy_ontology_accelerator.ontology_engine.core.extraction_stages import (
    chunk_input_text as _chunk_input_text,
)
from taxonomy_ontology_accelerator.ontology_engine.core.extraction_stages import (
    deduplicate_extracted_entities,
    evolve_ontology_schema,
    infer_upper_ontology,
    resolve_conflicting_relationships,
)
from taxonomy_ontology_accelerator.ontology_engine.core.extraction_stages import (
    run_llm_extraction as _run_llm_extraction,
)
from taxonomy_ontology_accelerator.ontology_engine.core.models import (
    OntologyOutput,
)
from taxonomy_ontology_accelerator.commons.io.file_utils import (
    join_path,
    normalize_path,
)

logger = logging.getLogger(__name__)

__all__ = [
    "ExtractionState",
    "build_and_validate",
    "build_relationships",
    "chunk_input_text",
    "deduplicate_entities",
    "evolve_schema",
    "export_owl",
    "infer_upper_ontology_hierarchy",
    "finalize_metadata",
    "load_existing_data",
    "merge_relationships",
    "merge_with_existing",
    "resolve_conflicts",
    "run_llm_extraction",
    "save_output",
    "setup",
]


# ========================================================================
# Setup (Grouped)
# ========================================================================


def setup(
    state: ExtractionState,
    input_path: str | Path,
    output_dir: str | Path | None = None,
    prompt_path: str | Path | None = None,
) -> None:
    """
    Complete setup for ontology extraction.

    This grouped function handles all core setup stages:
    - Load configuration (from YAML)
    - Validate input parameters (check domain, input_path)
    - Load domain-specific prompt (optional, for specialized extraction)
    - Load and normalize input content (files or directories)
    - Setup output directory (create dirs, initialize checkpoint manager)

    After this, you can proceed to extraction stages (chunk, extract, etc).

    Args:
        state: Extraction state to populate with configuration and data
        input_path: Path to input file or directory (required)
        output_dir: Custom output directory (optional, uses config default if None)
        prompt_path: Path to domain prompt file (optional, uses generic prompt if None)

    Raises:
        ValueError: If validation fails or no valid input text found
        FileNotFoundError: If prompt/input files don't exist
        OSError: If files cannot be read

    Example:
        from taxonomy_ontology_accelerator import ExtractionState, setup

        state = ExtractionState(domain="travel", incremental=False)
        setup(state, input_path="data.txt")
        # Now ready for extraction stages
    """
    assert state is not None, "state must not be None"
    assert isinstance(state, ExtractionState), "state must be ExtractionState"
    assert input_path is not None, "input_path must not be None"

    # Load configuration
    _load_configuration(state)

    # Set input_path and validate parameters
    state.input_path = normalize_path(input_path)
    _validate_input_parameters(state)

    # Load domain-specific prompt (optional)
    if prompt_path is not None:
        _load_domain_prompt(prompt_path, state)

    # Load input content
    assert state.input_path is not None, "state.input_path must be set before loading input"
    _load_input_content(state.input_path, state)

    # Setup output directory
    _setup_output_directory(output_dir, state)


def load_existing_data(state: ExtractionState) -> None:
    """
    Load existing schema, graph, and embeddings for incremental extraction.

    This stage is separate from setup() because it's only needed for incremental mode.

    For incremental mode:
    - Loads existing schema.json, graph.json, and embeddings
    - Pre-merges existing entities into the entity map for deduplication
    - Sets up resolved ID mapping for entity deduplication

    For non-incremental mode:
    - Creates empty ExistingData (fresh extraction)

    Args:
        state: Extraction state to populate with existing_data, existing_schema, etc.

    Example:
        state = ExtractionState(domain="travel", incremental=True)
        setup(state, input_path="data.txt")
        load_existing_data(state)  # Load previous ontology for merging
    """
    assert state is not None, "state must not be None"
    assert isinstance(state, ExtractionState), "state must be ExtractionState"

    load_existing_ontology_data(state)


# ========================================================================
# Extraction Stages
# ========================================================================


async def chunk_input_text(state: ExtractionState) -> OntologyOutput | None:
    """
    Split input texts into chunks for LLM processing.

    Uses configured chunking strategy (token-based with overlap) to create
    appropriately sized chunks for the LLM. Also checks if file was already
    processed via checkpoint (enables resumable extraction).

    Args:
        state: Extraction state with texts to chunk

    Returns:
        OntologyOutput if file already processed (skip extraction), None otherwise
    """
    assert state is not None, "state must not be None"
    assert isinstance(state, ExtractionState), "state must be ExtractionState"

    return await _chunk_input_text(state)


async def run_llm_extraction(
    extraction_agent: "Agent[None, ExtractionResult]",
    extraction_prompt: str,
    state: ExtractionState,
) -> None:
    """
    Extract entities and relationships from chunks using LLM.

    Processes chunks in batches using the configured extraction agent.
    Supports periodic flushing for memory efficiency and checkpointing.
    Tracks file completion status for resumable extraction.

    Args:
        extraction_agent: Configured pydantic-ai Agent (injected dependency)
        extraction_prompt: Main extraction prompt text
        state: Extraction state with chunks

    Note:
        This is an async function. Must be awaited or run in an async context.
    """
    assert extraction_agent is not None, "extraction_agent must not be None"
    assert extraction_prompt is not None, "extraction_prompt must not be None"
    assert state is not None, "state must not be None"

    await _run_llm_extraction(extraction_agent, extraction_prompt, state)


# ========================================================================
# Processing Stages
# ========================================================================


async def deduplicate_entities(state: ExtractionState) -> None:
    """
    Normalize labels and deduplicate entities using embeddings.

    Deduplication process:
    1. Normalize entity labels (lowercase, strip, etc.)
    2. Generate embeddings for semantic similarity
    3. Find duplicates using cosine similarity
    4. Merge duplicate entities, preserving highest confidence values
    5. Update entity label to ID mapping

    Args:
        state: Extraction state with all_concepts to deduplicate

    Raises:
        ValueError: If entity count exceeds configured limits
    """
    assert state is not None, "state must not be None"
    assert isinstance(state, ExtractionState), "state must be ExtractionState"

    await deduplicate_extracted_entities(state)


async def build_relationships(state: ExtractionState) -> None:
    """
    Build relationships between extracted entities.

    Converts extracted relationship triples (from_label, to_label, type)
    into Relationship objects with resolved entity IDs. Handles:
    - Entity label to ID resolution
    - Existing entity mapping for incremental extraction
    - Relationship deduplication
    - Orphaned relationship detection (entities not found)

    Args:
        state: Extraction state to populate with relationships
    """
    assert state is not None, "state must not be None"
    assert isinstance(state, ExtractionState), "state must be ExtractionState"

    await _build_entity_relationships(state)


async def evolve_schema(state: ExtractionState) -> None:
    """
    Evolve schema with new entity and relationship types.

    Schema evolution:
    1. Checks extracted entity types against existing schema
    2. Uses semantic similarity to match equivalent types
    3. Creates new types for genuinely novel entities
    4. Updates relationship type constraints based on usage
    5. Increments schema version on changes

    Args:
        state: Extraction state to populate with schema and type counts
    """
    assert state is not None, "state must not be None"
    assert isinstance(state, ExtractionState), "state must be ExtractionState"

    await evolve_ontology_schema(state)


async def infer_upper_ontology_hierarchy(state: ExtractionState) -> None:
    """
    Infer upper ontology hierarchy for all extracted concept types.

    Post-extraction stage that uses an LLM to assign abstract parent classes
    to the full vocabulary of extracted concept types, introducing upper ontology
    anchors (Agent, Place, PolicyConstruct, etc.) and intermediate grouping
    classes (Requirement, Document, etc.) that are absent from source text.

    Must run after evolve_schema and before resolve_conflicts.

    Args:
        state: Extraction state with evolved ontology schema
    """
    assert state is not None, "state must not be None"
    assert isinstance(state, ExtractionState), "state must be ExtractionState"

    await infer_upper_ontology(state)


def resolve_conflicts(state: ExtractionState) -> None:
    """
    Resolve conflicting relationships based on configured strategy.

    Handles cases where multiple relationships of the same type exist between
    the same entities. Resolution strategies include:
    - Keep most recent (based on timestamp)
    - Keep highest confidence
    - Merge properties from both

    Only runs if conflict_resolution.enabled is true in config.

    Args:
        state: Extraction state with relationships to potentially resolve
    """
    assert state is not None, "state must not be None"
    assert isinstance(state, ExtractionState), "state must be ExtractionState"

    resolve_conflicting_relationships(state)


# ========================================================================
# Finalization Stages
# ========================================================================


def merge_with_existing(state: ExtractionState) -> None:
    """
    Merge newly extracted entities with existing graph data.

    For incremental extraction, merges new entities with existing ones:
    1. Matches entities by normalized label
    2. Merges properties, preserving higher confidence values
    3. Updates timestamps and merge metadata
    4. Removes duplicates, keeping canonical entities
    5. Validates entity counts after merge

    Skips if no existing graph (fresh extraction).

    Args:
        state: Extraction state with entities and existing_graph
    """
    assert state is not None, "state must not be None"
    assert isinstance(state, ExtractionState), "state must be ExtractionState"

    merge_with_existing_graph(state)


async def merge_relationships(state: ExtractionState) -> None:
    """
    Merge new relationships with existing and remove duplicates.

    Performs relationship merging:
    1. Updates entity IDs using resolved mapping
    2. Normalizes relationship types for matching
    3. Merges duplicate relationships (same from, to, type)
    4. Removes orphaned relationships (missing entities)
    5. Validates relationship count accounting

    Args:
        state: Extraction state with relationships to merge
    """
    assert state is not None, "state must not be None"
    assert isinstance(state, ExtractionState), "state must be ExtractionState"

    await merge_and_deduplicate_relationships(state)


def build_and_validate(state: ExtractionState) -> None:
    """
    Build final ontology graph and run validation checks.

    Creates the OntologyGraph object and validates:
    1. Post-merge validation (entity/relationship integrity)
    2. Schema conformance (types, constraints)
    3. Required fields present
    4. Relationship endpoint validity

    Raises ValueError if critical validation errors found (unless
    continue_on_error is enabled in config).

    Args:
        state: Extraction state to populate with graph

    Raises:
        ValueError: If critical validation errors found and continue_on_error is False
    """
    assert state is not None, "state must not be None"
    assert isinstance(state, ExtractionState), "state must be ExtractionState"

    build_and_validate_graph(state)


def save_output(state: ExtractionState) -> tuple[bool, bool, Path, Path]:
    """
    Save schema and graph JSON files to output directory.

    Saves:
    - schema.json: Ontology schema with entity/relationship type definitions
    - graph.json: Ontology graph with entities and relationships

    Uses file locking to prevent concurrent writes. Schema includes
    a graph representation for visualization tools.

    Args:
        state: Extraction state with schema and graph to save

    Returns:
        Tuple of (schema_saved, graph_saved, schema_path, graph_path)
    """
    assert state is not None, "state must not be None"
    assert isinstance(state, ExtractionState), "state must be ExtractionState"

    return save_schema_and_graph(state)


def export_owl(state: ExtractionState) -> None:
    """
    Export ontology to OWL/RDF format if configured.

    Exports the ontology to standard semantic web formats:
    - Turtle (.ttl): Human-readable RDF format
    - RDF/XML (.owl): W3C standard format

    Export format is controlled by config.output.export.format.
    Requires rdflib library. Export is optional and controlled by config.

    Args:
        state: Extraction state with schema and graph to export
    """
    assert state is not None, "state must not be None"
    assert isinstance(state, ExtractionState), "state must be ExtractionState"

    export_to_owl_format(state)


def finalize_metadata(state: ExtractionState) -> OntologyOutput:
    """
    Build processing metadata and return final OntologyOutput.

    Compiles extraction statistics and creates the final output object:
    - Entity and relationship counts (before and after deduplication)
    - New type counts from schema evolution
    - Processing time and LLM call count
    - Embeddings generated count
    - Collected errors and warnings

    Also logs a human-readable summary of the extraction results.

    Args:
        state: Extraction state with all computed values

    Returns:
        Complete OntologyOutput with schema, graph, metadata, and errors
    """
    assert state is not None, "state must not be None"
    assert isinstance(state, ExtractionState), "state must be ExtractionState"
    assert state.output_dir is not None, "output_dir must be set"

    config = state.config
    assert config is not None, "config must be loaded"

    schema_path = join_path(state.output_dir, config.output.schema_filename)
    graph_path = join_path(state.output_dir, config.output.graph_filename)

    return finalize_extraction_output(state, schema_path, graph_path)
