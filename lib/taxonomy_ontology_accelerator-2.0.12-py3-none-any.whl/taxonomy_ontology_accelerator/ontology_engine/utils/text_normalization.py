"""
Text normalization utilities for ontology extraction.

Implements LRU (Least Recently Used) cache for normalization to prevent
unbounded memory growth while maintaining performance.
"""

import hashlib
import re
import threading
from collections import OrderedDict
from typing import TYPE_CHECKING, Protocol, runtime_checkable

from taxonomy_ontology_accelerator.commons.utils.logger import get_logger

# Default patterns for formal ontology identifiers.
# Multiple patterns to avoid false positives on words like `is_a` or `part_of`.
_DEFAULT_FORMAL_ID_PATTERNS = [
    r"^[A-Z][A-Za-z0-9]*_\d+$",  # OBO underscore: VO_0010343, DOID_4325, NCBITaxon_186538
    r"^[A-Z][A-Za-z0-9]*:\d+$",  # HPO/MONDO colon: HP:0001234, MONDO:0000001
    r"^[A-Z][A-Za-z0-9]*:[A-Z0-9.]+$",  # ICD colon: ICD10CM:E11.9
]
# Keep single-string version for backward compat (used nowhere internally now)
_DEFAULT_FORMAL_ID_PATTERN_STR = r"^[A-Z][A-Za-z0-9]*_\d+$"

if TYPE_CHECKING:
    from taxonomy_ontology_accelerator.commons.errors import ErrorCollector
    from taxonomy_ontology_accelerator.ontology_engine.config.config import OntologyConfig


@runtime_checkable
class EntityLike(Protocol):
    """Protocol for objects that can be used for embedding text generation."""

    @property
    def label(self) -> str:
        """Return entity label."""
        assert self is not None, "self must not be None"
        assert True, "Protocol property placeholder"
        ...

    @property
    def aliases(self) -> list[str] | None:
        """Return entity aliases."""
        assert self is not None, "self must not be None"
        assert True, "Protocol property placeholder"
        ...


logger = get_logger()


def split_identifier_words(text: str) -> str:
    """Insert spaces into CamelCase and acronym boundaries without lowercasing."""
    assert text is not None, "text parameter is required"
    assert isinstance(text, str), "text must be a string"

    split_acronyms = re.sub(r"([A-Z]+)([A-Z][a-z])", r"\1 \2", text)
    return re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", split_acronyms)


def is_formal_identifier_default(text: str) -> bool:
    """
    Check if text matches any default formal ontology identifier pattern.

    Uses the built-in default patterns without requiring config.
    Matches: VO_0010343, DOID_4325, NCBITaxon_186538, HP:0001234, ICD10CM:E11.9, etc.
    Does NOT match: is_a, part_of, snake_case_words.

    Args:
        text: Text to check

    Returns:
        True if text matches any default formal identifier pattern
    """
    assert text is not None, "text parameter is required"
    assert isinstance(text, str), "text must be a string"

    stripped = text.strip()
    return any(re.match(pattern, stripped) for pattern in _DEFAULT_FORMAL_ID_PATTERNS)


def is_formal_identifier(text: str, config: "OntologyConfig") -> bool:
    """
    Check if text matches any configured formal ontology identifier pattern.

    Uses patterns from config.text_processing.normalization.preserve_identifier_patterns.
    Users can customize patterns in their domain config.yaml to match their ontology format.

    Args:
        text: Text to check
        config: Ontology configuration with identifier patterns

    Returns:
        True if text matches any configured formal identifier pattern
    """
    assert text is not None, "text parameter is required"
    assert config is not None, "config parameter is required"

    stripped = text.strip()
    for pattern_str in config.text_processing.normalization.preserve_identifier_patterns:
        if re.match(pattern_str, stripped):
            return True
    return False


# ========================================================================
# LRU Cache for Normalization
# ========================================================================


class LRUNormalizationCache:
    """
    LRU (Least Recently Used) cache for text normalization.

    Prevents unbounded memory growth by evicting least recently used entries
    when cache size exceeds the limit.
    """

    def __init__(self, max_size: int = 10000):
        """
        Initialize LRU normalization cache.

        Args:
            max_size: Maximum number of entries to cache (default: 10000)
        """
        assert isinstance(max_size, int), "max_size must be an integer"
        assert max_size > 0, "max_size must be positive"
        self.max_size = max_size
        self._cache: OrderedDict[str, str] = OrderedDict()

    def get(self, key: str) -> str | None:
        """
        Get cached normalized value.

        Moves entry to end (most recently used) if found.

        Args:
            key: Original text to look up

        Returns:
            Normalized text if cached, None otherwise
        """
        assert key is not None, "key parameter is required"
        assert isinstance(key, str), "key must be a string"
        if key in self._cache:
            # Move to end (most recently used)
            value = self._cache.pop(key)
            self._cache[key] = value
            return value
        return None

    def set(self, key: str, value: str) -> None:
        """
        Cache normalized value.

        Evicts least recently used entry if cache is full.

        Args:
            key: Original text
            value: Normalized text
        """
        assert key is not None, "key parameter is required"
        assert isinstance(value, str), "value must be a string"
        # Remove if already exists (will be re-added at end)
        if key in self._cache:
            self._cache.pop(key)

        # Add to end (most recently used)
        self._cache[key] = value

        # Evict oldest if cache is full
        if len(self._cache) > self.max_size:
            # Remove first item (least recently used)
            self._cache.popitem(last=False)

    def clear(self) -> None:
        """Clear all cached entries."""
        assert hasattr(self, "_cache"), "cache must be initialized"
        assert isinstance(self._cache, OrderedDict), "_cache must be an OrderedDict"
        self._cache.clear()

    def __len__(self) -> int:
        """Get current cache size."""
        assert hasattr(self, "_cache"), "cache must be initialized"
        assert isinstance(self._cache, OrderedDict), "_cache must be an OrderedDict"
        return len(self._cache)


# Global LRU cache instance (thread-safe with lock protection)
_global_normalization_cache: LRUNormalizationCache | None = None
_normalization_cache_lock = threading.Lock()


def get_global_normalization_cache() -> LRUNormalizationCache:
    """
    Get or create global normalization cache (thread-safe).

    Returns:
        Global LRUNormalizationCache instance
    """
    assert _normalization_cache_lock is not None, "cache lock must be initialized"
    assert isinstance(_normalization_cache_lock, type(threading.Lock())), (
        "cache lock must be a Lock"
    )
    global _global_normalization_cache
    with _normalization_cache_lock:
        if _global_normalization_cache is None:
            _global_normalization_cache = LRUNormalizationCache()
        return _global_normalization_cache


# ========================================================================
# Text Normalization Functions
# ========================================================================


def _get_from_cache(text: str, cache: dict[str, str] | LRUNormalizationCache | None) -> str | None:
    """Get value from cache (supports dict and LRUNormalizationCache)."""
    assert text is not None, "text parameter is required"
    assert isinstance(text, str), "text must be a string"
    if cache is None:
        return None
    return cache.get(text)


def _set_in_cache(
    text: str, value: str, cache: dict[str, str] | LRUNormalizationCache | None
) -> None:
    """Set value in cache (supports dict and LRUNormalizationCache)."""
    assert text is not None, "text parameter is required"
    assert isinstance(value, str), "value must be a string"
    if cache is None:
        return
    if isinstance(cache, LRUNormalizationCache):
        cache.set(text, value)
    else:
        cache[text] = value


def _expand_abbreviations(text: str, mappings: dict[str, str]) -> str:
    """
    Expand abbreviations in text using provided mappings.

    Features:
    - Case-insensitive matching (ny, NY, Ny all match)
    - Whole-word matching only (prevents "USA" in "USAGE")
    - Preserves original case of surrounding text
    - Uses first match for duplicate abbreviations

    Args:
        text: Input text to expand
        mappings: Abbreviation → full form dictionary

    Returns:
        Text with abbreviations expanded

    Example:
        >>> mappings = {"NY": "New York", "USA": "United States"}
        >>> _expand_abbreviations("Visit NY and the USA", mappings)
        'Visit New York and the United States'
    """
    assert text is not None, "text parameter is required"
    assert isinstance(text, str), "text must be a string"
    assert mappings is not None, "mappings parameter is required"

    if not mappings:
        return text

    result = text
    for abbrev, expansion in mappings.items():
        # Match abbreviation as whole word (case-insensitive)
        # Use \b for word boundaries to prevent partial matches
        pattern = r"\b" + re.escape(abbrev) + r"\b"
        result = re.sub(pattern, expansion, result, flags=re.IGNORECASE)

    return result


def _apply_normalization_pipeline(text: str, config: "OntologyConfig") -> str:
    """Apply possessive removal, abbreviation expansion, casing, and punctuation rules."""
    assert text is not None, "text parameter is required"
    assert config is not None, "config parameter is required"

    normalized = split_identifier_words(text)
    normalized = re.sub(r"(\w+)['']s?\b", r"\1", normalized)

    norm_config = config.text_processing.normalization
    if norm_config.abbreviation_mappings:
        normalized = _expand_abbreviations(normalized, norm_config.abbreviation_mappings)

    if norm_config.casing == "lowercase":
        normalized = normalized.lower()
    elif norm_config.casing == "uppercase":
        normalized = normalized.upper()

    if norm_config.punctuation_handling == "remove":
        normalized = re.sub(r"[^\w\s]", "", normalized)
    elif norm_config.punctuation_handling == "normalize":
        normalized = re.sub(r"\s+", " ", normalized)

    if norm_config.remove_common_words:
        words = [w for w in normalized.split() if w.lower() not in norm_config.remove_common_words]
        normalized = " ".join(words)

    return normalized


def _bounded_edit_distance(left: str, right: str, max_distance: int) -> int:
    """Compute Levenshtein distance with an early exit bound."""
    assert left is not None, "left parameter is required"
    assert right is not None, "right parameter is required"
    assert isinstance(max_distance, int), "max_distance must be an integer"

    if left == right:
        return 0
    if abs(len(left) - len(right)) > max_distance:
        return max_distance + 1

    previous = list(range(len(right) + 1))
    for i, left_char in enumerate(left, start=1):
        current = [i]
        row_min = current[0]
        for j, right_char in enumerate(right, start=1):
            cost = 0 if left_char == right_char else 1
            current.append(
                min(
                    previous[j] + 1,
                    current[j - 1] + 1,
                    previous[j - 1] + cost,
                )
            )
            row_min = min(row_min, current[-1])
        if row_min > max_distance:
            return max_distance + 1
        previous = current
    return previous[-1]


def _match_token_case(source_token: str, replacement: str) -> str:
    """Project the original token's case onto the replacement token."""
    assert source_token is not None, "source_token parameter is required"
    assert replacement is not None, "replacement parameter is required"

    if source_token.isupper():
        return replacement.upper()
    if source_token[:1].isupper():
        return replacement.capitalize()
    return replacement


def correct_text_against_vocabulary(
    text: str,
    vocabulary: set[str],
    config: "OntologyConfig",
) -> str:
    """Correct unique low-edit token typos against an existing vocabulary."""
    assert text is not None, "text parameter is required"
    assert vocabulary is not None, "vocabulary parameter is required"
    assert config is not None, "config parameter is required"

    norm_config = config.text_processing.normalization
    if not norm_config.fuzzy_vocabulary_correction_enabled or not vocabulary:
        return text

    max_distance = norm_config.fuzzy_vocabulary_correction_max_edit_distance
    min_length = norm_config.fuzzy_vocabulary_correction_min_token_length
    normalized_vocab = {token.lower() for token in vocabulary if token}

    corrected_tokens: list[str] = []
    for token in text.split():
        lowered = token.lower()
        if (
            len(lowered) < min_length
            or lowered in normalized_vocab
            or not lowered.isalpha()
        ):
            corrected_tokens.append(token)
            continue

        candidates = [
            candidate
            for candidate in normalized_vocab
            if candidate[:1] == lowered[:1]
            and abs(len(candidate) - len(lowered)) <= max_distance
            and _bounded_edit_distance(lowered, candidate, max_distance) <= max_distance
        ]
        if not candidates:
            corrected_tokens.append(token)
            continue

        scored = sorted(
            (
                (_bounded_edit_distance(lowered, candidate, max_distance), len(candidate), candidate)
                for candidate in candidates
            ),
            key=lambda item: (item[0], item[1], item[2]),
        )
        best_distance = scored[0][0]
        best_candidates = [candidate for distance, _len, candidate in scored if distance == best_distance]
        if len(best_candidates) != 1:
            corrected_tokens.append(token)
            continue

        corrected_tokens.append(_match_token_case(token, best_candidates[0]))

    return " ".join(corrected_tokens)


def normalize_text(
    text: str,
    config: "OntologyConfig",
    cache: dict[str, str] | LRUNormalizationCache | None = None,
) -> str:
    """
    Normalize text according to configuration rules.

    Supports both dict and LRUNormalizationCache for caching.
    LRU cache prevents unbounded memory growth.

    Args:
        text: Input text to normalize
        config: Ontology configuration
        cache: Optional normalization cache (dict or LRUNormalizationCache) for performance

    Returns:
        Normalized text
    """
    assert text is not None, "text parameter is required"
    assert config is not None, "config parameter is required"

    # Preserve formal ontology identifiers as-is (e.g., VO_0010343, DOID_4325)
    stripped = text.strip()
    if is_formal_identifier(stripped, config):
        return stripped

    cached_value = _get_from_cache(text, cache)
    if cached_value is not None:
        return cached_value

    normalized = _apply_normalization_pipeline(text, config).strip()
    # Guard: if all characters were stripped (e.g. all-punctuation input like "---"),
    # fall back to the stripped original to avoid empty-string keys in entity_map.
    if not normalized:
        normalized = stripped
    _set_in_cache(text, normalized, cache)
    return normalized


def normalize_input_texts(
    input_texts: str | list[str],
    config: "OntologyConfig",
) -> list[str]:
    """
    Normalize input texts to list of non-empty strings.

    Args:
        input_texts: Input text(s) - string or list of strings
        config: Ontology configuration

    Returns:
        List of normalized text shards

    Raises:
        ValueError: If input is empty or invalid
    """
    assert input_texts is not None, "input_texts parameter is required"
    assert config is not None, "config parameter is required"
    texts = [input_texts] if isinstance(input_texts, str) else list(input_texts)

    texts = [t.strip() for t in texts if t.strip()]  # Filter empty strings and strip whitespace

    if not texts:
        raise ValueError(
            "Input texts are empty after normalization. Provide at least one non-empty text string."
        )

    validation = config.input_validation

    if validation.max_text_length is not None:
        total_length = sum(len(t) for t in texts)
        if total_length > validation.max_text_length:
            raise ValueError(
                f"Total input text length ({total_length}) exceeds maximum "
                f"({validation.max_text_length} characters)"
            )

    if validation.max_shards is not None and len(texts) > validation.max_shards:
        raise ValueError(
            f"Number of input shards ({len(texts)}) exceeds maximum ({validation.max_shards})"
        )

    for i, text in enumerate(texts):
        if len(text) < validation.min_shard_length:
            raise ValueError(
                f"Input shard {i} length ({len(text)}) is below minimum "
                f"({validation.min_shard_length} characters)"
            )

        if validation.max_shard_length is not None and len(text) > validation.max_shard_length:
            raise ValueError(
                f"Input shard {i} length ({len(text)}) exceeds maximum "
                f"({validation.max_shard_length} characters)"
            )

    return texts


# ========================================================================
# Canonical Key Generation
# ========================================================================


def generate_canonical_key(normalized_label: str, entity_type: str | None = None) -> str:
    """
    Generate stable canonical key from normalized label.

    Args:
        normalized_label: Normalized entity label
        entity_type: Optional entity type for type-aware keys (prefix with '{type}__')

    Returns:
        Canonical key (lowercase, alphanumeric + underscores only)
    """
    assert normalized_label is not None, "normalized_label parameter is required"
    assert isinstance(normalized_label, str), "normalized_label must be a string"

    # Preserve formal identifiers as canonical keys (case-sensitive)
    if is_formal_identifier_default(normalized_label):
        return normalized_label

    key = normalized_label.lower()
    key = re.sub(r"[^\w]+", "_", key)
    key = key.strip("_")

    if not key:
        key = hashlib.md5(normalized_label.encode()).hexdigest()[:16]

    # Prefix with entity type if provided (type-aware canonical keys)
    if entity_type is not None:
        type_prefix = re.sub(r"[^\w]+", "_", entity_type.lower()).strip("_")
        key = f"{type_prefix}__{key}"

    return key


# ========================================================================
# Normalization with Hash
# ========================================================================


def normalize_text_with_hash(
    text: str,
    config: "OntologyConfig",
    cache: dict[str, tuple[str, str]] | None = None,
) -> tuple[str, str]:
    """
    Normalize text and return both normalized text and hash.

    Args:
        text: Input text to normalize
        config: Ontology configuration
        cache: Optional cache dict mapping text -> (normalized, hash)

    Returns:
        Tuple of (normalized_text, hash_hex)
    """
    assert text is not None, "text parameter is required"
    assert config is not None, "config parameter is required"
    if cache is not None and text in cache:
        return cache[text]

    normalized = normalize_text(text, config, cache=None)
    label_hash = hashlib.md5(normalized.encode()).hexdigest()

    if cache is not None:
        cache[text] = (normalized, label_hash)

    return normalized, label_hash


# ========================================================================
# Validation and Helper Functions
# ========================================================================


def validate_normalized_string(
    normalized: str | None,
    original: str,
    context: str = "value",
) -> tuple[bool, str]:
    """
    Validate normalized string and return fallback if empty.

    Eliminates redundant empty string checks after normalization.

    Args:
        normalized: Normalized string (may be None or empty)
        original: Original string to use as fallback
        context: Context description for logging (e.g., "type", "label")

    Returns:
        Tuple of (is_valid, final_value)
        - is_valid: True if normalized is valid, False if fallback used
        - final_value: Valid string to use (normalized if valid, original otherwise)
    """
    assert original is not None, "original parameter is required"
    assert isinstance(context, str), "context must be a string"
    if not normalized or not normalized.strip():
        logger.warning(
            f"{context.capitalize()} '{original}' normalized to empty string. Using original value."
        )
        return (False, original)
    return (True, normalized)


def normalize_type_with_validation(
    type_name: str,
    config: "OntologyConfig",
    normalization_cache: dict[str, str],
    error_collector: "ErrorCollector | None" = None,
    context: str = "type",
) -> str:
    """
    Normalize type name with validation and error collection.

    Uses naming_conventions config to apply the correct casing style
    (UpperCamelCase for entity types, lowerCamelCase for relationship types)
    instead of generic text normalization which would destroy casing.

    Args:
        type_name: Type name to normalize
        config: Ontology configuration
        normalization_cache: Cache for normalization results
        error_collector: Optional error collector for warnings
        context: Context for error messages (e.g., "entity type", "relationship type")

    Returns:
        Normalized type name (or original if normalization failed)
    """
    assert type_name is not None, "type_name parameter is required"
    assert config is not None, "config parameter is required"

    # Preserve formal ontology identifiers as-is
    if is_formal_identifier(type_name, config):
        return type_name

    from taxonomy_ontology_accelerator.ontology_engine.core.models import apply_type_casing
    from taxonomy_ontology_accelerator.ontology_engine.utils.error_helpers import (
        collect_error_if_enabled,
    )
    from taxonomy_ontology_accelerator.ontology_engine.utils.spelling_variants import (
        convert_spelling_compound,
    )

    # Determine casing from naming_conventions based on context
    if "relationship" in context.lower():
        casing = config.naming_conventions.relationship_type_casing
        spelling_variant = config.naming_conventions.spelling_variant
    else:
        casing = config.naming_conventions.entity_type_casing
        spelling_variant = config.naming_conventions.entity_iri_spelling_variant
        if spelling_variant == "preserve":
            spelling_variant = config.naming_conventions.spelling_variant

    cache_key = f"{context}|{casing}|{spelling_variant}|{type_name}"
    cached_value = normalization_cache.get(cache_key)
    if cached_value is not None:
        return cached_value

    spelling_normalized = split_identifier_words(type_name)
    if spelling_variant != "preserve":
        spelling_normalized = convert_spelling_compound(spelling_normalized, spelling_variant)

    normalized = apply_type_casing(spelling_normalized, casing)
    is_valid, final_value = validate_normalized_string(normalized, type_name, context)

    if not is_valid and error_collector:
        warning_msg = (
            f"{context.capitalize()} '{type_name}' normalized to empty string. "
            f"Using original type name."
        )
        collect_error_if_enabled(
            error_collector,
            config,
            "warning",
            "schema_evolution",
            warning_msg,
        )

    normalization_cache[cache_key] = final_value
    return final_value


def get_entity_text_for_embedding(entity: EntityLike) -> str:
    """
    Get text representation of entity for embedding generation.

    Uses label + aliases for consistent semantic matching.
    Eliminates redundant pattern repeated 4+ times across entity_processor.py and relationship_builder.py.

    Args:
        entity: Entity-like object (must have label attribute, may have aliases)

    Returns:
        Text string combining label and aliases (space-separated)
    """
    assert entity is not None, "entity parameter is required"
    assert isinstance(entity, EntityLike), "entity must implement EntityLike protocol"
    entity_text = entity.label
    if entity.aliases:
        entity_text = f"{entity_text} {' '.join(entity.alias_names)}"
    return entity_text
