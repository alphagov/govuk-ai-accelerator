from __future__ import annotations

from typing import Any

try:
    from botocore.config import Config as BotoConfig
except ImportError:  # pragma: no cover - exercised in environments without botocore extras
    BotoConfig = None

DEFAULT_AWS_MAX_POOL_CONNECTIONS = 32
DEFAULT_BEDROCK_REQUEST_CONCURRENCY = 10
AWS_POOL_HEADROOM = 4
MAX_AWS_MAX_POOL_CONNECTIONS = 256
DEFAULT_BEDROCK_READ_TIMEOUT_SECONDS = 300.0
DEFAULT_BEDROCK_CONNECT_TIMEOUT_SECONDS = 10.0


def recommended_max_pool_connections(
    config: Any | None = None,
    *,
    concurrency_hint: int | None = None,
) -> int:
    pool_size = DEFAULT_AWS_MAX_POOL_CONNECTIONS

    if config is not None:
        parallel_files = max(1, int(getattr(config, "parallel_files", 1)))
        llm_config = getattr(config, "llm", None)
        governor_config = getattr(llm_config, "bedrock_quota_governor", None)
        if getattr(governor_config, "enabled", False):
            per_worker_concurrency = max(1, int(getattr(governor_config, "max_concurrency", 1)))
        else:
            per_worker_concurrency = DEFAULT_BEDROCK_REQUEST_CONCURRENCY
        pool_size = max(pool_size, parallel_files * per_worker_concurrency + AWS_POOL_HEADROOM)

    if concurrency_hint is not None:
        pool_size = max(pool_size, max(1, int(concurrency_hint)) + AWS_POOL_HEADROOM)

    return min(MAX_AWS_MAX_POOL_CONNECTIONS, pool_size)


def build_aws_client_config(
    config: Any | None = None,
    *,
    concurrency_hint: int | None = None,
    read_timeout: float | None = None,
    connect_timeout: float | None = None,
    **extra_kwargs: Any,
):
    if BotoConfig is None:
        return None

    resolved_read_timeout = (
        read_timeout
        if read_timeout is not None
        else float(
            getattr(
                getattr(config, "llm", None),
                "bedrock_read_timeout_seconds",
                DEFAULT_BEDROCK_READ_TIMEOUT_SECONDS,
            )
        )
    )
    resolved_connect_timeout = (
        connect_timeout
        if connect_timeout is not None
        else float(
            getattr(
                getattr(config, "llm", None),
                "bedrock_connect_timeout_seconds",
                DEFAULT_BEDROCK_CONNECT_TIMEOUT_SECONDS,
            )
        )
    )

    kwargs: dict[str, Any] = {
        "max_pool_connections": recommended_max_pool_connections(
            config,
            concurrency_hint=concurrency_hint,
        ),
        "read_timeout": resolved_read_timeout,
        "connect_timeout": resolved_connect_timeout,
    }
    kwargs.update(extra_kwargs)
    return BotoConfig(**kwargs)
