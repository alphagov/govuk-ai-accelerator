"""
Version management utilities for ontology extraction.
"""

# Standard semantic version has 3 parts: major.minor.patch
SEMANTIC_VERSION_PARTS = 3


# ========================================================================
# Version Increment Functions
# ========================================================================


def increment_schema_version(version: str, strategy: str) -> str:
    """
    Increment schema version string.

    Handles various version formats: "1.0", "1.0.0", "v1.0.0", etc.
    Pads to 3 parts if needed. Validates numeric parts.

    Args:
        version: Current version string
        strategy: Increment strategy ("patch", "minor", "major")

    Returns:
        Incremented version string

    Raises:
        ValueError: If version format is invalid or cannot be incremented
    """
    assert version is not None, "Version string must not be None"
    assert len(version) > 0, "Version string must not be empty"
    assert isinstance(strategy, str), "Strategy must be a string"

    version = version.lstrip("vV")  # Remove 'v' or 'V' prefix if present
    parts = version.split(".")  # Split version into parts (e.g., "1.2.3" -> ["1", "2", "3"])

    while (
        len(parts) < SEMANTIC_VERSION_PARTS
    ):  # Pad to 3 parts if needed (e.g., "1.2" -> ["1", "2", "0"])
        parts.append("0")

    parts = parts[:SEMANTIC_VERSION_PARTS]  # Take only first 3 parts (ignore extra parts)

    try:
        major, minor, patch = [int(p) for p in parts]  # Convert to integers
    except ValueError as e:  # Handle non-numeric parts
        raise ValueError(
            f"Invalid version format '{version}': all parts must be numeric. Error: {e}"
        ) from e

    if strategy == "patch":  # Increment patch version (1.2.3 -> 1.2.4)
        patch += 1
    elif strategy == "minor":  # Increment minor version (1.2.3 -> 1.3.0)
        minor += 1
        patch = 0  # Reset patch to 0
    elif strategy == "major":  # Increment major version (1.2.3 -> 2.0.0)
        major += 1
        minor = 0  # Reset minor to 0
        patch = 0  # Reset patch to 0
    else:
        raise ValueError(f"Invalid version increment strategy: {strategy}")

    return f"{major}.{minor}.{patch}"
