"""
Timing utilities for performance monitoring.
"""

import math
import time
from collections.abc import Generator
from contextlib import contextmanager
from typing import cast

from taxonomy_ontology_accelerator.commons.utils.logger import RichLogger, get_logger

logger = cast("RichLogger", get_logger())

# Time interval thresholds (in seconds)
SECONDS_PER_MINUTE = 60
SECONDS_PER_HOUR = 3600


# ========================================================================
# Time Formatting
# ========================================================================


def format_time_interval(seconds: float) -> str:
    """
    Format time interval in human-readable format.

    Args:
        seconds: Time in seconds

    Returns:
        Formatted string (e.g., "45s", "2.5m", "1.2h")
    """
    assert seconds >= 0, "Time interval must be non-negative"
    assert math.isfinite(seconds), "Time interval must be finite"

    if seconds < SECONDS_PER_MINUTE:
        return f"{seconds:.0f}s"
    if seconds < SECONDS_PER_HOUR:
        return f"{seconds / SECONDS_PER_MINUTE:.1f}m"
    return f"{seconds / SECONDS_PER_HOUR:.1f}h"


# ========================================================================
# Stage Timing Context Manager
# ========================================================================


@contextmanager
def stage_timer(
    stage_name: str, stage_num: int | None = None, total_stages: int | None = None
) -> Generator[None]:
    """
    Context manager for timing pipeline stages with consistent logging.

    Args:
        stage_name: Name of the stage (e.g., "Configuration loaded")
        stage_num: Optional stage number (e.g., 1)
        total_stages: Optional total number of stages (e.g., 9)

    Example:
        with stage_timer("Configuration loaded"):
            config = load_config()
    """
    assert stage_name is not None, "Stage name must not be None"
    assert isinstance(stage_name, str), "Stage name must be a string"

    start_time = time.time()  # Record start time
    stage_prefix = (
        f"[{stage_num}/{total_stages}]" if stage_num and total_stages else ""
    )  # Build prefix if stage info available

    try:
        yield  # Execute stage code
        elapsed = time.time() - start_time  # Calculate elapsed time
        if stage_prefix:  # Log with prefix if available
            assert stage_num is not None, "stage_num must be set when stage_prefix exists"
            assert total_stages is not None, "total_stages must be set when stage_prefix exists"
            logger.stage(stage_num, total_stages, f"{stage_name} completed in {elapsed:.2f}s")
        else:
            logger.complete(f"{stage_name} completed in {elapsed:.2f}s")
    except Exception as e:  # Handle stage failures
        elapsed = time.time() - start_time  # Calculate elapsed time even on failure
        if stage_prefix:  # Log error with prefix if available
            logger.error(f"{stage_prefix} {stage_name} failed after {elapsed:.2f}s | Error: {e}")
        else:
            logger.error(f"{stage_name} failed after {elapsed:.2f}s | Error: {e}")
        raise  # Re-raise exception
