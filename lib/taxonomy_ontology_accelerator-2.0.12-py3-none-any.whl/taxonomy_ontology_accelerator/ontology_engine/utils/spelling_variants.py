"""
Spelling variant conversion using localspelling library.

Simple wrapper around localspelling for UK/US spelling conversion.
Converts only spelling variants (e.g., "honour" vs "honor"),
not vocabulary differences (e.g., "pavement" vs "sidewalk").
"""
import re

from localspelling import convert_spelling as localspelling_convert
from localspelling.spelling_converter import get_dictionary

__all__ = ["convert_spelling", "convert_spelling_compound"]


def convert_spelling(
    text: str,
    from_variant: str,
    to_variant: str,
) -> str:
    """Convert text between spelling variants (US/UK/preserve).

    Uses localspelling library for accurate spelling conversion.
    Preserves case and only converts spelling variants, not vocabulary.

    Args:
        text: Text to convert
        from_variant: Source variant ("US" or "UK" or "preserve") - currently unused
        to_variant: Target variant ("US" or "UK" or "preserve")

    Returns:
        Converted text with target spelling variant

    Examples:
        >>> convert_spelling("The organization color", "US", "UK")
        'The organisation colour'
        >>> convert_spelling("behaviour analyse", "UK", "US")
        'behavior analyze'
        >>> convert_spelling("hello world", "US", "preserve")
        'hello world'
    """
    assert text is not None, "text must not be None"
    assert isinstance(text, str), "text must be a string"

    # Preserve means no conversion
    if from_variant == "preserve" or to_variant == "preserve":
        return text

    # Convert to target locale (localspelling uses "gb" for UK, "us" for US)
    target_locale = "gb" if to_variant == "UK" else "us"
    return localspelling_convert(text, target_locale)


_GB_US_SUPPLEMENT = {
    "dependant": "dependent",
    "dependants": "dependents",
    "licence": "license",
    "licences": "licenses",
    "programme": "program",
    "programmes": "programs",
    "fulfils": "fulfills",
    "fulfilment": "fulfillment",
    "fulfilments": "fulfillments",
}

_COMMON_TYPO_SUPPLEMENT = {
    "maximom": "maximum",
    "minimom": "minimum",
}

_MIN_COMPOUND_MATCH_LENGTH = 4


def _build_no_boundary_pattern(dictionary: dict) -> re.Pattern:
    """Single-pass regex for compound strings — no \\b, longest match first."""
    keys = sorted(dictionary, key=len, reverse=True)
    return re.compile("(?i)" + "|".join(re.escape(k) for k in keys))


def _build_word_boundary_pattern(dictionary: dict) -> re.Pattern:
    """Regex for exact token replacement with word boundaries."""
    keys = sorted(dictionary, key=len, reverse=True)
    return re.compile(r"\b(" + "|".join(re.escape(k) for k in keys) + r")\b", re.IGNORECASE)


def _preserve_case(word: str, replacement: str) -> str:
    """Apply a replacement while preserving the source token's case style."""
    if word == word.upper():
        return replacement.upper()
    if word[0].isupper():
        return replacement.capitalize()
    return replacement


def _build_spelling_dictionary(to_variant: str) -> dict[str, str]:
    """Build the exact replacement dictionary for a target spelling variant."""
    locale = "gb" if to_variant == "UK" else "us"
    merged = dict(get_dictionary(locale))
    merged.update(_COMMON_TYPO_SUPPLEMENT)
    if to_variant == "US":
        merged.update(_GB_US_SUPPLEMENT)
    elif to_variant == "UK":
        merged.update({v: k for k, v in _GB_US_SUPPLEMENT.items()})
    return merged


def _apply_exact_token_replacements(text: str, dictionary: dict[str, str]) -> str:
    """Replace whole-word tokens exactly without touching substrings inside words."""
    pattern = _build_word_boundary_pattern(dictionary)

    def _replace(match: re.Match) -> str:
        word = match.group(0)
        replacement = dictionary.get(word.lower(), word)
        return _preserve_case(word, replacement)

    return pattern.sub(_replace, text)


def convert_spelling_compound(text: str, to_variant: str) -> str:
    """Convert spelling in compound strings without requiring word boundaries.

    Use for canonical_keys or other run-on strings where localspelling's
    \\b word-boundary matching fails (e.g. 'labourmarketconsideration').
    Uses a single-pass regex (longest match first) to avoid cascading
    replacements (e.g. 'enrolment' is consumed before 'enrol' can fire).
    Also applies _GB_US_SUPPLEMENT for words absent from localspelling.

    Args:
        text: Text to convert
        to_variant: Target variant ("US" or "UK" or "preserve")

    Returns:
        Converted text with target spelling variant
    """
    assert text is not None, "text must not be None"
    assert isinstance(text, str), "text must be a string"

    if to_variant == "preserve":
        return text

    merged = _build_spelling_dictionary(to_variant)

    # When text already has word boundaries, prefer exact token conversion so
    # short spelling entries such as "mum -> mom" do not fire inside
    # unrelated words like "maximum".
    if re.search(r"[\s_\-./]", text):
        locale = "gb" if to_variant == "UK" else "us"
        converted = localspelling_convert(text, locale)
        return _apply_exact_token_replacements(converted, merged)

    exact_replacement = merged.get(text.lower())
    if exact_replacement is not None:
        return _preserve_case(text, exact_replacement)

    compound_dictionary = {
        key: value for key, value in merged.items() if len(key) >= _MIN_COMPOUND_MATCH_LENGTH
    }
    pattern = _build_no_boundary_pattern(compound_dictionary)

    def _replace(match: re.Match) -> str:
        word = match.group(0)
        replacement = compound_dictionary.get(word.lower(), word)
        return _preserve_case(word, replacement)

    return pattern.sub(_replace, text)
