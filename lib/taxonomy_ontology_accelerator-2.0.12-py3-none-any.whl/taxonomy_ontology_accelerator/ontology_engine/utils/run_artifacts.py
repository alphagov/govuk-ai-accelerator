import contextlib
import re
import shutil
import subprocess
import sys
from datetime import datetime
from io import StringIO
from pathlib import Path
from typing import Any

import fsspec
from fsspec import AbstractFileSystem

from taxonomy_ontology_accelerator.commons.io.file_utils import (
    canonicalize_listed_path,
    join_path,
    safe_write_file,
)
from taxonomy_ontology_accelerator.commons.utils.logger import get_logger

CANONICAL_RUN_PATTERN = re.compile(r"^run-(\d{8})-(\d+)$")
LEGACY_RUN_PATTERN = re.compile(r"^run-(\d+)-")


def get_current_commit_hash() -> str:
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--short", "HEAD"],
            check=True,
            capture_output=True,
            text=True,
        )
        commit_hash = result.stdout.strip()
        return commit_hash if commit_hash else "unknown"
    except Exception:
        return "unknown"


def extract_run_sequence(name: str) -> int | None:
    assert isinstance(name, str), "name must be a string"

    canonical_match = CANONICAL_RUN_PATTERN.match(name)
    if canonical_match:
        return int(canonical_match.group(2))

    legacy_match = LEGACY_RUN_PATTERN.match(name)
    if legacy_match:
        return int(legacy_match.group(1))

    return None


def build_next_run_name(existing_names: list[str]) -> str:
    assert isinstance(existing_names, list), "existing_names must be a list"
    max_run_number = 0
    for name in existing_names:
        run_sequence = extract_run_sequence(name)
        if run_sequence is not None:
            max_run_number = max(max_run_number, run_sequence)

    next_run_number = max_run_number + 1
    now = datetime.now()
    date_part = now.strftime("%Y%m%d")
    return f"run-{date_part}-{next_run_number}"


def allocate_run_output_dir(
    current_output_dir: str | Path,
    domain: str,
    fs: AbstractFileSystem,
) -> str | Path:
    assert current_output_dir is not None, "current_output_dir must not be None"
    assert domain, "domain must not be empty"
    assert fs is not None, "fs must not be None"

    output_str = str(current_output_dir).rstrip("/")
    parts = output_str.split("/")

    if len(parts) >= 2 and parts[-1] == "output" and CANONICAL_RUN_PATTERN.match(parts[-2]):
        return current_output_dir
    if len(parts) >= 2 and parts[-1] == "output" and parts[-2] == domain:
        run_root = "/".join(parts[:-1])
    elif parts[-1] == domain:
        run_root = output_str
    else:
        run_root = f"{output_str}/{domain}"

    fs.makedirs(run_root, exist_ok=True)

    existing_names: list[str] = []
    try:
        items = fs.ls(run_root, detail=True)
    except FileNotFoundError:
        items = []
    for item in items:
        if isinstance(item, dict):
            name = str(item.get("name", "")).rstrip("/").split("/")[-1]
            if item.get("type") == "directory" and name:
                existing_names.append(name)
        else:
            name = str(item).rstrip("/").split("/")[-1]
            if name:
                existing_names.append(name)

    run_name = build_next_run_name(existing_names)
    allocated = f"{run_root}/{run_name}/output"
    if isinstance(current_output_dir, Path):
        return Path(allocated)
    return allocated


def run_snapshot_dir_from_output_dir(output_dir: str | Path) -> str | Path:
    """Return the run root for a resolved output directory."""
    assert output_dir is not None, "output_dir must not be None"

    if isinstance(output_dir, Path):
        return output_dir.parent if output_dir.name == "output" else output_dir

    normalized_output = output_dir.rstrip("/")
    if normalized_output.split("/")[-1] == "output":
        return normalized_output.rsplit("/", 1)[0]
    return normalized_output


def _basename(path: str | Path) -> str:
    assert path is not None, "path must not be None"
    return str(path).rstrip("/").split("/")[-1]


def _copy_file_between_filesystems(
    source_path: str | Path,
    destination_path: str | Path,
    *,
    source_fs: AbstractFileSystem,
    destination_fs: AbstractFileSystem,
) -> None:
    parent_dir = (
        destination_path.parent
        if isinstance(destination_path, Path)
        else destination_path.rsplit("/", 1)[0]
    )
    destination_fs.makedirs(str(parent_dir), exist_ok=True)
    with source_fs.open(str(source_path), "rb") as src, destination_fs.open(
        str(destination_path), "wb"
    ) as dst:
        shutil.copyfileobj(src, dst)


def _copy_tree_between_filesystems(
    source_dir: str | Path,
    destination_dir: str | Path,
    *,
    source_fs: AbstractFileSystem,
    destination_fs: AbstractFileSystem,
) -> None:
    destination_fs.makedirs(str(destination_dir), exist_ok=True)

    for item in source_fs.ls(str(source_dir), detail=True):
        if isinstance(item, dict):
            source_child = canonicalize_listed_path(str(item.get("name", "")), source_dir)
            item_type = item.get("type")
        else:
            source_child = canonicalize_listed_path(str(item), source_dir)
            item_type = source_fs.info(str(source_child)).get("type")

        if not source_child:
            continue

        destination_child = join_path(destination_dir, _basename(source_child))
        if item_type == "directory":
            _copy_tree_between_filesystems(
                source_child,
                destination_child,
                source_fs=source_fs,
                destination_fs=destination_fs,
            )
            continue

        _copy_file_between_filesystems(
            source_child,
            destination_child,
            source_fs=source_fs,
            destination_fs=destination_fs,
        )


def copy_path_between_filesystems(
    source_path: str | Path,
    destination_path: str | Path,
    *,
    source_fs: AbstractFileSystem,
    destination_fs: AbstractFileSystem,
) -> None:
    """Copy a file or directory between arbitrary fsspec filesystems."""
    assert source_path is not None, "source_path must not be None"
    assert destination_path is not None, "destination_path must not be None"

    source_str = str(source_path)
    fs = source_fs
    if not fs.exists(source_str):
        return

    if fs.isdir(source_str):
        _copy_tree_between_filesystems(
            source_path,
            destination_path,
            source_fs=source_fs,
            destination_fs=destination_fs,
        )
        return

    _copy_file_between_filesystems(
        source_path,
        destination_path,
        source_fs=source_fs,
        destination_fs=destination_fs,
    )


def prepare_run_snapshot(
    run_snapshot_dir: str | Path,
    destination_fs: AbstractFileSystem,
    *,
    input_path: str | Path | None = None,
    prompt_path: str | Path | None = None,
    config_path: str | Path | None = None,
    config_text: str | None = None,
    prompt_text: str | None = None,
    source_fs: AbstractFileSystem | None = None,
) -> None:
    """Materialize CLI-style run snapshot artifacts in the target run directory."""
    assert run_snapshot_dir is not None, "run_snapshot_dir must not be None"
    assert destination_fs is not None, "destination_fs must not be None"

    source_fs = source_fs or destination_fs
    destination_fs.makedirs(str(run_snapshot_dir), exist_ok=True)
    fs = source_fs

    if input_path is not None and fs.exists(str(input_path)):
        input_destination = join_path(run_snapshot_dir, "input")
        if fs.isdir(str(input_path)):
            copy_path_between_filesystems(
                input_path,
                input_destination,
                source_fs=source_fs,
                destination_fs=destination_fs,
            )
        else:
            copy_path_between_filesystems(
                input_path,
                join_path(input_destination, _basename(input_path)),
                source_fs=source_fs,
                destination_fs=destination_fs,
            )

    if prompt_path is not None and fs.exists(str(prompt_path)):
        prompts_destination = join_path(run_snapshot_dir, "prompts")
        if fs.isdir(str(prompt_path)):
            copy_path_between_filesystems(
                prompt_path,
                prompts_destination,
                source_fs=source_fs,
                destination_fs=destination_fs,
            )
        else:
            copy_path_between_filesystems(
                prompt_path,
                join_path(prompts_destination, _basename(prompt_path)),
                source_fs=source_fs,
                destination_fs=destination_fs,
            )
    elif prompt_text:
        safe_write_file(
            join_path(run_snapshot_dir, "prompts", "prompt.txt"),
            prompt_text,
            fs=destination_fs,
        )

    if config_path is not None and fs.exists(str(config_path)):
        copy_path_between_filesystems(
            config_path,
            join_path(run_snapshot_dir, "config.yaml"),
            source_fs=source_fs,
            destination_fs=destination_fs,
        )
    elif config_text:
        safe_write_file(
            join_path(run_snapshot_dir, "config.yaml"),
            config_text,
            fs=destination_fs,
        )

    destination_fs.makedirs(str(join_path(run_snapshot_dir, "output")), exist_ok=True)


@contextlib.contextmanager
def capture_run_logs_to_stream(stream: StringIO, consoles: list[Any] | None = None):
    ansi_pattern = re.compile(r"\x1B\[[0-?]*[ -/]*[@-~]")
    spinner_prefix_pattern = re.compile(r"^[\u2800-\u28ff]\s+Extracting ontology\.\.\.")

    class _TimestampedStreamWriter:
        def __init__(self, stream_obj):
            self.stream_obj = stream_obj
            self._line_buffer = ""

        def _write_line(self, line: str):
            cleaned = ansi_pattern.sub("", line).replace("\r", "")
            cleaned = spinner_prefix_pattern.sub("", cleaned, count=1).lstrip()
            if not cleaned.strip():
                return
            ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            self.stream_obj.write(f"[{ts}] {cleaned.rstrip()}\n")

        def write(self, data: str):
            if not data:
                return 0

            chunk = ansi_pattern.sub("", data)
            chunk = chunk.replace("\r\n", "\n").replace("\r", "\n")
            self._line_buffer += chunk

            while "\n" in self._line_buffer:
                line, self._line_buffer = self._line_buffer.split("\n", 1)
                self._write_line(line)
            return len(data)

        def flush(self):
            if self._line_buffer:
                self._write_line(self._line_buffer)
                self._line_buffer = ""
            self.stream_obj.flush()

    class _TeeWriter:
        def __init__(self, primary, secondary):
            self.primary = primary
            self.secondary = secondary

        def write(self, data):
            self.primary.write(data)
            self.secondary.write(data)
            return len(data)

        def flush(self):
            self.primary.flush()
            self.secondary.flush()

        def __getattr__(self, name):
            return getattr(self.primary, name)

    shared_logger = get_logger()
    consoles = consoles or []
    original_console_files = []

    timestamped_stream = _TimestampedStreamWriter(stream)
    tee_stdout = _TeeWriter(sys.stdout, timestamped_stream)
    tee_stderr = _TeeWriter(sys.stderr, timestamped_stream)

    original_shared_logger_console_file = shared_logger.console.file
    shared_logger.console.file = tee_stdout

    try:
        for console in consoles:
            original_console_files.append((console, console.file))
            console.file = tee_stdout

        with contextlib.redirect_stdout(tee_stdout), contextlib.redirect_stderr(tee_stderr):
            yield
    finally:
        timestamped_stream.flush()
        for console, original_file in original_console_files:
            console.file = original_file
        shared_logger.console.file = original_shared_logger_console_file


@contextlib.contextmanager
def capture_run_logs(log_path: Path, consoles: list[Any] | None = None):
    fs = fsspec.filesystem("file")
    fs.makedirs(str(log_path.parent), exist_ok=True)

    with log_path.open("a", encoding="utf-8") as log_file:
        with capture_run_logs_to_stream(log_file, consoles=consoles):
            yield
