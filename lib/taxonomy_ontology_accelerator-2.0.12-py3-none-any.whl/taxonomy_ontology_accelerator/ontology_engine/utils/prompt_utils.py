"""Utility functions for loading and working with prompts."""

from pathlib import Path

from fsspec import AbstractFileSystem

from taxonomy_ontology_accelerator.commons.io.file_utils import safe_read_file
from taxonomy_ontology_accelerator.commons.utils.logger import get_logger

logger = get_logger()


def load_prompt(prompt_path: str | Path, fs: AbstractFileSystem | None = None) -> str:
    """
    Load prompt from file.

    Simple file reader for prompt files. Use with pydantic-ai decorators to compose prompts.

    Args:
        prompt_path: Path to prompt file (string or Path object)
        fs: Optional filesystem instance for dependency injection (defaults to local filesystem)

    Returns:
        Prompt string

    Raises:
        OSError: If prompt file cannot be read
        ValueError: If prompt file is empty
    """
    assert prompt_path is not None, "Prompt path must not be None"
    assert isinstance(prompt_path, (str, Path)), "Prompt path must be string or Path"

    if isinstance(prompt_path, str) and fs is None:
        prompt_path = Path(prompt_path)

    logger.debug(f"Loading prompt from: {prompt_path}")

    try:
        prompt = safe_read_file(prompt_path, fs=fs)
    except (OSError, FileNotFoundError) as e:
        msg = f"Failed to read prompt file {prompt_path}: {e}\nCheck file permissions and path."
        raise OSError(msg) from e

    if not prompt or not prompt.strip():
        raise ValueError(f"Prompt file is empty: {prompt_path}\nAdd prompt content.")

    return prompt


def inject_source_annotations(batch_chunks: list[str], chunk_sources: list[str]) -> str:
    """
    Inject source annotations into chunks for source grounding.

    Args:
        batch_chunks: List of text chunks
        chunk_sources: List of source identifiers

    Returns:
        Annotated text with source metadata
    """
    assert batch_chunks is not None, "Batch chunks must not be None"
    assert chunk_sources is not None, "Chunk sources must not be None"

    source_annotated_chunks: list[str] = []
    for chunk_idx, chunk in enumerate(batch_chunks):
        source_id = (
            chunk_sources[chunk_idx]
            if chunk_idx < len(chunk_sources)
            else f"unknown_source_{chunk_idx}"
        )
        source_annotated_chunks.append(
            f"SOURCE_URLS: {source_id}\nCHUNK_INDEX: {chunk_idx}\n{chunk}"
        )
    return "\n\n---DOCUMENT_SEPARATOR---\n\n".join(source_annotated_chunks)
