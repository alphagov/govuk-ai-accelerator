"""
Memory estimation and checking utilities for ontology extraction.

Provides memory estimation for graph, embeddings, and FAISS index loading,
with fail-fast checks to prevent out-of-memory crashes.
"""

import contextlib
import platform
import subprocess
from typing import TYPE_CHECKING

import fsspec

from taxonomy_ontology_accelerator.commons.utils.logger import get_logger

logger = get_logger()

# Optional dependency: psutil for accurate memory checking
try:
    import psutil  # pyright: ignore[reportMissingModuleSource]

    _psutil_available = True
except ImportError:
    psutil = None  # type: ignore[assignment]
    _psutil_available = False

PSUTIL_AVAILABLE = _psutil_available

# Thresholds for memory estimation
LARGE_GRAPH_ENTITY_THRESHOLD = 10000  # Entity count threshold for additional overhead
VERY_LARGE_GRAPH_ENTITY_THRESHOLD = 50000  # Entity count threshold for relationship overhead

if TYPE_CHECKING:
    from taxonomy_ontology_accelerator.ontology_engine.config.config import OntologyConfig


# ========================================================================
# Memory Availability Checking
# ========================================================================


def get_available_memory() -> int | None:
    """
    Get available system memory in MB.

    Returns:
        Available memory in MB, or None if unavailable
    """
    assert isinstance(PSUTIL_AVAILABLE, bool), "PSUTIL_AVAILABLE must be boolean"

    if PSUTIL_AVAILABLE:
        assert psutil is not None, "psutil must be available when PSUTIL_AVAILABLE is True"
        try:
            mem = psutil.virtual_memory()
            return int(mem.available / (1024 * 1024))  # pyright: ignore[reportAny]
        except Exception as e:
            logger.debug(f"Failed to get available memory via psutil: {e}")

    # Fallback: platform-specific methods (less accurate)
    try:
        system = platform.system()
        if system == "Linux":
            # Read from /proc/meminfo
            try:
                fs = fsspec.filesystem("file")
                with fs.open("/proc/meminfo", "r") as f:
                    for line in f:
                        if line.startswith("MemAvailable:"):
                            kb = int(line.split()[1])
                            return kb // 1024
            except (OSError, ValueError):
                pass
        elif system == "Darwin":  # macOS
            # Use vm_stat command
            with contextlib.suppress(subprocess.CalledProcessError, FileNotFoundError):
                _ = subprocess.run(["vm_stat"], capture_output=True, text=True, check=True)
                # Parse vm_stat output (complex, approximate)
                # For simplicity, return None if psutil unavailable
        # Windows: Would need wmi or similar, skip for now
    except Exception as e:
        logger.debug(f"Failed to get available memory via platform method: {e}")

    return None


# ========================================================================
# Memory Estimation Functions
# ========================================================================


def estimate_graph_memory(file_size_mb: float, entity_count: int | None = None) -> int:
    """
    Estimate memory needed to load graph.json (in MB).

    Optimized for large graphs (100k+ nodes): uses entity count for more accurate
    estimation when available, accounting for Python object overhead.

    Args:
        file_size_mb: Graph JSON file size in MB
        entity_count: Optional entity count for more accurate estimation (recommended for 10k+ entities)

    Returns:
        Estimated memory in MB
    """
    assert file_size_mb is not None, "File size must not be None"
    assert isinstance(file_size_mb, int | float), "File size must be numeric"
    assert file_size_mb >= 0, "File size must be non-negative"

    # JSON parsing creates ~2x memory overhead (string + parsed objects)
    base_estimate = int(file_size_mb * 2.0)

    # Pydantic model overhead: ~20-30% additional
    pydantic_overhead = int(base_estimate * 0.25)

    # Additional overhead for entity maps, sets, caches built during loading
    if entity_count and entity_count > LARGE_GRAPH_ENTITY_THRESHOLD:
        # Large graphs: overhead scales with entity count (more maps, sets, caches)
        processing_overhead = 50 + int((entity_count / 1000) * 0.5)  # ~0.5MB per 1k entities
    else:
        processing_overhead = 50  # MB

    total = base_estimate + pydantic_overhead + processing_overhead

    # If entity count available, refine estimate
    if entity_count:
        # Rough estimate: ~2-5KB per entity (label, type, properties, metadata)
        # Convert KB to MB: 3KB per entity = 3/1024 MB per entity
        entity_memory_mb = int((entity_count * 3) / 1024)  # 3KB per entity
        # For very large graphs, add relationship overhead
        if entity_count > VERY_LARGE_GRAPH_ENTITY_THRESHOLD:
            # Estimate ~1 relationship per entity on average for large graphs
            relationship_overhead_mb = int((entity_count * 2) / 1024)  # ~2KB per relationship
            entity_memory_mb += relationship_overhead_mb
        # Use higher of file-based or entity-based estimate
        total = max(total, entity_memory_mb)

    return total


def estimate_embeddings_memory(entity_count: int, embedding_dimension: int = 768) -> int:
    """
    Estimate memory needed for embeddings (in MB).

    Args:
        entity_count: Number of entities with embeddings
        embedding_dimension: Embedding dimension (default: 768 for all-mpnet-base-v2)

    Returns:
        Estimated memory in MB
    """
    assert entity_count is not None, "Entity count must not be None"
    assert isinstance(entity_count, int), "Entity count must be an integer"
    assert entity_count >= 0, "Entity count must be non-negative"

    # Each embedding: dimension x 4 bytes (float32)
    embedding_size_bytes = embedding_dimension * 4

    # Dict overhead: ~10-20% for keys and structure
    dict_overhead = 1.15

    # Total per entity
    bytes_per_entity = embedding_size_bytes * dict_overhead

    # Convert to MB
    return int((entity_count * bytes_per_entity) / (1024 * 1024))


def estimate_faiss_memory(
    entity_count: int, index_type: str = "IndexFlatL2", embedding_dimension: int = 768
) -> int:
    """
    Estimate memory needed for FAISS index (in MB).

    Args:
        entity_count: Number of entities
        index_type: FAISS index type
        embedding_dimension: Embedding dimension (default: 768)

    Returns:
        Estimated memory in MB
    """
    assert entity_count is not None, "Entity count must not be None"
    assert isinstance(entity_count, int), "Entity count must be an integer"
    assert index_type is not None, "Index type must not be None"

    # Base: embeddings in index (same as embeddings memory)
    base_memory = estimate_embeddings_memory(entity_count, embedding_dimension)

    # Index overhead depends on type (FAISS index structures add memory overhead)
    if index_type == "IndexFlatL2":
        # Exact search: minimal overhead (~same as embeddings, no additional structures)
        overhead_multiplier = 1.0  # No overhead (exact search)
    elif index_type == "IndexIVFFlat":
        # Approximate: ~10-20% overhead (inverted file index for clustering)
        overhead_multiplier = 1.15  # 15% overhead (conservative estimate)
    elif index_type == "IndexHNSW":
        # Hierarchical: ~30-50% overhead (hierarchical navigable small world graph)
        overhead_multiplier = 1.4  # 40% overhead (conservative estimate)
    else:
        # Default: conservative estimate (unknown index type)
        overhead_multiplier = 1.2  # 20% overhead (safe default)

    return int(base_memory * overhead_multiplier)


def estimate_total_memory(
    graph_file_size_mb: float | None = None,
    graph_entity_count: int | None = None,
    embeddings_entity_count: int | None = None,
    use_faiss: bool = False,
    faiss_index_type: str = "IndexFlatL2",
    embedding_dimension: int = 768,
) -> int:
    """
    Estimate total memory needed for ontology extraction (in MB).

    Args:
        graph_file_size_mb: Graph JSON file size in MB
        graph_entity_count: Number of entities in graph
        embeddings_entity_count: Number of entities with embeddings
        use_faiss: Whether FAISS index will be used
        faiss_index_type: FAISS index type if used
        embedding_dimension: Embedding dimension (default: 768)

    Returns:
        Total estimated memory in MB
    """
    assert isinstance(use_faiss, bool), "use_faiss must be a boolean"
    assert faiss_index_type is not None, "FAISS index type must not be None"

    total = 0  # Initialize total memory estimate

    # Graph memory (loaded graph data structures)
    if graph_file_size_mb is not None:  # Graph file size provided
        total += estimate_graph_memory(
            graph_file_size_mb, graph_entity_count
        )  # Add graph memory estimate

    # Embeddings memory (embedding vectors)
    if embeddings_entity_count is not None:  # Embedding count provided
        total += estimate_embeddings_memory(
            embeddings_entity_count, embedding_dimension
        )  # Add embeddings memory estimate

    # FAISS index memory (index structures for similarity search)
    if use_faiss and embeddings_entity_count is not None:  # FAISS enabled and count provided
        total += estimate_faiss_memory(
            embeddings_entity_count, faiss_index_type, embedding_dimension
        )  # Add FAISS index memory estimate

    # Processing overhead (new entities, caches, temporary structures, etc.)
    processing_overhead = 500  # MB (conservative estimate for processing overhead)
    total += processing_overhead  # Add overhead to total

    return total


# ========================================================================
# Memory Checking Functions
# ========================================================================


def _get_max_usage_limit(available_mb: int, config_max_usage_mb: int | None) -> int:
    """
    Get maximum memory usage limit in MB.

    Args:
        available_mb: Available memory in MB
        config_max_usage_mb: Configured max usage from config (or None)

    Returns:
        Maximum usage limit in MB
    """
    assert available_mb is not None, "Available MB must not be None"
    assert isinstance(available_mb, int), "Available MB must be an integer"

    if config_max_usage_mb is None:
        return int(available_mb * 0.8)
    return config_max_usage_mb


def _get_warn_threshold(available_mb: int, config_warn_threshold_mb: int | None) -> int:
    """
    Get memory warning threshold in MB.

    Args:
        available_mb: Available memory in MB
        config_warn_threshold_mb: Configured warning threshold from config (or None)

    Returns:
        Warning threshold in MB
    """
    assert available_mb is not None, "Available MB must not be None"
    assert isinstance(available_mb, int), "Available MB must be an integer"

    if config_warn_threshold_mb is None:
        return int(available_mb * 0.7)
    return config_warn_threshold_mb


def _check_memory_sufficient(
    required_mb: int,
    max_usage_mb: int,
    available_mb: int,
    component: str,
    estimated_mb: int,
    safety_margin_mb: int,
) -> None:
    """
    Check if required memory is within limits.

    Args:
        required_mb: Required memory (estimated + safety margin)
        max_usage_mb: Maximum allowed memory usage
        available_mb: Available memory
        component: Component name for error messages
        estimated_mb: Estimated memory needed
        safety_margin_mb: Safety margin

    Raises:
        MemoryError: If insufficient memory available
    """
    assert required_mb is not None, "Required MB must not be None"
    assert max_usage_mb is not None, "Max usage MB must not be None"

    if required_mb > max_usage_mb:
        msg = (
            f"Insufficient memory to load {component}. "
            f"Estimated need: {estimated_mb}MB + safety margin {safety_margin_mb}MB = {required_mb}MB. "
            f"Available: {available_mb}MB, Maximum allowed: {max_usage_mb}MB. "
            f"Reduce entity count, disable embedding cache, or increase available RAM. "
            f"Configure memory limits in config.yaml: memory.max_usage_mb"
        )
        raise MemoryError(msg)


def check_memory_available(
    estimated_mb: int,
    config: "OntologyConfig",
    component: str,
) -> None:
    """
    Check if sufficient memory is available before loading data.

    Raises MemoryError with clear message if insufficient memory.

    Args:
        estimated_mb: Estimated memory needed in MB
        config: Ontology configuration
        component: Component name for error messages (e.g., "graph", "embeddings")

    Raises:
        MemoryError: If insufficient memory available
    """
    assert estimated_mb is not None, "Estimated MB must not be None"
    assert isinstance(estimated_mb, int), "Estimated MB must be an integer"
    assert config is not None, "Config must not be None"

    if not config.memory.check_available:
        return

    available_mb = get_available_memory()

    if available_mb is None:
        msg = (
            f"Cannot determine available memory. Estimated {estimated_mb}MB needed for {component}. "
            f"Proceeding with caution. Install psutil for accurate memory checking: pip install psutil"
        )
        logger.warning(msg)
        return

    safety_margin_mb = config.memory.safety_margin_mb
    required_mb = estimated_mb + safety_margin_mb

    max_usage_mb = _get_max_usage_limit(available_mb, config.memory.max_usage_mb)

    _check_memory_sufficient(
        required_mb, max_usage_mb, available_mb, component, estimated_mb, safety_margin_mb
    )

    warn_threshold_mb = _get_warn_threshold(available_mb, config.memory.warn_threshold_mb)

    if required_mb > warn_threshold_mb:
        msg = (
            f"High memory usage for {component}: {required_mb}MB estimated "
            f"({required_mb / available_mb * 100:.1f}% of available {available_mb}MB). "
            f"Consider reducing entity count or disabling embedding cache."
        )
        logger.warning(msg)
