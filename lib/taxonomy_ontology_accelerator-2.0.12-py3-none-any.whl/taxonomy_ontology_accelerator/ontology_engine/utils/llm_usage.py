"""Compatibility helpers for reading and estimating LLM usage."""

import json
from typing import Any

from pydantic_ai.usage import RunUsage

from taxonomy_ontology_accelerator.ontology_engine.utils.validation import estimate_tokens

ESTIMATED_USAGE_FLAG = "is_estimated_missing_llm_usage"
ESTIMATED_USAGE_CALLS = "estimated_missing_llm_usage_calls"


def get_llm_result_usage(result: Any) -> Any:
    """Return usage from PydanticAI result objects across API versions."""
    if result is None:
        return None

    usage = getattr(result, "usage", None)
    if usage is None:
        return None
    if callable(usage):
        return usage()
    return usage


def llm_usage_token_sum(usage: Any) -> int:
    """Return the sum of token counters on a PydanticAI usage-like object."""
    if usage is None:
        return 0
    return sum(
        int(getattr(usage, attr, 0) or 0)
        for attr in (
            "input_tokens",
            "output_tokens",
            "cache_read_tokens",
            "cache_write_tokens",
        )
    )


def is_estimated_llm_usage(usage: Any) -> bool:
    """Return true when the usage was estimated because provider usage was missing."""
    return bool(getattr(usage, ESTIMATED_USAGE_FLAG, False))


def estimated_llm_usage_calls(usage: Any) -> int:
    """Return the number of missing-usage calls represented by a usage object."""
    if not is_estimated_llm_usage(usage):
        return 0
    return int(getattr(usage, ESTIMATED_USAGE_CALLS, 1) or 1)


def _mark_estimated_usage(usage: RunUsage, calls: int = 1) -> RunUsage:
    setattr(usage, ESTIMATED_USAGE_FLAG, True)
    setattr(usage, ESTIMATED_USAGE_CALLS, calls)
    return usage


def combine_llm_usage(left: Any, right: Any) -> RunUsage:
    """Combine actual or estimated usage objects without losing estimate markers."""
    combined = RunUsage(
        input_tokens=int(getattr(left, "input_tokens", 0) or 0)
        + int(getattr(right, "input_tokens", 0) or 0),
        output_tokens=int(getattr(left, "output_tokens", 0) or 0)
        + int(getattr(right, "output_tokens", 0) or 0),
        cache_read_tokens=int(getattr(left, "cache_read_tokens", 0) or 0)
        + int(getattr(right, "cache_read_tokens", 0) or 0),
        cache_write_tokens=int(getattr(left, "cache_write_tokens", 0) or 0)
        + int(getattr(right, "cache_write_tokens", 0) or 0),
    )
    missing_calls = estimated_llm_usage_calls(left) + estimated_llm_usage_calls(right)
    if missing_calls:
        _mark_estimated_usage(combined, missing_calls)
    return combined


def get_or_estimate_llm_result_usage(result: Any, prompt: str, config: Any) -> Any:
    """Return provider usage, or estimate prompt/output tokens when usage is missing."""
    usage = get_llm_result_usage(result)
    if llm_usage_token_sum(usage) > 0:
        return usage

    chars_per_token = int(
        getattr(config.text_processing.chunking, "chars_per_token_estimate", 4) or 4
    )
    input_tokens = max(1, estimate_tokens(prompt, chars_per_token))
    output_tokens = _estimate_output_tokens_from_result(result, chars_per_token)
    if output_tokens <= 0:
        output_tokens = max(1, int(input_tokens * 0.25))
        max_tokens = int(getattr(config.llm, "max_tokens", 0) or 0)
        if max_tokens > 0:
            output_tokens = min(output_tokens, max_tokens)

    return _mark_estimated_usage(
        RunUsage(input_tokens=input_tokens, output_tokens=output_tokens),
    )


def _estimate_output_tokens_from_result(result: Any, chars_per_token: int) -> int:
    raw_output = getattr(result, "output", None)
    if raw_output is None:
        raw_output = getattr(result, "data", None)
    if raw_output is None:
        return 0
    if isinstance(raw_output, str):
        output_text = raw_output
    elif hasattr(raw_output, "model_dump_json"):
        output_text = raw_output.model_dump_json()
    elif hasattr(raw_output, "model_dump"):
        output_text = json.dumps(raw_output.model_dump(), default=str)
    else:
        output_text = str(raw_output)
    return max(1, estimate_tokens(output_text, chars_per_token)) if output_text else 0
