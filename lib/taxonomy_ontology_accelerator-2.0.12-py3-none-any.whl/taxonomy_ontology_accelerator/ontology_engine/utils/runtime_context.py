from __future__ import annotations

from contextvars import ContextVar, Token
from pathlib import Path

_worker_tag: ContextVar[str | None] = ContextVar("toa_worker_tag", default=None)
_source_file: ContextVar[str | None] = ContextVar("toa_source_file", default=None)


def set_runtime_context(worker_tag: str | None, source_file: str | None) -> tuple[Token, Token]:
    return _worker_tag.set(worker_tag), _source_file.set(source_file)


def reset_runtime_context(tokens: tuple[Token, Token]) -> None:
    worker_token, source_token = tokens
    _worker_tag.reset(worker_token)
    _source_file.reset(source_token)


def format_runtime_prefix() -> str:
    worker_tag = _worker_tag.get()
    source_file = _source_file.get()
    if not worker_tag and not source_file:
        return ""
    if worker_tag and source_file:
        return f"[{worker_tag}|{Path(source_file).name}] "
    if worker_tag:
        return f"[{worker_tag}] "
    return f"[{Path(source_file).name}] "
