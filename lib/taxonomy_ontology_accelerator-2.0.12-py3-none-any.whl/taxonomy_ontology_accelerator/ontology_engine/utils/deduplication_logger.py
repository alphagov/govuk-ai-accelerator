"""
Deduplication logging utilities.

Emits structured logs for entity merge decisions during deduplication.
Outputs JSONL log (one merge per line) and JSON summary with statistics.
"""

from pathlib import Path

from fsspec import AbstractFileSystem
from pydantic import BaseModel, Field

from taxonomy_ontology_accelerator.commons.io.file_utils import (
    join_path,
    safe_write_json,
    safe_write_jsonl,
)
from taxonomy_ontology_accelerator.commons.utils.logger import get_logger
from taxonomy_ontology_accelerator.ontology_engine.core.models import (
    DeduplicationSummary,
    MergeDecision,
)

logger = get_logger()


class DeduplicationLogConfig(BaseModel):
    """Configuration for deduplication log emission."""

    log_filename: str = Field(default="deduplication.jsonl")
    summary_filename: str = Field(default="deduplication_summary.json")
    fs: AbstractFileSystem | None = Field(default=None)

    model_config = {"arbitrary_types_allowed": True}


def emit_deduplication_logs(
    merge_decisions: list[MergeDecision],
    total_before: int,
    total_after: int,
    output_dir: Path | str,
    config: DeduplicationLogConfig | None = None,
) -> tuple[Path | str, Path | str]:
    """
    Emit deduplication logs and summary to output directory.

    Args:
        merge_decisions: List of merge decisions from deduplication
        total_before: Total entities before deduplication
        total_after: Total entities after deduplication
        output_dir: Directory to write logs
        config: Optional configuration (filenames and filesystem)

    Returns:
        Tuple of (log_path, summary_path)

    Raises:
        OSError: If files cannot be written
    """
    assert merge_decisions is not None, "Merge decisions must not be None"
    assert isinstance(merge_decisions, list), "Merge decisions must be a list"
    assert total_before >= 0, "Total before must be non-negative"
    assert total_after >= 0, "Total after must be non-negative"
    assert output_dir is not None, "Output directory must not be None"
    cfg = config or DeduplicationLogConfig()

    log_path = join_path(output_dir, cfg.log_filename)
    summary_path = join_path(output_dir, cfg.summary_filename)

    records = [decision.model_dump() for decision in merge_decisions]
    safe_write_jsonl(log_path, records, fs=cfg.fs)

    summary = _build_summary(merge_decisions, total_before, total_after)
    safe_write_json(summary_path, summary.model_dump(), fs=cfg.fs, pretty=True)

    return log_path, summary_path


def _build_summary(
    merge_decisions: list[MergeDecision],
    total_before: int,
    total_after: int,
) -> DeduplicationSummary:
    """
    Build deduplication summary from merge decisions.

    Args:
        merge_decisions: List of merge decisions
        total_before: Total entities before deduplication
        total_after: Total entities after deduplication

    Returns:
        DeduplicationSummary with aggregated statistics
    """
    assert merge_decisions is not None, "Merge decisions must not be None"
    assert isinstance(merge_decisions, list), "Merge decisions must be a list"
    assert total_before >= 0, "Total before must be non-negative"
    assert total_after >= 0, "Total after must be non-negative"

    merge_by_stage: dict[str, int] = {}
    semantic_scores: list[float] = []

    for decision in merge_decisions:
        merge_by_stage[decision.reason] = merge_by_stage.get(decision.reason, 0) + 1

        if decision.reason == "semantic" and decision.similarity_score is not None:
            semantic_scores.append(decision.similarity_score)

    avg_similarity = sum(semantic_scores) / len(semantic_scores) if semantic_scores else None

    return DeduplicationSummary(
        total_entities_before=total_before,
        total_entities_after=total_after,
        total_merged=len(merge_decisions),
        merge_by_stage=merge_by_stage,
        avg_similarity_semantic=avg_similarity,
    )
