"""
Utilities for ontology engine.

Contains helper functions for normalization, ID generation, file loading, validation, and versioning.
"""

from taxonomy_ontology_accelerator.ontology_engine.utils.error_helpers import validate_confidence
from taxonomy_ontology_accelerator.ontology_engine.utils.file_loading import (
    ensure_output_directory,
    load_input_file,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.id_generation import (
    generate_entity_id,
    generate_relationship_id,
    get_current_timestamp,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.math_utils import (
    safe_divide,
    safe_percentage,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.schema_comparator import (
    SchemaComparisonResult,
    TypeComparison,
    compare_schemas,
    load_schema_from_file,
    print_comparison_report,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.text_normalization import (
    generate_canonical_key,
    normalize_input_texts,
    normalize_text,
    normalize_text_with_hash,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.validation import (
    estimate_tokens,
    validate_and_merge_chunks,
    validate_batch_size,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.versioning import increment_schema_version

__all__ = [
    "SchemaComparisonResult",
    # Schema comparison
    "TypeComparison",
    "compare_schemas",
    "ensure_output_directory",
    "estimate_tokens",
    "generate_canonical_key",
    "generate_entity_id",
    "generate_relationship_id",
    "get_current_timestamp",
    "increment_schema_version",
    "load_input_file",
    "load_schema_from_file",
    "normalize_input_texts",
    "normalize_text",
    "normalize_text_with_hash",
    "print_comparison_report",
    "safe_divide",
    "safe_percentage",
    "validate_and_merge_chunks",
    "validate_batch_size",
    "validate_confidence",
]
