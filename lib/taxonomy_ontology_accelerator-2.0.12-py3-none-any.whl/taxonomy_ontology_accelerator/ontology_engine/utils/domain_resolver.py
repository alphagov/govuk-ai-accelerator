"""
Domain path resolution utilities using convention-over-configuration.

Provides:
- Input path resolution: {domain}/input/ → domain.input in config → error
- Prompt path resolution: {domain}/prompts/ → domain.prompt in config → None (uses code default)
- Output directory resolution: config.output.base_directory + domain name
"""

import re
import time
from pathlib import Path
from typing import TYPE_CHECKING

import fsspec

from taxonomy_ontology_accelerator.commons.io.fsspec_utils import (
    get_filesystem_from_config,
)
from taxonomy_ontology_accelerator.commons.utils.logger import get_logger

if TYPE_CHECKING:
    from taxonomy_ontology_accelerator.ontology_engine.config.config import OntologyConfig
else:
    from taxonomy_ontology_accelerator.ontology_engine.config.config import OntologyConfig

logger = get_logger()


# ========================================================================
# Domain Name Validation
# ========================================================================


def sanitize_domain_name(domain: str) -> str:
    """
    Sanitize and validate domain name.

    Domain names must:
    - Be non-empty after stripping whitespace
    - Contain only alphanumeric characters, underscores, and hyphens
    - Not contain path separators or special characters

    Args:
        domain: Raw domain name

    Returns:
        Sanitized domain name (stripped, validated)

    Raises:
        ValueError: If domain name is invalid

    Examples:
        >>> sanitize_domain_name("travel")
        'travel'
        >>> sanitize_domain_name("  healthcare_2024  ")
        'healthcare_2024'
        >>> sanitize_domain_name("../../etc/passwd")
        ValueError: Invalid domain name
    """
    assert domain is not None, "Domain must not be None"
    assert isinstance(domain, str), "Domain must be a string"

    # Strip whitespace
    sanitized = domain.strip()

    # Check not empty
    if not sanitized:
        raise ValueError("Domain name must not be empty")

    # Validate characters (alphanumeric, underscore, hyphen only)
    if not re.match(r"^[a-zA-Z0-9_-]+$", sanitized):
        raise ValueError(
            f"Invalid domain name: '{domain}'\n"
            f"Domain names must contain only alphanumeric characters, underscores, and hyphens.\n"
            f"Examples: 'travel', 'healthcare_2024', 'finance-uk'"
        )

    return sanitized


class DomainResolver:
    """Resolves domain-specific paths using convention-over-configuration."""

    @staticmethod
    def _check_explicit_input(config: OntologyConfig, start_time: float) -> Path | None:
        """Check for explicit input path in config."""
        assert config is not None, "config must not be None"
        assert isinstance(start_time, float), "start_time must be a float"
        domain_input = config.domain if hasattr(config, "domain") else None
        if not (domain_input and hasattr(domain_input, "input") and domain_input.input):
            return None

        fs = fsspec.filesystem("file")
        explicit_input = Path(domain_input.input)
        if not explicit_input.is_absolute():
            explicit_input = Path.cwd() / explicit_input

        if fs.exists(str(explicit_input)):
            elapsed_ms = (time.perf_counter() - start_time) * 1000
            logger.debug(
                f"Using explicit input path from config: {explicit_input} ({elapsed_ms:.1f}ms)"
            )
            return explicit_input.absolute()

        raise FileNotFoundError(
            f"Input path specified in config does not exist: {explicit_input}\n"
            f"Config value: domain.input = '{domain_input.input}'"
        )

    @staticmethod
    def _check_convention_input(domain_folder: Path, start_time: float) -> Path | None:
        """Check for convention-based input path."""
        assert isinstance(domain_folder, Path), "domain_folder must be a Path"
        assert isinstance(start_time, float), "start_time must be a float"
        fs = fsspec.filesystem("file")
        convention_input = domain_folder / "input"
        if fs.exists(str(convention_input)) and fs.isdir(str(convention_input)):
            elapsed_ms = (time.perf_counter() - start_time) * 1000
            logger.debug(f"Using convention input path: {convention_input} ({elapsed_ms:.1f}ms)")
            return convention_input.absolute()
        return None

    @staticmethod
    def resolve_input_path(domain: str, config: OntologyConfig) -> Path:
        """Resolve input path for a domain (config → convention → error)."""
        assert domain, "Domain must not be empty"
        assert config is not None, "Config must not be None"

        start_time = time.perf_counter()
        domain_folder = DomainResolver.validate_domain_folder(domain)

        # Priority 1: Explicit config
        explicit = DomainResolver._check_explicit_input(config, start_time)
        if explicit:
            return explicit

        # Priority 2: Convention
        convention = DomainResolver._check_convention_input(domain_folder, start_time)
        if convention:
            return convention

        # Priority 3: Error
        raise ValueError(
            f"Input not found for domain '{domain}'. "
            f"Either:\n  1. Create '{domain_folder}/input/' folder, OR\n"
            f"  2. Specify 'domain.input' in '{domain_folder}/config.yaml'"
        )

    @staticmethod
    def _check_explicit_prompt(config: OntologyConfig, start_time: float) -> Path | None:
        """Check for explicit prompt path in config."""
        assert config is not None, "config must not be None"
        assert isinstance(start_time, float), "start_time must be a float"
        domain_config = config.domain if hasattr(config, "domain") else None
        if not (domain_config and hasattr(domain_config, "prompt") and domain_config.prompt):
            return None

        fs = fsspec.filesystem("file")
        explicit_prompt = Path(domain_config.prompt)
        if not explicit_prompt.is_absolute():
            explicit_prompt = Path.cwd() / explicit_prompt

        if fs.exists(str(explicit_prompt)):
            elapsed_ms = (time.perf_counter() - start_time) * 1000
            logger.debug(
                f"Using explicit prompt path from config: {explicit_prompt} ({elapsed_ms:.1f}ms)"
            )
            return explicit_prompt.absolute()

        raise FileNotFoundError(
            f"Prompt path specified in config does not exist: {explicit_prompt}\n"
            f"Config value: domain.prompt = '{domain_config.prompt}'"
        )

    @staticmethod
    def _check_convention_prompt(domain_folder: Path, start_time: float) -> Path | None:
        """Check for convention-based prompt path."""
        assert isinstance(domain_folder, Path), "domain_folder must be a Path"
        assert isinstance(start_time, float), "start_time must be a float"
        fs = fsspec.filesystem("file")
        convention_prompts = domain_folder / "prompts"
        if not (fs.exists(str(convention_prompts)) and fs.isdir(str(convention_prompts))):
            return None

        # Look for specific prompt filenames first
        priority_names = ["prompt.txt", "extraction_prompt.txt", "llm_prompt.txt"]
        for name in priority_names:
            prompt_file = convention_prompts / name
            if fs.exists(str(prompt_file)) and fs.isfile(str(prompt_file)):
                elapsed_ms = (time.perf_counter() - start_time) * 1000
                logger.debug(f"Using convention prompt: {prompt_file} ({elapsed_ms:.1f}ms)")
                return prompt_file.absolute()

        # Use first .txt file
        prompt_files = sorted(fs.glob(f"{convention_prompts!s}/*.txt"))
        if prompt_files:
            elapsed_ms = (time.perf_counter() - start_time) * 1000
            first_prompt = str(prompt_files[0])  # Ensure it's a string
            logger.debug(
                f"Using convention prompt (first .txt): {first_prompt} ({elapsed_ms:.1f}ms)"
            )
            return Path(first_prompt).absolute()
        return None

    @staticmethod
    def resolve_prompt_path(domain: str, config: OntologyConfig) -> Path:
        """Resolve prompt path for a domain (config → convention → None for code default)."""
        assert domain, "Domain must not be empty"
        assert config is not None, "Config must not be None"

        start_time = time.perf_counter()
        domain_folder = DomainResolver.validate_domain_folder(domain)

        # Priority 1: Explicit config
        explicit = DomainResolver._check_explicit_prompt(config, start_time)
        if explicit:
            return explicit

        # Priority 2: Convention
        convention = DomainResolver._check_convention_prompt(domain_folder, start_time)
        if convention:
            return convention

        # Priority 3: No domain prompt (use code default)
        elapsed_ms = (time.perf_counter() - start_time) * 1000
        logger.debug(f"No domain prompt found - will use code default ({elapsed_ms:.1f}ms)")
        return None

    @staticmethod
    def resolve_research_prompt_path(domain: str, config: OntologyConfig) -> Path | None:
        """
        Resolve research prompt path for a domain.

        Priority:
        1. config.research.system_prompt_file (if set in config)
        2. {domain}/prompts/research_system_prompt.txt (convention)
        3. None (use code default)

        Args:
            domain: Domain identifier
            config: Loaded ontology configuration

        Returns:
            Absolute path to research prompt file, or None if not found
        """
        assert domain, "Domain must not be empty"
        assert config is not None, "Config must not be None"

        start_time = time.perf_counter()

        # Check for convention-based research prompt
        try:
            domain_folder = DomainResolver.validate_domain_folder(domain)
        except FileNotFoundError:
            # Domain folder doesn't exist yet - that's OK for research
            elapsed_ms = (time.perf_counter() - start_time) * 1000
            logger.debug(f"No domain folder found for research prompt ({elapsed_ms:.1f}ms)")
            return None

        fs = fsspec.filesystem("file")
        convention_prompts = domain_folder / "prompts"
        if fs.exists(str(convention_prompts)) and fs.isdir(str(convention_prompts)):
            # Look for research-specific prompt files
            research_prompt_names = [
                "research_system_prompt.txt",
                "research_prompt.txt",
                "research.txt",
            ]
            for name in research_prompt_names:
                prompt_file = convention_prompts / name
                if fs.exists(str(prompt_file)) and fs.isfile(str(prompt_file)):
                    elapsed_ms = (time.perf_counter() - start_time) * 1000
                    logger.debug(f"Using research prompt: {prompt_file} ({elapsed_ms:.1f}ms)")
                    return prompt_file.absolute()

        # No research prompt found - use code default
        elapsed_ms = (time.perf_counter() - start_time) * 1000
        logger.debug(f"No research prompt found - will use code default ({elapsed_ms:.1f}ms)")
        return None

    @staticmethod
    def resolve_output_directory(domain: str, config: OntologyConfig) -> Path | str:
        """
        Resolve output directory for a domain.

        Logic:
        1. Get base_directory from config (default: "output/ontology")
        2. If relative path → resolve from CWD
        3. If absolute path → use as-is
        4. Append domain name if config.output.append_domain_name is True
        5. Create directory if it doesn't exist

        Args:
            domain: Domain identifier
            config: Loaded ontology configuration

        Returns:
            Absolute path to domain's output directory
        """
        assert domain, "Domain must not be empty"
        assert config is not None, "Config must not be None"
        assert config.output is not None, "Config.output must not be None"

        protocol = getattr(config.filesystem, "protocol", "local")
        if protocol != "local":
            output_path = str(config.output.base_directory).rstrip("/")
            if config.output.append_domain_name:
                output_path = f"{output_path}/{domain}/output"
            fs = get_filesystem_from_config(protocol, getattr(config.filesystem, "options", None) or {})
            fs.makedirs(output_path, exist_ok=True)
            logger.debug(f"Output directory resolved: {output_path}")
            return output_path

        base_dir = config.output.base_directory
        output_path = Path(base_dir)

        # If relative, resolve from current working directory
        if not output_path.is_absolute():
            output_path = Path.cwd() / output_path

        # Append domain name if configured
        if config.output.append_domain_name:
            output_path = output_path / domain / "output"

        # Create directory if it doesn't exist
        fs = fsspec.filesystem("file")
        fs.makedirs(str(output_path), exist_ok=True)

        logger.debug(f"Output directory resolved: {output_path}")
        return output_path.absolute()

    @staticmethod
    def validate_domain_folder(domain: str) -> Path:
        """
        Validate that domain folder exists in domains/ directory.

        Checks: domains/{domain}/

        Args:
            domain: Domain identifier (folder name)

        Returns:
            Absolute path to domain folder

        Raises:
            ValueError: If domain is empty or invalid
            FileNotFoundError: If domain folder doesn't exist
        """
        assert domain is not None, "domain must not be None"
        assert isinstance(domain, str), "domain must be a string"

        # Sanitize and validate domain name
        sanitized_domain = sanitize_domain_name(domain)

        fs = fsspec.filesystem("file")
        domain_folder = Path("domains") / sanitized_domain
        if fs.exists(str(domain_folder)) and fs.isdir(str(domain_folder)):
            return domain_folder.absolute()

        # Not found
        expected_path = domain_folder.absolute()

        raise FileNotFoundError(
            f"Domain folder not found: {domain}/\n"
            f"Current working directory: {Path.cwd()}\n"
            f"Expected domain folder at: {expected_path}"
        )


# ========================================================================
# Domain Discovery for Autocomplete
# ========================================================================
# MOVED: list_available_domains has been moved to commons.utils.domain_utils
# to avoid circular dependencies and maintain architecture boundaries.
