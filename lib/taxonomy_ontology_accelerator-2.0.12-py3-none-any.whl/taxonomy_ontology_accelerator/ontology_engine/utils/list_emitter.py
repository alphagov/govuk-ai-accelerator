"""
Utilities for emitting entity and relationship lists at pipeline stages.

Provides functions to emit structured JSONL files showing entity and relationship
transformations at different pipeline stages for debugging and analysis.
"""

from collections import defaultdict
from pathlib import Path
from typing import Any

from fsspec import AbstractFileSystem

from taxonomy_ontology_accelerator.commons.io.file_utils import (
    join_path,
    safe_write_json,
    safe_write_jsonl,
)
from taxonomy_ontology_accelerator.ontology_engine.core.models import (
    Entity,
    ExtractedConcept,
    ExtractedRelationship,
    OntologyGraph,
    OntologySchema,
    Relationship,
)

MAX_ENTITY_TYPE_EXAMPLES = 2


def _emit_jsonl_records(
    records: list[dict[str, Any]],
    filepath: Path | str,
    fs: AbstractFileSystem | None = None,
) -> Path | str:
    """
    Internal helper to write JSONL records to file.

    Args:
        records: List of dictionaries to write as JSONL
        filepath: Full path to output file
        fs: Optional filesystem instance

    Returns:
        Path to written file
    """
    assert records is not None, "records must not be None"
    assert isinstance(records, list), "records must be a list"
    assert filepath is not None, "filepath must not be None"
    safe_write_jsonl(filepath, records, fs=fs)
    return filepath


def emit_raw_entity_list(
    concepts: list[ExtractedConcept],
    output_dir: Path | str,
    fs: AbstractFileSystem | None = None,
) -> Path | str:
    """
    Emit raw extracted concepts as JSONL.

    Args:
        concepts: List of extracted concepts from LLM
        output_dir: Output directory path
        fs: Optional filesystem instance

    Returns:
        Path to emitted entities.raw.jsonl file
    """
    assert concepts is not None, "concepts must not be None"
    assert isinstance(concepts, list), "concepts must be a list"
    assert output_dir is not None, "output_dir must not be None"
    records = [
        {
            "label": concept.label,
            "type": concept.concept_type,
            "description": concept.description,
            "aliases": concept.aliases,
            "properties": concept.properties,
            "restrictions": concept.restrictions,
            "confidence": concept.confidence,
        }
        for concept in concepts
    ]
    return _emit_jsonl_records(records, join_path(output_dir, "entities.raw.jsonl"), fs)


def emit_raw_relationship_list(
    relationships: list[ExtractedRelationship],
    output_dir: Path | str,
    fs: AbstractFileSystem | None = None,
) -> Path | str:
    """
    Emit raw extracted relationships as JSONL.

    Args:
        relationships: List of extracted relationships from LLM
        output_dir: Output directory path
        fs: Optional filesystem instance

    Returns:
        Path to emitted relationships.raw.jsonl file
    """
    assert relationships is not None, "relationships must not be None"
    assert isinstance(relationships, list), "relationships must be a list"
    assert output_dir is not None, "output_dir must not be None"
    records = [
        {
            "source": rel.source_label,
            "type": rel.type,
            "target": rel.target_label,
            "description": rel.description,
            "properties": rel.properties,
            "characteristics": rel.characteristics,
            "inverse_of": rel.inverse_of,
            "confidence": rel.confidence,
        }
        for rel in relationships
    ]
    return _emit_jsonl_records(records, join_path(output_dir, "relationships.raw.jsonl"), fs)


def emit_entity_list(
    entities: list[Entity],
    output_dir: Path | str,
    stage: str = "final",
    fs: AbstractFileSystem | None = None,
) -> Path | str:
    """
    Emit entities as JSONL.

    Args:
        entities: List of entities
        output_dir: Output directory path
        stage: Pipeline stage name (e.g., "processed", "final")
        fs: Optional filesystem instance

    Returns:
        Path to emitted JSONL file
    """
    assert entities is not None, "entities must not be None"
    assert isinstance(entities, list), "entities must be a list"
    assert output_dir is not None, "output_dir must not be None"
    records = [
        {
            "id": entity.id,
            "label": entity.label,
            "type": entity.type,
            "aliases": entity.alias_names,
            "confidence": entity.metadata.get("confidence") if entity.metadata else None,
        }
        for entity in entities
    ]
    return _emit_jsonl_records(records, join_path(output_dir, f"entities.{stage}.jsonl"), fs)


def emit_relationship_list(
    relationships: list[Relationship],
    entities: list[Entity],
    output_dir: Path | str,
    stage: str = "final",
    fs: AbstractFileSystem | None = None,
) -> Path | str:
    """
    Emit relationships as JSONL with resolved labels.

    Args:
        relationships: List of relationships
        entities: List of entities (for label resolution)
        output_dir: Output directory path
        stage: Pipeline stage name (e.g., "processed", "final")
        fs: Optional filesystem instance

    Returns:
        Path to emitted JSONL file
    """
    assert relationships is not None, "relationships must not be None"
    assert isinstance(relationships, list), "relationships must be a list"
    assert entities is not None, "entities must not be None"
    assert isinstance(entities, list), "entities must be a list"

    entity_id_to_label = {e.id: e.label for e in entities}

    records = [
        {
            "source": entity_id_to_label.get(rel.from_, rel.from_),
            "type": rel.type,
            "target": entity_id_to_label.get(rel.to, rel.to),
            "source_id": rel.from_,
            "target_id": rel.to,
            "confidence": rel.metadata.get("confidence") if rel.metadata else None,
        }
        for rel in relationships
    ]
    return _emit_jsonl_records(records, join_path(output_dir, f"relationships.{stage}.jsonl"), fs)


def _build_entity_type_stats(
    entities: list[Entity],
) -> tuple[dict[str, int], dict[str, list[str]]]:
    """Build entity type counts and examples."""
    assert entities is not None, "entities must not be None"
    assert isinstance(entities, list), "entities must be a list"

    entity_type_counts: dict[str, int] = defaultdict(int)
    entity_type_examples: dict[str, list[str]] = defaultdict(list)

    for entity in entities:
        entity_type_counts[entity.type] += 1
        if len(entity_type_examples[entity.type]) < MAX_ENTITY_TYPE_EXAMPLES:
            entity_type_examples[entity.type].append(entity.label)

    return entity_type_counts, entity_type_examples


def _build_relationship_type_stats(
    relationships: list[Relationship],
    entity_id_to_type: dict[str, str],
) -> tuple[dict[str, int], dict[str, set[str]], dict[str, set[str]]]:
    """Build relationship type counts and type mappings."""
    assert relationships is not None, "relationships must not be None"
    assert entity_id_to_type is not None, "entity_id_to_type must not be None"

    relationship_type_counts: dict[str, int] = defaultdict(int)
    relationship_from_types: dict[str, set[str]] = defaultdict(set)
    relationship_to_types: dict[str, set[str]] = defaultdict(set)

    for rel in relationships:
        relationship_type_counts[rel.type] += 1
        from_type = entity_id_to_type.get(rel.from_, "Unknown")
        to_type = entity_id_to_type.get(rel.to, "Unknown")
        relationship_from_types[rel.type].add(from_type)
        relationship_to_types[rel.type].add(to_type)

    return relationship_type_counts, relationship_from_types, relationship_to_types


def emit_vocabulary(
    schema: OntologySchema,
    graph: OntologyGraph,
    output_dir: Path | str,
    stage_stats: dict[str, dict[str, int]] | None = None,
    fs: AbstractFileSystem | None = None,
) -> Path | str:
    """
    Emit vocabulary.json with complete metadata.

    Args:
        schema: Ontology schema
        graph: Ontology graph
        output_dir: Output directory path
        stage_stats: Optional statistics from pipeline stages
        fs: Optional filesystem instance

    Returns:
        Path to emitted vocabulary.json file
    """
    assert schema is not None, "schema must not be None"
    assert graph is not None, "graph must not be None"

    entity_type_counts, entity_type_examples = _build_entity_type_stats(graph.entities)
    entity_id_to_type = {e.id: e.type for e in graph.entities}
    rel_counts, rel_from, rel_to = _build_relationship_type_stats(
        graph.relationships, entity_id_to_type
    )

    vocabulary = {
        "entity_types": {
            etype: {"count": entity_type_counts[etype], "examples": entity_type_examples[etype]}
            for etype in entity_type_counts
        },
        "relationship_types": {
            rtype: {
                "count": rel_counts[rtype],
                "from_types": sorted(rel_from[rtype]),
                "to_types": sorted(rel_to[rtype]),
            }
            for rtype in rel_counts
        },
        "total_entities": len(graph.entities),
        "total_relationships": len(graph.relationships),
    }

    if stage_stats:
        vocabulary["pipeline_stages"] = stage_stats

    filepath = join_path(output_dir, "vocabulary.json")
    safe_write_json(filepath, vocabulary, fs=fs, pretty=True)

    return filepath
