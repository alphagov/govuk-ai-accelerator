"""
Validation utilities for ontology extraction.
"""

from taxonomy_ontology_accelerator.commons.utils.logger import get_logger
from taxonomy_ontology_accelerator.ontology_engine.config.config import OntologyConfig

logger = get_logger()


# ========================================================================
# Chunk Validation
# ========================================================================


def validate_and_merge_chunks(
    chunks: list[str],
    config: OntologyConfig,
) -> list[str]:
    """
    Validate chunks and merge small ones to meet min_chunk_size requirement.

    CRITICAL: Merged chunks must NEVER exceed the max chunk size (chunk_size * chars_per_token).
    This ensures chunks always fit within the LLM's context window after accounting for prompt overhead.

    Args:
        chunks: List of text chunks
        config: Ontology configuration

    Returns:
        Validated and merged chunks list
    """
    assert chunks is not None, "Chunks must not be None"
    assert isinstance(chunks, list), "Chunks must be a list"
    assert config is not None, "Config must not be None"
    assert hasattr(config, "text_processing"), "Config must have text_processing attribute"

    if not chunks:
        return []

    min_size = config.text_processing.chunking.min_chunk_size
    # Calculate max chunk size in characters (chunk_size is in tokens)
    chars_per_token = config.text_processing.chunking.chars_per_token_estimate
    if chars_per_token <= 0:
        chars_per_token = 4  # Fallback to conservative estimate
    max_size = config.text_processing.chunking.chunk_size * chars_per_token

    valid_chunks: list[str] = []

    for chunk in chunks:
        chunk = chunk.strip()

        if not chunk:
            continue

        # Try to merge small chunks, but NEVER exceed max_size
        if len(chunk) < min_size and valid_chunks:
            merged = valid_chunks[-1] + "\n\n" + chunk
            # Only merge if result doesn't exceed max chunk size
            if len(merged) <= max_size:
                valid_chunks[-1] = merged
            else:
                # Can't merge without exceeding limit - keep as separate chunk
                valid_chunks.append(chunk)
        else:
            # Chunk meets min_size or is first chunk
            valid_chunks.append(chunk)

    return valid_chunks


# ========================================================================
# Batch Size Validation
# ========================================================================


def validate_batch_size(
    batch_size: int,
    min_size: int,
    max_size: int | None,
    _config: OntologyConfig,  # Reserved for logging/future options
) -> int:
    """
    Validate and adjust batch size to be within min/max bounds.

    Args:
        batch_size: Requested batch size
        min_size: Minimum allowed batch size
        max_size: Maximum allowed batch size (None = no limit)
        config: Ontology configuration (for logging)

    Returns:
        Validated batch size (adjusted if needed)
    """
    assert batch_size is not None, "Batch size must not be None"
    assert isinstance(batch_size, int), "Batch size must be an integer"
    assert min_size is not None, "Min size must not be None"
    assert isinstance(min_size, int), "Min size must be an integer"
    assert min_size >= 0, "Min size must be non-negative"

    if batch_size < min_size:  # Below minimum threshold (too small)
        logger.warning(
            f"Batch size {batch_size} is below minimum {min_size}. Using minimum value {min_size}."
        )
        return min_size  # Return minimum (enforce lower bound)

    if max_size is not None and batch_size > max_size:  # Above maximum threshold (too large)
        logger.warning(
            f"Batch size {batch_size} exceeds maximum {max_size}. Using maximum value {max_size}."
        )
        return max_size  # Return maximum (enforce upper bound)

    return batch_size


# ========================================================================
# Token Estimation
# ========================================================================


def estimate_tokens(text: str, chars_per_token: int | float) -> int:
    """
    Estimate token count from character count.

    Args:
        text: Text to estimate
        chars_per_token: Characters per token estimate

    Returns:
        Estimated token count
    """
    assert text is not None, "Text must not be None"
    assert isinstance(text, str), "Text must be a string"
    assert chars_per_token is not None, "Chars per token must not be None"
    assert isinstance(chars_per_token, int), "Chars per token must be an integer"

    return len(text) // chars_per_token if chars_per_token > 0 else len(text)
