"""
Mathematical utility functions for safe calculations.

Provides helper functions for common mathematical operations with proper
error handling and edge case management.
"""

import math


def safe_divide(numerator: float | int, denominator: float | int, default: float = 0.0) -> float:
    """
    Safely divide two numbers, returning a default value if denominator is zero.

    This function eliminates the repeated pattern of `value / divisor if divisor > 0 else default`
    throughout the codebase, improving readability and maintainability.

    Args:
        numerator: The number to divide
        denominator: The number to divide by
        default: Value to return if denominator is zero or negative (default: 0.0)

    Returns:
        Result of division, or default if denominator is zero/negative

    Examples:
        >>> safe_divide(10, 5)
        2.0
        >>> safe_divide(10, 0)
        0.0
        >>> safe_divide(10, 0, default=1.0)
        1.0
        >>> safe_divide(10, -5)
        0.0
    """
    assert isinstance(numerator, int | float), "Numerator must be int or float"
    assert isinstance(denominator, int | float), "Denominator must be int or float"
    assert math.isfinite(numerator), "Numerator must be finite (not inf/nan)"
    assert math.isfinite(denominator), "Denominator must be finite (not inf/nan)"

    if denominator > 0:  # Valid denominator
        return float(numerator) / float(denominator)  # Perform division
    return default  # Return default on zero/negative denominator


def safe_percentage(
    numerator: float | int, denominator: float | int, default: float = 0.0
) -> float:
    """
    Calculate percentage safely, returning default if denominator is zero.

    Equivalent to: (numerator / denominator) * 100 if denominator > 0 else default

    Args:
        numerator: The part value
        denominator: The total value
        default: Value to return if denominator is zero or negative (default: 0.0)

    Returns:
        Percentage value (0-100), or default if denominator is zero/negative

    Examples:
        >>> safe_percentage(25, 100)
        25.0
        >>> safe_percentage(25, 0)
        0.0
        >>> safe_percentage(1, 3)
        33.333333333333336
    """
    assert isinstance(numerator, int | float), "Numerator must be int or float"
    assert isinstance(denominator, int | float), "Denominator must be int or float"
    assert math.isfinite(numerator), "Numerator must be finite (not inf/nan)"
    assert math.isfinite(denominator), "Denominator must be finite (not inf/nan)"

    if denominator > 0:
        return (float(numerator) / float(denominator)) * 100.0
    return default
