"""
File loading utilities for ontology extraction.
"""

import os
import time
from pathlib import Path
from typing import TYPE_CHECKING

from taxonomy_ontology_accelerator.commons.io.file_utils import (
    canonicalize_listed_path,
    safe_read_file,
)
from taxonomy_ontology_accelerator.commons.io.fsspec_utils import get_default_filesystem
from taxonomy_ontology_accelerator.commons.utils.logger import get_logger

if TYPE_CHECKING:
    from taxonomy_ontology_accelerator.ontology_engine.config.config import OntologyConfig
from taxonomy_ontology_accelerator.ontology_engine.utils.math_utils import (
    safe_divide,
    safe_percentage,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.text_normalization import (
    normalize_input_texts,
)
from taxonomy_ontology_accelerator.ontology_engine.utils.timing import format_time_interval

logger = get_logger()

# Progress logging interval thresholds
SMALL_FILE_COUNT = 10  # Log every file for small jobs
MEDIUM_FILE_COUNT = 50  # Log every 5 files for medium jobs
LARGE_FILE_COUNT = 200  # Log every 20 files for large jobs


# ========================================================================
# File Loading Helper Functions
# ========================================================================


SUPPORTED_EXTENSIONS = {
    ".txt",
    ".text",
    ".md",
    ".markdown",
    ".json",
    ".html",
    ".htm",
    ".xml",
    ".yaml",
    ".yml",
}


def _find_supported_files(input_path: str | Path, fs=None) -> list[str]:
    """
    Find all files with supported extensions in directory.

    Args:
        input_path: Directory path to search (str for cloud, Path for local)
        fs: Filesystem instance (defaults to local filesystem)

    Returns:
        Sorted list of file paths as strings

    Raises:
        ValueError: If no supported files found
    """
    assert input_path is not None, "input_path parameter is required"
    assert isinstance(input_path, str | Path), "input_path must be str or Path"
    if fs is None:
        fs = get_default_filesystem()

    input_str = str(input_path)

    # Use fs.glob for recursive file discovery (works for both local and cloud)
    # Pattern: directory/**/* finds all files recursively
    glob_pattern = f"{input_str.rstrip('/')}/**"
    all_paths = [canonicalize_listed_path(path, input_str) for path in fs.glob(glob_pattern)]

    # Filter for supported extensions and files only
    all_files = [
        path
        for path in all_paths
        if any(path.lower().endswith(ext) for ext in SUPPORTED_EXTENSIONS) and fs.isfile(path)
    ]
    all_files = sorted(set(all_files))

    if not all_files:
        raise ValueError(
            f"No supported text files found in directory: {input_path}\n"
            f"Directory must contain at least one supported file format "
            f"(.txt, .md, .json, .html, .xml, .yaml, etc.)."
        )

    # Log start of loading for large file counts
    if len(all_files) > 1:
        logger.load(f"[Input Loading] Loading {len(all_files)} files...")

    return all_files


def _calculate_progress_interval(file_count: int) -> int:
    """
    Calculate appropriate progress logging interval based on file count.

    Args:
        file_count: Total number of files

    Returns:
        Interval for progress logging
    """
    assert isinstance(file_count, int), "file_count must be an integer"
    assert file_count >= 0, "file_count must be non-negative"
    if file_count <= SMALL_FILE_COUNT:
        return 1
    if file_count <= MEDIUM_FILE_COUNT:
        return 5
    if file_count <= LARGE_FILE_COUNT:
        return 20
    return 50


def _check_file_size(
    file_path: str | Path, max_bytes: int | None, max_mb: float | None, fs=None
) -> tuple[bool, int]:
    """
    Check if file exceeds size limit.

    Args:
        file_path: Path to file (str for cloud, Path for local)
        max_bytes: Maximum size in bytes (None if no limit)
        max_mb: Maximum size in MB for logging
        fs: Filesystem instance (defaults to local filesystem)

    Returns:
        Tuple of (should_skip, 1 if skipped due to size else 0)
    """
    assert file_path is not None, "file_path parameter is required"
    assert isinstance(file_path, str | Path), "file_path must be str or Path"
    if max_bytes is None:
        return False, 0

    if fs is None:
        fs = get_default_filesystem()

    try:
        file_str = str(file_path)
        info = fs.info(file_str)
        file_size = info.get("size", 0)
        if file_size > max_bytes:
            file_size_mb = file_size / (1024 * 1024)
            # Extract filename from path (works for both local and cloud)
            filename = os.path.basename(file_str)
            logger.warning(
                f"Skipping file (exceeds max_file_size_mb): {filename} "
                f"({file_size_mb:.2f}MB > {max_mb:.2f}MB)"
            )
            return True, 1
    except OSError as e:
        filename = os.path.basename(str(file_path))
        logger.debug(f"Could not check file size for {filename}: {e}")

    return False, 0


def _read_single_file(
    file_path: str | Path, input_path: str | Path, fs=None
) -> tuple[str | None, str | None]:
    """
    Read a single file and generate its source ID.

    Args:
        file_path: Path to file to read (str for cloud, Path for local)
        input_path: Base input directory for relative path calculation
        fs: Filesystem instance (defaults to local filesystem)

    Returns:
        Tuple of (content, source_id) or (None, None) on failure
    """
    assert file_path is not None, "file_path parameter is required"
    assert input_path is not None, "input_path parameter is required"

    content = safe_read_file(file_path, fs=fs)
    if not content or not content.strip():
        logger.warning(f"Skipping empty file: {file_path}")
        return None, None

    # Use absolute path for checkpointing consistency
    # For cloud paths, use as-is; for local paths, use absolute
    source_id = str(file_path.absolute()) if isinstance(file_path, Path) else str(file_path)

    return content, source_id


def _log_file_progress(
    idx: int, total: int, files_read: int, files_skipped: int, start_time: float
) -> None:
    """
    Log file loading progress.

    Args:
        idx: Current file index
        total: Total file count
        files_read: Files successfully read
        files_skipped: Files skipped
        start_time: Time when loading started
    """
    assert isinstance(idx, int), "idx must be an integer"
    assert isinstance(total, int), "total must be an integer"
    elapsed = time.time() - start_time
    progress_pct = safe_percentage(idx, total)
    rate = safe_divide(idx, elapsed)
    remaining = safe_divide(total - idx, rate)

    elapsed_str = format_time_interval(elapsed)
    eta_str = format_time_interval(remaining)

    logger.debug(
        f"  Loading files: {idx}/{total} ({progress_pct:.1f}%) | "
        f"Read: {files_read}, Skipped: {files_skipped} | "
        f"Elapsed: {elapsed_str} | ETA: {eta_str}"
    )


def _process_single_directory_file(
    file_path: str | Path,
    input_path: str | Path,
    max_file_size_bytes: int | None,
    max_mb: float | None,
    fs=None,
) -> tuple[str | None, str | None, bool, int]:
    """Process a single file. Returns (content, source_id, skipped, size_skip)."""
    assert file_path is not None, "file_path parameter is required"
    assert input_path is not None, "input_path parameter is required"

    if fs is None:
        fs = get_default_filesystem()

    # Skip symlinks (fs.islink works for local, returns False for cloud)
    file_str = str(file_path)
    try:
        if fs.islink(file_str):
            return None, None, True, 0
    except (AttributeError, NotImplementedError):
        # Some filesystems don't support islink - skip check
        pass

    should_skip, size_skip = _check_file_size(file_path, max_file_size_bytes, max_mb, fs)
    if should_skip:
        return None, None, True, size_skip

    content, source_id = _read_single_file(file_path, input_path, fs)
    return content, source_id, not (content and source_id), 0


def _process_directory_files(
    all_files: list[str], input_path: str | Path, config: "OntologyConfig", fs=None
) -> tuple[list[str], list[str], int, int, int]:
    """Process all files in directory with progress tracking."""
    assert all_files is not None, "all_files parameter is required"
    assert config is not None, "config parameter is required"

    if fs is None:
        fs = get_default_filesystem()

    all_contents, source_tracking = [], []
    files_read, files_skipped, files_skipped_size = 0, 0, 0
    progress_interval = _calculate_progress_interval(len(all_files))
    file_load_start = time.time()

    max_mb = config.input_validation.max_file_size_mb
    max_bytes = int(max_mb * 1024 * 1024) if max_mb else None

    for idx, file_path in enumerate(all_files, 1):
        try:
            content, source_id, skipped, size_skip = _process_single_directory_file(
                file_path, input_path, max_bytes, max_mb, fs
            )
            if skipped:
                files_skipped += 1
                files_skipped_size += size_skip
            else:
                all_contents.append(content)
                source_tracking.append(source_id)
                files_read += 1
        except PermissionError:
            files_skipped += 1
        except Exception:
            files_skipped += 1

        if idx % progress_interval == 0 or idx == len(all_files):
            _log_file_progress(idx, len(all_files), files_read, files_skipped, file_load_start)

    return all_contents, source_tracking, files_read, files_skipped, files_skipped_size


def _log_skip_summary(files_skipped: int, files_skipped_size: int, max_mb: float | None) -> None:
    """
    Log summary of skipped files.

    Args:
        files_skipped: Total files skipped
        files_skipped_size: Files skipped due to size
        max_mb: Max file size setting for logging
    """
    assert isinstance(files_skipped, int), "files_skipped must be an integer"
    assert isinstance(files_skipped_size, int), "files_skipped_size must be an integer"
    if files_skipped == 0:
        return

    skip_reasons = []
    if files_skipped_size > 0 and max_mb is not None:
        skip_reasons.append(f"{files_skipped_size} exceeded max_file_size_mb ({max_mb:.2f}MB)")

    other_skipped = files_skipped - files_skipped_size
    if other_skipped > 0:
        skip_reasons.append(f"{other_skipped} empty/unreadable/symlinks")

    skip_summary = ", ".join(skip_reasons)
    logger.debug(f"Skipped {files_skipped} file(s) | Reasons: {skip_summary}")


def _get_paragraph_separator(config: "OntologyConfig") -> str:
    """
    Get paragraph separator from config or use default.

    Args:
        config: Ontology configuration

    Returns:
        Paragraph separator string
    """
    assert config is not None, "config parameter is required"
    assert hasattr(config, "text_processing"), "config must have text_processing attribute"
    if (
        hasattr(config, "text_processing")
        and hasattr(config.text_processing, "chunking")
        and config.text_processing.chunking.separators
    ):
        return config.text_processing.chunking.separators[0]
    return "\n\n"


def _split_into_paragraphs(
    contents: list[str], sources: list[str], paragraph_sep: str
) -> tuple[list[str], list[str]]:
    """
    Split contents into paragraphs with source tracking.

    Args:
        contents: List of file contents
        sources: List of source IDs (parallel to contents)
        paragraph_sep: Separator for splitting

    Returns:
        Tuple of (texts, text_sources)
    """
    assert contents is not None, "contents parameter is required"
    assert sources is not None, "sources parameter is required"
    texts: list[str] = []
    text_sources: list[str] = []

    for content, source_id in zip(contents, sources, strict=True):
        paragraphs = content.split(paragraph_sep)
        for para in paragraphs:
            para_stripped = para.strip()
            if para_stripped:
                texts.append(para_stripped)
                text_sources.append(source_id)

    return texts, text_sources


def _shard_input_contents(
    contents: list[str],
    sources: list[str],
    config: "OntologyConfig",
) -> tuple[list[str], list[str]]:
    """
    Shard raw file contents before chunking.

    Defaults to one shard per file to preserve whole-file context. Paragraph
    sharding remains available as an explicit config opt-in.
    """
    assert contents is not None, "contents parameter is required"
    assert sources is not None, "sources parameter is required"
    assert config is not None, "config parameter is required"

    strategy = config.text_processing.chunking.input_sharding_strategy
    if strategy == "paragraph":
        paragraph_sep = _get_paragraph_separator(config)
        return _split_into_paragraphs(contents, sources, paragraph_sep)

    texts: list[str] = []
    text_sources: list[str] = []
    for content, source_id in zip(contents, sources, strict=True):
        content_stripped = content.strip()
        if content_stripped:
            texts.append(content_stripped)
            text_sources.append(source_id)

    return texts, text_sources


def _load_from_directory(
    input_path: str | Path, config: "OntologyConfig", fs=None
) -> tuple[list[str], list[str]]:
    """
    Load input from directory with source tracking.

    Args:
        input_path: Directory path (str for cloud, Path for local)
        config: Ontology configuration
        fs: Filesystem instance (defaults to local filesystem)

    Returns:
        Tuple of (texts, source_ids)

    Raises:
        ValueError: If no valid content found
    """
    assert input_path is not None, "input_path parameter is required"
    assert config is not None, "config parameter is required"

    if fs is None:
        fs = get_default_filesystem()

    all_files = _find_supported_files(input_path, fs)
    file_load_start = time.time()

    all_contents, source_tracking, files_read, files_skipped, files_skipped_size = (
        _process_directory_files(all_files, input_path, config, fs)
    )

    _log_skip_summary(files_skipped, files_skipped_size, config.input_validation.max_file_size_mb)

    if not all_contents:
        raise ValueError(
            f"All supported files in directory are empty or unreadable: {input_path}\n"
            f"At least one file must contain readable text content."
        )

    total_load_time = time.time() - file_load_start
    logger.debug(f"Successfully read {files_read} file(s) from directory in {total_load_time:.1f}s")

    texts, text_sources = _shard_input_contents(all_contents, source_tracking, config)

    if not texts:
        raise ValueError(
            f"All supported files in directory are empty or contain no valid text: {input_path}\n"
            f"At least one file must contain readable text content."
        )

    normalized_texts = normalize_input_texts(texts, config)
    return normalized_texts, text_sources


def _check_single_file_size(input_path: str | Path, config: "OntologyConfig", fs=None) -> None:
    """
    Check if single file exceeds size limit.

    Args:
        input_path: Path to file (str for cloud, Path for local)
        config: Ontology configuration
        fs: Filesystem instance (defaults to local filesystem)

    Raises:
        ValueError: If file exceeds size limit
    """
    assert input_path is not None, "input_path parameter is required"
    assert config is not None, "config parameter is required"

    max_mb = config.input_validation.max_file_size_mb
    if max_mb is None:
        return

    if fs is None:
        fs = get_default_filesystem()

    try:
        input_str = str(input_path)
        info = fs.info(input_str)
        file_size = info.get("size", 0)
        max_bytes = int(max_mb * 1024 * 1024)
        if file_size > max_bytes:
            file_size_mb = file_size / (1024 * 1024)
            raise ValueError(
                f"Input file exceeds max_file_size_mb: {input_path}\n"
                f"File size: {file_size_mb:.2f}MB, Maximum allowed: {max_mb:.2f}MB\n"
                f"Configure max_file_size_mb in config.yaml to allow larger files, or split the file."
            )
    except OSError as e:
        logger.warning(f"Could not check file size for {input_path}: {e}")


def _load_from_file(
    input_path: str | Path, config: "OntologyConfig", fs=None
) -> tuple[list[str], list[str]]:
    """
    Load input from single file with source tracking.

    Args:
        input_path: File path (str for cloud, Path for local)
        config: Ontology configuration
        fs: Filesystem instance (defaults to local filesystem)

    Returns:
        Tuple of (texts, source_ids)

    Raises:
        ValueError: If file is empty or has no valid content
    """
    assert input_path is not None, "input_path parameter is required"
    assert config is not None, "config parameter is required"

    if fs is None:
        fs = get_default_filesystem()

    _check_single_file_size(input_path, config, fs)

    combined_content = safe_read_file(input_path, fs=fs)
    if not combined_content or not combined_content.strip():
        raise ValueError(
            f"Input file is empty: {input_path}\nFile must contain non-empty text content."
        )

    # Use absolute path for checkpointing consistency
    # For cloud paths, use as-is; for local paths, use absolute
    source_id = str(input_path.absolute()) if isinstance(input_path, Path) else str(input_path)

    texts, text_sources = _shard_input_contents([combined_content], [source_id], config)

    if not texts:
        raise ValueError(
            f"Input contains no valid text after parsing: {input_path}\n"
            f"Must contain readable text content."
        )

    normalized_texts = normalize_input_texts(texts, config)
    return normalized_texts, text_sources


# ========================================================================
# Main Input File Loading Function
# ========================================================================


def load_input_file(
    input_file: str | Path, config: "OntologyConfig", fs=None
) -> tuple[list[str], list[str]]:
    """
    Load and normalize input from file or directory with source tracking.

    If a file path is provided, reads that file (any format: .txt, .md, .json, .html, etc.).
    If a directory path is provided, reads all supported text files recursively.

    Supported file formats for directories:
    - Text files: .txt, .text
    - Markdown: .md, .markdown
    - JSON: .json (read as text)
    - Other text formats: .html, .xml, .yaml, .yml

    Args:
        input_file: Path to input file or directory containing text files
        config: Ontology configuration
        fs: Filesystem instance (defaults to local filesystem)

    Returns:
        Tuple of (texts, source_ids) where:
        - texts: List of normalized text shards (from all files if directory provided)
        - source_ids: List of source identifiers, where source_ids[i] is the source for texts[i]
          - For file input: source_ids[i] = file_path.name (just filename for consistency)
          - For directory input: source_ids[i] = relative path from input directory
            - Falls back to filename if relative path fails (e.g., Windows different drives)

    Raises:
        FileNotFoundError: If file/directory doesn't exist
        ValueError: If no supported files found in directory or all files are empty
    """
    assert input_file is not None, "input_file parameter is required"
    assert config is not None, "config parameter is required"

    if fs is None:
        fs = get_default_filesystem()

    # Keep input_file as-is (str for cloud, Path for local)
    # Don't convert cloud paths to Path objects
    input_path = input_file
    input_str = str(input_path)

    if not fs.exists(input_str):
        raise FileNotFoundError(
            f"Input file or directory not found: {input_path}\n"
            f"Provide a valid file or directory path."
        )

    if fs.isdir(input_str):
        return _load_from_directory(input_path, config, fs)

    return _load_from_file(input_path, config, fs)


# ========================================================================
# Output Directory Management
# ========================================================================


def ensure_output_directory(output_dir: str | Path, fs=None) -> None:
    """
    Ensure output directory exists.

    Args:
        output_dir: Output directory path (str for cloud, Path for local)
        fs: Filesystem instance (defaults to local filesystem)

    Raises:
        IOError: If directory cannot be created
    """
    assert output_dir is not None, "output_dir parameter is required"
    assert isinstance(output_dir, str | Path), "output_dir must be str or Path"

    if fs is None:
        fs = get_default_filesystem()

    try:
        fs.makedirs(str(output_dir), exist_ok=True)
    except OSError as e:
        raise OSError(
            f"Failed to create output directory {output_dir}: {e}\n"
            f"Check permissions and disk space."
        ) from e
