"""
Error handling helper utilities for ontology engine.
"""

from taxonomy_ontology_accelerator.commons.errors import ErrorCollector
from taxonomy_ontology_accelerator.commons.utils.logger import get_logger
from taxonomy_ontology_accelerator.ontology_engine.config.config import OntologyConfig

logger = get_logger()


# ========================================================================
# Error Collection Helpers
# ========================================================================


def should_collect_error(severity: str, config: OntologyConfig) -> bool:
    """
    Check if error of given severity should be collected.

    Args:
        severity: Error severity level ("error", "warning", "info")
        config: Ontology configuration

    Returns:
        True if error should be collected, False otherwise
    """
    assert isinstance(severity, str), "Severity must be a string"
    assert config is not None, "Config must not be None"

    return severity in config.error_handling.collect_severities


def check_max_errors(
    error_collector: ErrorCollector,
    config: OntologyConfig,
    _error_type: str,  # Reserved for error categorization
    message: str,
) -> bool:
    """
    Check if max_errors limit has been reached before adding error.

    Raises ValueError if limit is reached.

    Args:
        error_collector: Error collector instance
        config: Ontology configuration
        error_type: Error type for logging
        message: Error message for logging

    Returns:
        True if error can be added

    Raises:
        ValueError: If max_errors limit is reached
    """
    assert error_collector is not None, "Error collector must not be None"
    assert config is not None, "Config must not be None"
    assert isinstance(message, str), "Message must be a string"

    if (
        config.error_handling.max_errors is not None  # Max errors configured (check enabled)
        and len(error_collector.errors)
        >= config.error_handling.max_errors  # Limit reached (threshold exceeded)
    ):
        error_msg = f"Maximum error limit ({config.error_handling.max_errors}) reached. {message}"
        logger.error(error_msg)  # Log error limit reached
        raise ValueError(error_msg)  # Fail fast when limit exceeded (prevent error accumulation)
    return True  # Within limit, continue processing


# ========================================================================
# Validation Helpers
# ========================================================================


def validate_confidence(confidence: float | int | None, default: float = 1.0) -> float:
    """
    Validate and normalize confidence value.

    Args:
        confidence: Confidence value from metadata (may be None or invalid)
        default: Default value if confidence is invalid

    Returns:
        Valid confidence value (float >= 0)
    """
    assert isinstance(default, int | float), "Default must be a number"
    assert default >= 0, "Default must be non-negative"

    if not isinstance(confidence, int | float) or confidence < 0:  # Invalid confidence value
        return default  # Return default value
    return float(confidence)  # Convert to float and return


def merge_metadata_confidence(
    target_metadata: dict[str, float | int | str],
    _source_metadata: dict[str, float | int | str],  # Kept for API consistency
    target_confidence: float,
    source_confidence: float,
) -> None:
    """
    Merge confidence values in metadata (common pattern for entities and relationships).

    Args:
        target_metadata: Target metadata dict to update (modified in-place)
        _source_metadata: Source metadata dict (reserved for future use)
        target_confidence: Confidence of target
        source_confidence: Confidence of source
    """
    assert isinstance(target_metadata, dict), "Target metadata must be a dictionary"
    assert isinstance(target_confidence, int | float), "Target confidence must be a number"
    assert isinstance(source_confidence, int | float), "Source confidence must be a number"

    target_metadata["confidence"] = max(
        target_confidence, source_confidence, target_metadata.get("confidence", 1.0)
    )


def raise_validation_error(stage_num: int, total_stages: int, message: str) -> None:
    """
    Raise ValueError with consistent stage logging.

    Args:
        stage_num: Stage number for logging
        total_stages: Total number of stages
        message: Error message

    Raises:
        ValueError: Always raises with the provided message
    """
    assert isinstance(stage_num, int), "Stage number must be an integer"
    assert isinstance(total_stages, int), "Total stages must be an integer"
    assert isinstance(message, str), "Message must be a string"

    logger.error(f"[{stage_num}/{total_stages}] Validation failed: {message}")
    raise ValueError(message)


def collect_error_if_enabled(
    error_collector: ErrorCollector,
    config: OntologyConfig,
    severity: str,
    error_type: str,
    message: str,
) -> None:
    """
    Collect error if enabled in config, eliminating redundant error collection code.

    This helper consolidates the repeated pattern:
    ```python
    if should_collect_error(severity, config):
        check_max_errors(error_collector, config, error_type, message)
        error_collector.add_error(...)
    ```

    Args:
        error_collector: Error collector instance
        config: Ontology configuration
        severity: Error severity ("error", "warning", "info")
        error_type: Error type identifier
        message: Error message
    """
    assert error_collector is not None, "Error collector must not be None"
    assert config is not None, "Config must not be None"
    assert isinstance(severity, str), "Severity must be a string"
    assert isinstance(error_type, str), "Error type must be a string"

    if should_collect_error(severity, config):
        _ = check_max_errors(error_collector, config, error_type, message)
        error_collector.add_error(
            error_type=error_type,
            message=message,
            severity=severity,
        )
