"""
Utilities for safely loading user-provided Python functions.
"""

import importlib.util
import inspect
import tempfile
from collections.abc import Callable
from pathlib import Path

import fsspec

from taxonomy_ontology_accelerator.commons.io.fsspec_utils import get_default_filesystem
from taxonomy_ontology_accelerator.commons.utils.logger import get_logger

logger = get_logger()


def _is_cloud_path(path: str) -> bool:
    """Check if path is a cloud storage path (s3://, gs://, az://, etc.)."""
    assert path is not None
    assert isinstance(path, str)
    cloud_protocols = [
        "s3://",
        "gs://",
        "gcs://",
        "az://",
        "abfs://",
        "hdfs://",
        "http://",
        "https://",
    ]
    return any(path.startswith(protocol) for protocol in cloud_protocols)


def _download_to_temp(file_path: str) -> Path | None:
    """Download cloud file to temporary local file."""
    assert file_path is not None
    assert _is_cloud_path(file_path), "file_path must be a cloud path"

    try:
        # Get appropriate filesystem for the protocol
        fs = fsspec.filesystem(file_path.split("://")[0])

        # Check if file exists
        if not fs.exists(file_path):
            logger.warning(f"Cloud file not found: {file_path}")
            return None

        # Create temp file with .py extension
        with tempfile.NamedTemporaryFile(mode="wb", suffix=".py", delete=False) as temp_file:
            temp_path = Path(temp_file.name)

            # Download file content
            with fs.open(file_path, "rb") as cloud_file:
                temp_file.write(cloud_file.read())

            logger.info(f"Downloaded cloud file to temporary location: {file_path} -> {temp_path}")
            return temp_path

    except Exception as e:
        logger.warning(f"Failed to download cloud file {file_path}: {e}")
        return None


def _validate_file_path(file_path: str | Path) -> Path | None:
    """
    Validate that file path exists and is a file.

    For cloud paths (s3://, gs://, etc.), downloads to temporary local file.
    For local paths, validates existence directly.
    """
    assert file_path is not None
    assert isinstance(file_path, (str, Path)), "file_path must be str or Path"

    # Handle cloud paths by downloading to temp file
    if isinstance(file_path, str) and _is_cloud_path(file_path):
        return _download_to_temp(file_path)

    # Handle local paths
    path = Path(file_path)
    fs = get_default_filesystem()
    if not fs.exists(str(path)):
        logger.warning(f"Custom function file not found: {file_path}")
        return None
    if not fs.isfile(str(path)):
        logger.warning(f"Custom function path is not a file: {file_path}")
        return None
    return path


def _load_module_from_path(path: Path) -> object | None:
    """Load Python module from file path."""
    assert path is not None
    fs = get_default_filesystem()
    assert fs.exists(str(path)), "path must exist"
    spec = importlib.util.spec_from_file_location("custom_module", path)
    if spec is None or spec.loader is None:
        logger.warning(f"Failed to load module spec from: {path}")
        return None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _extract_function_from_module(
    module: object, function_name: str, file_path: Path
) -> Callable | None:
    """Extract function from module by name."""
    assert module is not None
    assert function_name is not None
    # NASA01-A compliant: Use dict access instead of getattr
    if function_name not in module.__dict__:
        available = [name for name in dir(module) if not name.startswith("_")]
        logger.warning(
            f"Function '{function_name}' not found in {file_path}. Available functions: {available}"
        )
        return None
    func = module.__dict__[function_name]
    if not callable(func):
        logger.warning(f"'{function_name}' in {file_path} is not callable")
        return None
    return func


def load_custom_function(
    file_path: str | Path,
    function_name: str,
) -> Callable | None:
    """
    Safely load a Python function from a file.

    Supports both local and cloud storage paths (s3://, gs://, az://, etc.).
    Cloud files are automatically downloaded to temporary local files and
    cleaned up after loading.

    Args:
        file_path: Path to Python file containing function (local or cloud URL)
        function_name: Name of function to load

    Returns:
        Function object if successful, None if failed

    Raises:
        No exceptions raised - errors are logged as warnings
    """
    assert file_path is not None, "file_path is required"
    assert function_name is not None, "function_name is required"

    temp_path = None
    is_cloud = isinstance(file_path, str) and _is_cloud_path(file_path)

    try:
        path = _validate_file_path(file_path)
        if path is None:
            return None

        # Track temp file for cleanup if this was a cloud download
        if is_cloud:
            temp_path = path

        module = _load_module_from_path(path)
        if module is None:
            return None
        func = _extract_function_from_module(module, function_name, path)
        if func is None:
            return None
        logger.info(f"Successfully loaded custom function '{function_name}' from {file_path}")
        return func
    except Exception as e:
        logger.warning(f"Error loading custom function from {file_path}: {e}")
        return None
    finally:
        # Clean up temporary file if it was downloaded from cloud
        if temp_path is not None:
            fs = get_default_filesystem()
            if fs.exists(str(temp_path)):
                try:
                    temp_path.unlink()
                    logger.debug(f"Cleaned up temporary file: {temp_path}")
                except Exception as cleanup_error:
                    logger.warning(
                        f"Failed to clean up temporary file {temp_path}: {cleanup_error}"
                    )


def validate_chunking_function_signature(func: Callable) -> bool:
    """
    Validate that a function has the expected chunking function signature.

    Expected signature:
    def func(text: str, chunk_size: int, chunk_overlap: int,
             separators: list[str], chars_per_token: float) -> list[str]

    Args:
        func: Function to validate

    Returns:
        True if signature is valid, False otherwise
    """
    assert func is not None
    assert callable(func)

    try:
        sig = inspect.signature(func)
        params = list(sig.parameters.keys())

        # Check parameter names
        expected_params = ["text", "chunk_size", "chunk_overlap", "separators", "chars_per_token"]
        if params != expected_params:
            logger.warning(
                f"Custom chunking function has incorrect parameters. "
                f"Expected: {expected_params}, Got: {params}"
            )
            return False

        return True

    except Exception as e:
        logger.warning(f"Error validating function signature: {e}")
        return False
