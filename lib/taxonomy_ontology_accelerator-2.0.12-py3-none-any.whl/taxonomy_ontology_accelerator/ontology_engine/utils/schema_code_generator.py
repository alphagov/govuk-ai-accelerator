"""Generate Pydantic models from ontology schema.json files."""

import json
import subprocess
import tempfile
from pathlib import Path
from typing import Any

from fsspec import AbstractFileSystem

from taxonomy_ontology_accelerator.commons.io.fsspec_utils import get_default_filesystem
from taxonomy_ontology_accelerator.commons.utils.logger import get_logger

logger = get_logger()


class SchemaCodeGeneratorError(Exception):
    """Schema code generation failed."""


def generate_pydantic_models_from_schema(
    schema_file: str | Path,
    output_file: str | Path,
    domain: str | None = None,
    fs: AbstractFileSystem | None = None,
) -> Path:
    """
    Generate Pydantic models from schema.json using datamodel-code-generator.

    Args:
        schema_file: Path to input schema.json
        output_file: Path where to save generated .py file (any location)
        domain: Optional domain name for better documentation
        fs: Optional filesystem instance (defaults to local filesystem)

    Returns:
        Path to generated file

    Example:
        >>> generate_pydantic_models_from_schema(
        ...     "output/ontology/travel/schema.json",
        ...     "my_models/travel.py",
        ...     domain="travel"
        ... )
    """
    assert schema_file is not None, "schema_file parameter is required"
    assert output_file is not None, "output_file parameter is required"
    schema_path = Path(schema_file)
    output_path = Path(output_file)

    if fs is None:
        fs = get_default_filesystem()

    if not fs.exists(str(schema_path)):
        raise FileNotFoundError(f"Schema not found: {schema_path}")

    logger.info(f"Generating Pydantic models from {schema_path}")

    # Load schema and convert to JSON Schema format
    schema_data = _load_and_convert_schema(schema_path, domain)

    # Generate models using datamodel-code-generator
    generated_code = _run_datamodel_codegen(schema_data)

    # Add header and exports
    final_code = _add_header_and_exports(generated_code, schema_data, domain)

    # Write output
    fs.makedirs(str(output_path.parent), exist_ok=True)
    with fs.open(str(output_path), "w", encoding="utf-8") as f:
        f.write(final_code)

    logger.info(
        f"✓ Generated {len(schema_data.get('entity_types', {}))} entity types, "
        f"{len(schema_data.get('relationship_types', {}))} relationship types → {output_path}"
    )

    return output_path


def _load_and_convert_schema(schema_path: Path, _domain: str | None) -> dict[str, Any]:
    """Load schema.json and convert to JSON Schema format for datamodel-code-generator."""
    assert schema_path is not None, "schema_path parameter is required"
    assert isinstance(schema_path, Path), "schema_path must be a Path object"
    with schema_path.open("r", encoding="utf-8") as f:
        schema_data = json.load(f)

    if "entity_types" not in schema_data:
        raise SchemaCodeGeneratorError("Schema missing 'entity_types'")

    # Convert to JSON Schema format
    definitions = {}

    # Entity types → JSON Schema definitions
    for name, defn in schema_data.get("entity_types", {}).items():
        class_name = "".join(w.capitalize() for w in name.split("_"))
        definitions[class_name] = {
            "type": "object",
            "properties": {field: _infer_type(field) for field in defn.get("fields", [])},
            "required": defn.get("required_fields", []),
        }

    # Relationship types → JSON Schema definitions
    for name, defn in schema_data.get("relationship_types", {}).items():
        class_name = "".join(w.capitalize() for w in name.split("_")) + "Relationship"
        definitions[class_name] = {
            "type": "object",
            "properties": {
                "from_entity": {"type": "string"},
                "to_entity": {"type": "string"},
                "relationship_type": {"type": "string", "const": name},
                **{
                    f: _infer_type(f)
                    for f in defn.get("fields", [])
                    if f not in ["from_entity", "to_entity", "relationship_type"]
                },
            },
            "required": ["from_entity", "to_entity", "relationship_type"],
        }

    schema_data["json_schema"] = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "definitions": definitions,
    }

    return schema_data


def _infer_type(field: str) -> dict[str, str | dict[str, str]]:
    """Infer JSON Schema type from field name."""
    assert field is not None, "field parameter is required"
    assert isinstance(field, str), "field must be a string"
    f = field.lower()
    if "aliases" in f or f.endswith("s"):
        return {"type": "array", "items": {"type": "string"}}
    if any(k in f for k in ["properties", "metadata"]):
        return {"type": "object"}
    if any(k in f for k in ["count", "score", "confidence"]):
        return {"type": "number"}
    if any(k in f for k in ["is_", "has_", "enabled"]):
        return {"type": "boolean"}
    return {"type": "string"}


def _run_datamodel_codegen(schema_data: dict[str, Any]) -> str:
    """Run datamodel-code-generator on JSON Schema."""
    assert schema_data is not None, "schema_data parameter is required"
    assert isinstance(schema_data, dict), "schema_data must be a dictionary"
    with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False, encoding="utf-8") as f:
        json.dump(schema_data["json_schema"], f, indent=2)
        temp_path = f.name

    try:
        result = subprocess.run(
            [
                "datamodel-codegen",
                "--input",
                temp_path,
                "--input-file-type",
                "jsonschema",
                "--output-model-type",
                "pydantic_v2.BaseModel",
                "--use-standard-collections",
                "--use-union-operator",
            ],
            capture_output=True,
            text=True,
            check=True,
        )
        return result.stdout
    except subprocess.CalledProcessError as e:
        raise SchemaCodeGeneratorError(f"datamodel-codegen failed: {e.stderr}") from e
    except FileNotFoundError:
        raise SchemaCodeGeneratorError(
            "datamodel-codegen not found. Install: uv pip install datamodel-code-generator"
        ) from None
    finally:
        Path(temp_path).unlink(missing_ok=True)


def _add_header_and_exports(code: str, schema_data: dict, domain: str | None) -> str:
    """Add module docstring and __all__ exports."""
    assert code is not None, "code parameter is required"
    assert isinstance(schema_data, dict), "schema_data must be a dictionary"
    header = f'''"""
Auto-generated Pydantic models for {domain or "ontology"} schema.

Generated from: schema v{schema_data.get("version", "unknown")}
Entity types: {len(schema_data.get("entity_types", {}))}
Relationship types: {len(schema_data.get("relationship_types", {}))}

Do not edit manually - regenerate using generate_pydantic_models_from_schema()
"""

'''

    # Extract class names for __all__
    classes = [
        line.split("class ")[1].split("(")[0].strip()
        for line in code.split("\n")
        if line.startswith("class ") and "(" in line
    ]

    return header + code + (f"\n\n__all__ = {classes}\n" if classes else "")
