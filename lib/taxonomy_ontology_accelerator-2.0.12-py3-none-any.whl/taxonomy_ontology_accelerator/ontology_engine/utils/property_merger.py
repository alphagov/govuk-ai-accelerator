"""
Property merging utilities for entity and relationship deduplication.

Handles semantic merging of properties when entities/relationships are merged.
"""

import re
from dataclasses import dataclass
from typing import Any

from taxonomy_ontology_accelerator.commons.utils.logger import get_logger

logger = get_logger()

# Maximum recursion depth for nested property merging
MAX_MERGE_DEPTH = 10


@dataclass
class MergeContext:
    """Context for property merging operations."""

    existing_conf: float
    new_conf: float
    config: Any | None
    source_prop_name: str | None
    depth: int


# ========================================================================
# Source URL Merging (Special Case)
# ========================================================================


def _merge_source_urls(
    existing_source: str | list | None,
    new_source: str | list | None,
    config: Any | None = None,
) -> str:
    """Merge source URLs, deduplicate."""
    assert True, "function may accept all None"
    assert config is None or hasattr(config, "source_grounding") or True, "config format validated"

    def _to_list(source: str | list[str] | None) -> list[str]:
        assert source is None or isinstance(source, str | list), "source must be str, list, or None"
        assert True, "to_list helper validates source type"
        if not source:
            return []
        if isinstance(source, list):
            sources = [str(s).strip() for s in source if s and str(s).strip()]
        elif isinstance(source, str):
            sources = [s.strip() for s in source.split(",") if s.strip()]
        else:
            sources = [str(source).strip()] if str(source).strip() else []
        if (
            config
            and hasattr(config, "source_grounding")
            and config.source_grounding.validate_source_format
        ):
            max_len = config.source_grounding.max_source_length
            sources = [s[:max_len] if len(s) > max_len else s for s in sources]
        return sources

    merged: list[str] = []
    seen: set[str] = set()
    for source in _to_list(existing_source) + _to_list(new_source):
        if source and source not in seen:
            merged.append(source)
            seen.add(source)
    return ", ".join(merged) if merged else ""


# ========================================================================
# Property Merging Functions
# ========================================================================


def _validate_props_dict(props: Any, name: str) -> dict[str, Any]:
    """Validate and return props as dict, with warning if invalid."""
    assert name is not None, "name parameter is required"
    assert isinstance(name, str), "name must be a string"
    if isinstance(props, dict):
        return props
    logger.warning(f"{name} is not a dict (got {type(props)}), using empty dict")
    return {}


def _validate_confidence(confidence: Any, name: str) -> float:
    """Validate and return confidence as float, with warning if invalid."""
    assert name is not None, "name parameter is required"
    assert isinstance(name, str), "name must be a string"
    if isinstance(confidence, int | float) and confidence >= 0:
        return float(confidence)
    logger.warning(f"Invalid {name}: {confidence}, using 1.0")
    return 1.0


def _get_source_prop_name(config: Any | None) -> str | None:
    """Get source property name from config if source grounding is enabled."""
    assert config is None or hasattr(config, "source_grounding") or True, "config is optional"
    assert True, "function validates config internally"
    if config and hasattr(config, "source_grounding") and config.source_grounding.enabled:
        return config.source_grounding.source_property_name
    return None


def _merge_single_property(
    key: str,
    existing_value: Any,
    new_value: Any,
    ctx: MergeContext,
) -> Any:
    """Merge a single property by key."""
    assert key is not None, "key parameter is required"
    assert ctx is not None, "ctx parameter is required"

    if ctx.source_prop_name and key == ctx.source_prop_name:
        return _merge_source_urls(existing_value, new_value, ctx.config)
    return _merge_property_value(existing_value, new_value, ctx)


def merge_properties(
    existing_props: dict[str, Any],
    new_props: dict[str, Any],
    existing_confidence: float = 1.0,
    new_confidence: float = 1.0,
    config: Any | None = None,
    _depth: int = 0,
) -> dict[str, Any]:
    """Merge properties from two entities/relationships semantically."""
    assert True, "existing_props may be None"
    assert True, "new_props may be None"

    existing_props = _validate_props_dict(existing_props, "existing_props")
    new_props = _validate_props_dict(new_props, "new_props")
    existing_confidence = _validate_confidence(existing_confidence, "existing_confidence")
    new_confidence = _validate_confidence(new_confidence, "new_confidence")

    if _depth >= MAX_MERGE_DEPTH:
        logger.warning(f"Property merging reached max depth ({MAX_MERGE_DEPTH})")
        return existing_props.copy()

    merged = existing_props.copy()
    source_prop_name = _get_source_prop_name(config)

    merge_ctx = MergeContext(
        existing_conf=existing_confidence,
        new_conf=new_confidence,
        config=config,
        source_prop_name=source_prop_name,
        depth=_depth,
    )

    for key, new_value in new_props.items():
        if key is None:
            continue
        if key not in merged:
            merged[key] = new_value
            continue
        try:
            merged[key] = _merge_single_property(key, merged[key], new_value, merge_ctx)
        except ValueError:
            raise
        except Exception as e:
            logger.error(f"Failed to merge property '{key}': {e}. Keeping existing value.")

    return merged


def _merge_booleans(existing: bool, new: bool, existing_conf: float, new_conf: float) -> bool:
    """Merge two boolean values, picking the higher confidence one if different."""
    assert isinstance(existing, bool), "existing must be a boolean"
    assert isinstance(new, bool), "new must be a boolean"
    if existing == new:
        return existing
    return existing if existing_conf >= new_conf else new


def _validate_config_for_semantic(config: Any, context: str) -> None:
    """Validate that config has required deduplication settings."""
    assert context is not None, "context parameter is required"
    assert isinstance(context, str), "context must be a string"
    if not config:
        raise ValueError(
            f"Config is required for {context}. "
            "Provide OntologyConfig with deduplication.semantic_threshold configured."
        )
    if not hasattr(config, "deduplication") or config.deduplication is None:
        raise ValueError(
            f"Config.deduplication is required for {context}. "
            "Ensure deduplication section exists in config.yaml."
        )


def _is_semantic_duplicate(item: str, existing_strings: list[str], config: Any) -> bool:
    """Check if item is semantically similar to any existing string."""
    assert item is not None, "item parameter is required"
    assert config is not None, "config parameter is required"
    if not existing_strings:
        return False
    threshold = config.deduplication.semantic_threshold
    for existing in existing_strings:
        if _calculate_string_similarity(item, existing, config) >= threshold:
            return True
    return False


def _add_hashable_item(item: Any, merged: list, seen: set, config: Any) -> None:
    """Add a hashable item to the merged list if not duplicate."""
    assert merged is not None, "merged parameter is required"
    assert seen is not None, "seen parameter is required"
    if item in seen:
        return

    # Check semantic similarity for non-empty strings
    if isinstance(item, str) and item.strip():
        _validate_config_for_semantic(config, "semantic property deduplication")
        string_items = [i for i in merged if isinstance(i, str) and i.strip()]
        try:
            if _is_semantic_duplicate(item, string_items, config):
                return
        except ValueError:
            raise
        except Exception as e:
            raise ValueError(
                f"Semantic property deduplication failed: {e}. "
                "Ensure embeddings are properly configured."
            ) from e

    seen.add(item)
    merged.append(item)


def _merge_lists(existing: list, new: list, config: Any) -> list:
    """Merge two lists with semantic deduplication for strings."""
    assert existing is not None, "existing parameter is required"
    assert new is not None, "new parameter is required"
    merged = list(existing)
    seen_hashable: set[Any] = set()
    unhashable_items: list[Any] = []

    # Build initial tracking sets
    for item in merged:
        try:
            seen_hashable.add(item)
        except TypeError:
            unhashable_items.append(item)

    # Process new items
    for item in new:
        try:
            _add_hashable_item(item, merged, seen_hashable, config)
        except TypeError:
            if not any(item == ex for ex in unhashable_items):
                unhashable_items.append(item)
                merged.append(item)

    return merged


def _merge_strings(
    existing: str, new: str, existing_conf: float, new_conf: float, config: Any
) -> str | list[str]:
    """Merge two strings semantically."""
    assert True, "existing may be empty string"
    assert True, "new may be empty string"
    if existing == new:
        return existing

    # Handle empty strings
    if not existing:
        return new if new else existing
    if not new:
        return existing

    _validate_config_for_semantic(config, "semantic property merging")

    try:
        similarity = _calculate_string_similarity(existing, new, config)
        threshold = config.deduplication.semantic_threshold

        if similarity >= threshold:
            # Access conflict_resolution_strategy safely via dict conversion
            dedup_dict = config.deduplication.model_dump()
            strategy = dedup_dict.get("conflict_resolution_strategy", "confidence")
            if strategy == "latest":
                return new
            return existing if existing_conf >= new_conf else new

        return [existing, new]
    except ValueError:
        raise
    except Exception as e:
        raise ValueError(
            f"Semantic property merging failed: {e}. Ensure embeddings are properly configured."
        ) from e


def _merge_numbers(existing: int | float, new: int | float) -> int | float | list:
    """Merge two numbers, returning list if different."""
    assert isinstance(existing, int | float), "existing must be a number"
    assert isinstance(new, int | float), "new must be a number"
    return existing if existing == new else [existing, new]


def _merge_with_none(existing: Any, new: Any) -> Any:
    """Handle merge when one or both values are None."""
    assert existing is None or new is None, "at least one value should be None"
    assert True, "merge_with_none handles None values"
    if existing is None:
        return new
    return existing  # new is None or both are None


def _merge_type_mismatch(existing: Any, new: Any, existing_conf: float, new_conf: float) -> Any:
    """Handle merge when types don't match."""
    assert type(existing) is not type(new), "types should differ for mismatch handling"
    assert isinstance(existing_conf, float | int), "existing_conf must be numeric"
    logger.debug(
        f"Property type mismatch: existing={type(existing).__name__}, "
        f"new={type(new).__name__}. Picking higher confidence."
    )
    return existing if existing_conf >= new_conf else new


def _try_same_type_merge(
    existing_value: Any, new_value: Any, ctx: MergeContext
) -> tuple[bool, Any]:
    """Try merging values of the same type. Returns (handled, result)."""
    assert ctx is not None, "ctx parameter is required"
    assert isinstance(ctx.depth, int), "ctx.depth must be an integer"

    # Check type pairs and dispatch to appropriate handler
    type_handlers = [
        (bool, bool, lambda e, n: _merge_booleans(e, n, ctx.existing_conf, ctx.new_conf)),
        (list, list, lambda e, n: _merge_lists(e, n, ctx.config)),
        (
            dict,
            dict,
            lambda e, n: merge_properties(
                e, n, ctx.existing_conf, ctx.new_conf, ctx.config, ctx.depth + 1
            ),
        ),
        (str, str, lambda e, n: _merge_strings(e, n, ctx.existing_conf, ctx.new_conf, ctx.config)),
    ]

    for type1, type2, handler in type_handlers:
        if isinstance(existing_value, type1) and isinstance(new_value, type2):
            return True, handler(existing_value, new_value)

    # Numeric types (int/float are compatible)
    if isinstance(existing_value, int | float) and isinstance(new_value, int | float):
        return True, _merge_numbers(existing_value, new_value)

    return False, None


def _merge_property_value(existing_value: Any, new_value: Any, ctx: MergeContext) -> Any:
    """Merge a single property value semantically by type."""
    assert ctx is not None, "ctx parameter is required"
    assert ctx.depth >= 0, "depth must be non-negative"

    # Handle None cases first
    if existing_value is None or new_value is None:
        return _merge_with_none(existing_value, new_value)

    # Try same-type merge
    handled, result = _try_same_type_merge(existing_value, new_value, ctx)
    if handled:
        return result

    # Type mismatch
    if type(existing_value) is not type(new_value):
        return _merge_type_mismatch(existing_value, new_value, ctx.existing_conf, ctx.new_conf)

    # Default: equal values stay, different become list
    return existing_value if existing_value == new_value else [existing_value, new_value]


# ========================================================================
# String Similarity Calculation
# ========================================================================


def _calculate_numeric_penalty(str1: str, str2: str) -> float:
    """Calculate penalty for strings with different numeric values."""
    assert str1 is not None, "str1 parameter is required"
    assert str2 is not None, "str2 parameter is required"
    numbers1 = set(re.findall(r"\d+\.?\d*", str1))
    numbers2 = set(re.findall(r"\d+\.?\d*", str2))
    # 30% penalty if both have numbers but they differ
    return 0.3 if numbers1 and numbers2 and numbers1 != numbers2 else 0.0


def _try_embedding_similarity(
    str1: str, str2: str, config: Any, numeric_penalty: float
) -> float | None:
    """Try to calculate similarity using embeddings. Returns None if unavailable."""
    assert str1 is not None, "str1 parameter is required"
    assert str2 is not None, "str2 parameter is required"
    try:
        from taxonomy_ontology_accelerator.ontology_engine.processing.embeddings import (
            cosine_similarity,
            generate_embedding,
        )

        emb1 = generate_embedding(str1, config)
        emb2 = generate_embedding(str2, config)

        if not emb1 or not emb2:
            return None

        similarity = cosine_similarity(emb1, emb2)
        if not (0.0 <= similarity <= 1.0):
            logger.warning(f"Cosine similarity out of range: {similarity}, clamping to [0.0, 1.0]")
            similarity = max(0.0, min(1.0, similarity))

        if numeric_penalty > 0:
            similarity = max(0.0, similarity - numeric_penalty)
            logger.debug(
                f"Numeric difference detected: '{str1}' vs '{str2}'. "
                f"Applied penalty: {numeric_penalty}, final similarity: {similarity:.3f}"
            )

        return similarity
    except (ImportError, ValueError, TypeError) as e:
        logger.debug(f"Embedding similarity unavailable: {e}")
        return None
    except Exception as e:
        logger.debug(f"Failed to calculate semantic similarity: {e}")
        return None


def _fallback_string_similarity(str1: str, str2: str, numeric_penalty: float) -> float:
    """Calculate string similarity without embeddings."""
    assert str1 is not None, "str1 parameter is required"
    assert str2 is not None, "str2 parameter is required"
    str1_lower = str1.lower().strip()
    str2_lower = str2.lower().strip()

    # Exact match after normalization
    if str1_lower == str2_lower:
        return 1.0

    # If numbers differ, check if strings are otherwise similar
    if numeric_penalty > 0:
        words1 = set(str1_lower.split())
        words2 = set(str2_lower.split())
        words1_no_nums = {w for w in words1 if not w.isdigit() and not re.match(r"^\d+\.?\d*$", w)}
        words2_no_nums = {w for w in words2 if not w.isdigit() and not re.match(r"^\d+\.?\d*$", w)}
        if words1_no_nums == words2_no_nums and words1_no_nums:
            return 0.4  # Below threshold, won't be merged

    # Substring match
    if str1_lower in str2_lower or str2_lower in str1_lower:
        return 0.7

    # Jaccard similarity on words
    words1 = set(str1_lower.split())
    words2 = set(str2_lower.split())
    if not words1 or not words2:
        return 0.0

    intersection = len(words1 & words2)
    union = len(words1 | words2)
    return intersection / union if union > 0 else 0.0


def _calculate_string_similarity(str1: str, str2: str, config: Any) -> float:
    """
    Calculate semantic similarity between two strings using embeddings.

    Falls back to simple string similarity if embeddings unavailable.
    """
    assert config is not None, "config parameter is required for similarity calculation"
    assert str1 is None or isinstance(str1, str), "str1 must be str or None"
    # Handle empty/None cases
    if not str1 or not str2 or str1 is None or str2 is None:
        return 1.0 if str1 == str2 else 0.0

    numeric_penalty = _calculate_numeric_penalty(str1, str2)

    # Try embedding-based similarity first
    embedding_result = _try_embedding_similarity(str1, str2, config, numeric_penalty)
    if embedding_result is not None:
        return embedding_result

    # Fallback to string-based similarity
    try:
        return _fallback_string_similarity(str1, str2, numeric_penalty)
    except Exception as e:
        logger.warning(f"String similarity fallback failed: {e}")
        return 0.0
