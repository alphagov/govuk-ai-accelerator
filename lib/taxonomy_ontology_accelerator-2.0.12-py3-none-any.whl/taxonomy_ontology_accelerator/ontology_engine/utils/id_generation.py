"""
ID and timestamp generation utilities for ontology extraction.
"""

import time
from typing import Any

from taxonomy_ontology_accelerator.ontology_engine.config.config import OntologyConfig

# ========================================================================
# ID Generation Functions
# ========================================================================


def generate_entity_id(counter: int, config: OntologyConfig) -> str:
    """
    Generate entity ID using configured format.

    Args:
        counter: Entity counter value
        config: Ontology configuration

    Returns:
        Formatted entity ID
    """
    assert counter is not None, "Counter must not be None"
    assert isinstance(counter, int), "Counter must be an integer"
    assert config is not None, "Config must not be None"

    prefix = config.output.entity_id_prefix  # Get prefix (e.g., "entity_")
    format_str = config.output.entity_id_format  # Get format string (e.g., "{prefix}{counter:06d}")
    return format_str.format(prefix=prefix, counter=counter)  # Format ID with prefix and counter


def generate_relationship_id(counter: int, config: OntologyConfig) -> str:
    """
    Generate relationship ID using configured format.

    Args:
        counter: Relationship counter value
        config: Ontology configuration

    Returns:
        Formatted relationship ID
    """
    assert counter is not None, "Counter must not be None"
    assert isinstance(counter, int), "Counter must be an integer"
    assert config is not None, "Config must not be None"

    prefix = config.output.relationship_id_prefix
    format_str = config.output.relationship_id_format
    return format_str.format(prefix=prefix, counter=counter)


# ========================================================================
# ID Counter Extraction
# ========================================================================


def extract_id_counter(
    entity_id: str,
    prefix: str,
) -> int | None:
    """
    Extract counter value from an entity or relationship ID.

    Args:
        entity_id: Entity or relationship ID (e.g., "entity_000123" or "rel_000456")
        prefix: ID prefix to strip (e.g., "entity_" or "rel_")

    Returns:
        Counter value as integer, or None if ID doesn't match expected format

    Example:
        >>> extract_id_counter("entity_000123", "entity_")
        123
        >>> extract_id_counter("rel_000456", "rel_")
        456
        >>> extract_id_counter("invalid_id", "entity_")
        None
    """
    assert entity_id is not None, "Entity ID must not be None"
    assert isinstance(entity_id, str), "Entity ID must be a string"
    assert prefix is not None, "Prefix must not be None"
    assert isinstance(prefix, str), "Prefix must be a string"

    if not entity_id.startswith(prefix):  # Check if ID has expected prefix
        return None  # Invalid format

    try:
        counter_str = entity_id[len(prefix) :].lstrip(
            "_"
        )  # Extract counter part (remove prefix and leading underscores)
        if not counter_str:  # Empty counter string
            return None  # Invalid format
        counter = int(counter_str)
        if counter < 0:
            return None
        return counter
    except (ValueError, IndexError):
        return None


def find_max_id_counter(
    ids: list[str],
    prefix: str,
) -> int:
    """
    Find maximum counter value from a list of IDs.

    Args:
        ids: List of entity or relationship IDs
        prefix: ID prefix to match (e.g., "entity_" or "rel_")

    Returns:
        Maximum counter value found, or -1 if no matching IDs found

    Example:
        >>> find_max_id_counter(["entity_000001", "entity_000123", "entity_000045"], "entity_")
        123
        >>> find_max_id_counter(["invalid_id"], "entity_")
        -1
    """
    assert ids is not None, "IDs must not be None"
    assert isinstance(ids, list), "IDs must be a list"
    assert prefix is not None, "Prefix must not be None"

    max_counter = -1  # Initialize to -1 (no valid IDs found)
    for entity_id in ids:  # Iterate all IDs
        counter = extract_id_counter(entity_id, prefix)  # Extract counter from ID
        if counter is not None:  # Valid counter extracted
            max_counter = max(max_counter, counter)  # Track maximum counter value
    return max_counter  # Return max counter (or -1 if none found)


def _extract_ids_from_items(
    items: list[Any],  # pyright: ignore[reportExplicitAny]
    id_attr: str,
) -> list[str]:
    """
    Extract ID strings from items using attribute name.

    Note: Currently only supports id_attr="id" to comply with NASA01 (no getattr).
    """
    assert items is not None, "Items must not be None"
    assert isinstance(items, list), "Items must be a list"
    assert id_attr == "id", "Only 'id' attribute is supported (NASA01 compliance)"

    ids: list[str] = []
    for item in items:  # pyright: ignore[reportAny]
        if hasattr(item, "id"):  # pyright: ignore[reportAny]
            item_id = item.id  # pyright: ignore[reportAny]
            if item_id is not None:
                ids.append(item_id)  # pyright: ignore[reportAny]
    return ids


def initialize_id_counter(
    items: list[Any] | None,  # pyright: ignore[reportExplicitAny]
    id_attr: str,
    prefix: str,
) -> int:
    """
    Initialize ID counter from existing items (for incremental mode).

    Extracts IDs from items, finds max counter, and returns next counter value.
    This eliminates redundant ID counter initialization code across modules.

    Args:
        items: List of items with IDs (e.g., entities or relationships), or None
        id_attr: Attribute name to get ID from (e.g., "id" for Entity/Relationship objects)
        prefix: ID prefix to match (e.g., "entity_" or "rel_")

    Returns:
        Next counter value to use (0 if no items or no valid IDs found)

    Example:
        >>> entities = [Entity(id="entity_000001"), Entity(id="entity_000123")]
        >>> initialize_id_counter(entities, "id", "entity_")
        124
        >>> initialize_id_counter(None, "id", "entity_")
        0
    """
    assert id_attr is not None, "ID attribute must not be None"
    assert isinstance(id_attr, str), "ID attribute must be a string"
    assert prefix is not None, "Prefix must not be None"

    if not items:
        return 0

    ids = _extract_ids_from_items(items, id_attr)
    max_counter = find_max_id_counter(ids, prefix)

    if max_counter >= 0:
        return max_counter + 1
    return 0


# ========================================================================
# Timestamp Generation
# ========================================================================


def get_current_timestamp(config: OntologyConfig) -> str:
    """
    Get current UTC timestamp using configured format.

    Args:
        config: Ontology configuration

    Returns:
        Formatted timestamp string
    """
    assert config is not None, "Config must not be None"
    assert hasattr(config, "output"), "Config must have output attribute"

    return time.strftime(config.output.timestamp_format, time.gmtime())
