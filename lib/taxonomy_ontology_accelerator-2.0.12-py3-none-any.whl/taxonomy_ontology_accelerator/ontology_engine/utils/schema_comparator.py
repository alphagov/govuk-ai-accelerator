"""
Schema comparison utility for comparing two ontology schemas.

This module provides library functions to compare schemas from different ontologies,
identifying similarities, differences, and semantic matches between entity types
and relationship types.

Example:
    >>> from taxonomy_ontology_accelerator.ontology_engine.utils.schema_comparator import compare_schemas
    >>> result = compare_schemas("schema1.json", "schema2.json")
    >>> print(f"Common types: {result.common_types}")
    >>> print(f"Unique to schema1: {result.unique_to_original}")
"""

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, cast

from fsspec import AbstractFileSystem
from pydantic import ValidationError

from taxonomy_ontology_accelerator.commons.io.file_utils import safe_read_file
from taxonomy_ontology_accelerator.commons.utils.logger import get_logger
from taxonomy_ontology_accelerator.ontology_engine.config.config import (
    OntologyConfig,
    OntologyConfigLoader,
)
from taxonomy_ontology_accelerator.ontology_engine.core.models import OntologySchema
from taxonomy_ontology_accelerator.ontology_engine.processing.type_similarity import (
    find_similar_type,
)

logger = get_logger()


@dataclass
class TypeComparison:
    """Result of comparing a single type."""

    type_name: str
    original_has: bool
    optimized_has: bool
    exact_match: bool
    similar_type: str | None
    similarity_score: float
    original_description: str | None
    optimized_description: str | None


@dataclass
class SchemaComparisonResult:
    """Comparison result between original and optimized schema."""

    original_path: str
    optimized_path: str | None
    original_domain: str
    optimized_domain: str

    entity_type_comparisons: list[TypeComparison]
    unique_to_original: list[str]
    unique_to_optimized: list[str]
    common_types: list[str]

    relationship_type_comparisons: list[TypeComparison]
    unique_rels_to_original: list[str]
    unique_rels_to_optimized: list[str]
    common_rels: list[str]

    total_entity_types_original: int
    total_entity_types_optimized: int
    total_relationship_types_original: int
    total_relationship_types_optimized: int


def load_schema_from_file(file_path: Path, fs: AbstractFileSystem | None = None) -> OntologySchema:
    """Load schema from schema.json or graph.json file."""
    assert file_path is not None, "File path must not be None"
    assert isinstance(file_path, Path), "File path must be a Path object"

    try:
        json_content = safe_read_file(file_path, fs=fs)
        parsed_data = json.loads(json_content)  # pyright: ignore[reportAny]
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid JSON in {file_path}: {e}") from e

    assert isinstance(parsed_data, dict), "Parsed JSON must be a dictionary"
    data = cast("dict[str, Any]", parsed_data)  # pyright: ignore[reportExplicitAny]
    assert len(data) > 0, "Parsed JSON must not be empty"

    schema_data = _extract_schema_data(data)

    try:
        return OntologySchema(**schema_data)  # pyright: ignore[reportAny]
    except ValidationError as e:
        raise ValueError(f"Failed to parse schema from {file_path}: {e}") from e


def _extract_schema_data(data: dict[str, Any]) -> dict[str, Any]:  # pyright: ignore[reportExplicitAny]
    """Extract schema data from various JSON file formats."""
    assert isinstance(data, dict), "Data must be a dictionary"
    assert len(data) > 0, "Data must not be empty"

    if "schema" in data and isinstance(data["schema"], dict):
        schema_data = cast("dict[str, Any]", data["schema"])  # pyright: ignore[reportExplicitAny]
        logger.debug("Extracted schema from schema.json format")
        return schema_data

    if "entity_types" in data or ("domain" in data and "entity_types" in data):
        logger.debug("Extracted schema from direct schema format")
        return data

    if "graph" in data and isinstance(data["graph"], dict):
        graph_data = cast("dict[str, Any]", data["graph"])  # pyright: ignore[reportExplicitAny]
        if "schema" in graph_data and isinstance(graph_data["schema"], dict):
            return cast("dict[str, Any]", graph_data["schema"])  # pyright: ignore[reportExplicitAny]
        error_msg = (
            "graph.json file does not contain schema information. "
            "Please provide a schema.json file instead."
        )
        raise ValueError(error_msg)

    error_msg = (
        f"Unknown file format. Expected schema.json or graph.json with schema field. "
        f"File contains keys: {list(data.keys())}"
    )
    raise ValueError(error_msg)


def compare_schemas(
    schema1_path: str | Path,
    schema2_path: str | Path,
    config: OntologyConfig | None = None,
    similarity_threshold: float = 0.7,
) -> SchemaComparisonResult:
    """
    Compare two schemas and identify similarities and differences.

    Args:
        schema1_path: Path to first schema.json or graph.json file
        schema2_path: Path to second schema.json or graph.json file
        config: Ontology configuration (optional, will load default if not provided)
        similarity_threshold: Minimum similarity score to consider types as similar (0.0-1.0)

    Returns:
        SchemaComparisonResult with detailed comparison information
    """
    assert schema1_path is not None, "Schema 1 path must not be None"
    assert schema2_path is not None, "Schema 2 path must not be None"
    assert 0.0 <= similarity_threshold <= 1.0, "Similarity threshold must be between 0.0 and 1.0"

    schema1_path = Path(schema1_path)
    schema2_path = Path(schema2_path)

    if config is None:
        config = OntologyConfigLoader.load()

    schema1, schema2 = _load_schemas(schema1_path, schema2_path)

    entity_comparisons = _compare_entity_types(schema1, schema2, config, similarity_threshold)
    relationship_comparisons = _compare_relationship_types(
        schema1, schema2, config, similarity_threshold
    )

    unique_to_original, unique_to_optimized, common_types = _extract_type_lists(entity_comparisons)
    unique_rels_to_original, unique_rels_to_optimized, common_rels = _extract_type_lists(
        relationship_comparisons
    )

    return SchemaComparisonResult(
        original_path=str(schema1_path),
        optimized_path=str(schema2_path),
        original_domain=schema1.domain,
        optimized_domain=schema2.domain,
        entity_type_comparisons=entity_comparisons,
        unique_to_original=unique_to_original,
        unique_to_optimized=unique_to_optimized,
        common_types=common_types,
        relationship_type_comparisons=relationship_comparisons,
        unique_rels_to_original=unique_rels_to_original,
        unique_rels_to_optimized=unique_rels_to_optimized,
        common_rels=common_rels,
        total_entity_types_original=len(schema1.entity_types),
        total_entity_types_optimized=len(schema2.entity_types),
        total_relationship_types_original=len(schema1.relationship_types),
        total_relationship_types_optimized=len(schema2.relationship_types),
    )


def _load_schemas(schema1_path: Path, schema2_path: Path) -> tuple[OntologySchema, OntologySchema]:
    """Load both schemas from their file paths."""
    assert schema1_path is not None, "Schema 1 path must not be None"
    assert schema2_path is not None, "Schema 2 path must not be None"

    logger.info(f"Loading schema 1 from: {schema1_path}")
    schema1 = load_schema_from_file(schema1_path)

    logger.info(f"Loading schema 2 from: {schema2_path}")
    schema2 = load_schema_from_file(schema2_path)

    return schema1, schema2


def _extract_type_lists(
    comparisons: list[TypeComparison],
) -> tuple[list[str], list[str], list[str]]:
    """Extract unique and common type names from comparisons."""
    assert comparisons is not None, "Comparisons list must not be None"
    assert isinstance(comparisons, list), "Comparisons must be a list"

    unique_to_original = [
        comp.type_name for comp in comparisons if comp.original_has and not comp.optimized_has
    ]
    unique_to_optimized = [
        comp.type_name for comp in comparisons if comp.optimized_has and not comp.original_has
    ]
    common_types = [
        comp.type_name for comp in comparisons if comp.original_has and comp.optimized_has
    ]

    return unique_to_original, unique_to_optimized, common_types


def _compare_entity_types(
    schema1: OntologySchema,
    schema2: OntologySchema,
    config: OntologyConfig,
    threshold: float,
) -> list[TypeComparison]:
    """Compare entity types between two schemas."""
    assert schema1 is not None, "Schema 1 must not be None"
    assert schema2 is not None, "Schema 2 must not be None"
    assert config is not None, "Config must not be None"
    assert 0.0 <= threshold <= 1.0, "Threshold must be between 0.0 and 1.0"

    comparisons: list[TypeComparison] = []
    all_types = set(schema1.entity_types.keys()) | set(schema2.entity_types.keys())

    for type_name in all_types:
        schema1_def = schema1.entity_types.get(type_name)
        schema2_def = schema2.entity_types.get(type_name)

        original_has = schema1_def is not None
        optimized_has = schema2_def is not None
        exact_match = original_has and optimized_has

        similar_type: str | None = None
        similarity_score = 1.0 if exact_match else 0.0

        if original_has and not optimized_has:
            similar_type, similarity_score = find_similar_type(
                type_name,
                None,
                schema2,
                threshold,
                config,
            )
        elif optimized_has and not original_has:
            similar_type, similarity_score = find_similar_type(
                type_name,
                None,
                schema1,
                threshold,
                config,
            )

        comparisons.append(
            TypeComparison(
                type_name=type_name,
                original_has=original_has,
                optimized_has=optimized_has,
                exact_match=exact_match,
                similar_type=similar_type,
                similarity_score=similarity_score,
                original_description=None,
                optimized_description=None,
            )
        )

    return comparisons


def _compare_relationship_types(
    schema1: OntologySchema,
    schema2: OntologySchema,
    _config: OntologyConfig,
    _threshold: float,
) -> list[TypeComparison]:
    """Compare relationship types between two schemas."""
    assert schema1 is not None, "Schema 1 must not be None"
    assert schema2 is not None, "Schema 2 must not be None"

    comparisons: list[TypeComparison] = []
    all_rels = set(schema1.relationship_types.keys()) | set(schema2.relationship_types.keys())

    for rel_name in all_rels:
        schema1_def = schema1.relationship_types.get(rel_name)
        schema2_def = schema2.relationship_types.get(rel_name)

        original_has = schema1_def is not None
        optimized_has = schema2_def is not None
        exact_match = original_has and optimized_has

        similar_type = None
        similarity_score = 1.0 if exact_match else 0.0

        comparisons.append(
            TypeComparison(
                type_name=rel_name,
                original_has=original_has,
                optimized_has=optimized_has,
                exact_match=exact_match,
                similar_type=similar_type,
                similarity_score=similarity_score,
                original_description=None,
                optimized_description=None,
            )
        )

    return comparisons


def print_comparison_report(result: SchemaComparisonResult) -> None:
    """Print a human-readable comparison report."""
    assert result is not None, "Result must not be None"
    assert isinstance(result, SchemaComparisonResult), "Result must be a SchemaComparisonResult"

    _print_report_header(result)
    _print_entity_comparison(result)
    _print_relationship_comparison(result)


def _print_report_header(result: SchemaComparisonResult) -> None:
    """Print comparison report header with schema metadata."""
    assert result is not None, "Result must not be None"
    assert result.original_path is not None, "Original path must not be None"

    print("=" * 70)
    print("SCHEMA COMPARISON REPORT")
    print("=" * 70)
    print()
    print(f"Schema 1: {result.original_path}")
    print(f"  Domain: {result.original_domain}")
    print(f"  Entity Types: {result.total_entity_types_original}")
    print(f"  Relationship Types: {result.total_relationship_types_original}")
    print()
    print(f"Schema 2: {result.optimized_path}")
    print(f"  Domain: {result.optimized_domain}")
    print(f"  Entity Types: {result.total_entity_types_optimized}")
    print(f"  Relationship Types: {result.total_relationship_types_optimized}")
    print()


def _print_entity_comparison(result: SchemaComparisonResult) -> None:
    """Print entity type comparison section."""
    assert result is not None, "Result must not be None"
    assert result.entity_type_comparisons is not None, "Entity type comparisons must not be None"

    print("=" * 70)
    print("ENTITY TYPE COMPARISON")
    print("=" * 70)
    print()
    print(f"Common Types ({len(result.common_types)}):")
    for type_name in sorted(result.common_types):
        print(f"  ✓ {type_name}")
    print()
    print(f"Only in Schema 1 ({len(result.unique_to_original)}):")
    for type_name in sorted(result.unique_to_original):
        comp = next(c for c in result.entity_type_comparisons if c.type_name == type_name)
        if comp.similar_type:
            msg = (
                f"  → {type_name} (similar to Schema 2: {comp.similar_type}, "
                f"score: {comp.similarity_score:.3f})"
            )
            print(msg)
        else:
            print(f"  → {type_name}")
    print()
    print(f"Only in Schema 2 ({len(result.unique_to_optimized)}):")
    for type_name in sorted(result.unique_to_optimized):
        comp = next(c for c in result.entity_type_comparisons if c.type_name == type_name)
        if comp.similar_type:
            msg = (
                f"  → {type_name} (similar to Schema 1: {comp.similar_type}, "
                f"score: {comp.similarity_score:.3f})"
            )
            print(msg)
        else:
            print(f"  → {type_name}")
    print()


def _print_relationship_comparison(result: SchemaComparisonResult) -> None:
    """Print relationship type comparison section."""
    assert result is not None, "Result must not be None"
    assert result.relationship_type_comparisons is not None, (
        "Relationship type comparisons must not be None"
    )

    print("=" * 70)
    print("RELATIONSHIP TYPE COMPARISON")
    print("=" * 70)
    print()
    print(f"Common Relationships ({len(result.common_rels)}):")
    for rel_name in sorted(result.common_rels):
        print(f"  ✓ {rel_name}")
    print()
    print(f"Only in Schema 1 ({len(result.unique_rels_to_original)}):")
    for rel_name in sorted(result.unique_rels_to_original):
        print(f"  → {rel_name}")
    print()
    print(f"Only in Schema 2 ({len(result.unique_rels_to_optimized)}):")
    for rel_name in sorted(result.unique_rels_to_optimized):
        print(f"  → {rel_name}")
    print()
    print("=" * 70)
