"""
Allow running the package as a module: python -m taxonomy_ontology_accelerator

Usage:
    python -m taxonomy_ontology_accelerator --help
    python -m taxonomy_ontology_accelerator taxonomy extract -d travel -i ./data/
    python -m taxonomy_ontology_accelerator ontology extract -i file.txt -d travel
    python -m taxonomy_ontology_accelerator doctor
"""

from taxonomy_ontology_accelerator.cli import run_cli

if __name__ == "__main__":
    run_cli()
