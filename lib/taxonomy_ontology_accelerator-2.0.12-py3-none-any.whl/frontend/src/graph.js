import Graph from 'graphology';
import Sigma from 'sigma';
import forceAtlas2 from 'graphology-layout-forceatlas2';
import { EdgeCurvedArrowProgram as EdgeCurveProgram } from "@sigma/edge-curve";
import { NodeBorderProgram } from '@sigma/node-border';

let sigmaInstance = null;
let currentDomain = null;
let currentData = null;
let graphData = null;
let highlightedNodes = new Set();
let highlightedEdges = new Set();
let hoveredNode = null;

function getAppBasePath() {
    const pathname = window.location.pathname || '/';
    if (pathname === '/') return '';
    return pathname.endsWith('/') ? pathname.slice(0, -1) : pathname;
}

function buildAppUrl(path) {
    assert(typeof path === 'string' && path.length > 0, 'path must be a non-empty string');
    const normalizedPath = path.startsWith('/') ? path : `/${path}`;
    return `${getAppBasePath()}${normalizedPath}`;
}

function showError(message) {
    assert(typeof message === 'string', 'message must be a string');
    const errorEl = document.getElementById('error');
    assert(errorEl !== null, 'error element must exist in DOM');
    errorEl.textContent = message;
    errorEl.style.display = 'block';
    setTimeout(() => { errorEl.style.display = 'none'; }, 5000);
}

function updateInfo(nodeCount, linkCount) {
    assert(typeof nodeCount === 'number', 'nodeCount must be a number');
    assert(typeof linkCount === 'number', 'linkCount must be a number');
    document.getElementById('info').textContent = `${nodeCount} nodes · ${linkCount} edges`;
}

function assert(condition, message) {
    if (!condition) throw new Error(`Assertion failed: ${message}`);
}

async function loadDomains() {
    try {
        const response = await fetch(buildAppUrl('/api/domains'));
        const data = await response.json();
        const select = document.getElementById('domain-select');
        data.domains.forEach(domain => {
            const option = document.createElement('option');
            option.value = domain.name;
            option.textContent = `${domain.name}${domain.has_graph ? '' : ' (no graph)'}`;
            option.disabled = !domain.has_graph;
            select.appendChild(option);
        });
        if (data.domains.length > 0) {
            const firstWithGraph = data.domains.find(d => d.has_graph);
            if (firstWithGraph) {
                select.value = firstWithGraph.name;
                currentDomain = firstWithGraph.name;
                window.currentDomain = currentDomain;
                await loadGraph();
            }
        }
    } catch (error) {
        showError('Failed to load domains: ' + error.message);
    }
}

function getColorForType(type) {
    if (!type) return [99, 102, 241];
    let hash = 0;
    for (let i = 0; i < type.length; i++) {
        hash = ((hash << 5) - hash) + type.charCodeAt(i);
        hash = hash & hash;
    }
    const hue = Math.abs(hash) % 360;
    const saturation = 65 + (Math.abs(hash >> 8) % 20);
    const lightness = 50 + (Math.abs(hash >> 16) % 15);
    const h = hue / 360, s = saturation / 100, l = lightness / 100;
    const c = (1 - Math.abs(2 * l - 1)) * s;
    const x = c * (1 - Math.abs((h * 6) % 2 - 1));
    const m = l - c / 2;
    let r = 0, g = 0, b = 0;
    if (h < 1/6) { r = c; g = x; b = 0; }
    else if (h < 2/6) { r = x; g = c; b = 0; }
    else if (h < 3/6) { r = 0; g = c; b = x; }
    else if (h < 4/6) { r = 0; g = x; b = c; }
    else if (h < 5/6) { r = x; g = 0; b = c; }
    else { r = c; g = 0; b = x; }
    return [Math.round((r + m) * 255), Math.round((g + m) * 255), Math.round((b + m) * 255)];
}

function rgbToHex(r, g, b) {
    assert(r >= 0 && r <= 255, 'r must be 0-255');
    assert(b >= 0 && b <= 255, 'b must be 0-255');
    return '#' + [r, g, b].map(x => Math.round(Math.min(255, x)).toString(16).padStart(2, '0')).join('');
}

function brighten(hex, factor) {
    assert(typeof hex === 'string' && hex.startsWith('#'), 'hex must be a hex color string');
    assert(factor > 0, 'factor must be positive');
    const r = parseInt(hex.slice(1, 3), 16);
    const g = parseInt(hex.slice(3, 5), 16);
    const b = parseInt(hex.slice(5, 7), 16);
    return rgbToHex(r + (255 - r) * factor, g + (255 - g) * factor, b + (255 - b) * factor);
}

function showLoading(visible) {
    const overlay = document.getElementById('loading-overlay');
    if (overlay) overlay.style.display = visible ? 'flex' : 'none';
}

async function loadGraph(file) {
    showLoading(true);
    const sourcesFile = file.replace(/\/output\/graph\.json$/, '/input/sources.json');
    fetch(buildAppUrl(`/api/sources?file=${encodeURIComponent(sourcesFile)}`))
        .then(r => (r.ok ? r.json() : {}))
        .then(map => { window.sourcesMap = map || {}; })
        .catch(() => { window.sourcesMap = {}; });
    try {
        const response = await fetch(
            buildAppUrl(`/api/graph?file=${encodeURIComponent(file)}`)
        );
        if (!response.ok) {
            let message = 'Failed to load graph';
            try {
                const error = await response.json();
                message = error.detail || message;
            } catch (_) {
            }
            showError(message);
            return;
        }
        const data = await response.json();
        currentData = data;
        window.currentData = currentData;

        const typeCounts = data.nodes.reduce((acc, n) => {
            acc[n.type] = (acc[n.type] || 0) + 1;
            return acc;
        }, {});
        updateFilterOptions(typeCounts);
        updateLegend(typeCounts);

        const analysis = data.analysis || {};
        const maxConnectivity = Math.max(...Object.values(analysis).map(a => a.connectivity), 1);

        if (sigmaInstance) { sigmaInstance.kill(); sigmaInstance = null; }

        graphData = new Graph({ multi: true, type: 'directed' });

        data.nodes.forEach(node => {
            assert(node.id !== undefined, 'node must have an id');
            const rgb = getColorForType(node.type);
            const nodeAnalysis = analysis[node.id];
            const connectivity = nodeAnalysis?.connectivity || 0;
            const size = 4 + (connectivity / maxConnectivity) * 18;
            const color = rgbToHex(rgb[0], rgb[1], rgb[2]);
            graphData.addNode(node.id, {
                label: node.label || node.id,
                size,
                color,
                borderColor: brighten(color, 0.4),
                borderSize: 0.15,
                x: Math.random() * 1000 - 500,
                y: Math.random() * 1000 - 500,
            });
        });

        data.links.forEach(link => {
            assert(link.source !== undefined, 'link must have source');
            assert(link.target !== undefined, 'link must have target');
            if (!graphData.hasNode(link.source) || !graphData.hasNode(link.target)) return;
            try {
                graphData.addEdge(link.source, link.target, {
                    label: link.type || '',
                    type: 'curved',
                    color: 'rgba(99,102,241,0.35)',
                    size: 1.5,
                });
            } catch (_) { /* skip */ }
        });

        forceAtlas2.assign(graphData, {
            iterations: 300,
            settings: { ...forceAtlas2.inferSettings(graphData), gravity: 1, scalingRatio: 4, slowDown: 10 },
        });

        const container = document.getElementById('graph');
        assert(container !== null, 'graph container must exist');

        sigmaInstance = new Sigma(graphData, container, {
            renderEdgeLabels: true,
            defaultEdgeType: 'curved',
            defaultNodeType: 'bordered',
            edgeProgramClasses: { curved: EdgeCurveProgram },
            nodeProgramClasses: { bordered: NodeBorderProgram },
            labelFont: '"Inter", -apple-system, BlinkMacSystemFont, sans-serif',
            labelColor: { color: '#e2e8f0' },
            labelSize: 11,
            labelWeight: '500',
            labelRenderedSizeThreshold: 5,
            edgeLabelFont: '"Inter", -apple-system, sans-serif',
            edgeLabelColor: { color: '#818cf8' },
            edgeLabelSize: 8,
            zIndex: true,
            nodeReducer: (node, data) => {
                const res = { ...data };
                const isHovered = hoveredNode === node;
                const isHighlighted = highlightedNodes.size === 0 || highlightedNodes.has(node);
                if (!isHighlighted) {
                    return { ...res, color: '#0f172a', borderColor: '#1e293b', label: null, size: data.size * 0.4, zIndex: 0 };
                }
                if (isHovered) {
                    return { ...res, color: brighten(data.color, 0.5), borderColor: '#ffffff', size: data.size * 1.3, zIndex: 10 };
                }
                return { ...res, zIndex: 1 };
            },
            edgeReducer: (edge, data) => {
                const srcOrTgt = graphData.source(edge) === hoveredNode || graphData.target(edge) === hoveredNode;
                if (highlightedEdges.size > 0) {
                    if (!highlightedEdges.has(edge)) return { ...data, color: 'rgba(10,14,26,0.15)', label: null };
                    return { ...data, color: 'rgba(129,140,248,0.85)', size: 2.5, label: data.label };
                }
                if (srcOrTgt) return { ...data, color: 'rgba(129,140,248,0.7)', size: 2.5, label: data.label };
                return data;
            },
        });

        sigmaInstance.on('enterNode', ({ node }) => {
            hoveredNode = node;
            sigmaInstance.refresh();
            container.style.cursor = 'pointer';
        });
        sigmaInstance.on('leaveNode', () => {
            hoveredNode = null;
            sigmaInstance.refresh();
            container.style.cursor = 'default';
        });
        sigmaInstance.on('clickNode', ({ node }) => {
            const nodeIndex = currentData.nodes.findIndex(n => n.id === node);
            if (nodeIndex >= 0) { showDetailedInfo(nodeIndex); highlightNodeNeighborhood(node); }
        });
        sigmaInstance.on('clickStage', () => { clearHighlight(); });

        window.sigmaInstance = sigmaInstance;
        window.graph = sigmaInstance;
        window.setGraphHighlight = setGraphHighlight;
        setupSearch();
        updateInfo(data.nodes.length, data.links.length);
    } catch (error) {
        showError('Failed to load graph: ' + error.message);
    } finally {
        showLoading(false);
    }
}

function highlightNodeNeighborhood(nodeId) {
    assert(nodeId !== undefined, 'nodeId must be defined');
    assert(graphData !== null, 'graphData must be initialized');
    if (!sigmaInstance) return;
    highlightedNodes = new Set([nodeId]);
    highlightedEdges = new Set();
    graphData.forEachEdge((edge, _attrs, source, target) => {
        if (source === nodeId || target === nodeId) {
            highlightedEdges.add(edge);
            highlightedNodes.add(source);
            highlightedNodes.add(target);
        }
    });
    sigmaInstance.refresh();
}

function clearHighlight() {
    highlightedNodes = new Set();
    highlightedEdges = new Set();
    if (sigmaInstance) sigmaInstance.refresh();
}

function setGraphHighlight(nodeIds) {
    assert(Array.isArray(nodeIds), 'nodeIds must be an array');
    assert(nodeIds.length >= 0, 'nodeIds must have non-negative length');
    if (!sigmaInstance || !graphData) return;
    highlightedNodes = new Set(nodeIds);
    highlightedEdges = new Set();
    nodeIds.forEach(nodeId => {
        graphData.forEachEdge((edge, _attrs, source, target) => {
            if (source === nodeId || target === nodeId) {
                highlightedEdges.add(edge);
                highlightedNodes.add(source);
                highlightedNodes.add(target);
            }
        });
    });
    sigmaInstance.refresh();
}

function renderSourceBadges(rawSourceUrls) {
    if (!rawSourceUrls || typeof rawSourceUrls !== 'string') return '';
    const sourcesMap = window.sourcesMap || {};
    const seen = new Set();
    const entries = rawSourceUrls.split(',')
        .map(s => s.trim())
        .filter(Boolean)
        .filter(entry => { if (seen.has(entry)) return false; seen.add(entry); return true; });
    if (!entries.length) return '';
    const badgeStyle = 'display:inline-block;padding:1px 6px;border-radius:3px;font-size:0.7rem;font-weight:500;text-decoration:none;margin-right:4px';
    return entries.map(entry => {
        const webpageUrl = sourcesMap[entry]
            || sourcesMap[entry.split('/').pop()?.replace(/\.md$/, '')]
            || null;
        const s3Path = entry.startsWith('s3://') ? entry.replace(/^s3:\/\//, '') : null;
        const s3Badge = s3Path
            ? `<a href="/viewer/bucket/${s3Path}" target="_blank" style="${badgeStyle};background:#1e3a5f;color:#93c5fd">S3</a>`
            : `<span style="${badgeStyle};background:#1e293b;color:#94a3b8">${entry.split('/').pop()}</span>`;
        const govBadge = webpageUrl
            ? `<a href="${webpageUrl}" target="_blank" style="${badgeStyle};background:#14532d;color:#86efac">gov.uk</a>`
            : '';
        return `<span style="display:inline-flex;align-items:center;gap:2px;margin:2px 0">${s3Badge}${govBadge}</span>`;
    }).join('<br>');
}

function showDetailedInfo(index) {
    assert(typeof index === 'number', 'index must be a number');
    const panel = document.getElementById('details-panel');
    const content = document.getElementById('details-content');
    const graphEl = document.getElementById('graph');
    const node = currentData.nodes[index];
    if (!node) return;
    const analysis = currentData.analysis?.[node.id];
    const rgb = getColorForType(node.type);
    const typeColor = rgbToHex(rgb[0], rgb[1], rgb[2]);

    let html = `<h3 style="margin-bottom:0.5rem">${node.label || node.id}</h3>`;
    html += `<span class="type" style="background:${typeColor}22;color:${typeColor};border:1px solid ${typeColor}44">${node.type}</span>`;
    if (node.description) html += `<p style="margin-top:1rem;color:#cbd5e1;line-height:1.6">${node.description}</p>`;
    if (analysis) html += `<p style="margin-top:1rem;color:#64748b;font-size:0.8rem">${analysis.connectivity} connections · depth ${analysis.depth}</p>`;

    const excludeKeys = ['id', 'label', 'type', 'description'];
    const otherProps = Object.entries(node).filter(([key, value]) => !excludeKeys.includes(key) && value);
    if (otherProps.length > 0) {
        html += '<div style="margin-top:1.5rem"><h4 style="font-size:0.7rem;text-transform:uppercase;color:#64748b;margin-bottom:0.75rem;font-weight:600;letter-spacing:0.08em">Properties</h4>';
        otherProps.forEach(([key, value]) => {
            let parsed = value;
            if (typeof value === 'string') { try { parsed = JSON.parse(value); } catch {} }
            const label = key.replace(/([A-Z])/g, ' $1').replace(/^./, s => s.toUpperCase());
            if (Array.isArray(parsed) && parsed.length > 0) {
                html += `<div style="margin-bottom:0.75rem"><p style="color:#94a3b8;font-size:0.8rem;margin-bottom:0.25rem">${label}</p>`;
                const badgeStyle = 'display:inline-block;padding:1px 6px;border-radius:3px;font-size:0.65rem;font-weight:500;text-decoration:none;margin-left:4px';
                parsed.forEach(item => {
                    if (key === 'aliases' && typeof item === 'object' && item !== null && item.name) {
                        let badges = '';
                        if (item.source_files && item.source_files.length > 0) {
                            const sourcesMap = window.sourcesMap || {};
                            item.source_files.forEach(sf => {
                                const s3Path = sf.startsWith('s3://') ? sf.replace(/^s3:\/\//, '') : null;
                                const webUrl = sourcesMap[sf] || null;
                                if (s3Path) badges += `<a href="/viewer/bucket/${s3Path}" target="_blank" style="${badgeStyle};background:#1e3a5f;color:#93c5fd">S3</a>`;
                                if (webUrl) badges += `<a href="${webUrl}" target="_blank" style="${badgeStyle};background:#14532d;color:#86efac">gov.uk</a>`;
                            });
                        }
                        html += `<p style="color:#e4e4e7;font-size:0.8rem;padding-left:0.5rem">· ${item.name}${badges}</p>`;
                    } else {
                        html += `<p style="color:#e4e4e7;font-size:0.8rem;padding-left:0.5rem">· ${typeof item === 'object' ? JSON.stringify(item) : item}</p>`;
                    }
                });
                html += '</div>';
            } else if (typeof parsed === 'object' && parsed !== null) {
                html += `<div style="margin-bottom:0.75rem"><p style="color:#94a3b8;font-size:0.8rem;margin-bottom:0.25rem">${label}</p>`;
                Object.entries(parsed).forEach(([k, v]) => {
                    const pl = k.replace(/([A-Z])/g, ' $1').replace(/^./, s => s.toUpperCase());
                    if (k === 'sourceUrls' && typeof v === 'string') {
                        const badges = renderSourceBadges(v);
                        if (badges) {
                            html += `<div style="padding-left:0.5rem;margin-bottom:0.25rem"><p style="color:#94a3b8;font-size:0.75rem;margin-bottom:0.25rem">${pl}</p>${badges}</div>`;
                        }
                        return;
                    }
                    const isUrl = typeof v === 'string' && (v.startsWith('http') || v.startsWith('file://'));
                    const dv = isUrl ? `<a href="${v}" target="_blank" style="color:#60a5fa">${v}</a>` : v;
                    html += `<p style="color:#e4e4e7;font-size:0.8rem;padding-left:0.5rem">${pl}: ${dv}</p>`;
                });
                html += '</div>';
            } else if (parsed) {
                html += `<p style="margin-bottom:0.5rem"><span style="color:#94a3b8;font-size:0.8rem">${label}:</span> <span style="color:#e4e4e7;font-size:0.8rem">${parsed}</span></p>`;
            }
        });
        html += '</div>';
    }
    html += formatRelationships(node.id);
    content.innerHTML = html;
    panel.classList.add('open');
    graphEl.classList.add('with-panel');
    document.getElementById('controls').classList.add('with-panel');
}

function formatRelationships(nodeId) {
    assert(nodeId !== undefined, 'nodeId must be defined');
    if (!currentData?.links) return '';
    const outgoing = currentData.links.filter(l => l.source === nodeId);
    const incoming = currentData.links.filter(l => l.target === nodeId);
    if (outgoing.length === 0 && incoming.length === 0) return '';
    let html = '<div style="margin-top:1.5rem"><h4 style="font-size:0.7rem;text-transform:uppercase;color:#64748b;margin-bottom:0.75rem;font-weight:600;letter-spacing:0.08em">Relationships</h4>';
    outgoing.forEach(rel => { html += formatRelationship(rel, 'outgoing'); });
    incoming.forEach(rel => { html += formatRelationship(rel, 'incoming'); });
    html += '</div>';
    return html;
}

function formatRelationship(rel, direction) {
    assert(rel !== null && rel !== undefined, 'rel must be defined');
    assert(direction === 'outgoing' || direction === 'incoming', 'invalid direction');
    const other = currentData.nodes.find(n => n.id === (direction === 'outgoing' ? rel.target : rel.source));
    const otherLabel = other ? (other.label || other.id) : (direction === 'outgoing' ? rel.target : rel.source);
    const arrow = direction === 'outgoing' ? '→' : '←';
    let html = '<div style="margin-bottom:0.5rem;padding:0.5rem 0.75rem;background:rgba(99,102,241,0.08);border-radius:6px;border-left:2px solid rgba(99,102,241,0.5)">';
    html += `<p style="margin:0;font-size:0.8rem"><span style="color:#818cf8;font-weight:500">${rel.type}</span> <span style="color:#475569">${arrow}</span> <span style="color:#e2e8f0">${otherLabel}</span></p>`;
    let props = rel.properties;
    if (typeof props === 'string') { try { props = JSON.parse(props); } catch {} }
    if (props && typeof props === 'object' && Object.keys(props).length > 0) {
        html += '<div style="margin-top:0.4rem;padding-left:0.5rem">';
        Object.entries(props).forEach(([k, v]) => {
            const pl = k.replace(/([A-Z])/g, ' $1').replace(/^./, s => s.toUpperCase());
            if (k === 'sourceUrls' && typeof v === 'string') {
                const badges = renderSourceBadges(v);
                if (badges) {
                    html += `<div style="margin:0.2rem 0"><p style="font-size:0.75rem;color:#94a3b8;margin-bottom:0.15rem">${pl}</p>${badges}</div>`;
                }
                return;
            }
            html += `<p style="font-size:0.75rem;margin:0.2rem 0;color:#94a3b8">${pl}: ${v}</p>`;
        });
        html += '</div>';
    }
    html += '</div>';
    return html;
}

window.closeDetailsPanel = function() {
    document.getElementById('details-panel').classList.remove('open');
    document.getElementById('graph').classList.remove('with-panel');
    document.getElementById('controls').classList.remove('with-panel');
    clearHighlight();
};

function setupSearch() {
    assert(sigmaInstance !== null, 'sigmaInstance must be initialized');
    document.getElementById('search').addEventListener('input', (e) => {
        const query = e.target.value.toLowerCase().trim();
        if (!query) { clearHighlight(); return; }
        if (!currentData || !graphData) return;
        const matchingIds = new Set(
            currentData.nodes
                .filter(n => n.label?.toLowerCase().includes(query) || n.id?.toLowerCase().includes(query) || n.description?.toLowerCase().includes(query))
                .map(n => n.id)
        );
        if (matchingIds.size > 0) {
            highlightedNodes = matchingIds;
            highlightedEdges = new Set();
            sigmaInstance.refresh();
            if (matchingIds.size === 1) {
                const nodeId = [...matchingIds][0];
                const d = sigmaInstance.getNodeDisplayData(nodeId);
                if (d) sigmaInstance.getCamera().animate({ x: d.x, y: d.y, ratio: 0.3 }, { duration: 500 });
            }
        } else {
            clearHighlight();
        }
    });
}

function updateFilterOptions(typeCounts) {
    assert(typeCounts !== null && typeof typeCounts === 'object', 'typeCounts must be an object');
    const select = document.getElementById('filter');
    select.innerHTML = '<option value="">All types</option>';
    Object.entries(typeCounts).sort((a, b) => b[1] - a[1]).forEach(([type, count]) => {
        const opt = document.createElement('option');
        opt.value = type;
        opt.textContent = `${type} (${count})`;
        select.appendChild(opt);
    });
}

function updateLegend(typeCounts) {
    assert(typeCounts !== null && typeof typeCounts === 'object', 'typeCounts must be an object');
    const legend = document.getElementById('legend');
    if (!legend) return;
    const entries = Object.entries(typeCounts).sort((a, b) => b[1] - a[1]).slice(0, 8);
    legend.innerHTML = entries.map(([type]) => {
        const rgb = getColorForType(type);
        const color = rgbToHex(rgb[0], rgb[1], rgb[2]);
        return `<div class="legend-item"><span class="legend-dot" style="background:${color};box-shadow:0 0 6px ${color}88"></span><span class="legend-label">${type}</span></div>`;
    }).join('');
}

async function onDomainChange() {
    const select = document.getElementById('domain-select');
    assert(select !== null, 'domain-select element must exist');
    currentDomain = select.value;
    window.currentDomain = currentDomain;
    if (currentDomain) await loadGraph();
}

window.loadGraph = loadGraph;
window.onDomainChange = onDomainChange;
window.buildAppUrl = buildAppUrl;
window.applyFilter = function() {
    const filter = document.getElementById('filter').value;
    if (!sigmaInstance || !currentData || !graphData) return;
    if (!filter) { clearHighlight(); return; }
    highlightedNodes = new Set(currentData.nodes.filter(n => n.type === filter).map(n => n.id));
    highlightedEdges = new Set();
    sigmaInstance.refresh();
};

export { getColorForType };
