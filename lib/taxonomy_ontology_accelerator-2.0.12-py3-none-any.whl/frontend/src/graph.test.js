import { describe, it, expect, vi } from 'vitest';

vi.mock('sigma', () => ({ default: class Sigma { kill() {} on() {} refresh() {} getCamera() { return { animate() {} }; } getNodeDisplayData() { return null; } source() { return null; } target() { return null; } } }));
vi.mock('graphology', () => ({ default: class Graph { addNode() {} addEdge() {} hasNode() { return true; } forEachEdge() {} source() { return null; } target() { return null; } } }));
vi.mock('graphology-layout-forceatlas2', () => ({ default: { assign: vi.fn(), inferSettings: vi.fn(() => ({})) } }));
vi.mock('@sigma/edge-curve', () => ({ EdgeCurvedArrowProgram: class {} }));
vi.mock('@sigma/node-border', () => ({ NodeBorderProgram: class {} }));

import { getColorForType } from './graph.js';

describe('getColorForType', () => {
    it('returns default color for null', () => {
        const color = getColorForType(null);
        expect(color).toEqual([99, 102, 241]);
    });

    it('returns default color for undefined', () => {
        const color = getColorForType(undefined);
        expect(color).toEqual([99, 102, 241]);
    });

    it('returns default color for empty string', () => {
        const color = getColorForType('');
        expect(color).toEqual([99, 102, 241]);
    });

    it('returns deterministic color for same type', () => {
        const color1 = getColorForType('MedicalConcept');
        const color2 = getColorForType('MedicalConcept');
        expect(color1).toEqual(color2);
    });

    it('returns valid RGB values within 0-255 range', () => {
        const types = ['MedicalConcept', 'Location', 'Organization', 'Person', 'Event'];

        types.forEach(type => {
            const [r, g, b] = getColorForType(type);
            expect(r).toBeGreaterThanOrEqual(0);
            expect(r).toBeLessThanOrEqual(255);
            expect(g).toBeGreaterThanOrEqual(0);
            expect(g).toBeLessThanOrEqual(255);
            expect(b).toBeGreaterThanOrEqual(0);
            expect(b).toBeLessThanOrEqual(255);
        });
    });

    it('returns different colors for different types', () => {
        const color1 = getColorForType('MedicalConcept');
        const color2 = getColorForType('Location');
        expect(color1).not.toEqual(color2);
    });

    it('returns array of three numbers', () => {
        const color = getColorForType('TestType');
        expect(Array.isArray(color)).toBe(true);
        expect(color).toHaveLength(3);
        expect(typeof color[0]).toBe('number');
        expect(typeof color[1]).toBe('number');
        expect(typeof color[2]).toBe('number');
    });

    it('returns integer RGB values', () => {
        const [r, g, b] = getColorForType('TestType');
        expect(Number.isInteger(r)).toBe(true);
        expect(Number.isInteger(g)).toBe(true);
        expect(Number.isInteger(b)).toBe(true);
    });
});
